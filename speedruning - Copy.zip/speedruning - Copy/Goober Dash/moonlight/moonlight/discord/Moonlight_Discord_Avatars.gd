extends Reference
class_name Moonlight_DiscordAvatars

signal avatar_ready(uri, texture)
signal avatar_failed(uri)


var _cached_avatars: = {}


var _failed_avatars: = {}


var _retrieval_queue: = []
var _current_retrieval_uri: = ""
var _active_request: HTTPRequest


var _debug_log: = true

func retrieve_avatar(avatar_uri: String):
	if _debug_log:
		print("Moonlight_DiscordAvatars retrieve_avatar " + avatar_uri)
		
	if _cached_avatars.has(avatar_uri):
		emit_signal("avatar_ready", avatar_uri, _cached_avatars[avatar_uri])
	else:
		if not _failed_avatars.has(avatar_uri):
			_schedule_retrieval(avatar_uri)


func _schedule_retrieval(avatar_uri: String):
	if _debug_log:
		print("Moonlight_DiscordAvatars _schedule_retrieval " + avatar_uri)
	_retrieval_queue.push_back(avatar_uri)

func _kill_active_request():
	if _active_request:
		if _active_request.get_parent() != null:
			if _debug_log:
				print("Moonlight_DiscordAvatars _kill_active_request ")
			_active_request.get_parent().remove_child(_active_request)
			_active_request.queue_free()
			_active_request = null
	_current_retrieval_uri = ""

func pump_retrieval_queue():
	if _active_request != null:
		return

			
	if _retrieval_queue.size() == 0:
		return
			
	if _debug_log:
		print("Moonlight_DiscordAvatars pump_retrieval_queue has work ")
	
	var url: String = _retrieval_queue[0]
	_current_retrieval_uri = url
	_retrieval_queue.remove(0)
			
	_active_request = HTTPRequest.new()
	
	_active_request.timeout = 3
	_active_request.connect("request_completed", self, "_request_completed")
	var method = HTTPClient.METHOD_GET
	
	Moonlight.add_child(_active_request)
	
	var err: = _active_request.request(url, PoolStringArray(), true, method, "")

	if err != OK:
		if _debug_log:
			print("Moonlight_DiscordAvatars err")
		yield(_active_request.get_tree(), "idle_frame")
		_request_failed();
	else:
		if _debug_log:
			print("Moonlight_DiscordAvatars request started success")

	
	
func _request_failed():
	if _debug_log:
		print("Moonlight_DiscordAvatars _request_failed")
	emit_signal("avatar_failed", _current_retrieval_uri)
	_failed_avatars[_current_retrieval_uri] = true
	_kill_active_request()
	
	
func _request_completed(result: int, response_code: int, headers: PoolStringArray, body: PoolByteArray):
	if _debug_log:
		print("[Moonlight_DiscordAvatars] _request_completed")
		
	
	if response_code == 200:
		var image = Image.new()
		image.load_png_from_buffer(body)
		var itex = ImageTexture.new()
		itex.create_from_image(image, Texture.FLAG_MIPMAPS | Texture.FLAG_FILTER)
		_cached_avatars[_current_retrieval_uri] = itex
		emit_signal("avatar_ready", _current_retrieval_uri, itex)
	else:
		_request_failed()
		
	_kill_active_request()
