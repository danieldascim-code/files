extends Reference
class_name Moonlight_DiscordAPI

var _has_cached_is_in_discord: = false
var _cached_is_in_discord: = false
const enable_force_test: = false
var _cached_discord_instance_id: = ""
var _cached_discord_guild_id: = ""
var _cached_discord_channel_id: = ""
var _cached_discord_platform: = ""

var avatar_cache: Moonlight_DiscordAvatars

var display_name_cache: = {}
var avatar_user_id_cache: = {}

func cache_local_player_discord_data(storage: Moonlight_Storage):
	var user_id: String = storage.storage_get("account.user.id", "")
	var discord_data: Dictionary = storage.storage_get("player.discord", {})
	if not discord_data.empty():
		cache_player_discord_data(user_id, discord_data)

func cache_player_discord_data(user_id: String, discord_data: Dictionary):
	var display_name: String = discord_data.get("display_name", "")
	var avatar_url: String = discord_data.get("avatar_url", "")
	cache_player_data(user_id, display_name, avatar_url)

func cache_player_data(user_id: String, display_name: String, avatar_url: String):
	print("[Moonlight_DiscordAPI] cache_player_data() user_id: %s display_name: %s avatar: %s" % [user_id, display_name, avatar_url])
	display_name_cache[user_id] = display_name
	avatar_user_id_cache[user_id] = avatar_url

func _init():
	avatar_cache = Moonlight_DiscordAvatars.new()

func is_in_discord() -> bool:
	if not _has_cached_is_in_discord:
		_has_cached_is_in_discord = true
		_cached_is_in_discord = _compute_is_in_discord()
	return _cached_is_in_discord

func discord_platform() -> String:
	if not _has_cached_is_in_discord:
		is_in_discord()
	return _cached_discord_platform

func discord_platform_is_mobile() -> bool:
	return is_in_discord() and discord_platform() == "mobile"

func discord_instance_id() -> String:
	if not _has_cached_is_in_discord:
		is_in_discord()
	return _cached_discord_instance_id
	
func discord_guild_id() -> String:
	if not _has_cached_is_in_discord:
		is_in_discord()
	return _cached_discord_guild_id
	
func discord_channel_id() -> String:
	if not _has_cached_is_in_discord:
		is_in_discord()
	return _cached_discord_channel_id

func open_url(url: String):
	JavaScript.eval(\
	"\n\t\tdiscordOpenURL(\"" + url + \
	"\");\n\t")

func _compute_is_in_discord() -> bool:
	if OS.has_feature("editor") and enable_force_test:
		return true
	
	if not OS.has_feature("web"):
		return false
	var html_params: = HTMLRequestParams.get_request_params()
	_cached_discord_instance_id = html_params.get("instance_id", "")
	_cached_discord_guild_id = html_params.get("guild_id", "")
	_cached_discord_channel_id = html_params.get("channel_id", "")
	_cached_discord_platform = html_params.get("platform", "")
	return not _cached_discord_instance_id.empty()

func _discord_proxy_host() -> String:
	return GoodConfig.get_config_value("discord_proxy_host", "")

func proxy_url_gameserver_fallback_address(gameserver_fallback_address: String) -> String:
	
	
	
	var dot_index: = gameserver_fallback_address.find(".")
	assert (dot_index >= 0)
	var gameserver_prefix: = gameserver_fallback_address.substr(0, dot_index)
	
	var slash_index: = gameserver_fallback_address.find_last("/")
	var gameserver_path: = gameserver_fallback_address.substr(slash_index)
	
	var proxy_host: = _discord_proxy_host()
	var proxied_game_server_address: = gameserver_prefix + gameserver_path
	var proxied_url: = "%s/winterpixel/%s" % [proxy_host, proxied_game_server_address]
	print("[DiscordAPI] input gameserver fallback url: \'%s\' proxied fallback url: \'%s\'" % [gameserver_fallback_address, proxied_url])
	return proxied_url

func proxy_url_gameserver_port(gameserver_port: int) -> int:
	
	return 443
