extends Node

var sdk_handle = null
var _cb_commercial_break
var _cb_reward_break
var _cb_shareable_url

var _cached_base_url = ""

signal commercial_break_done(response)
signal rewarded_break_done(response)
signal shareable_url_ready(url)


func _ready():
	if OS.has_feature("JavaScript") == false:
		return
	if AdManager.get_ad_driver() != "poki":
		return
		
	sdk_handle = JavaScript.get_interface("PokiSDK")
	_cb_commercial_break = JavaScript.create_callback(self, "on_commercial_break")
	_cb_reward_break = JavaScript.create_callback(self, "on_reward_break")
	_cb_shareable_url = JavaScript.create_callback(self, "on_shareable_url")
	
	shareableURL({})

func baseShareableUrl():
	return _cached_base_url

func getURLParam(p):
	if not sdk_handle:
		printerr("poki getURLParam called but handle is null")
		return ""
	return sdk_handle.getURLParam(p)

func gameplayStart():
	if not sdk_handle:
		return
	sdk_handle.gameplayStart()
	
func gameplayStop():
	if not sdk_handle:
		return
	sdk_handle.gameplayStop()
	
func gameLoadingStart():
	if not sdk_handle:
		return
	sdk_handle.gameLoadingStart()
	
func gameLoadingFinished():
	if not sdk_handle:
		return
	sdk_handle.gameLoadingFinished()
	
func commercialBreak():
	if not sdk_handle:
		return
	sdk_handle.commercialBreak().then(_cb_commercial_break)
	
func on_commercial_break(args):
	print("Commercial break done!")
	emit_signal("commercial_break_done", args[0])

func rewardedBreak():
	if not sdk_handle:
		return
	sdk_handle.rewardedBreak().then(_cb_reward_break)
	
func on_reward_break(args):
	print("Reward break done!")
	emit_signal("rewarded_break_done", args[0])
	
func shareableURL(obj: Dictionary):
	if not sdk_handle:
		return
	var params = JavaScript.create_object("Object")
	
	for key in obj.keys():
		params[key] = obj[key]
	sdk_handle.shareableURL(params).then(_cb_shareable_url)

func on_shareable_url(url):
	if _cached_base_url == "":
		_cached_base_url = url[0]
	emit_signal("shareable_url_ready", url[0])
	
func isAdBlocked():
	if not sdk_handle:
		return false
	var ret = sdk_handle.isAdBlocked()
	return ret
	
func enableEventTracking():
	if not sdk_handle:
		return
	sdk_handle.enableEventTracking()
