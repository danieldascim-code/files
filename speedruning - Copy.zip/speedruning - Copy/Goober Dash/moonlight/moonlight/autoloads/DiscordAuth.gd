extends Node



signal on_discordAuthorize(data)
signal on_discordAuthenticated(data)
signal on_discordSkusLoaded(data)
signal on_discord_initialized()



signal discord_participants_changed(participants_array)

var interface: JavaScriptObject
var callbacks: = {}
var is_initialized: = false
var access_token: = ""

func _ready():
	print("DiscordAuth _ready")
	if Moonlight.discord_api.is_in_discord():
		print("[DiscordAuth] _setup()")
		interface = JavaScript.get_interface("discordCallbacks")
		register_callback("on_discordReady")
		register_callback("on_discordAuthorized")
		register_callback("on_discordAuthenticated")
		register_callback("on_discordParticipantsChanged")
		register_callback("on_purchaseCallback")
		register_callback("on_skusLoaded")

func register_callback(callback: String):
	assert (has_method(callback))
	if not has_method(callback):
		printerr("[DiscordAuth] register_callback() tried to register invalid callback: \'%s\'" % [callback])
		return
	var js_callback: = JavaScript.create_callback(self, callback)
	callbacks[callback] = js_callback
	interface.registerCallback(callback, js_callback)

func authorize_discord() -> Dictionary:
	var oauth_client_id: String = GoodConfig.get_config_value("discord_oauth_client_id", "")
	if not is_initialized:
		print("[DiscordAuth] initializing discord")
		JavaScript.eval("initializeDiscord(\'" + oauth_client_id + "\');")
		yield(self, "on_discord_initialized")
	print("[DiscordAuth] discord initialized. authorizing")
	JavaScript.eval("authorizeDiscord(\'" + oauth_client_id + "\');")
	var result: Dictionary = yield(self, "on_discordAuthorize")
	return result

func authenticate_discord(access_token: String) -> Dictionary:
	print("[DiscordAuth] authenticate_discord(%s)" % [access_token])
	JavaScript.eval("authenticateDiscord(\"" + access_token + "\");")
	var result: Dictionary = yield(self, "on_discordAuthenticated")
	return result

func on_purchaseCallback(args: Array) -> void :
	print("[DiscordAuth] on_purchaseCallback() %s" % [args])
	async_process_purchases()

func async_process_purchases() -> void :
	print("[DiscordAuth] async_process_purchases()")
	var process_purchases_result: Dictionary = yield(Moonlight.call_rpc("discord_shop_process_purchases", {}, true), "completed")
	print("[DiscordAuth] async_process_purchases() result: %s" % [process_purchases_result])
	if process_purchases_result.has("error"):
		pass
	return

func on_skusLoaded(args: Array) -> void :
	print("[DiscordAuth] on_skusLoaded() %s" % [args])
	var skus_json: String = args[0]
	var skus_data: Dictionary = parse_json(skus_json)
	emit_signal("on_discordSkusLoaded", skus_data)

func on_discordReady(args: Array):
	print("[DiscordAuth] on_discordReady()")
	if args.size() == 0:
		print("[DiscordAuth] on_discordReady() ERROR")
		get_tree().quit()
		return
	is_initialized = true
	emit_signal("on_discord_initialized")
	
func on_discordAuthorized(args: Array):
	print("[DiscordAuth] on_discordAuthorized() %s" % [args])
	
	if args.size() == 0:
		print("[DiscordAuth] on_discordAuthorized() error")
		emit_signal("on_discordAuthorize", {"error": "Discord authorization failed"})
		return
	
	var arg = args[0]
	if typeof(arg) != TYPE_STRING:
		print("[DiscordAuth] on_discordAuthorized() error")
		emit_signal("on_discordAuthorize", {"error": "Invalid first argument"})
		return
	
	var code = String(args[0])
	emit_signal("on_discordAuthorize", {"code": code})

func on_discordAuthenticated(args: Array):
	print("[DiscordAuth] on_discordAuthenticated()")
	if args.size() == 0:
		emit_signal("on_discordAuthenticated", {"error": "Discord authentication failed."})
		return
	emit_signal("on_discordAuthenticated", {})
	
func on_discordParticipantsChanged(args: Array):
	
	print("[DiscordAuth] on_discordParticipantsChanged(%s)" % [args])
	var participants_json: String = args[0]
	var participants_data: Dictionary = parse_json(participants_json)
	var participants: Array = participants_data["participants"]
	emit_signal("discord_participants_changed", participants)

func get_discord_participants():
	
	JavaScript.eval("discordGetParticipants();")




