extends Node

signal get_user_response(p_dict)
signal show_auth_prompt_response(p_dict)
signal show_account_link_response(p_dict)
signal get_user_token_response(p_dict)
signal get_crazygames_invite_link(p_dict)
signal get_crazygames_invite_button(p_dict)


var has_registered_auth_listener: bool = false
var is_available: bool = false
var is_logged_in: bool = false
var crazy_games_user: Dictionary = {}


var userAccountAvailableCB = null
var getUserCB = null
var authListenerCB = null
var showAuthPromptCB = null
var getUserTokenCB = null
var accountLinkPromptCB = null
var getInviteLinkCB = null
var getInviteButtonCB = null

func _ready():
	print("CrazyAuth _ready")
	
	if OS.has_feature("winterpixelads"):
		userAccountAvailableCB = JavaScript.create_callback(self, "on_crazygamesUserAccountAvailable")
		getUserCB = JavaScript.create_callback(self, "on_crazygamesGetUser")
		authListenerCB = JavaScript.create_callback(self, "on_crazygamesAuthListener")
		showAuthPromptCB = JavaScript.create_callback(self, "on_crazygamesShowAuthPrompt")
		getUserTokenCB = JavaScript.create_callback(self, "on_crazygamesGetUserToken")
		accountLinkPromptCB = JavaScript.create_callback(self, "on_crazygamesAccountLinkPrompt")
		getInviteLinkCB = JavaScript.create_callback(self, "on_crazygamesInviteLink")
		getInviteButtonCB = JavaScript.create_callback(self, "on_crazygamesInviteButton")
		
		var jsLib: = JavaScript.get_interface("winterpixelAdHandlers")
		jsLib.registerCrazygamesUserAccountAvailable(userAccountAvailableCB)
		jsLib.registerCrazygamesGetUser(getUserCB)
		jsLib.registerCrazygamesAuthListener(authListenerCB)
		jsLib.registerCrazygamesShowAuthPrompt(showAuthPromptCB)
		jsLib.registerCrazygamesGetUserToken(getUserTokenCB)
		jsLib.registerCrazygamesAccountLinkPrompt(accountLinkPromptCB)
		jsLib.registerCrazygamesInviteLink(getInviteLinkCB)
		jsLib.registerCrazygamesInviteButton(getInviteButtonCB)


	
	async_check_user_accounts_available()
	
func _process(delta: float) -> void :
	
	if Moonlight.is_logged_in() and not has_registered_auth_listener:
		auth_listener_init()
		
	
func supports_ads() -> bool:
	return OS.has_feature("winterpixelads")
	
func is_user_accounts_available():
	return is_available
	

func hide_invite_button():
	if supports_ads():
		JavaScript.eval(\
\
		"\n\t\t\twinterpixelCrazyHideInviteButton();\n\t\t")
	return self


func async_check_user_accounts_available():
	if supports_ads():
		JavaScript.eval(\
\
		"\n\t\t\twinterpixelCrazyUserAccountsAvailable();\n\t\t")
	return self
		
func async_get_user():
	if supports_ads():
		JavaScript.eval(\
\
		"\n\t\t\twinterpixelCrazyGetUser();\n\t\t")
	return self
	
func async_show_auth_prompt():
	if supports_ads():
		JavaScript.eval(\
\
		"\n\t\t\twinterpixelCrazyShowAuthPrompt();\n\t\t")
	return self
	
func async_get_user_token():
	if supports_ads():
		JavaScript.eval(\
\
		"\n\t\t\twinterpixelCrazyGetUserToken();\n\t\t")
	return self
	
func async_get_invite_link(invite_dict: Dictionary):
	if supports_ads():
		var jsonString = to_json(invite_dict)
		JavaScript.eval(\
		"\n\t\t\twinterpixelCrazyGetInviteLink(\'" + jsonString + \
		"\');\n\t\t")
	return self
	
func async_get_invite_button(invite_dict: Dictionary):
	if supports_ads():
		var jsonString = to_json(invite_dict)
		JavaScript.eval(\
		"\n\t\t\twinterpixelCrazyGetInviteButton(\'" + jsonString + \
		"\');\n\t\t")
	return self
	
func async_show_account_link_prompt():
	if supports_ads():
		JavaScript.eval(\
\
		"\n\t\t\twinterpixelCrazyAccountLinkPrompt();\n\t\t")
	return self

func auth_listener_init():
	if not has_registered_auth_listener:
		has_registered_auth_listener = true
		if supports_ads():
			JavaScript.eval(\
\
			"\n\t\t\t\twinterpixelCrazyAccountInit();\n\t\t\t")
			
	return self



func on_crazygamesUserAccountAvailable(args: Array):
	print("[CrazyAuth] crazygamesUserAccountAvailable args length: " + str(args.size()))
	if args.size() > 0:
		var avail = bool(args[0])
		is_available = avail

func on_crazygamesGetUser(args: Array):
	print("[CrazyAuth] crazygamesGetUser args length: " + str(args.size()))
	if args.size() > 0:
		var arg = args[0]
		if typeof(arg) == TYPE_STRING:
			var user = String(args[0])
			var json: = JSON.parse(user)
			if json.error != OK or typeof(json.result) != TYPE_DICTIONARY:
				printerr("Unable to parse response: %s" % user)
				is_logged_in = false
				crazy_games_user = {}
				emit_signal("get_user_response", {"error": "Unable to parse response: %s" % user})
				return
			var dict: Dictionary = json.result
			is_logged_in = true
			crazy_games_user = dict
			print(crazy_games_user)
			emit_signal("get_user_response", {"user": crazy_games_user})
			return
		
	
	print("Unable crazygamesGetUser no user")
	is_logged_in = false
	crazy_games_user = {}
	emit_signal("get_user_response", {"error": "No user"})
	return
	
func on_crazygamesAuthListener(args: Array):
	print("[CrazyAuth] on_crazygamesAuthListener args length: " + str(args.size()))
	
	
	
	
	
	return
	
func on_crazygamesShowAuthPrompt(args: Array):
	print("[CrazyAuth] on_crazygamesShowAuthPrompt args length: " + str(args.size()))
	if args.size() > 0:
		var arg = args[0]
		if typeof(arg) == TYPE_STRING:
			var user = String(args[0])
			var json: = JSON.parse(user)
			if json.error != OK or typeof(json.result) != TYPE_DICTIONARY:
				printerr("Unable to parse response: %s" % user)
				is_logged_in = false
				crazy_games_user = {}
				emit_signal("show_auth_prompt_response", {"error": "Unable to parse response: %s" % user})
				return
			var dict: Dictionary = json.result
			is_logged_in = true
			crazy_games_user = dict
			print(crazy_games_user)
			emit_signal("show_auth_prompt_response", {"user": crazy_games_user})
			return
		elif typeof(arg) == TYPE_REAL:
			var err: float = args[0]
			print("show_auth_prompt_response error %f" % err)
			if err == 2.0:
				
				emit_signal("show_auth_prompt_response", {"error": "Already signed in"})
				return
			elif err == 3.0:
				
				emit_signal("show_auth_prompt_response", {"error": "Auth in progress"})
				return
			elif err == 4.0:
				
				is_logged_in = false
				crazy_games_user = {}
				emit_signal("show_auth_prompt_response", {"error": "User cancelled"})
				return
			else:
				printerr("show_auth_prompt_response Should not get here")
				
				emit_signal("show_auth_prompt_response", {"error": "Unknown value"})
				return

	
	print("Unable on_crazygamesShowAuthPrompt no new auth")
	emit_signal("show_auth_prompt_response", {"error": "No auth"})
	return

func on_crazygamesGetUserToken(args: Array):
	print("[CrazyAuth] crazygamesGetUserToken args length: " + str(args.size()))
	if args.size() > 0:
		var arg = args[0]
		if typeof(arg) == TYPE_STRING:
			var token = String(args[0])
			print("token" + token)
			emit_signal("get_user_token_response", {"token": token})
			return
		
	
	print("on_crazygamesGetUserToken error")
	emit_signal("get_user_token_response", {"error": "User token error"})
	return
	
	
func on_crazygamesAccountLinkPrompt(args: Array):
	print("[CrazyAuth] crazygamesAccountLinkPrompt args length: " + str(args.size()))
	if args.size() > 0:
		var arg = args[0]
		if typeof(arg) == TYPE_STRING:
			var response = String(args[0])
			var json: = JSON.parse(response)
			if json.error != OK or typeof(json.result) != TYPE_DICTIONARY:
				printerr("Unable to parse response: %s" % response)
				emit_signal("show_account_link_response", {"error": "Unable to parse response: %s" % response})
				return
			var dict: Dictionary = json.result
			print(dict)
			
			emit_signal("show_account_link_response", dict)
			return
		elif typeof(arg) == TYPE_REAL:
			var err: float = args[0]
			print("show_account_link_response error %f" % err)
			if err == 2.0:
				
				emit_signal("show_account_link_response", {"error": "Must be signed in on crazygames to link an account!"})
				return
			elif err == 3.0:
				
				emit_signal("show_account_link_response", {"error": "Account link in progress!"})
				return
			else:
				printerr("show_account_link_response Should not get here")
				
				emit_signal("show_account_link_response", {"error": "Unknown value."})
				return

	
	print("Unable on_crazygamesAccountLinkPrompt ")
	emit_signal("show_account_link_response", {"error": "Unknown error."})
	return

func on_crazygamesInviteLink(args: Array):
	print("[CrazyAuth] on_crazygamesInviteLink args length: " + str(args.size()))
	if args.size() > 0:
		var arg = args[0]
		if typeof(arg) == TYPE_STRING:
			var link = String(args[0])
			print("link: " + link)
			emit_signal("get_crazygames_invite_link", {"link": link})
			return
		
	
	print("on_crazygamesInviteLink error")
	emit_signal("get_crazygames_invite_link", {"error": "Get invite link error"})
	return

func on_crazygamesInviteButton(args: Array):
	print("[CrazyAuth] on_crazygamesInviteButton args length: " + str(args.size()))
	if args.size() > 0:
		var arg = args[0]
		if typeof(arg) == TYPE_STRING:
			var link = String(args[0])
			print("link: " + link)
			emit_signal("get_crazygames_invite_button", {"link": link})
			return
		
	
	print("on_crazygamesInviteButton error")
	emit_signal("get_crazygames_invite_button", {"error": "Get invite button error"})
	return
