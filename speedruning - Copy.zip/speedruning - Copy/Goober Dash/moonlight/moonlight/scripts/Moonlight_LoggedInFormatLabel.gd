extends Label

export  var logged_in_string: = "logged in as: <username>"
export  var logged_out_string: = "not logged in"

func _ready():
	Moonlight.connect("on_authentication_succeeded", self, "update_label")
	Moonlight.connect("on_log_out", self, "update_label")
	update_label()

func update_label():
	if Moonlight.is_logged_in():
		self.text = logged_in_string_formatted()
	else:
		self.text = logged_out_string

func logged_in_string_formatted() -> String:
	return logged_in_string.replace("<username>", Moonlight.session.username)
