extends Label

func _ready():
	Moonlight.storage.observe("account.user.display_name", self, "on_data_changed")
	update_label()

func on_data_changed(diff: Moonlight_StorageDiff):
	update_label()

func update_label():
	text = Moonlight.storage.storage_get("account.user.display_name", "")
