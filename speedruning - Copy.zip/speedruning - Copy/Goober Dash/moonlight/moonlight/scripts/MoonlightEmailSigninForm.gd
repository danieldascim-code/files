extends Control
class_name MoonlightEmailSigninForm

signal error_message
signal login_succeeded
signal login_request_sent
signal login_request_finished
signal signup_pressed
signal back_pressed

export (NodePath) var _email_label
export (NodePath) var _password_label
export (NodePath) var _password_container
export (NodePath) var _message_label
export (NodePath) var _login_button
export (NodePath) var _back_button
export (NodePath) var _spinner
export (NodePath) var _forgot_password_button

export (bool) var clear_form_on_entry: = true

onready var email_label: = get_node(_email_label) as LineEdit
onready var password_label: = get_node(_password_label) as LineEdit
onready var password_container: = get_node(_password_container) as Control
onready var message_label: = get_node(_message_label) as Label
onready var login_button: = get_node(_login_button) as Button
onready var back_button: = get_node(_back_button) as Button
onready var spinner: = get_node(_spinner) as Control
onready var forgot_password_button: = get_node(_forgot_password_button) as Button

onready var header_label: = $HeaderLabel as SDFLabel

func _ready():
	login_button.connect("pressed", self, "on_login_pressed")
	email_label.connect("text_entered", self, "on_login_pressed_arg")
	login_button.connect("visibility_changed", self, "do_clear_form_on_entry")
	password_label.connect("text_entered", self, "on_auth_pressed_arg")
	back_button.connect("pressed", self, "emit_signal", ["back_pressed"])
	forgot_password_button.connect("pressed", self, "on_forgot_password_pressed")
	Moonlight.connect("on_socket_message_parsed", self, "on_socket_message_parsed")
	spinner.visible = false
	forgot_password_button.visible = false
	message_label.text = ""
	email_label.visible = true
	password_container.visible = false
	
func on_forgot_password_pressed():
	var email = email_label.text.to_lower()
	var payload: = {"email": email, "platform": "winterpixel"}
	if AdManager.get_ad_driver() == "crazygames":
		payload["platform"] = "crazygames"
	if AdManager.get_ad_driver() == "poki":
		payload["platform"] = "poki"
	hide_forgot_password()
	clear_error_message()
	show_spinner()
	var rpc_result: Dictionary = yield(Moonlight.call_rpc("forgot_password_email", payload), "completed")
	hide_spinner()
	if rpc_result.has("error"):
		send_error_message(rpc_result.get("error", ""))
	else:
		message_label.text = "Please check your email to verify an account password reset"
		email_label.visible = false
		
		

func show_forgot_password(string: String = ""):
	if string.empty():
		message_label.text = "INCORRECT PASSWORD"
	else:
		message_label.text = string
	forgot_password_button.visible = true

func hide_forgot_password():
	forgot_password_button.visible = false
	
func on_socket_message_parsed(nakama_notification: NakamaAPI.ApiNotification, content_json: Dictionary):
	if nakama_notification.subject == "EMAIL_VERIFIED":

		emit_signal("login_succeeded")
		Moonlight.socket.close()
		get_tree().change_scene(GoodSceneRegistry.connecting_scene)

func clear():
	email_label.text = ""
	password_label.text = ""
	clear_error_message()
	enable_buttons(true)
	
	password_container.visible = false
	spinner.visible = false
	message_label.text = "Sign In or Sign Up!"

func on_login_pressed_arg(_argument):
	on_login_pressed()

func on_auth_pressed_arg(_argument):
	on_auth_pressed()
	
func on_auth_pressed():
	hide_forgot_password()
	clear_error_message()
	show_spinner()
	var email = email_label.text.to_lower()
	var password = password_label.text
	
	var payload: = {"email": email, "password": password}
	var rpc_result: Dictionary = yield(Moonlight.call_rpc("email_auth", payload), "completed")
	hide_spinner()
	if rpc_result.has("error"):
		var err_string: String = rpc_result.get("error", "")
		if err_string.count(" Invalid credentials") > 0:
			
			show_forgot_password()
		else:
			hide_forgot_password()
			send_error_message(rpc_result.get("error", ""))
	else:
		var uuid: String = rpc_result.get("uuid", "")
		var customid: String = rpc_result.get("customid", "")
		var custom_email_device_id: String = rpc_result.get("customemaildeviceid", "")
		
		emit_signal("login_succeeded")
		Moonlight.auth.log_out()
		print("[MoonlightEmailSigninForm] login succeeded. got email_device_id: %s" % [ not custom_email_device_id.empty()])
		if not custom_email_device_id.empty():
			Moonlight.saved_data.set_email_device_id_credentials(custom_email_device_id)
		else:
			Moonlight.saved_data.set_email_credentials(email, password)
		get_tree().change_scene(GoodSceneRegistry.connecting_scene)


func on_login_pressed():
	var email = email_label.text.to_lower()
	var password = password_label.text
	
	clear_error_message()
	
	if email.empty():
		send_error_message("Email is required.")
		return
	
	emit_signal("login_request_sent")
	enable_buttons(false)
	var client_version: = Moonlight.get_client_version()
	clear_error_message()
	show_spinner()
	hide_forgot_password()
	
	
	var new_session = yield(Moonlight.client.authenticate_email_async(email, "definitely a wrong password here", null, false, {"client_version": client_version}), "completed")
	hide_spinner()
	enable_buttons(true)
	emit_signal("login_request_finished")
	
	if new_session.is_exception():
		
		
		
		
		
		if (new_session.exception.status_code == 401):
			email_label.visible = false
			password_container.visible = true
			message_label.text = ""
			login_button.disconnect("pressed", self, "on_login_pressed")
			login_button.connect("pressed", self, "on_auth_pressed")
			show_forgot_password("FORGOT PASSWORD?")
			return
		elif (new_session.exception.status_code == 400):
			send_error_message(new_session.exception.message)
		elif (new_session.exception.status_code == 404):
			show_spinner()
			var payload: = {"email": email, "platform": "winterpixel"}
			if AdManager.get_ad_driver() == "crazygames":
				payload["platform"] = "crazygames"
			if AdManager.get_ad_driver() == "poki":
				payload["platform"] = "poki"
			var rpc_result: Dictionary = yield(Moonlight.call_rpc("request_email_signup", payload), "completed")
			hide_spinner()
			if rpc_result.has("error"):
				send_error_message(rpc_result.get("error", ""))
				login_button.disabled = true
			else:
				message_label.text = "Please check your email to verify this account.\n\nThen use the password provided to sign in!"
				email_label.visible = false
				password_container.visible = true
				login_button.disconnect("pressed", self, "on_login_pressed")
				login_button.connect("pressed", self, "on_auth_pressed")
				pass
			
		
		
	elif not new_session.is_valid():
		send_error_message("Login failed.")
	else:
		emit_signal("login_succeeded")
		Moonlight.auth.log_out()
		Moonlight.saved_data.set_email_credentials(email, password)
		get_tree().change_scene(GoodSceneRegistry.connecting_scene)

func show_spinner():
	spinner.visible = true

func hide_spinner():
	spinner.visible = false
	
func clear_error_message():
	if message_label != null:
		message_label.text = ""

func send_error_message(msg: String):
	if message_label != null:
		message_label.text = msg
	emit_signal("error_message", msg)

func enable_buttons(enabled: bool):
	login_button.disabled = not enabled

func do_clear_form_on_entry():
	if clear_form_on_entry and login_button.is_visible_in_tree():
		clear()
	
func _process(delta):
	if email_label.visible:
		header_label.text = "EMAIL"
	else:
		header_label.text = "PASSWORD"
	if password_container.visible:
		login_button.label_text = "SIGN IN"
	else:
		login_button.label_text = "NEXT"
