extends Reference
class_name Moonlight_Friends

signal query_friends_successful
signal query_friends_error
signal local_friend_code_changed

signal friend_status_changed(user_id, online, status)
signal send_friend_request_complete(friend_code, user_id, response)

enum FriendRequestResponse{
	Success, 
	FriendCodeNotFound, 
	Failed, 
}

enum FriendState{
	Friends = 0
	Sent = 1
	Invited = 2
	Banned = 3
}

var local_friend_code: = ""
var friend_list_unfiltered: = []
var friend_user_ids: = []
var friend_statuses: = {}
var enable_friend_presence: = false

func _init(socket: NakamaSocket):

	Moonlight.connect("on_friend_accepted", self, "on_friend_accepted")
	Moonlight.connect("on_friend_request", self, "on_friend_request")
	Moonlight.connect("on_authentication_succeeded", self, "query_friends_list")
	Moonlight.socket.connect("received_status_presence", self, "on_socket_received_status_presence")
	
	query_friends_list()
	refresh_local_friend_code()

func on_account_metadata_changed(metadata_key: String):
	if metadata_key == "friend_code":
		refresh_local_friend_code()

func refresh_local_friend_code():
	
	var friend_code: = "TODO"
	local_friend_code = friend_code
	emit_signal("local_friend_code_changed")

func on_socket_received_status_presence(status_presence: NakamaRTAPI.StatusPresenceEvent):
	var offline: = {}
	for u in status_presence.leaves:
		var user_presence: = u as NakamaRTAPI.UserPresence
		offline[user_presence.user_id] = true
	
	for u in status_presence.joins:
		var user_presence: = u as NakamaRTAPI.UserPresence
		friend_statuses[user_presence.user_id] = user_presence.status
		offline.erase(user_presence.user_id)
		emit_signal("friend_status_changed", user_presence.user_id, true, user_presence.status)
	
	for user_id in offline:
		friend_statuses.erase(user_id)
		emit_signal("friend_status_changed", user_id, false, "")

func on_friend_accepted(username: String):
	query_friends_list()

func on_friend_request(username: String):
	query_friends_list()

func query_friends_list():
	var updated_friend_list: = []
	friend_list_unfiltered.clear()
	if Moonlight.is_logged_in() and not Moonlight.auth.is_guest_account():
		if Moonlight.is_logged_in():
			
			enable_friend_presence = true
		
		
		var friend_list_page: NakamaAPI.ApiFriendList = yield(Moonlight.client.list_friends_async(Moonlight.session), "completed")
		if friend_list_page.is_exception():
			printerr("[Moonlight_Friends] An error occured: %s" % friend_list_page)
			emit_signal("query_friends_error")
			return
		updated_friend_list.append_array(friend_list_page.friends)
		
		friend_list_unfiltered = updated_friend_list
		
		var updated_friend_user_ids: = []
		for f in friend_list_unfiltered:
			var friend: = f as NakamaAPI.ApiFriend
			match friend.state:
				FriendState.Friends:
					updated_friend_user_ids.append(friend.user.id)
				_:
					pass
		friend_user_ids = updated_friend_user_ids
		
		print("[Moonlight_Friends] found %s friends" % [friend_list_page.friends.size()])
		emit_signal("query_friends_successful")
		
		if enable_friend_presence:
			print(friend_user_ids)
			var status: = yield(Moonlight.socket.follow_users_async(PoolStringArray(friend_user_ids)), "completed") as NakamaRTAPI.Status
			print(status)
	else:
		emit_signal("query_friends_error")

func delete_friend(user_id: String):
	var response: = yield(Moonlight.client.delete_friends_async(Moonlight.session, [user_id]), "completed") as NakamaAsyncResult
	if response.is_exception():
		printerr("[UIFriendsPanel] delete_friend() error: %s" % [response])
		return false
	query_friends_list()
	return true

func add_friend(user_id: String):
	var response: = yield(Moonlight.client.add_friends_async(Moonlight.session, [user_id]), "completed") as NakamaAsyncResult
	if response.is_exception():
		printerr("[UIFriendsPanel] add_friend() error: %s" % [response])
		return false
	query_friends_list()
	return true

func send_friend_request(friend_code: String):
	if friend_code.empty():
		
		emit_signal("send_friend_request_complete", friend_code, "", FriendRequestResponse.FriendCodeNotFound)
		return
	
	var payload: = {"friend_code": friend_code}
	var response: = yield(Moonlight.client.rpc_async(Moonlight.session, "winterpixel_query_user_id_for_friend_code", to_json(payload)), "completed") as NakamaAPI.ApiRpc
	
	if response.is_exception():
		printerr("[UIFriendsPanel] send_friend_request() friend_code error: %s" % [response])
		emit_signal("send_friend_request_complete", friend_code, "", FriendRequestResponse.FriendCodeNotFound)
		return
	
	var response_data = parse_json(response.payload)
	if not (response_data is Dictionary and response_data.has("user_id")):
		emit_signal("send_friend_request_complete", friend_code, "", FriendRequestResponse.FriendCodeNotFound)
		return
	
	var friend_user_id: = response_data["user_id"] as String
	var success: = yield(Moonlight.friends.add_friend(friend_user_id), "completed") as bool
	if success:
		emit_signal("send_friend_request_complete", friend_code, friend_user_id, FriendRequestResponse.Success)
	else:
		emit_signal("send_friend_request_complete", friend_code, friend_user_id, FriendRequestResponse.Failed)
	
	
	
	query_friends_list()
