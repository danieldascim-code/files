extends Reference
class_name Moonlight_Seasons

signal season_rollover()

var season_number: int
var season_start: int
var season_end: int
var season_seconds_left: int
var season_duration: int
var last_season_number: int

var season_definitions: = []

func _parse_seasons(storage: Moonlight_Storage):
	var stored_season_definitions: Array = storage.storage_get("metadata.seasons.season_templates", [])
	season_definitions = stored_season_definitions.duplicate(true)
	
	
	_calculate_current_season_info()

func update(delta: float):
	if not season_definitions.empty():
		_calculate_current_season_info()

func _calculate_current_season_info():
	var now: = OS.get_unix_time()
	var current_season_definition: = compute_current_season_definition(now)
	if not current_season_definition.empty():
		var start_number: int = int(current_season_definition["start_number"])
		var start_time: int = int(current_season_definition["start_time"])
		season_duration = int(current_season_definition["duration"])
		season_number = start_number + ((now - start_time) / season_duration)
		season_start = start_time + season_duration * (season_number - start_number)
		season_end = season_start + season_duration
		season_seconds_left = season_end - now
		if last_season_number != season_number:
			emit_signal("season_rollover")
		last_season_number = season_number

func compute_current_season_definition(time: int) -> Dictionary:
	var current_season_definition: Dictionary = {}
	var current_season_start_timestamp: int = 0
	for s in season_definitions:
		var season_definition: Dictionary = s
		var season_start_timestamp: int = season_definition["start_time"]
		if season_start_timestamp > current_season_start_timestamp:
			if time >= season_start_timestamp:
				current_season_definition = season_definition
				current_season_start_timestamp = season_start_timestamp
	return current_season_definition
