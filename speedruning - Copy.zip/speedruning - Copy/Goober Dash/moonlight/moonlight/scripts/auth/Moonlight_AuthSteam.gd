extends Moonlight_AuthBase


var app_id: = - 1

var ticket_id: = Steam.AUTH_TICKET_INVALID


func _init():
	app_id = GoodConfig.get_config_value("steam_app_id")
	print("[Moonlight_AuthSteam] _init() steam_app_id: " + str(app_id))

	
	print("[Moonlight_AuthSteam] calling steamInit()")
	var init: = Steam.steamInit(false)
	if init["status"] != 1:
		OS.alert(init["verbal"] + " (%s)" % init["status"])
		Moonlight.get_tree().quit()
	
	if Steam.restartAppIfNecessary(app_id):
		print("[Moonlight_AuthSteam] steam requested restart. see you soon!")
		Moonlight.get_tree().quit()
	



	
	Moonlight.get_tree().connect("idle_frame", Steam, "run_callbacks")
	Moonlight.connect("tree_exiting", self, "_cancel_ticket")
	
	Steam.connect("steam_shutdown", Moonlight.get_tree(), "quit")


func authenticate(signal_on_success: = true) -> void :
	if not ._check_can_auth():
		return
	
	is_attempting_authentication = true
	var session: NakamaSession = null
	
	
	
	if Moonlight.saved_data.has_email_credentials():
		
		var result = _auth_email()
		if result is GDScriptFunctionState:
			result = yield(result, "completed")
		session = result
	elif Moonlight.saved_data.has_email_device_id_credentials():
		var result = _auth_email_device_id()
		if result is GDScriptFunctionState:
			result = yield(result, "completed")
		session = result
	else:
		
		var result = _auth_steam()
		if result is GDScriptFunctionState:
			result = yield(result, "completed")
		session = result
	
	Moonlight.session = session
	
	
	if ._check_session_valid(session):
		if not yield(_post_auth(), "completed"):
			Moonlight.session = null
			session = null
	
	is_attempting_authentication = false
	
	if ._check_session_valid(session):
		last_authentication_time = OS.get_unix_time()
		if signal_on_success:
			Moonlight.emit_signal("on_authentication_succeeded")

func log_out() -> void :
	_cancel_ticket()
	.log_out()

func is_platform_auth_supported() -> bool:
	return true

func is_account_linked_to_platform() -> bool:
	return is_logged_in() and not Moonlight.local_account.user.steam_id.empty()

func is_account_linked_to_email() -> bool:
	return .is_account_linked_to_email()

func _get_auth_ticket(timeout_seconds: = 5.0) -> String:
	var auth_ticket_data: = Steam.getAuthSessionTicket()
	
	var timeout: = Moonlight.get_tree().create_timer(timeout_seconds)
	timeout.connect("timeout", Steam, "emit_signal", ["get_auth_session_ticket_response", 0, Steam.RESULT_TIMEOUT])
	var response: = yield(Steam, "get_auth_session_ticket_response") as Array
	timeout.disconnect("timeout", Steam, "emit_signal")
	
	ticket_id = response[0] as int
	var result: = response[1] as int
	if result != Steam.RESULT_OK:
		printerr("[Moonlight_AuthSteam] failed to communicate our session ticket with Steam server (result code %s)" % result)
		return ""
	
	
	var auth_ticket_string: = ""
	for i in auth_ticket_data["size"] as int:
		auth_ticket_string += "%02x" % auth_ticket_data["buffer"][i]
	
	return auth_ticket_string

func _cancel_ticket():
	if ticket_id != Steam.AUTH_TICKET_INVALID:
		print("[Moonlight_AuthSteam] _cancel_ticket")
		Steam.cancelAuthTicket(ticket_id)
		ticket_id = Steam.AUTH_TICKET_INVALID

func _auth_failed():
	is_attempting_authentication = false
	_cancel_ticket()

func _auth_steam() -> NakamaSession:
	if not Steam.isSteamRunning():
		printerr("[Moonlight_AuthSteam] steam not initialized")
		return null
	
	
	print("[Moonlight_AuthSteam] acquiring steam session ticket...")

	var auth_ticket_string: = yield(_get_auth_ticket(), "completed") as String
	if auth_ticket_string.empty():
		_auth_failed()
		return null
	
	
	print("[Moonlight_AuthSteam] authenticating with nakama...")
	var client_version: = Moonlight.get_client_version()
	var persona_name: = Steam.getPersonaName()
	var session: NakamaSession = yield(
		Moonlight.client.authenticate_steam_async(
			auth_ticket_string, 
			null, 
			true, 
			{
				"client_version": client_version, 
				"platform": OS.get_name(), 
				"persona_name": persona_name
			}), 
		"completed"
	)
	
	
	if session.is_exception():
		printerr("[Moonlight_AuthSteam] exception trying to auth with steam: %s " % str(session.exception))
		_auth_failed()
		return session
	elif not session.is_valid():
		printerr("[Moonlight_AuthSteam] failed to auth with steam: %s " % str(session))
		_auth_failed()
		return session
	
	print("[Moonlight_AuthSteam] nakama auth with steam succeeded.")
	
	return session
