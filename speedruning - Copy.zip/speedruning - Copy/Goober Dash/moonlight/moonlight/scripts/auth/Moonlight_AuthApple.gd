extends Moonlight_AuthBase
class_name Moonlight_AuthApple

var apple_sign_in: AppleSignin

signal success
signal error

func success(dict: Dictionary):
	emit_signal("success", dict)
	
func error(string: String):
	emit_signal("error", string)

func _init():
	print("[Moonlight_AuthApple] _init()")
	apple_sign_in = AppleSignin.new()

func signup_apple() -> void :
	print("Moonlight_AuthApple auth_apple")
	print(apple_sign_in)
	if ( not apple_sign_in.is_connected("signin_success", self, "success")):
		apple_sign_in.connect("signin_success", self, "success")
	if ( not apple_sign_in.is_connected("signin_failed", self, "error")):
		apple_sign_in.connect("signin_failed", self, "error")
	apple_sign_in.signin_with_apple()
	

func _auth_apple() -> NakamaSession:
	
	assert (Moonlight.saved_data.has_apple_auth_credentials())
	var token: = Moonlight.saved_data.apple_auth_token()
	
	
	var client_version: = Moonlight.get_client_version()
	var session: NakamaSession = yield(Moonlight.client.authenticate_apple_async(token, null, false, {"client_version": client_version, "platform": OS.get_name()}), "completed")
	
	
	if session.is_exception():
		print("[Moonlight_AuthApple] apple auth status" + str(session.exception))
		if session.exception.status_code == 401 or session.exception.status_code == 404:
			print("[Moonlight_AuthApple] apple auth credentials invalid. clearing saved credentials.")
			Moonlight.saved_data.clear_apple_auth_credentials()
			Moonlight.saved_data.clear_custom_uuid()
		else:
			printerr("[Moonlight_AuthApple] exception trying to log in with apple auth: %s" % str(session.exception))
		
		emit_signal("error", "Signin with apple failed, please try again or log into an existing account")
		return session
	elif not session.is_valid():
		printerr("[Moonlight_AuthApple] failed to auth with apple auth: %s " % str(session))
		emit_signal("error", "Signin failed.")
		return session
	
	print("[Moonlight_AuthApple] apple auth succeeded")
	
	
	
	var payload: = {"token": token}
	var result: NakamaAPI.ApiRpc = yield(Moonlight.client.rpc_async(session, "apple_auth", to_json(payload)), "completed")
	if not result or result.is_exception():
		printerr("[Moonlight_AuthApple] apple_auth failed: %s " % [result.payload])
	else:
		print("[Moonlight_AuthApple] apple_auth success")
		var payload_parsed = parse_json(result.payload)
		if payload_parsed is Dictionary:
			var parsedDict: Dictionary = payload_parsed
			var customappleid: String = parsedDict.get("customappledeviceid", "")
			if customappleid != "":
				print("[Moonlight_AuthApple] apple_auth using customappledeviceid")
				Moonlight.saved_data.clear_apple_auth_credentials()
				Moonlight.saved_data.set_apple_device_id_credentials(customappleid)
			else:
				printerr("[Moonlight_AuthApple] customappledeviceid is undefined")
				
		else:
			printerr("[Moonlight_AuthApple] unknown response type")
	
	emit_signal("success", {})
	return session
