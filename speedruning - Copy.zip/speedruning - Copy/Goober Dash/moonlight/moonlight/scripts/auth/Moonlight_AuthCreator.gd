extends Reference
class_name Moonlight_AuthCreator

const base_path: = "res://moonlight/moonlight/scripts/auth/"
const auth_base: = "Moonlight_AuthBase.gd"
const auth_steam: = "Moonlight_AuthSteam.gd"

static func create_authenticator() -> Moonlight_Auth:
	var should_test_steam: = OS.has_feature("editor") and Engine.has_singleton("Steam")
	if should_test_steam or OS.has_feature("steam"):
		print("[Moonlight_AuthCreator] loading steam authenticator")
		return _load_script(base_path + auth_steam).new()
	
	elif OS.has_feature("iOS") or OS.has_feature("OSX"):
		return _load_script(base_path + "Moonlight_AuthApple.gd").new()


	
	return _load_script(base_path + auth_base).new()


static func _load_script(file: String):
	if ResourceLoader.exists(file, "Script"):
		var s: = load(file) as Script
		if s != null:
			return s
		else:
			printerr("[Moonlight_AuthLoader] failed to load authenticator impl \"%s\"" % file)
	else:
		printerr("[Moonlight_AuthLoader] failed to find file \"%s\"" % file)
	return null
