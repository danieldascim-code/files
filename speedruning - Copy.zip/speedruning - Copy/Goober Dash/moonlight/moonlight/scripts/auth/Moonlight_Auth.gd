extends Reference
class_name Moonlight_Auth

var is_attempting_authentication: = false
var last_authentication_time: = 0

func authenticate(signal_on_success: = true) -> void :
	printerr("[Moonlight_Auth] authenticate must be implemented")

func log_out() -> void :
	printerr("[Moonlight_Auth] log_out must be implemented")

func is_logged_in() -> bool:
	printerr("[Moonlight_Auth] is_logged_in must be implemented")
	return false

static func is_guest_username(username: String) -> bool:
	
	return username.begins_with("Guest") and username.length() > 5 and username.substr(5).is_valid_float()

func is_guest_account() -> bool:
	printerr("[Moonlight_Auth] is_guest_account must be implemented")
	return false

func is_platform_auth_supported() -> bool:
	printerr("[Moonlight_Auth] is_platform_auth_supported must be implemented")
	return false


func is_account_linked_to_platform() -> bool:
	printerr("[Moonlight_Auth] is_account_linked_to_platform must be implemented")
	return false


func is_account_linked_to_email() -> bool:
	printerr("[Moonlight_Auth] is_account_linked_to_email must be implemented")
	return false
