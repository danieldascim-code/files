extends Moonlight_Auth
class_name Moonlight_AuthBase

func authenticate(signal_on_success: = true) -> void :
	if not _check_can_auth():
		return
	
	
	is_attempting_authentication = true
	var session: NakamaSession = null
	if Moonlight.discord_api.is_in_discord():
		var result = _auth_discord()
		if result is GDScriptFunctionState:
			result = yield(result, "completed")
		session = result
	elif Moonlight.saved_data.has_crazygames_device_id_credentials():
		var result = _auth_crazygames()
		if result is GDScriptFunctionState:
			result = yield(result, "completed")
		session = result
	elif Moonlight.saved_data.has_email_device_id_credentials():
		var result = _auth_email_device_id()
		if result is GDScriptFunctionState:
			result = yield(result, "completed")
		session = result
	elif Moonlight.saved_data.has_email_credentials():
		
		var result = _auth_email()
		if result is GDScriptFunctionState:
			result = yield(result, "completed")
		session = result
	elif Moonlight.saved_data.has_apple_device_id_credentials():
		var result = _auth_apple_device_id()
		if result is GDScriptFunctionState:
			result = yield(result, "completed")
		session = result
	elif Moonlight.saved_data.has_apple_auth_credentials():
		var result = _auth_apple()
		if result is GDScriptFunctionState:
			result = yield(result, "completed")
		session = result
	else:
		
		var result = _auth_custom()
		if result is GDScriptFunctionState:
			result = yield(result, "completed")
		session = result
	
	Moonlight.session = session
	
	
	if _check_session_valid(session):
		var post_auth = _post_auth()
		while post_auth is GDScriptFunctionState:
			post_auth = yield(post_auth, "completed")
		if not post_auth is bool or not post_auth:
			Moonlight.session = null
			session = null
	
	is_attempting_authentication = false
	
	if _check_session_valid(session):
		last_authentication_time = OS.get_unix_time()
		if signal_on_success:
			Moonlight.emit_signal("on_authentication_succeeded")

func log_out():
	print("[Moonlight_AuthBase] log_out")
	Moonlight.session = null
	Moonlight.local_account = null
	Moonlight.socket.close()
	Moonlight.saved_data.clear_apple_device_id_credentials()
	Moonlight.saved_data.clear_apple_auth_credentials()
	Moonlight.saved_data.clear_email_credentials()
	Moonlight.saved_data.clear_email_device_id_credentials()
	Moonlight.saved_data.clear_crazygames_device_id_credentials()
	Moonlight.saved_data.clear_discord_device_id_credentials()
	Moonlight.saved_data.clear_custom_uuid()
	Moonlight.storage._storage_clear()
	Moonlight.emit_signal("on_log_out")

func is_logged_in() -> bool:
	return Moonlight.client != null\
	and Moonlight.local_account != null\
	and Moonlight.storage.has_valid_data\
	and Moonlight.session != null\
	and Moonlight.session.is_valid()\
	and Moonlight.socket != null\
	and Moonlight.socket.is_connected_to_host()\
	and not is_attempting_authentication

func is_guest_account() -> bool:
	if not Moonlight.local_account:
		
		return false
	
	var u: = Moonlight.local_account.user
	
	return Moonlight.local_account.email.empty() and \
	Moonlight.local_account.devices.empty() and \
	u.apple_id.empty() and \
	u.steam_id.empty() and \
	u.facebook_id.empty() and \
	u.facebook_instant_game_id.empty() and \
	u.gamecenter_id.empty() and \
	u.google_id.empty() and \
	not Moonlight.discord_api.is_in_discord()

func is_platform_auth_supported() -> bool:
	return Moonlight.discord_api.is_in_discord()

func is_account_linked_to_platform() -> bool:
	if Moonlight.discord_api.is_in_discord():
		return is_account_linked_to_discord()
	return false

func is_account_linked_to_discord() -> bool:
	if not Moonlight.local_account:
		return false
	for d in Moonlight.local_account.devices:
		var device: NakamaAPI.ApiAccountDevice = d
		var device_id: = device.id
		if device_id.find("discord") == 0:
			return true
	return false

func is_account_linked_to_email() -> bool:
	return is_logged_in() and not Moonlight.local_account.email.empty()

func _check_session_valid(session: NakamaSession) -> bool:
	return session != null\
	and session.is_valid()\
	and not session.is_exception()

func _auth_apple() -> NakamaSession:
	printerr("[Moonlight_AuthBase] _auth_apple must be implemented in subclass")
	return NakamaSession.new(null, false, null, NakamaException.new("Invalid auth method, must be implemented in subclass"))

func _auth_email(session_vars_override: Dictionary = {}) -> NakamaSession:
	
	assert (Moonlight.saved_data.has_email_credentials())
	var email: = Moonlight.saved_data.email()
	var password: = Moonlight.saved_data.password()
	
	
	var client_version: = Moonlight.get_client_version()
	var session_vars: = {"client_version": client_version, "platform": OS.get_name()}
	session_vars.merge(session_vars_override, true)
	var session: NakamaSession = yield(Moonlight.client.authenticate_email_async(email, password, null, false, session_vars), "completed")
	
	
	if session.is_exception():
		if session.exception.status_code == 400 or session.exception.status_code == 401 or session.exception.status_code == 404:
			print("[Moonlight_AuthBase] email credentials invalid. clearing saved credentials.")
			Moonlight.saved_data.clear_email_credentials()
			Moonlight.saved_data.clear_custom_uuid()
		else:
			printerr("[Moonlight_AuthBase] exception trying to log in with email: %s" % str(session.exception))
		return session
	elif not session.is_valid():
		printerr("[Moonlight_AuthBase] failed to auth with email: %s " % str(session))
		return session
	
	print("[Moonlight_AuthBase] email auth succeeded")
	Moonlight.saved_data.set_email_credentials(email, password)
	
	return session

func _auth_email_device_id(vars_override: Dictionary = {}) -> NakamaSession:
	
	assert (Moonlight.saved_data.has_email_device_id_credentials())
	var email_device_id: = Moonlight.saved_data.email_device_id()
	
		
	var client_version: = Moonlight.get_client_version()
	var session_vars: = {"client_version": client_version, "platform": OS.get_name()}
	session_vars.merge(vars_override, true)
	var session: NakamaSession = yield(Moonlight.client.authenticate_device_async(email_device_id, null, false, session_vars), "completed")
	
	
	if session.is_exception():
		if session.exception.status_code == 400 or session.exception.status_code == 401 or session.exception.status_code == 404:
			print("[Moonlight_AuthBase] email device id credentials invalid. clearing saved credentials.")
			Moonlight.saved_data.clear_email_device_id_credentials()
			Moonlight.saved_data.clear_custom_uuid()
		else:
			printerr("[Moonlight_AuthBase] exception trying to log in with email device id: %s" % str(session.exception))
		return session
	elif not session.is_valid():
		printerr("[Moonlight_AuthBase] failed to auth with email device id: %s " % str(session))
		return session
	
	print("[Moonlight_AuthBase] email device id auth succeeded")
	return session
	
func _auth_apple_device_id() -> NakamaSession:
	
	assert (Moonlight.saved_data.has_apple_device_id_credentials())
	var apple_device_id: = Moonlight.saved_data.apple_device_id()
	
		
	var client_version: = Moonlight.get_client_version()
	var session: NakamaSession = yield(Moonlight.client.authenticate_device_async(apple_device_id, null, false, {"client_version": client_version, "platform": OS.get_name()}), "completed")
	
	
	if session.is_exception():
		if session.exception.status_code == 400 or session.exception.status_code == 401 or session.exception.status_code == 404:
			print("[Moonlight_AuthBase] apple device id credentials invalid. clearing saved credentials.")
			Moonlight.saved_data.clear_apple_device_id_credentials()
			Moonlight.saved_data.clear_custom_uuid()
		else:
			printerr("[Moonlight_AuthBase] exception trying to log in with apple device id: %s" % str(session.exception))
		return session
	elif not session.is_valid():
		printerr("[Moonlight_AuthBase] failed to auth with apple device id: %s " % str(session))
		return session
	
	print("[Moonlight_AuthBase] apple device id auth succeeded")
	return session

func _auth_discord() -> NakamaSession:
	print("[Moonlight_AuthBase] authorizing discord")
	var client_version: = Moonlight.get_client_version()
	var guild_id = Moonlight.discord_api.discord_guild_id()
	var session_vars: = {"client_version": client_version, "platform": "discord", "guild_id": guild_id}
	var is_already_authenticated_with_discord: = not DiscordAuth.access_token.empty()
	if not is_already_authenticated_with_discord:
		var result: Dictionary = yield(DiscordAuth.authorize_discord(), "completed")
		if result.has("error"):
			print("[Moonlight_AuthBase] discord failed to authorize.")
			
			
			var session: = NakamaSession.new(null, false, null, NakamaException.new("discord failed to authorize"))
			return session
		var code: String = result["code"]
		session_vars["code"] = code
	else:
		session_vars["discord_access_token"] = DiscordAuth.access_token
	
	
	print("[Moonlight_AuthBase] discord authorization succeeded. authenticating with nakama.")
	var session: NakamaSession
	if Moonlight.saved_data.has_email_device_id_credentials():
		print("[Moonlight_AuthBase] authenticating with nakama with email id")
		session = yield(_auth_email_device_id(session_vars), "completed")
	elif Moonlight.saved_data.has_email_credentials():
		print("[Moonlight_AuthBase] authenticating with nakama with email")
		session = yield(_auth_email(session_vars), "completed")
	else:
		print("[Moonlight_AuthBase] authenticating with nakama with discord id")
		session = yield(Moonlight.client.authenticate_device_async("discord_1", null, true, session_vars), "completed")
		
	
	if session.is_exception():
		if session.exception.status_code == 400 or session.exception.status_code == 401 or session.exception.status_code == 404:
			print("[Moonlight_AuthBase] discord device id credentials invalid. clearing saved credentials.")
			Moonlight.saved_data.clear_discord_device_id_credentials()
			Moonlight.saved_data.clear_custom_uuid()
		else:
			printerr("[Moonlight_AuthBase] exception trying to log in with discord device id: %s" % str(session.exception))
		return session
	elif not session.is_valid():
		printerr("[Moonlight_AuthBase] failed to auth with discord device id: %s " % str(session))
		return session
	
	
	if not is_already_authenticated_with_discord:
		print("[Moonlight_AuthBase] discord_id nakama authentication succeeded. authenticating with discord SDK")
		var session_access_token: String = session.vars.get("DiscordAccessToken")
		DiscordAuth.access_token = session_access_token
		var authenticate_result: Dictionary = yield(DiscordAuth.authenticate_discord(session_access_token), "completed")
		if authenticate_result.has("error"):
			printerr("[Moonlight_AuthBase] discord authenticate failed: %s" % [authenticate_result])
			session = NakamaSession.new(null, false, null, NakamaException.new("discord failed to authenticate"))
	else:
		print("[Moonlight_AuthBase] discord_id nakama authentication succeeded and already authenticated with discord SDK")
	return session

func _auth_crazygames() -> NakamaSession:
	
	assert (Moonlight.saved_data.has_crazygames_device_id_credentials())
	var crazy_device_id: = Moonlight.saved_data.crazygames_device_id()
	
	
	
	var token: String = ""
	var result: Dictionary = yield(CrazyAuth.async_get_user_token(), "get_user_token_response")
	if (result.has("error")):
		print("[Moonlight_AuthBase] crazygames device id credentials invalid, no token from crazygames. clearing saved credentials.")
	else:
		token = result["token"]
	
	
	var client_version: = Moonlight.get_client_version()
	var session: NakamaSession = yield(Moonlight.client.authenticate_device_async(crazy_device_id, null, false, {"client_version": client_version, "platform": OS.get_name(), "token": token}), "completed")
	
	
	if session.is_exception():
		if session.exception.status_code == 400 or session.exception.status_code == 401 or session.exception.status_code == 404:
			print("[Moonlight_AuthBase] crazygames device id credentials invalid. clearing saved credentials.")
			Moonlight.saved_data.clear_crazygames_device_id_credentials()
			Moonlight.saved_data.clear_custom_uuid()
		else:
			printerr("[Moonlight_AuthBase] exception trying to log in with crazygames device id: %s" % str(session.exception))
		return session
	elif not session.is_valid():
		printerr("[Moonlight_AuthBase] failed to auth with crazygames device id: %s " % str(session))
		return session
	
	print("[Moonlight_AuthBase] crazygames device id auth succeeded")
	
	return session
	
func _auth_custom() -> NakamaSession:
	
	var create_new_account: = not Moonlight.saved_data.has_custom_uuid()
	var custom_uuid: = ""
	if create_new_account:
		print("[Moonlight_AuthBase] creating new guest account")
		custom_uuid = NetworkUUID.new().uuid4()
	else:
		custom_uuid = Moonlight.saved_data.custom_uuid()
	
	if Moonlight.nakama_force_allow_create:
		create_new_account = true
	
	
	var client_version: = Moonlight.get_client_version()
	var vars: = {"client_version": client_version, "platform": OS.get_name()}
	if OS.has_environment("ROBOT_AUTH_SECRET"):
		vars["robot_auth_secret"] = OS.get_environment("ROBOT_AUTH_SECRET")
	var session: NakamaSession = yield(Moonlight.client.authenticate_custom_async(custom_uuid, null, create_new_account, vars), "completed")
	
	
	if session.is_exception() or not session.is_valid():
		
		
		if not create_new_account:
			if session.is_exception():
				if session.exception.status_code == 401 or session.exception.status_code == 404:
					print("[Moonlight_AuthBase] saved guest credential invalid, creating new guest account.")
					Moonlight.saved_data.clear_custom_uuid()
					return _auth_custom()
				else:
					printerr("[Moonlight_AuthBase] exception trying to log in as guest:\n%s" % str(session.exception))
		
		printerr("[Moonlight_AuthBase] failed to create new guest: %s" % str(session))
		return session
	
	print("[Moonlight_AuthBase] guest auth succeeded")
	
	
	if create_new_account:
		Moonlight.saved_data.set_custom_uuid(custom_uuid)
	
	return session

func _check_can_auth() -> bool:
	if Moonlight.client == null:
		printerr("[Moonlight_AuthBase] Moonlight client not initialized")
		return false
	return true

func _post_auth() -> bool:
	
	var connect_result = Moonlight.connect_socket()
	if connect_result is GDScriptFunctionState:
		yield(connect_result, "completed")
	
	if Moonlight.socket == null or not Moonlight.socket.is_connected_to_host():
		printerr("[Moonlight_AuthBase] socket connection failure")
		return false
	
	print("[Moonlight_AuthBase] Socket connected. Fetching account...")
	var fetch_object = Moonlight._fetch_local_account()
	var fetch_suceeded: = false
	if fetch_object is bool:
		fetch_suceeded = fetch_object
	else:
		fetch_suceeded = yield(fetch_object, "completed") as bool
	
	if not fetch_suceeded:
		
		printerr("[Moonlight_AuthBase] account fetch failure")
		return false
	
	print("[Moonlight_AuthBase] account fetched.")
	
	return true
