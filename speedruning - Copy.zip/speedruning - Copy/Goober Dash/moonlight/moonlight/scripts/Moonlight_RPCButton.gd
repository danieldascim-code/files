extends Node
class_name Moonlight_RPCButton

onready var parent_button: = get_parent() as BaseButton

export  var rpc_key: = ""
export  var data: = {}

func _init() -> void :
	data = Dictionary()

func _ready() -> void :
	parent_button.connect("pressed", self, "on_button_pressed")

func on_button_pressed():
	Moonlight.call_rpc(rpc_key, data)
