extends CanvasLayer
class_name Moonlight_ConnectingScene



export (NodePath) var _root_tween
onready var root_tween: = $Background / Tween as Tween

export (NodePath) var _root_node
onready var root_node: = $Background as Control

export (NodePath) var _connection_failed_tween
onready var connection_failed_tween: = get_node(_connection_failed_tween) as Tween

export (NodePath) var _connection_failed
onready var connection_failed: = get_node(_connection_failed) as Control

export (NodePath) var _connecting_node
onready var connecting_node: = get_node(_connecting_node) as Control

export (NodePath) var _connecting_tween
onready var connecting_tween: = get_node(_connecting_tween) as Tween

export (NodePath) var _connection_failed_client_version
onready var connection_failed_client_version: = get_node(_connection_failed_client_version) as Control

export (NodePath) var _connection_failed_label
onready var connection_failed_label: = get_node(_connection_failed_label) as Label

export (NodePath) var _retry_button
onready var retry_button: = get_node(_retry_button) as BaseButton

export  var mute_master_before_loading_scene: = false

var timer: = 0.0
var num_auth_attempts: = 0
var is_loading: = false
var is_showing: = false
var is_connecting_showing: = false
var is_connection_failed_showing: = false

const min_time_before_failed: = 5.0
const max_num_auth_attempts: = 2
const text_for_update_required: = "you must update your game!"
const text_for_web_update_required: = "you must refresh the page!"
const text_for_connection_failed: = "connection failed!"
const skip_tutorial_request_params: = ["play", "lobby"]

func _ready() -> void :
	print("[ConnectingScene] _ready")
	retry_button.connect("pressed", self, "on_retry_button_pressed")
	
	
	connection_failed.visible = false
	connection_failed.modulate = Color.transparent
	connecting_node.visible = false
	connecting_node.modulate = Color.transparent
	
	
	is_showing = true
	root_node.visible = true
	root_node.modulate = Color.white
	if _will_load_tutorial():
		_load_tutorial()
	if not is_loading:
		if Moonlight.is_logged_in():
			go_to_next_scene()
	print("[ConnectingScene] _ready end")

func _will_load_deep_link() -> bool:
	
	if OS.has_feature("HTML5"):
		var request_params: = HTMLRequestParams.get_request_params()
		for param in skip_tutorial_request_params:
			if request_params.has(param):
				return true
	return false

func _will_load_tutorial() -> bool:
	return not _will_load_deep_link() and not SavedSettings.has_value("tutorial_started")

func _load_tutorial():
	var tutorial_path: = "res://scenes/TutorialScene.tscn"
	if not ResourceLoader.exists(tutorial_path):
		print("[Moonlight_ConnectingScene] no tutorial found")
		return
	
	var tutorial_scene: = GoodResourceLoader.load_resource(tutorial_path)
	if tutorial_scene != null:
		is_loading = true
		SavedSettings.set_value("tutorial_started", true)
		get_tree().change_scene_to(tutorial_scene)

func _process(delta: float) -> void :
	var is_logged_in: = Moonlight.is_logged_in()
	if is_logged_in:
		go_to_next_scene()
	
	if is_loading:
		return
	
	var should_show: = not is_logged_in
	if should_show != self.is_showing:
		self.is_showing = should_show
		if should_show:
			fade_in(root_tween, root_node)
		else:
			fade_out(root_tween, root_node)
	
	if is_logged_in:
		timer = 0.0
		num_auth_attempts = 0
	else:
		timer += delta
		if num_auth_attempts < max_num_auth_attempts:
			if not Moonlight.auth.is_attempting_authentication and not Moonlight.auth_failure_is_client_version() and not Moonlight.auth_failure_is_banned():
				num_auth_attempts += 1
				print("[ConnectingScene] attempting auth %s" % [num_auth_attempts])
				Moonlight.auth.authenticate()

		
		
		var should_show_connecting: = Moonlight.auth.is_attempting_authentication or timer < min_time_before_failed
		if should_show_connecting != self.is_connecting_showing:
			self.is_connecting_showing = should_show_connecting
			
			if should_show_connecting:
				fade_in(connecting_tween, connecting_node)
			else:
				fade_out(connecting_tween, connecting_node)
				
		
		
		var should_show_connection_failed: = not should_show_connecting
		if should_show_connection_failed != self.is_connection_failed_showing:
			self.is_connection_failed_showing = should_show_connection_failed
			if should_show_connection_failed:
				var is_client_version_failure: = Moonlight.auth_failure_is_client_version()
				connection_failed_client_version.visible = is_client_version_failure
				retry_button.visible = true
				if is_client_version_failure:
					if OS.has_feature("web"):
						retry_button.visible = false
						connection_failed_label.text = text_for_web_update_required
					else:
						connection_failed_label.text = text_for_update_required
				elif Moonlight.auth_failure_is_banned():
					connection_failed_label.text = "You\'ve been banned!"
				else:
					connection_failed_label.text = text_for_connection_failed
				fade_in(connection_failed_tween, connection_failed, fade_duration)
			else:
				fade_out(connection_failed_tween, connection_failed)

const fade_duration: = 0.1
func fade_in(tween: Tween, node: Control, delay: float = 0.0):
	node.visible = true
	tween.remove_all()
	tween.interpolate_property(node, "modulate", null, Color.white, fade_duration, Tween.TRANS_LINEAR, Tween.EASE_IN, delay)
	tween.start()

func fade_out(tween: Tween, node: Control):
	tween.remove_all()
	tween.interpolate_property(node, "modulate", null, Color.transparent, fade_duration, Tween.TRANS_LINEAR, Tween.EASE_IN)
	tween.interpolate_callback(node, fade_duration, "set_visible", false)
	tween.start()

func on_retry_button_pressed():
	
	
	timer = 0.0
	if Moonlight.auth_failure_is_banned():
		Moonlight.auth.log_out()
	Moonlight.auth.authenticate()

func go_to_next_scene():
	
	var home_scene: PackedScene = GoodResourceLoader.load_resource("res://scenes/HomeScene.tscn")
	if home_scene == null:
		printerr("[Moonlight_ConnectingScene] couldnt load home scene")
		return
	ScreenTransitions.fade_to_scene(home_scene)

