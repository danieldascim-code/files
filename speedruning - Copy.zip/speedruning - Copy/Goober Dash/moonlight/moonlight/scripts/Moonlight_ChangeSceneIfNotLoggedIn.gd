extends Node
class_name Moonlight_ChangeSceneIfNotLoggedIn

export  var not_logged_in_scene: = ""

var is_changing: = false

func _enter_tree() -> void :
	check_not_logged_in()

func _ready() -> void :
	check_not_logged_in()

func _process(delta: float) -> void :
	check_not_logged_in()

func check_not_logged_in():
	if not Moonlight.is_logged_in():
		if not is_changing:
			is_changing = true
			get_tree().change_scene(not_logged_in_scene)
			print_stack()
			print("change scene go to connecting scene")
