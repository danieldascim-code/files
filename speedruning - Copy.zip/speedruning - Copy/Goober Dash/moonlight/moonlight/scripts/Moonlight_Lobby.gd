extends Reference
class_name Moonlight_Lobby

signal lobby_code_changed

var lobby_code: = ""

func create_lobby(max_players: int):
	lobby_code = ""
	var result = Moonlight.party.create_lobby(max_players)
	if result is GDScriptFunctionState:
		yield(result, "completed")

	if Moonlight.party.is_in_lobby():
		var result2 = generate_lobby_code(Moonlight.party.party_id)
		if result2 is GDScriptFunctionState:
			lobby_code = yield(result2, "completed")
		elif result2 is String:
			lobby_code = result2
		emit_signal("lobby_code_changed")
	else:
		printerr("[Moonlight_Lobby] create_lobby() failed to create lobby")

func join_or_create_preset_lobby(max_players: int, p_lobby_code: String):
	print("[Moonlight_Lobby] join_or_create_preset_lobby(%s) attempting to join lobby" % [p_lobby_code])
	var join_result: Dictionary = yield(join_lobby_code(p_lobby_code), "completed")
	if join_result.has("error"):
		print("[Moonlight_Lobby] join_or_create_preset_lobby(%s) creating lobby" % [p_lobby_code])
		var create_result = yield(create_preset_lobby(max_players, p_lobby_code), "completed")
	else:
		print("[Moonlight_Lobby] join_or_create_preset_lobby(%s) joined lobby" % [p_lobby_code])

func create_preset_lobby(max_players: int, lobby_code: String):
	var result = Moonlight.party.create_lobby(max_players)
	if result is GDScriptFunctionState:
		yield(result, "completed")

	if Moonlight.party.is_in_lobby():
		var result2 = write_lobby_code(Moonlight.party.party_id, lobby_code)
		if result2 is GDScriptFunctionState:
			lobby_code = yield(result2, "completed")
		elif result2 is String:
			lobby_code = result2
		emit_signal("lobby_code_changed")
	else:
		printerr("[Moonlight_Lobby] create_lobby() failed to create lobby")

func generate_lobby_code(party_id: String) -> String:
	var payload: = {
		"party_id": party_id
	}
	
	var result: Dictionary = yield(Moonlight.call_rpc("custom_lobby_generate_lobby_code", payload, false), "completed")
	if result.has("error"):
		printerr("[Moonlight_Lobby] generate_lobby_code() got error %s" % [result])
		return ""
	
	var _lobby_code: String = result.get("lobby_code", "")
	return _lobby_code

func write_lobby_code(party_id: String, lobby_code: String) -> String:
	var payload: = {
		"party_id": party_id, 
		"lobby_code": lobby_code
	}
	
	var result: Dictionary = yield(Moonlight.call_rpc("custom_lobby_write_lobby_code", payload, false), "completed")
	if result.has("error"):
		printerr("[Moonlight_Lobby] generate_lobby_code() got error %s" % [result])
		return ""
	
	var _lobby_code: String = result.get("lobby_code", "")
	return _lobby_code

func join_lobby_code(_lobby_code: String) -> Dictionary:
	var query_result: Dictionary = yield(Moonlight.call_rpc("custom_lobby_query_party_id", {"lobby_code": _lobby_code}, false), "completed")
	if query_result.has("error"):
		printerr("[Moonlight_Lobby] join_lobby_code() couldnt find party_id for lobby_code: %s error: %s" % [_lobby_code, query_result["error"]])
		return query_result
	
	var party_id: = query_result.get("party_id", "") as String
	if party_id.empty():
		printerr("[Moonlight_Lobby] join_lobby_code() party_id was empty for lobby_code %s" % [_lobby_code])
		return {"error": "couldnt find party_id for lobby_code"}
	
	print("[Moonlight_Lobby] joining party_id %s from lobby_code %s" % [party_id, _lobby_code])
	var result: = yield(Moonlight.party._join_party(party_id, Moonlight_Party.PartyType.Lobby), "completed") as NakamaAsyncResult
	if result.is_exception():
		var message: = result.exception.message
		return {"error": message}
	lobby_code = _lobby_code
	emit_signal("lobby_code_changed")
	return query_result

func query_party_id_for_lobby_code(_lobby_code: String) -> NakamaAsyncResult:
	var payload: = {
		"lobby_code": _lobby_code
	}
	var result: = yield(Moonlight.client.rpc_async(Moonlight.session, "winterpixel_query_party_id_for_lobby_code", to_json(payload)), "completed") as NakamaAPI.ApiRpc
	if result.is_exception():
		printerr("[Moonlight_Lobby] query_party_id_for_lobby_code() got error %s" % [result])
	return result
