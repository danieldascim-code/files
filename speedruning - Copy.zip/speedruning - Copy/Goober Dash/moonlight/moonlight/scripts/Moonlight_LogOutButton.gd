extends Button

func _pressed():
	Moonlight.log_out()
