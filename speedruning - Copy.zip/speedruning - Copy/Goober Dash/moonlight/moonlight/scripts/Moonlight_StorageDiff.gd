extends Reference
class_name Moonlight_StorageDiff

var rpc_id: String
var value
var old_value
var value_diff
var diff: Dictionary
var value_key: String
