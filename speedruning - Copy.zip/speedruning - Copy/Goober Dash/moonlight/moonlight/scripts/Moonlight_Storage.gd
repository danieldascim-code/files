extends Reference
class_name Moonlight_Storage

var data: = {}
var local_data: = {}
var has_valid_data: = false

const local_data_path = "../backend/modules/data"

var change_listeners: = {}
var _static_diff: Moonlight_StorageDiff
var config_use_local_data: bool = false
var config_storage_force_local_data: bool = false
var config_rpc_diff_logging: bool = false

func _init() -> void :
	config_use_local_data = GoodConfig.get_config_value("moonlight_storage_use_local_data", true)
	config_storage_force_local_data = GoodConfig.get_config_value("moonlight_storage_force_local_data", false)
	config_rpc_diff_logging = GoodConfig.get_config_value("moonlight_rpc_diff_logging", false)
	_static_diff = Moonlight_StorageDiff.new()
	if (config_storage_force_local_data or config_use_local_data) and (OS.has_feature("editor") or OS.has_feature("server")):
		data = _editor_load_local_data()
		if config_storage_force_local_data:
			local_data = data.duplicate(true)

func observe(key: String, obj: Node, method: String, binds: = []):
	if not change_listeners.has(key):
		change_listeners[key] = {}
	
	change_listeners[key][obj] = {"method": method}
	if not binds.empty():
		var new_binds: = [_static_diff]
		new_binds.append_array(binds)
		change_listeners[key][obj]["binds"] = new_binds
	if not obj.is_connected("tree_exiting", self, "_remove_observer"):
		var e = obj.connect("tree_exiting", self, "_remove_observer", [obj])
		assert (e == OK)

func remove_observer(key: String, obj: Node):
	change_listeners[key].erase(obj)
	if change_listeners[key].size() == 0:
		change_listeners.erase(key)
	if obj.is_connected("tree_exiting", self, "_remove_observer"):
		obj.disconnect("tree_exiting", self, "_remove_observer")

func _remove_observer(obj: Node):
	var erase_listener_keys: = []
	for listener_key in change_listeners:
		var listeners: Dictionary = change_listeners[listener_key]
		if obj in listeners:
			listeners.erase(obj)
			if listeners.size() == 0:
				erase_listener_keys.append(listener_key)
	
	for k in erase_listener_keys:
		change_listeners.erase(k)

func storage_get(key: String, default_value = null):
	return nested_get(key, data, default_value)

func _storage_clear():
	has_valid_data = false
	data.clear()
	if OS.has_feature("editor") or OS.has_feature("server") and config_use_local_data and config_storage_force_local_data:
		data = local_data.duplicate(true)
	print("storage clear")

func _parse_rpc_response(rpc_id: String, rpc_data: Dictionary) -> bool:
	has_valid_data = true
	
	var data_changed: = false
	var data_change_keys: = []
	var data_change_values: = []
	var data_before: = data.duplicate(true)
	if rpc_data.has("data"):
		var d = rpc_data["data"] as Dictionary
		for collection in d:
			if config_storage_force_local_data:
				if local_data.has(collection):
					continue
			
			data_changed = true
			if not data.has(collection):
				data[collection] = {}
			var storage_objects = d[collection] as Dictionary
			data[collection].merge(storage_objects, true)

	if rpc_data.has("wallet"):
		data_changed = true
		data["wallet"] = rpc_data["wallet"]
		
	if rpc_data.has("account"):
		data_changed = true
		data["account"] = rpc_data["account"]
	
	if data_changed:
		
		
		var data_diff: = _dict_diff(data_before, data)
		
		if config_rpc_diff_logging:
			print("rpc_id: %s\ndiff:\n%s" % [rpc_id, JSON.print(data_diff, "  ")])
		
		_broadcast_changes(rpc_id, data, data_before, data_diff)
		
		
		
	
	return true

func _broadcast_changes(rpc_id: String, current_data: Dictionary, old_data: Dictionary, diff: Dictionary):
	for listener_key in change_listeners:
		var wildcard_matches: = _dict_wildcard_split(listener_key, diff)
		for k in wildcard_matches:
			var value_diff = nested_get(k, diff)
			if value_diff != null:
				
				_static_diff.rpc_id = rpc_id
				_static_diff.diff = diff
				_static_diff.value = nested_get(k, current_data)
				_static_diff.old_value = nested_get(k, old_data)
				_static_diff.value_diff = value_diff
				_static_diff.value_key = k
				var objects: Dictionary = change_listeners[listener_key]
				_broadcast_diff_to_objects(objects)


func _broadcast_diff_to_objects(objects: Dictionary):
	for o in objects:
		var obj: Node = o
		var method_def: Dictionary = objects[o]
		var method: String = method_def["method"]
		if method_def.has("binds") and not method_def["binds"].empty():
			var binds: Array = method_def["binds"]
			obj.callv(method, binds)
		else:
			obj.call(method, _static_diff)

func _editor_load_local_data() -> Dictionary:
	var local_data: = {}
	var project_path: = ProjectSettings.globalize_path("res://")
	var root_directory_path: = project_path.plus_file(local_data_path).simplify_path()
	var subdirs: = []
	subdirs.append(root_directory_path)
	var file_names: = []
	while not subdirs.empty():
		var directory: = Directory.new()
		var directory_path: String = subdirs.pop_back()
		var err: = directory.open(directory_path)
		if err != OK:
			printerr("[Moonlight] _editor_load_local_data(%s) open error: %d" % [directory_path, err])
			continue
		err = directory.list_dir_begin(true, true)
		if err != OK:
			printerr("[Moonlight] _editor_load_local_data(%s) list_dir_begin error: %d" % [directory_path, err])
			continue
		
		
		var file_name: = directory.get_next()
		while file_name != "":
			var file_path: = directory_path.plus_file(file_name)
			if directory.current_is_dir():
				subdirs.append(file_path)
			else:
				if file_path.get_extension() == "json":
					file_names.append(file_path)
			file_name = directory.get_next()
		directory.list_dir_end()
	
	for f in file_names:
		var absolute_file_path: String = f
		var relative_file_name: = absolute_file_path.trim_prefix(root_directory_path)
		var splat: = relative_file_name.split("/", false)
		assert (splat.size() > 0)
		var collection: = splat[0]
		var key: = relative_file_name.get_file().trim_suffix(".json")
		_merge_json_file_into_storage_object(local_data, absolute_file_path, collection, key)
	return local_data

func _merge_json_file_into_storage_object(json_object: Dictionary, absolute_path: String, collection: String, key: String):
	var json_file: = File.new()
	if not json_file.file_exists(absolute_path):
		printerr("[Moonlight] editor local data file not found %s" % [absolute_path])
		return
		
	
	
	var error: = json_file.open(absolute_path, File.READ)
	if error != OK:
		printerr("[Moonlight] error %s opening local cloud_config file %s" % [error, absolute_path])
		return
	
	var json_file_contents: = json_file.get_as_text()
	if json_file_contents.empty():
		return
	var json_parse_result: = JSON.parse(json_file_contents)
	if json_parse_result.error != OK:
		printerr("[Moonlight] path %s failed to parse\nError (%s) - %s\nLine: %s" % [absolute_path, json_parse_result.error, json_parse_result.error_string, json_parse_result.error_line])
		return
		
	if not json_parse_result.result is Dictionary:
		printerr("[Moonlight] json file at path %s wasnt a dictionary." % [absolute_path])
		return
	
	var parsed_object: Dictionary = json_parse_result.result
	if not json_object.has(collection):
		json_object[collection] = {}
	json_object[collection][key] = parsed_object














static func nested_get(nested_key: String, dictionary: Dictionary, default_value = null):
	var t: = typeof(default_value)
	var result = _nested_typed_dictionary_lookup(nested_key, dictionary, t)
	if result == null:
		return default_value
	return result

static func _nested_typed_dictionary_lookup(nested_key: String, dictionary: Dictionary, type: int):
	var split_key_array: = nested_key.split(".", false)
	var dictionary_level: = dictionary
	for i in split_key_array.size():
		var split_key: = split_key_array[i] as String
		
		if not dictionary_level.has(split_key):
			break
		
		var split_value = dictionary_level[split_key]
		var is_last_key: bool = i == split_key_array.size() - 1
		
		if is_last_key:
			var value = dictionary_level[split_key]
			if type == TYPE_NIL:
				return value
			var value_type: = typeof(value)
			match type:
				TYPE_INT:
					if value_type == TYPE_INT or value_type == TYPE_REAL:
						return int(value)
				_:
					if type != value_type:
						return null
					return value
			
			return null
		
		if not split_value is Dictionary:
			break
		dictionary_level = split_value
	return null

static func _dict_diff(a: Dictionary, b: Dictionary) -> Dictionary:
	var r: = {}
	for k in b:
		var diffed = _dict_value_diff(a, b, k)
		if diffed != null:
			r[k] = diffed
	return r

static func _dict_value_diff(a: Dictionary, b: Dictionary, k: String):
	var v_b = b[k]
	if not a.has(k):
		return v_b
	var v_a = a[k]
	if typeof(v_a) != typeof(v_b):
		return v_b
	if typeof(v_b) == TYPE_DICTIONARY:
		var d: = _dict_diff(v_a, v_b)
		if not d.empty():
			return d
		return null
	if v_a != v_b:
		return v_b
	return null


static func _dict_wildcard_split(nested_key: String, dictionary: Dictionary) -> Array:
	var split_key_array: = nested_key.split(".", true)
	var dictionary_level: Dictionary = dictionary
	var key_accumulator: = ""
	for i in split_key_array.size():
		var split_key: = split_key_array[i] as String
		if split_key.empty():
			return []
		var next_accumulator: = split_key
		if not key_accumulator.empty():
			next_accumulator = key_accumulator + "." + split_key
		
		if split_key == "*":
			var remaining_key: = ""
			if nested_key.length() > next_accumulator.length():
				remaining_key = nested_key.substr(next_accumulator.length())
				remaining_key = remaining_key.trim_prefix(".")
			var results: = []
			for k in dictionary_level:
				assert (k is String)
				var next_level = dictionary_level[k]
				var wildcard_key: String = k
				if not key_accumulator.empty():
					wildcard_key = key_accumulator + "." + wildcard_key
				if remaining_key.empty():
					results.append(wildcard_key)
				elif next_level is Dictionary:
					var subresults: = _dict_wildcard_split(remaining_key, next_level)
					for s in subresults:
						var next_level_key: String = wildcard_key + "." + s
						results.append(next_level_key)
				else:
					results.append(wildcard_key)
			return results
		
		key_accumulator = next_accumulator
		if not dictionary_level.has(split_key):
			return []
		if i == split_key_array.size() - 1:
			return [key_accumulator]
		var split_value = dictionary_level[split_key]
		if not split_value is Dictionary:
			return []
		dictionary_level = split_value
	return []
