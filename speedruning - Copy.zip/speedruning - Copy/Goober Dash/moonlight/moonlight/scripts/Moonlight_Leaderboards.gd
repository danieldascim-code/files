extends Reference

class_name Moonlight_Leaderboards

signal owner_records_fetched

var primary_leaderboards: = []
var owner_records: = {}
var has_fetched_owner_records: = false

func parse_primary_leaderboards(cloud_config: Dictionary) -> bool:
	primary_leaderboards.clear()
	var parse_succeeded: = false
	var cloud_config_primary_leaderboards = cloud_config.get("primary_leaderboards")
	if cloud_config_primary_leaderboards is Array:
		for leaderboard in cloud_config_primary_leaderboards:
			if leaderboard is String:
				primary_leaderboards.append(leaderboard)
				parse_succeeded = true
	
	print("[Moonlight_Leaderboards] parsed %d primary_leaderboards" % [primary_leaderboards.size()])
	return parse_succeeded

func leaderboard_id_for_season(leaderboard: String, season: int) -> String:
	return "%s_%d" % [leaderboard, season]

func query_primary_leaderboards(season: int) -> bool:
	if primary_leaderboards.size() == 0:
		return true
	return yield(query_owners_records(primary_leaderboards, season), "completed")

func query_owners_records(leaderboards: Array, season: int) -> bool:
	has_fetched_owner_records = false
	var data: = {
		"leaderboards": leaderboards, 
		"season": season
	}
	var data_json: = to_json(data)
	var rpc_results: = yield(Moonlight.client.rpc_async(Moonlight.session, "query_multiple_leaderboards", data_json), "completed") as NakamaAPI.ApiRpc
	if not rpc_results.is_exception():
		var leaderboards_json = parse_json(rpc_results.payload) as Dictionary
		if leaderboards_json == null:
			owner_records = {}
		else:
			owner_records = leaderboards_json
		has_fetched_owner_records = true
		emit_signal("owner_records_fetched")
		return true
	printerr("[Moonlight_Leaderboards] failed to query_owners_records. %s" % [rpc_results])
	return false

func get_owner_leaderboard_record(leaderboard: String, season: int) -> Dictionary:
	if has_fetched_owner_records:
		var leaderboard_id: = "%s_%d" % [leaderboard, season]
		if owner_records.has(leaderboard_id):
			return owner_records[leaderboard_id]
		else:
			printerr("[Moonlight_Leaderboards] failed to get_owner_leaderboard_record for leaderboard: %s season: %d" % [leaderboard, season])
	printerr("[Moonlight_Leaderboards] couldnt get_owner_leaderboard_record for leaderboard: %s season: %s" % [leaderboard, season])
	return {}

func get_owner_leaderboard_score(leaderboard: String, season: int) -> int:
	var leaderboard_record: = get_owner_leaderboard_record(leaderboard, season)
	return int(leaderboard_record.get("score", 0))

func get_owner_leaderboard_rank(leaderboard: String, season: int) -> int:
	var leaderboard_record: = get_owner_leaderboard_record(leaderboard, season)
	return int(leaderboard_record.get("rank", 0))


func query_seasonal_leaderboard(leaderboard: String, season: int, owner_ids: Array, limit: int, cursor: String) -> Dictionary:
	var payload: = {
		"leaderboard": leaderboard, 
		"season": season, 
		"owner_ids": owner_ids, 
		"cursor": cursor, 
		"limit": limit
	}
	
	var api_response: = yield(Moonlight.client.rpc_async(Moonlight.session, "query_leaderboard", to_json(payload)), "completed") as NakamaAPI.ApiRpc
	if api_response.is_exception():
		printerr("[Moonlight_Leaderboards] failed to query_leaderboard %s" % [api_response])
		return {}
	
	var response_payload: = api_response.payload
	var response_data: = parse_json(response_payload) as Dictionary
	return response_data

static func get_tier_by_id(tier_id: String, config: Dictionary) -> Dictionary:
	for t in config.get("trophy_tiers", []):
		var tier_definition: = t as Dictionary
		if tier_definition.get("id", "") == tier_id:
			return tier_definition
	
	printerr("[Moonlight_Leaderboards] get_tier_by_id() failed to find tier")
	return {}
	
static func compute_tier_for_rank(rank: int, config: Dictionary) -> Dictionary:
	for t in config.get("trophy_tiers", []):
		var tier_definition: = t as Dictionary
		if not tier_definition.has("maximum_rank"):
			return tier_definition
		else:
			var maximum_rank: = int(tier_definition["maximum_rank"])
			if rank <= maximum_rank:
				return tier_definition
	
	printerr("[Moonlight_Leaderboards] compute_tier_for_rank() failed to find tier for rank %s" % [rank])
	return {}

static func bottom_tier(config: Dictionary) -> Dictionary:
	var trophy_tiers: = config.get("trophy_tiers", []) as Array
	return trophy_tiers[trophy_tiers.size() - 1]
