extends Node
class_name Moonlight_DiscordAnonToggle

onready var parent_toggle: = get_parent() as Button
export  var _visibility_container: NodePath
onready var visibility_container: Control = get_node(_visibility_container)

func _ready() -> void :
	if not Moonlight.discord_api.is_in_discord():
		visibility_container.hide()
		return
	else:
		visibility_container.show()
	
	parent_toggle.connect("pressed", self, "on_parent_pressed")
	Moonlight.storage.observe("player.discord", self, "on_data_changed")
	_render_state()

func on_data_changed(_diff):
	_render_state()

func _render_state():
	var is_linked_account: bool = Moonlight.storage.storage_get("player.discord.is_linked_account", false)
	if is_linked_account:
		visibility_container.hide()
		return
	else:
		visibility_container.show()
	var is_public: bool = Moonlight.storage.storage_get("player.discord.is_public", false)
	parent_toggle.pressed = not is_public

func on_parent_pressed():
	var is_public: bool = not parent_toggle.pressed
	var rpc_result: Dictionary = yield(Moonlight.call_rpc("discord_set_public", {"is_public": is_public}), "completed")
	if rpc_result.has("error"):
		printerr("[Moonlight_DiscordAnonToggle] discord_set_public error: %s" % [rpc_result])
