extends Reference

class_name MoonlightSavedData

var data: = {}
const file_name = "user://moonlight_userdata"

func _init():
	data = load_data()

func custom_uuid() -> String:
	return data.get("uuid", "")

func set_custom_uuid(s: String):
	data["uuid"] = s
	save_data(data)

func has_custom_uuid() -> bool:
	return data.has("uuid") and data.get("uuid", "") != ""

func clear_custom_uuid():
	data.erase("uuid")
	save_data(data)

func email() -> String:
	return data.get("email", "")
	
func email_device_id() -> String:
	return data.get("email_device_id", "")
	
func apple_device_id() -> String:
	return data.get("apple_device_id", "")

func crazygames_device_id() -> String:
	return data.get("crazygames_device_id", "")
	
func discord_device_id() -> String:
	return data.get("discord_device_id", "")

func apple_auth_token() -> String:
	return data.get("apple_auth_token", "")

func password() -> String:
	return data.get("password", "")

func has_email_credentials() -> bool:
	return data.has_all(["email", "password"])
	
func has_email_device_id_credentials() -> bool:
	return data.has_all(["email_device_id"])
	
func has_apple_device_id_credentials() -> bool:
	return data.has_all(["apple_device_id"])
	
func has_crazygames_device_id_credentials() -> bool:
	return data.has_all(["crazygames_device_id"])
	
func has_discord_device_id_credentials() -> bool:
	return data.has_all(["discord_device_id"])

func has_apple_auth_credentials() -> bool:
	return data.has_all(["apple_auth_token"])

func set_apple_auth_credentials(email: String, token: String):
	if email != "":
		data["apple_auth_email"] = email
	data["apple_auth_token"] = token
	save_data(data)

func clear_apple_auth_credentials():
	data.erase("apple_auth_email")
	data.erase("apple_auth_token")
	save_data(data)

func set_email_credentials(email: String, password: String):
	data["email"] = email
	data["password"] = password
	save_data(data)

func clear_email_credentials():
	data.erase("email")
	data.erase("password")
	save_data(data)
	
func set_email_device_id_credentials(email_device_id: String):
	data["email_device_id"] = email_device_id
	save_data(data)
	
func set_apple_device_id_credentials(apple_device_id: String):
	data["apple_device_id"] = apple_device_id
	save_data(data)

func clear_email_device_id_credentials():
	data.erase("email_device_id")
	save_data(data)
	
func clear_apple_device_id_credentials():
	data.erase("apple_device_id")
	save_data(data)
	
func set_crazygames_device_id_credentials(crazy_device_id: String):
	data["crazygames_device_id"] = crazy_device_id
	save_data(data)
	
func set_discord_device_id_credentials(discord_device_id: String):
	data["discord_device_id"] = discord_device_id
	save_data(data)

func clear_crazygames_device_id_credentials():
	data.erase("crazygames_device_id")
	save_data(data)
	
func clear_discord_device_id_credentials():
	data.erase("discord_device_id")
	save_data(data)
	
func save_data(data: Dictionary):
	var file: = File.new()
	file.open_encrypted_with_pass(file_name, File.WRITE, p())
	file.store_string(to_json(data))
	file.close()

func p():
	return "Moonlight++" + str(1337)

func load_data() -> Dictionary:
	var file: = File.new()
	if file.file_exists(file_name):
		file.open_encrypted_with_pass(file_name, File.READ, p())
		var file_data = parse_json(file.get_as_text())
		file.close()
		if typeof(file_data) == TYPE_DICTIONARY:
			return file_data
		else:
			printerr("[MoonlightSavedData] Corrupted data!")
	else:
		pass
		
	
	return {}
