extends Node
class_name Moonlight_CurrentSeasonTimeLeftLabel

export (NodePath) var _days
onready var days: = get_node_or_null(_days) as Label
export  var days_format: = "%d"

export (NodePath) var _hours
onready var hours: = get_node_or_null(_hours) as Label
export  var hours_format: = "%d"

export (NodePath) var _minutes
onready var minutes: = get_node_or_null(_minutes) as Label
export  var minutes_format: = "%d"

export (NodePath) var _seconds
onready var seconds: = get_node_or_null(_seconds) as Label
export  var seconds_format: = "%02d"

onready var parent_label: = get_parent() as Label

func _process(_delta):
	var t: = DateTimeUtils.seconds_to_datetime(Moonlight.seasons.season_seconds_left)
	var n_days: = int(t["days"])
	var n_hours: = int(t["hours"])
	var n_minutes: = int(t["minutes"])
	var n_seconds: = int(t["seconds"])
	
	if parent_label:
		var single_label_text: = ""
		
		if n_days > 0:
			single_label_text = str(n_days) + "d"
		
		if n_days > 0 or n_hours > 0:
			if not single_label_text.empty():
				single_label_text += " "
			single_label_text += str(n_hours) + "h"
		
		if n_days > 0 or n_hours > 0 or n_minutes > 0:
			if not single_label_text.empty():
				single_label_text += " "
			single_label_text += str(n_minutes) + "m"
		
		if n_days == 0 and n_hours == 0:
			single_label_text += str(n_seconds) + "s"
		
		parent_label.text = single_label_text
	
	if days:
		if n_days > 0:
			days.visible = true
			days.text = days_format % [n_days]
		else:
			days.visible = false
	
	if hours:
		if n_days > 0 or n_hours > 0:
			hours.visible = true
			hours.text = hours_format % [n_hours]
		else:
			hours.visible = false
	
	if minutes:
		if n_days > 0 or n_hours > 0 or n_minutes > 0:
			minutes.visible = true
			minutes.text = minutes_format % [n_minutes]
		else:
			minutes.visible = false
	
	if seconds:
		var should_show_seconds: = n_days == 0 and n_hours == 0
		if should_show_seconds:
			seconds.visible = true
			seconds.text = seconds_format % [n_seconds]
		else:
			seconds.visible = false
