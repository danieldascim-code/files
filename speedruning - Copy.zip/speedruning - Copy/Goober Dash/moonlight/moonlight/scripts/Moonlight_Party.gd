extends Reference
class_name Moonlight_Party

enum OpCode{
	
	NONE = 0, 
	GAMEMODE, 
	MATCH_ID, 
	MEMBER_DATA, 
	PARTY_DATA, 
	BOUNCER
	
	
	
	
}

signal party_invites_changed()
signal party_members_changed()
signal party_member_joined(user_id)
signal party_member_left(user_id)
signal party_id_changed(party_id)
signal party_gamemode_selected(gamemode_id)
signal party_match_id_received(match_id)
signal party_member_data_changed(user_id, data)
signal party_data_received(user_id, data)
signal party_bouncer_state_changed(bouncer_state)
signal party_leader_changed()
signal party_code_changed()

const max_size: = 4

var party_id: = ""

enum PartyType{
	Squad, 
	Lobby
}
var party_type: int = PartyType.Squad
var gamemode_id: = ""
var match_id: = ""
var leader_user_id: = ""
var is_leader: = false
var party_members: = {}
var party_invites: = {}
var local_member_data: = {}
var party_member_data: = {}
var party_member_nakama_presences: = {}
var party_data: = {}

enum PartyBouncerState{
	Public, 
	Friends, 
	Closed, 
	Max
}
var bouncer_state: int = PartyBouncerState.Public setget set_bouncer_state

func _init(socket: NakamaSocket):
	socket.connect("received_channel_message", self, "on_received_channel_message")
	socket.connect("received_channel_presence", self, "on_received_channel_presence")
	socket.connect("received_stream_presence", self, "on_received_stream_presence")
	socket.connect("received_stream_state", self, "on_received_stream_state")
	socket.connect("received_party", self, "on_received_party")
	socket.connect("received_party_close", self, "on_received_party_close")
	socket.connect("received_party_data", self, "on_received_party_data")
	socket.connect("received_party_join_request", self, "on_received_party_join_request")
	socket.connect("received_party_leader", self, "on_received_party_leader")
	socket.connect("received_party_presence", self, "on_received_party_presence")
	socket.connect("received_error", self, "on_received_error")
	socket.connect("closed", self, "clear_party_invites")
	socket.connect("closed", self, "_clear_party_data")
	Moonlight.connect("on_socket_message_parsed", self, "on_socket_message_parsed")
	Moonlight.connect("on_log_out", self, "clear_party_invites")
	Moonlight.connect("on_log_out", self, "_clear_party_data")


func notify_party_match_id(match_id: String):
	if not is_in_party():
		printerr("[Moonlight_Party] notify_party_match_id() when not in a party")
		return
	
	print("[Moonlight_Party] notify_party_match_id() sending match_id %s" % [match_id])
	var result: = yield(Moonlight.socket.send_party_data_async(party_id, OpCode.MATCH_ID, match_id), "completed") as NakamaAsyncResult
	if result.is_exception():
		printerr("[Moonlight_Party] notify_party_match_id() error sending data to party %s" % [result])

func set_local_member_data(data: Dictionary):
	local_member_data = data
	var local_user_id: String = Moonlight.local_account.user.id
	party_member_data[local_user_id] = local_member_data
	emit_signal("party_member_data_changed", local_user_id, local_member_data)
	send_self_member_data()

func merge_local_member_data(data: Dictionary):
	for k in data:
		local_member_data[k] = data[k]
	set_local_member_data(local_member_data)

func get_local_member_data() -> Dictionary:
	return local_member_data

func send_party_data(_party_data: Dictionary):
	if not is_in_party():
		printerr("[Moonlight_Party] send_party_data() when not in a party")
		return
	if Moonlight.party.is_leader:
		var payload: = to_json(_party_data)
		print("[Moonlight_Party] send_party_data() sending party data %s" % [payload])
		var result: = yield(Moonlight.socket.send_party_data_async(party_id, OpCode.PARTY_DATA, payload), "completed") as NakamaAsyncResult
		if result.is_exception():
			printerr("[Moonlight_Party] send_party_data() error sending data to party %s" % [result])
		else:
			party_data = _party_data

func send_self_member_data():
	if not is_in_party():
		printerr("[Moonlight_Party] send_self_member_data() when not in a party")
		return
	
	var local_data_string: = to_json(local_member_data)
	print("[Moonlight_Party] send_self_member_data() sending member data %s" % [local_member_data])
	var result: = yield(Moonlight.socket.send_party_data_async(party_id, OpCode.MEMBER_DATA, local_data_string), "completed") as NakamaAsyncResult
	if result.is_exception():
		printerr("[Moonlight_Party] send_self_member_data() error sending data to party %s" % [result])

func _validate_bouncer_state(b: int) -> bool:
	return b >= 0 and b < PartyBouncerState.Max
	
func _broadcast_bouncer_state():
	if is_in_party() and is_leader:
		var data: = String(bouncer_state)
		var result: = yield(Moonlight.socket.send_party_data_async(party_id, OpCode.BOUNCER, data), "completed") as NakamaAsyncResult
		if result.is_exception():
			printerr("[Moonlight_Party] notify_party_match_id() error sending data to party %s" % [result])
	
func set_bouncer_state(b: int):
	if bouncer_state != b:
		if _validate_bouncer_state(b):
			bouncer_state = b
			emit_signal("party_bouncer_state_changed", bouncer_state)
			_broadcast_bouncer_state()
		else:
			printerr("[Moonlight_Party] set_bouncer_state() invalid bouncer state %s" % [b])

func is_bouncer_state(b: int) -> bool:
	return bouncer_state == b

func clear_party_invites():
	print("[Moonlight_Party] clear_party_invites()")
	party_invites.clear()
	emit_signal("party_invites_changed")

func _add_party_invite(user_id: String, display_name: String, party_id: String):
	if user_id.empty() or display_name.empty() or party_id.empty():
		printerr("[Moonlight_Party] invalid data in party invite")
		return
	
	if not party_invites.has(user_id):
		party_invites[user_id] = {
			"user_id": user_id, 
			"display_name": display_name, 
			"party_id": party_id, 
			"timestamp": OS.get_unix_time()
		}
		emit_signal("party_invites_changed")

func on_socket_message_parsed(nakama_notification: NakamaAPI.ApiNotification, content_json: Dictionary):
	match nakama_notification.code:
		Moonlight.SocketCode.PartyInvite:
			print("[Moonlight_Party] received party invite \n%s" % [content_json])
			var user_id: = content_json.get("user_id", "") as String
			var display_name: = content_json.get("display_name", "") as String
			var party_id: = content_json.get("party_id", "") as String
			_add_party_invite(user_id, display_name, party_id)

func create_party(max_size: int) -> void :
	var result = _create_party(max_size, PartyType.Squad, PartyBouncerState.Public)
	if result is GDScriptFunctionState:
		yield(result, "completed")

func create_lobby(size: int) -> void :
	var result = _create_party(size, PartyType.Lobby, PartyBouncerState.Public)
	if result is GDScriptFunctionState:
		yield(result, "completed")

func is_in_lobby() -> bool:
	return is_in_party() and party_type == PartyType.Lobby

func is_in_squad() -> bool:
	return is_in_party() and party_type == PartyType.Squad

func _create_party(max_size: int, type: int, __bouncer_state: int) -> void :



	
	if is_in_party():
		printerr("[Moonlight_Party] create_party() already in party")
		return
	
	bouncer_state = __bouncer_state
	
	print("[Moonlight_Party] create_party() creating party")
	var result: = yield(Moonlight.socket.create_party_async(false, max_size), "completed") as NakamaRTAPI.Party
	if result.is_exception():
		printerr("[MoonlightParty] error creating party %s" % [result])
		return
	
	print("[Moonlight_Party] create_party() party created %s" % [result])
	if result is NakamaRTAPI.Party:
		party_type = type
		yield(_parse_party(result), "completed")
	else:
		printerr("[Moonlight_Party] create_party() result is not expected %s" % [result])

func leave_party():
	if not is_in_party():
		printerr("[Moonlight_Party] leave_party() not in party")
		return
	
	print("[Moonlight_Party] leave_party()")
	var result: = yield(Moonlight.socket.leave_party_async(party_id), "completed") as NakamaAsyncResult
	if result.is_exception():
		printerr("[MoonlightParty] leave_party() error %s" % [result])
		return
	
	_clear_party_data()

func _clear_party_data():
	print("[Moonlight_Party] clear_party_data()")
	party_id = ""
	match_id = ""
	gamemode_id = ""
	is_leader = false
	leader_user_id = ""
	party_members.clear()
	party_member_nakama_presences.clear()
	local_member_data.clear()
	party_member_data.clear()
	party_data.clear()
	emit_signal("party_members_changed")
	emit_signal("party_id_changed", "")

func _parse_party(nakama_party: NakamaRTAPI.Party):
	party_id = ""
	is_leader = false
	leader_user_id = ""
	party_members.clear()
	party_member_nakama_presences.clear()
	
	var user_ids: = []
	if nakama_party != null:
		party_id = nakama_party.party_id
		leader_user_id = nakama_party.leader.user_id
		for u in nakama_party.presences:
			var user_presence: = u as NakamaRTAPI.UserPresence
			user_ids.append(user_presence.user_id)
		
		var user_datas: = yield(_query_users(user_ids), "completed") as Dictionary
		
		for u in nakama_party.presences:
			var user_presence: = u as NakamaRTAPI.UserPresence
			party_member_nakama_presences[user_presence.user_id] = user_presence
			_parse_party_member(user_presence, user_datas.get(user_presence.user_id, {}))
		
		is_leader = nakama_party.leader.user_id == nakama_party.self_presence.user_id
	
	send_self_member_data()
	send_party_data(party_data)
	emit_signal("party_id_changed", party_id)
	emit_signal("party_members_changed")
	for user_id in user_ids:
		emit_signal("party_member_joined", user_id)

func _parse_party_member(user_presence: NakamaRTAPI.UserPresence, user_data: Dictionary):
	var user_id: = user_presence.user_id
	var name: = user_data.get("display_name", "") as String
	var metadata: = user_data.get("metadata", {}) as Dictionary
	if SavedSettings.get_value("safety_mode", false):
		name = Moonlight_RandomName.filter_safe_name(name, user_id, metadata)
	party_members[user_id] = {
		"user_id": user_id, 
		"is_leader": user_presence.user_id == leader_user_id, 
		"is_self": user_presence.user_id == Moonlight.local_account.user.id, 
		"display_name": name, 
		"metadata": metadata
	}

func _query_user(user_id: String) -> Dictionary:
	return _query_users([user_id]).get(user_id, {})

func _query_users(user_ids: Array) -> Dictionary:
	var result: = yield(Moonlight.client.get_users_async(Moonlight.session, PoolStringArray(user_ids)), "completed") as NakamaAPI.ApiUsers
	
	if result.is_exception():
		printerr("[Moonlight_Party] _query_display_names() failed %s" % [result])
		return {}
	
	var user_infos: = {}
	for u in result.users:
		var user: = u as NakamaAPI.ApiUser
		var parse_result: = JSON.parse(user.metadata)
		var metadata_dictionary: = parse_result.result as Dictionary
		if metadata_dictionary == null:
			printerr("[Moonlight_Party] failed to parse metadata %s" % [parse_result])
			metadata_dictionary = {}
		user_infos[user.id] = {
			"display_name": user.display_name, 
			"metadata": metadata_dictionary
		}
	
	return user_infos

func is_in_party() -> bool:
	return Moonlight.is_logged_in() and not party_id.empty()

func invite_player_to_party(user_id: String):
	if not is_in_party():
		printerr("[Moonlight_Party] invite_player_to_party() player isnt in party")
		return
	
	var payload: = {
		"friend_user_id": user_id, 
		"party_id": party_id
	}
	
	print("[Moonlight_Party] invite_player_to_party() sending invite")
	var result: = yield(Moonlight.client.rpc_async(Moonlight.session, "winterpixel_invite_to_party", to_json(payload)), "completed") as NakamaAPI.ApiRpc
	if result.is_exception():
		printerr("[Moonlight_Party] invite_player_to_party() error sending invite %s" % [result])
	else:
		print("[Moonlight_Party] invite_player_to_party() sent invite %s" % [result])

func accept_invite_to_party(user_id: String, party_id: String):
	print("[Moonlight_Party] accept_invite_to_party()")
	party_invites.erase(user_id)
	emit_signal("party_invites_changed")
	yield(_join_party(party_id, PartyType.Squad), "completed")

func _join_party(_party_id: String, _type: int) -> NakamaAsyncResult:
	var result: = yield(Moonlight.socket.join_party_async(_party_id), "completed") as NakamaAsyncResult
	if result.is_exception():
		print("[Moonlight_Party] accept_invite_to_party() error %s" % [result])
	else:
		print("[Moonlight_Party] accept_invite_to_party() succeeded %s" % [result])
		party_type = _type
		party_id = _party_id
	return result

func deny_invite_to_party(user_id: String, party_id: String):
	print("[Moonlight_Party] deny_invite_to_party()")
	party_invites.erase(user_id)
	emit_signal("party_invites_changed")

func _accept_party_join_request(user_presence: NakamaRTAPI.UserPresence):
	print("[Moonlight_Party] _accept_party_join_request() accepting %s" % [user_presence])
	var result: NakamaAsyncResult = yield(Moonlight.socket.accept_party_member_async(party_id, user_presence), "completed")
	if result.is_exception():
		printerr("[Moonlight_Party] _accept_party_join_request() error %s" % [result])
	else:
		print("[Moonlight_Party] _accept_party_join_request() accepted join request %s" % [result])
	return result

func _deny_party_join_request(user_presence: NakamaRTAPI.UserPresence):
	print("[Moonlight_Party] _deny_party_join_request() denying %s" % [user_presence])
	yield(_remove_presence_from_party(user_presence), "completed")

func remove_player_from_party(user_id: String):
	if not is_in_party():
		printerr("[Moonlight_Party] remove_player_from_party() cannot remove player from party when not in a party")
		return
	
	if not party_member_nakama_presences.has(user_id):
		printerr("[Moonlight_Party] remove_player_from_party() cannot find player presence to remove")
		return
	
	var user_presence: = party_member_nakama_presences[user_id] as NakamaRTAPI.UserPresence
	if user_presence == null:
		printerr("[Moonlight_Party] remove_player_from_party() error in player presence")
		return
	
	print("[Moonlight_Party] remove_player_from_party() removing %s" % [user_id])
	_remove_presence_from_party(user_presence)

func _remove_presence_from_party(user_presence: NakamaRTAPI.UserPresence):
	print("[Moonlight_Party] remove_player_from_party() removing %s" % [user_presence])
	var result: NakamaAsyncResult = yield(Moonlight.socket.remove_party_member_async(party_id, user_presence), "completed")
	if result.is_exception():
		printerr("[Moonlight_Party] remove_player_from_party() error %s" % [result])
	else:
		print("[Moonlight_Party] remove_player_from_party() removed player %s" % [result])

func on_received_channel_message(p_channel_message: NakamaAPI.ApiChannelMessage):
	print("[Moonlight_Party] on_received_channel_message(%s)" % [p_channel_message])

func on_received_channel_presence(p_channel_presence: NakamaRTAPI.ChannelPresenceEvent):
	print("[Moonlight_Party] on_received_channel_presence(%s)" % [p_channel_presence])

func on_received_stream_presence(p_stream_presence: NakamaRTAPI.StreamPresenceEvent):
	print("[Moonlight_Party] on_received_stream_presence(%s)" % [p_stream_presence])

func on_received_stream_state(p_stream_state: NakamaRTAPI.StreamData):
	print("[Moonlight_Party] on_received_stream_state(%s)" % [p_stream_state])

func on_received_party(received_party: NakamaRTAPI.Party):
	print("[Moonlight_Party] on_received_party(%s)" % [received_party])
	_parse_party(received_party)

func on_received_party_close(p_party_close: NakamaRTAPI.PartyClose):
	print("[Moonlight_Party] on_received_party_close(%s)" % [p_party_close])
	if not is_in_party():
		printerr("[Moonlight_Party] on_received_party_close() when not in a party")
		return
	
	if p_party_close.party_id != party_id:
		printerr("[Moonlight_Party] on_received_party_close() for different party")
		return
	
	_clear_party_data()

func on_received_party_data(p_party_data: NakamaRTAPI.PartyData):
	print("[Moonlight_Party] on_received_party_data(%s)" % [p_party_data])
	match p_party_data.op_code:
		OpCode.GAMEMODE:
			gamemode_id = p_party_data.data
			print("[Moonlight_Party] on_received_party_data got gamemode_id %s" % [gamemode_id])
			emit_signal("party_gamemode_selected", gamemode_id)
		OpCode.MATCH_ID:
			match_id = p_party_data.data
			print("[Moonlight_Party] on_received_party_data got match_id %s" % [match_id])
			if match_id != "":
				emit_signal("party_match_id_received", match_id)
		OpCode.MEMBER_DATA:
			var json_parse_result: = JSON.parse(p_party_data.data)
			if json_parse_result.error != OK:
				printerr("[Moonlight_Party] data didnt parse")
				return
			if not json_parse_result.result is Dictionary:
				printerr("[Moonlight_Party] data isnt dictionary")
				return
			var user_id: = p_party_data.presence.user_id
			party_member_data[user_id] = json_parse_result.result
			emit_signal("party_member_data_changed", user_id, party_member_data[user_id])
		OpCode.PARTY_DATA:
			if p_party_data.presence.user_id == leader_user_id:
				var json_parse_result: = JSON.parse(p_party_data.data)
				if json_parse_result.error != OK:
					printerr("[Moonlight_Party] data didnt parse")
					return
				if not json_parse_result.result is Dictionary:
					printerr("[Moonlight_Party] data isnt dictionary")
					return
				party_data = json_parse_result.result
				emit_signal("party_data_received", party_data)
		OpCode.BOUNCER:
			if p_party_data.presence.user_id == leader_user_id:
				set_bouncer_state(int(p_party_data.data))
		OpCode.NONE, _:
			printerr("[Moonlight_Party] on_received_party_data received invalid op_code %s" % p_party_data.op_code)

func on_received_party_join_request(p_party_join_request: NakamaRTAPI.PartyJoinRequest):
	print("[Moonlight_Party] on_received_party_join_request(%s)" % [p_party_join_request])
	
	
	if not is_in_party():
		printerr("[Moonlight_Party] on_received_party_join_request() when not in a party")
		return
	
	if p_party_join_request.party_id != party_id:
		printerr("[Moonlight_Party] on_received_party_join_request() for different party")
		return
	
	for p in p_party_join_request.presences:
		var user_presence: = p as NakamaRTAPI.UserPresence
		var result: NakamaAsyncResult = null
		match bouncer_state:
			PartyBouncerState.Closed:
				print("[Moonlight_Party] party is closed. denying join request")
				result = yield(_deny_party_join_request(user_presence), "completed") as NakamaAsyncResult
			PartyBouncerState.Friends:
				if user_presence.user_id in Moonlight.friends.friend_user_ids:
					print("[Moonlight_Party] party is friends only. accepting friend")
					result = yield(_accept_party_join_request(user_presence), "completed") as NakamaAsyncResult
				else:
					print("[Moonlight_Party] party is friends only. denying friend")
					result = yield(_deny_party_join_request(user_presence), "completed") as NakamaAsyncResult
			_, PartyBouncerState.Public:
				print("[Moonlight_Party] party is public. accepting friend")
				result = yield(_accept_party_join_request(user_presence), "completed") as NakamaAsyncResult
			
		if result != null and result.is_exception():
			printerr("[Moonlight_Party] on_received_party_join_request() error accepting join request %s" % [result])
			continue

func on_received_party_leader(p_party_leader: NakamaRTAPI.PartyLeader):
	print("[Moonlight_Party] on_received_party_leader(%s)" % [p_party_leader])
	if not is_in_party():
		printerr("[Moonlight_Party] on_received_party_leader() when not in a party")
		return
	
	if p_party_leader.party_id != party_id:
		printerr("[Moonlight_Party] on_received_party_leader() for different party")
		return
	
	leader_user_id = p_party_leader.presence.user_id
	is_leader = leader_user_id == Moonlight.local_account.user.id
	party_member_nakama_presences[p_party_leader.presence.user_id] = p_party_leader.presence
	
	
	for user_id in party_members:
		var party_member_data: = party_members[user_id] as Dictionary
		party_member_data["is_leader"] = user_id == leader_user_id
	
	emit_signal("party_leader_changed")
	emit_signal("party_members_changed")

func on_received_party_presence(p_party_presence: NakamaRTAPI.PartyPresenceEvent):
	print("[Moonlight_Party] on_received_party_presence(%s)" % [p_party_presence])
	if not is_in_party():
		printerr("[Moonlight_Party] on_received_party_presence() when not in a party")
		return
	
	if p_party_presence.party_id != party_id:
		printerr("[Moonlight_Party] on_received_party_presence() for different party")
		return

	
	var user_ids: = []
	for j in p_party_presence.joins:
		var joining_presence: = j as NakamaRTAPI.UserPresence
		user_ids.append(joining_presence.user_id)
	
	
	
	if user_ids.size() > 0:
		var user_datas: = yield(_query_users(user_ids), "completed") as Dictionary
		for j in p_party_presence.joins:
			var joining_presence: = j as NakamaRTAPI.UserPresence
			_parse_party_member(joining_presence, user_datas.get(joining_presence.user_id))
			party_member_nakama_presences[joining_presence.user_id] = joining_presence
	
	
	var leavers: = []
	for l in p_party_presence.leaves:
		var leaving_presence: = l as NakamaRTAPI.UserPresence
		leavers.append(leaving_presence.user_id)
		if party_members.has(leaving_presence.user_id):
			party_members.erase(leaving_presence.user_id)
		if party_member_nakama_presences.has(leaving_presence.user_id):
			party_member_nakama_presences.erase(leaving_presence.user_id)
	
	
	for leaver_user_id in leavers:
		emit_signal("party_member_left", leaver_user_id)
		
	for joiner_user_id in user_ids:
		emit_signal("party_member_joined", joiner_user_id)
	
	emit_signal("party_members_changed")
	send_self_member_data()
	send_party_data(party_data)
	_broadcast_bouncer_state()

func on_received_error(error):
	printerr("[Moonlight_Party] on_received_error(%s)" % [error])






func write_squad_code(party_id: String, lobby_code: String) -> String:
	var payload: = {
		"party_id": party_id, 
		"lobby_code": lobby_code
	}
	
	var result: Dictionary = yield(Moonlight.call_rpc("custom_lobby_write_lobby_code", payload, false), "completed")
	if result.has("error"):
		printerr("[Moonlight_Lobby] generate_lobby_code() got error %s" % [result])
		return ""
	
	var _lobby_code: String = result.get("lobby_code", "")
	return _lobby_code

func join_or_create_preset_squad(max_players: int, p_lobby_code: String):
	print("[Moonlight_Lobby] join_or_create_preset_lobby(%s) attempting to join lobby" % [p_lobby_code])
	var join_result: Dictionary = yield(join_party_code(p_lobby_code), "completed")
	if join_result.has("error"):
		print("[Moonlight_Lobby] join_or_create_preset_lobby(%s) creating lobby" % [p_lobby_code])
		var create_result = yield(create_preset_squad(max_players, p_lobby_code), "completed")
	else:
		print("[Moonlight_Lobby] join_or_create_preset_lobby(%s) joined lobby" % [p_lobby_code])

func create_preset_squad(max_players: int, lobby_code: String):
	var result = create_party(max_players)
	if result is GDScriptFunctionState:
		yield(result, "completed")

	if Moonlight.party.is_in_squad():
		var result2: String = yield(write_squad_code(Moonlight.party.party_id, lobby_code), "completed")
		lobby_code = result2
		emit_signal("party_code_changed")
	else:
		printerr("[Moonlight_Lobby] create_lobby() failed to create lobby")

func join_party_code(_lobby_code: String) -> Dictionary:
	var query_result: Dictionary = yield(Moonlight.call_rpc("custom_lobby_query_party_id", {"lobby_code": _lobby_code}, false), "completed")
	if query_result.has("error"):
		printerr("[Moonlight_Lobby] join_lobby_code() couldnt find party_id for lobby_code: %s error: %s" % [_lobby_code, query_result["error"]])
		return query_result
	
	var party_id: = query_result.get("party_id", "") as String
	if party_id.empty():
		printerr("[Moonlight_Lobby] join_lobby_code() party_id was empty for lobby_code %s" % [_lobby_code])
		return {"error": "couldnt find party_id for lobby_code"}
	
	print("[Moonlight_Lobby] joining party_id %s from lobby_code %s" % [party_id, _lobby_code])
	var result: = yield(_join_party(party_id, PartyType.Squad), "completed") as NakamaAsyncResult
	if result.is_exception():
		var message: = result.exception.message
		return {"error": message}
	emit_signal("lobby_code_changed")
	return query_result
