extends Node
class_name Moonlight_LocalDisplayNameLabel

onready var parent_label: = get_parent() as Label

func _ready():
	Moonlight.storage.observe("account.user.display_name", self, "on_username_changed")
	Moonlight.connect("on_authentication_succeeded", self, "update_label")
	Moonlight.connect("on_log_out", self, "update_label")
	update_label()

func on_username_changed(_account):
	update_label()

func update_label():
	parent_label.text = Moonlight.storage.storage_get("account.user.display_name", "")
