extends Node
class_name Moonlight_SeasonProgressMeter

onready var parent_texture_progress: = get_parent() as TextureProgress

func _process(_delta):







	pass
