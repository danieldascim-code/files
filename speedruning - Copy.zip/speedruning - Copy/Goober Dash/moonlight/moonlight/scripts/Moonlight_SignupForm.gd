extends Control
class_name Moonlight_SignupForm

signal signup_succeeded
signal error_message
signal signup_request_sent
signal signup_request_completed
signal back_pressed

export (NodePath) var _email_label
export (NodePath) var _password_label

export (NodePath) var _username_label
export (NodePath) var _message_label
export (NodePath) var _login_form_email_label
export (NodePath) var _signup_button
export (NodePath) var _back_button

export (bool) var clear_form_on_entry: = true

onready var email_label: = get_node(_email_label) as LineEdit
onready var password_label: = get_node(_password_label) as LineEdit

onready var username_label: = get_node(_username_label) as LineEdit
onready var message_label: = get_node(_message_label) as Label
onready var login_form_email_label: = get_node(_login_form_email_label) as LineEdit
onready var signup_button: = get_node(_signup_button) as BaseButton
onready var back_button: = get_node(_back_button) as BaseButton

var should_ask_for_username: = true

const block_email_displaynames: = false



func _ready():
	
	
	
	signup_button.connect("pressed", self, "on_signup_pressed")
	signup_button.connect("visibility_changed", self, "do_clear_form_on_entry")
	password_label.connect("text_entered", self, "on_signup_pressed_arg")
	
	back_button.connect("pressed", self, "emit_signal", ["back_pressed"])
	
	
	if Moonlight.auth.is_platform_auth_supported() and Moonlight.auth.is_account_linked_to_platform():
		should_ask_for_username = false
	username_label.visible = should_ask_for_username
	
	var max_name_length: = Moonlight.cloud_config.get("max_name_length", 0) as int
	if max_name_length > 0:
		username_label.max_length = max_name_length

func clear():
	password_label.text = ""
	
	clear_error_message()
	username_label.text = ""
	enable_buttons(true)

func on_signup_pressed_arg(_argument):
	on_signup_pressed()

func on_signup_pressed():
	var email: = email_label.text.strip_edges()
	var password: = password_label.text
	
	var username: = username_label.text.strip_edges()
	
	if not should_ask_for_username:
		username = Moonlight.local_account.user.display_name
	
	clear_error_message()
	if email.empty():
		send_error_message("Email is required.")
		return
	if username.empty() and should_ask_for_username:
		send_error_message("Username is required.")
		return
	
	
	
	if email == username:
		send_error_message("Username should not be email.")
		return
	if password.empty():
		send_error_message("Password is required.")
		return
	
	
	
	
	emit_signal("signup_request_sent")
	enable_buttons(false)
	var payload: = {"email": email, "password": password, "username": username}
	var rpc_result: = yield(Moonlight.call_rpc("signup_email", payload), "completed") as Dictionary
	if rpc_result.has("error"):
		Moonlight.saved_data.set_email_credentials(email, password)
		Moonlight.saved_data.clear_custom_uuid()
	enable_buttons(true)
	
	emit_signal("signup_request_completed")
	
	if rpc_result.has("error"):
		send_error_message(rpc_result.get("error", ""))
	else:
		emit_signal("signup_succeeded")

func clear_error_message():
	if message_label != null:
		message_label.text = ""

func send_error_message(msg: String):
	var label_text: = msg
	if "desc = " in msg:
		
		

		
		




		var msg_start_token: = "desc = "
		var msg_start: = msg.find(msg_start_token) + msg_start_token.length()
		var substr_length: = - 1
		var msg_end: = msg.find("\n", msg_start)
		if msg_end >= 0:
			
			substr_length = msg_end - msg_start
		label_text = msg.substr(msg_start, substr_length)
		
	if message_label != null:
		message_label.text = label_text
	emit_signal("error_message", msg)

func do_clear_form_on_entry():
	if clear_form_on_entry and signup_button.is_visible_in_tree():
		clear()

func enable_buttons(enabled: bool):
	back_button.disabled = not enabled
	signup_button.disabled = not enabled
