extends Reference
class_name Moonlight_ELO

class Moonlight_ELOResult:
	
	var initial_rating_a: = 0.0
	var initial_rating_b: = 0.0
	var score_a: = 0.0

	
	var new_rating_a: = 0.0
	var new_rating_b: = 0.0
	var delta_a: = 0.0
	var delta_b: = 0.0

	func _init(
		_initial_rating_a: float, 
		_initial_rating_b: float, 
		_score_a: float, 
		_new_rating_a: float, 
		_new_rating_b: float, 
		_delta_a: float, 
		_delta_b: float):
		
		initial_rating_a = _initial_rating_a
		initial_rating_b = _initial_rating_b
		score_a = _score_a
		new_rating_a = _new_rating_a
		new_rating_b = _new_rating_b
		delta_a = _delta_a
		delta_b = _delta_b
	
static func round_away_from_zero(value: float) -> int:
	if value < 0.0:
		return int(floor(value))
	return int(ceil(value))

static func calculate_elo(rating_a: float, rating_b: float, score_a: float, k_factor: float, delta_factor: float) -> Moonlight_ELOResult:
	
	
	var score_b: = 1.0 - score_a
	var q_a: = pow(10.0, rating_a / delta_factor)
	var q_b: = pow(10.0, rating_b / delta_factor)
	var expected_score_a: = q_a / (q_a + q_b)
	var expected_score_b: = q_b / (q_a + q_b)

	var delta_a: = (k_factor * (score_a - expected_score_a))
	var new_rating_a: = rating_a + delta_a
	
	var delta_b: = (k_factor * (score_b - expected_score_b))
	var new_rating_b: = rating_b + delta_b

	return Moonlight_ELOResult.new(
		rating_a, 
		rating_b, 
		score_a, 
		new_rating_a, 
		new_rating_b, 
		delta_a, 
		delta_b
	)
