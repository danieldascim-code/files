extends Node
class_name Moonlight_SeasonSelector
signal selected_season_changed
onready var parent_options_button: = get_parent() as OptionButton
var selected_season: int
export  var minimum_season: = 1 setget set_minimum_season
export  var number_of_previous_options: = 4

func _ready():
	parent_options_button.connect("item_selected", self, "on_item_selected")
	Moonlight.seasons.connect("season_rollover", self, "on_season_rollover")
	
	rebuild_options()

func set_minimum_season(m: int):
	minimum_season = m
	rebuild_options()

func on_season_rollover():
	rebuild_options()
	update_selected_season()

func rebuild_options():
	
	var selected_option_index: = parent_options_button.selected
	
	
	parent_options_button.clear()
	parent_options_button.add_item("Current")
	var current_season: = Moonlight.seasons.season_number
	for i in number_of_previous_options:
		var season_number: int = current_season - 1 - i
		if season_number >= minimum_season:
			parent_options_button.add_item("Season " + str(season_number))
	
	
	
	
	if selected_option_index > 0 and selected_option_index < parent_options_button.items.size() - 1:
		parent_options_button.selected = selected_option_index + 1
	else:
		parent_options_button.selected = 0

func selected_season() -> int:
	var season_number: = Moonlight.seasons.season_number
	if parent_options_button.selected > 0:
		season_number = season_number - parent_options_button.selected
	return season_number

func on_item_selected(i: int):
	update_selected_season()

func update_selected_season():
	emit_signal("selected_season_changed")
