extends Node
class_name Moonlight_CurrentSeasonLabel

onready var parent_label: = get_parent() as Label
export  var season_format: = "Season %d"

func _ready():
	Moonlight.seasons.connect("season_rollover", self, "refresh")
	refresh()

func refresh():
	parent_label.text = season_format % [Moonlight.seasons.season_number]
