class_name Moonlight_JoinDiscordLobbyButton
extends Node

onready var parent_button: BaseButton = get_parent()

export  var max_party_size: = 32
func _ready() -> void :
	parent_button.visible = Moonlight.discord_api.is_in_discord()
	if parent_button.visible:
		parent_button.connect("pressed", self, "on_button_pressed")

func on_button_pressed():
	var discord_instance_id: = Moonlight.discord_api.discord_instance_id()
	Moonlight.lobby.join_or_create_preset_lobby(max_party_size, "discord_" + discord_instance_id)
