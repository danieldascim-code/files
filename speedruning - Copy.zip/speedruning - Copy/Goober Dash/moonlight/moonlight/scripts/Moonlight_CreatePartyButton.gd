extends Node
class_name Moonlight_CreatePartyButton

onready var parent_button: = get_parent() as BaseButton
export  var max_player_count: = 4

export  var hide_when_in_party: = true

func _ready() -> void :
	parent_button.connect("pressed", self, "on_parent_button_pressed")
	Moonlight.party.connect("party_id_changed", self, "on_party_id_changed")
	if hide_when_in_party:
		parent_button.visible = not Moonlight.party.is_in_party()
		print("visible: %s" % [parent_button.visible])

func on_party_id_changed(party_id: String):
	if hide_when_in_party:
		parent_button.visible = not Moonlight.party.is_in_party()

func on_parent_button_pressed():
	if Moonlight.party.is_in_party():
		return
	parent_button.disabled = true
	var r = Moonlight.party.create_party(max_player_count)
	if r is GDScriptFunctionState:
		yield(r, "completed")
	parent_button.disabled = false
