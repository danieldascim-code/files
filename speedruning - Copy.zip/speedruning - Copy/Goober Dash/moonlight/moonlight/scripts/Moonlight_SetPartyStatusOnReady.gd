extends Node
class_name Moonlight_SetPartyStatusOnReady

export  var status_string: = ""
export (int, "All", "Squad", "Lobby") var party_type

func _ready():
	if _should_set_party_status():
		Moonlight.party.merge_local_member_data({"status": status_string})
	Moonlight.party.connect("party_id_changed", self, "on_party_id_changed")

func on_party_id_changed(_party_id: String):
	if Moonlight.party.is_in_party():
		Moonlight.party.merge_local_member_data({"status": status_string})

func _should_set_party_status() -> bool:
	if Moonlight.party == null:
		printerr("[Moonlight_SetPartyStatusOnReady] cant set status because party is null.")
	match party_type:
		1:
			return Moonlight.party.is_in_squad()
		2:
			return Moonlight.party.is_in_lobby()
	return Moonlight.party.is_in_party()
