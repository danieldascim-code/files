extends Node
class_name Moonlight_AndroidWinterpixelUtils

var api = null

func _init():
	if OS.has_feature("Android"):
		if Engine.has_singleton("WinterpixelUtils"):
			api = Engine.get_singleton("WinterpixelUtils")
		else:
			printerr("[Moonlight_AndroidWinterpixelUtils] Moonlight_AndroidWinterpixelUtils support is not enabled.")
	


func request_review():
	if api:
		api.requestReview()
