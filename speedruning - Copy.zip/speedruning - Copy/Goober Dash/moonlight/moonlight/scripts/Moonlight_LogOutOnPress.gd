extends Node
class_name Moonlight_LogOutOnPress

onready var parent_button: = get_parent() as BaseButton

func _ready() -> void :
	parent_button.connect("pressed", self, "on_button_pressed")

func on_button_pressed():
	Moonlight.auth.log_out()
