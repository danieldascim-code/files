extends Node

class_name Moonlight_WalletLabel

export  var wallet_key: = ""
export  var default_value: = 0

onready var parent_label: = get_parent() as Label

func _ready() -> void :
	parent_label.text = str(default_value)
	if Moonlight.is_logged_in():
		refresh()
	
	Moonlight.connect("on_authentication_succeeded", self, "refresh")
	Moonlight.storage.observe("wallet." + wallet_key, self, "on_wallet_changed")

func on_wallet_changed(d: Moonlight_StorageDiff):
	refresh()

func refresh():
	parent_label.text = str(Moonlight.storage.storage_get("wallet." + wallet_key, default_value))
