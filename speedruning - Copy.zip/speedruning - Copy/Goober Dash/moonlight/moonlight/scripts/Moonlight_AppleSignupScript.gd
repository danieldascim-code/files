extends Node
class_name MoonlightAppleSignupScript

signal success
signal error

export  var signup: bool = true
export  var req_username: bool = true


func sign_in():
	print("MoonlightAppleSignupScript sign_in")
	var apple_auth: = Moonlight.auth as Moonlight_AuthApple
	if apple_auth == null:
		printerr("[MoonlightAppleSignupScript] sign_in() does not have Moonlight_AuthApple")
		return
	if not apple_auth.is_connected("error", self, "error"):
		apple_auth.connect("error", self, "error")
		apple_auth.connect("success", self, "success")
	apple_auth.signup_apple()

func link_apple_account_with_username_prompt(dict: Dictionary, custom_error_string: String = ""):
	var text_entry_dialog: UITextEntryDialog = GoodResourceLoader.load_resource(GoodSceneRegistry.text_entry_dialog_scene).instance()
	text_entry_dialog.title_text = "Enter your username"
	get_tree().current_scene.add_child(text_entry_dialog)
	var display_name: = yield(text_entry_dialog, "text_entered") as String
	
	var payload: = {"username": display_name, "token": dict["identityToken"]}
	var result: Dictionary = yield(Moonlight.call_rpc("signup_apple", payload), "completed")
	print("[MoonlightAppleSignupScript] rpc response %s " % [result])
	if result.has("error"):
		if not custom_error_string.empty():
			emit_signal("error", custom_error_string)
		else:
			emit_signal("error", "Apple ID sign in failed.  If this Apple ID is linked to another existing account, please try logging in instead.")
		Moonlight.saved_data.clear_apple_auth_credentials()
		return
	
	if result.has("customappledeviceid"):
		Moonlight.saved_data.set_apple_device_id_credentials(result["customappledeviceid"])
	else:
		Moonlight.saved_data.set_apple_auth_credentials(dict["email"], dict["identityToken"])
	Moonlight.saved_data.clear_custom_uuid()
	emit_signal("success")
	
func link_apple_account(dict: Dictionary, custom_error_string: String = ""):
	var payload: = {"token": dict["identityToken"]}
	var result: Dictionary = yield(Moonlight.call_rpc("signup_apple", payload), "completed")
	print("[MoonlightAppleSignupScript] rpc response %s " % [result])
	if result.has("error"):
		if not custom_error_string.empty():
			emit_signal("error", custom_error_string)
		else:
			emit_signal("error", "Apple ID sign in failed.  If this Apple ID is linked to another existing account, please try logging in instead.")
		Moonlight.saved_data.clear_apple_auth_credentials()
		return
	
	if result.has("customappledeviceid"):
		Moonlight.saved_data.set_apple_device_id_credentials(result["customappledeviceid"])
	else:
		Moonlight.saved_data.set_apple_auth_credentials(dict["email"], dict["identityToken"])
	Moonlight.saved_data.clear_custom_uuid()
	emit_signal("success")
	
func error(string: String):
	print("[MoonlightAppleSignupScript] error %s" % [string])
	emit_signal("error", string)
	
func success(dict: Dictionary):
	print("[MoonlightAppleSignupScript] success\n%s" % [dict])
	if signup:
		if req_username:
			link_apple_account_with_username_prompt(dict)
		else:
			link_apple_account(dict)
	else:
		var apple_auth: = Moonlight.auth as Moonlight_AuthApple
		var client_version: = Moonlight.get_client_version()
		var new_session = yield(Moonlight.client.authenticate_apple_async(dict["identityToken"], null, false, {"client_version": client_version}), "completed")
		if new_session == null or new_session.is_exception() or not new_session.is_valid():
			if Moonlight.auth.is_guest_account():
				
				if req_username:
					link_apple_account_with_username_prompt(dict, "Unable to login to account.")
				else:
					link_apple_account(dict, "Unable to login to account.")
			else:
				emit_signal("error", "Unable to login to account.")
				Moonlight.saved_data.clear_apple_auth_credentials()
		else:
			
			emit_signal("success")
			Moonlight.auth.log_out()
			Moonlight.saved_data.set_apple_auth_credentials(dict["email"], dict["identityToken"])
			
			get_tree().change_scene(GoodSceneRegistry.connecting_scene)
