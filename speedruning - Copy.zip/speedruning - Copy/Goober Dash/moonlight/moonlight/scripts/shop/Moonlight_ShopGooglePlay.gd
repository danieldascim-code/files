extends Moonlight_Shop
class_name Moonlight_ShopGooglePlay

const api_methods: = ["startConnection", "endConnection", "confirmPriceChange", "purchase", "updateSubscription", "querySkuDetails", "isReady", "getConnectionState", "queryPurchases", "acknowledgePurchase", "consumePurchase"]
const product_type_iap: = "inapp"
const product_type_subs: = "subs"

var api = null
var google_play_products_loaded: = false

func _init():
	print("[Moonlight_ShopGooglePlay] _init")
	if Engine.has_singleton("GodotGooglePlayBilling"):
		_init_api()
	else:
		printerr("[Moonlight_ShopGooglePlay] GooglePlayBilling support is not enabled.")


func buy_product(sku: String):
	print("[Moonlight_ShopGooglePlay] buy_product(%s)" % [sku])
	var purchase_result: = api_purchase(sku)
	print("[Moonlight_ShopGooglePlay] buy_product(%s) returned %s" % [sku, purchase_result])

func query_products():
	var product_skus: = skus.keys()
	print("[Moonlight_ShopGooglePlay] query_products() %s" % [product_skus])
	api_query_sku_details(product_skus, product_type_iap)

func query_purchases():
	print("[Moonlight_ShopGooglePlay] query_purchases()")
	api_query_purchases(product_type_iap)

func load_platform_product_data():
	print("[Moonlight_ShopGooglePlay] load_platform_product_data()")
	if not api_is_ready():
		print("[Moonlight_ShopGooglePlay] load_platform_product_data() not api_is_ready(). starting connection")
		api_start_connection()
	else:
		print("[Moonlight_ShopGooglePlay] load_platform_product_data() api_is_ready")
		_on_connected()

func are_products_loaded() -> bool:
	return google_play_products_loaded


func _process_purchases(purchases: Array):
	
	
	
	
	for purchase in purchases:
		if purchase.get("purchase_state", - 1) == 1:
			
			if not purchase.has("is_acknowledged") or not purchase.has("original_json"):
				printerr("[Moonlight_ShopGooglePlay] purchase data missing required keys")
				continue
			
			var is_acknowledged: = purchase["is_acknowledged"] as bool
			if not is_acknowledged:
				var original_json: = purchase["original_json"] as String
				var formatted_receipt: = {"json": original_json}
				var receipt: = to_json(formatted_receipt)
				var sku: String = purchase.sku
				var product_id: = get_product_id_for_sku(sku)
				if not products.has(product_id):
					printerr("[Moonlight_ShopGooglePlay] purchased unknown product_id %s" % [purchase.sku])
					continue
				
				var shop_product: = products.get(product_id) as Moonlight_ShopProduct
				if shop_product == null:
					printerr("[Moonlight_ShopGooglePlay] purchased invalid product_id %s" % [product_id])
					continue
				
				var rpc_payload: = {
					"platform": "google", 
					"receipt": receipt
				}
				print("[Moonlight_ShopGooglePlay] sending receipt\n%s\nfor purchase:\n%s\n" % [receipt, purchase])
				var rpc_response: Dictionary = yield(_validate_receipt(receipt, "google"), "completed")
				if rpc_response.has("error"):
					printerr("[Moonlight_ShopGooglePlay] rpc failed %s" % [rpc_response])
					continue
				else:
					print("[Moonlight_ShopGooglePlay] purchase rpc succeeded")
				
				if shop_product.is_consumable or shop_product.is_deal:
					print("[Moonlight_ShopGooglePlay] product_id %s is consumable, consuming" % [product_id])
					api_consume_purchase(purchase.purchase_token)
				else:
					print("[Moonlight_ShopGooglePlay] product_id %s is not consumable, acknowledging" % [product_id])
					api_acknowledge_purchase(purchase.purchase_token)
				
				emit_signal("product_purchase_complete", sku)

func _parse_product(product_data: Dictionary):
	var sku: String = product_data.get("sku", "")
	var product_id: = get_product_id_for_sku(sku)
	if product_id != null and not product_id.empty() and products.has(product_id):
		var shop_product: = products[product_id] as Moonlight_ShopProduct
		var platform_name: = product_data.get("name", "") as String
		var description = product_data.get("description", "") as String
		var price = product_data.get("price", "") as String
		var currency_code = product_data.get("price_currency_code", "") as String
		shop_product._apply_platform_properties(platform_name, description, price, currency_code)
	else:
		printerr("[Moonlight_ShopGooglePlayer] couldnt find product with product_id: %s" % [product_id])

func _print_unsupported_error():
	printerr("[Moonlight_ShopGooglePlay] GooglePlayBilling is not supported.")


func _on_connected():
	print("[Moonlight_ShopGooglePlay] on_connected")
	query_products()

func _on_disconnected():
	print("[Moonlight_ShopGooglePlay] _on_disconnected")

func _on_connect_error(response_id: int, debug_message: String):
	print("[Moonlight_ShopGooglePlay] _on_connect_error(%s, %s)" % [response_id, debug_message])

func _on_purchases_updated(purchases: Array):
	print("[Moonlight_ShopGooglePlay] _on_purchases_updated()")
	_process_purchases(purchases)

func _on_purchase_error(response_id: int, debug_message: String):
	
	if response_id != 1:
		print("[Moonlight_ShopGooglePlay] _on_purchase_error(%s, %s)" % [response_id, debug_message])

func _on_query_purchases_response(response: Dictionary):
	
	
	
	
	
	
	
	
	
	if response.get("status") == 0:
		var purchases = response.get("purchases") as Array
		if purchases != null:
			_process_purchases(purchases)
		else:
			printerr("[Moonlight_ShopGooglePlay] _on_query_purchases_response() error in purchases format response %s" % [response])
	else:
		printerr("[Moonlight_ShopGooglePlay] _on_query_purchases_response() error response %s" % [response])

func _on_sku_details_query_completed(product_data_array: Array):
	print("[Moonlight_ShopGooglePlay] _on_sku_details_query_completed %s" % [product_data_array.size()])
	
	
	
	
	
	
	for product_data_object in product_data_array:
		var product_data: = product_data_object as Dictionary
		_parse_product(product_data)
	
	query_purchases()
	
	print("[Moonlight_ShopGooglePlay] products loaded! %s" % [products.size()])
	google_play_products_loaded = true
	emit_signal("products_loaded")

func _on_sku_details_query_error(response_id: int, message: String, skus: Array):
	print("[Moonlight_ShopGooglePlay] _on_sku_details_query_error(%s, %s, %s)" % [response_id, message, skus])

func _on_purchase_acknowledged(purchase_token: String):
	print("[Moonlight_ShopGooglePlay] _on_purchase_acknowledged(%s)" % [purchase_token])

func _on_purchase_consumed(purchase_token: String):
	print("[Moonlight_ShopGooglePlay] _on_purchase_consumed(%s)" % [purchase_token])

func _on_purchase_consumption_error(response_id: int, debug_message: String, purchase_token: String):
	print("[Moonlight_ShopGooglePlay] _on_purchase_consumption_error(%s, %s, %s)" % [response_id, debug_message, purchase_token])


func _init_api():
	api = Engine.get_singleton("GodotGooglePlayBilling")
	if not api:
		_print_unsupported_error()
		return
	
	var e = api.connect("connected", self, "_on_connected")
	assert (e == OK)
	
	e = api.connect("disconnected", self, "_on_disconnected")
	assert (e == OK)
	
	e = api.connect("connect_error", self, "_on_connect_error")
	assert (e == OK)
	
	e = api.connect("purchases_updated", self, "_on_purchases_updated")
	assert (e == OK)
	
	e = api.connect("purchase_error", self, "_on_purchase_error")
	assert (e == OK)
	
	e = api.connect("query_purchases_response", self, "_on_query_purchases_response")
	assert (e == OK)
	
	e = api.connect("sku_details_query_completed", self, "_on_sku_details_query_completed")
	assert (e == OK)
	
	e = api.connect("sku_details_query_error", self, "_on_sku_details_query_error")
	assert (e == OK)
	
	e = api.connect("purchase_acknowledged", self, "_on_purchase_acknowledged")
	assert (e == OK)
	
	e = api.connect("purchase_acknowledgement_error", self, "_on_purchase_acknowledgement_error")
	assert (e == OK)
	
	e = api.connect("purchase_consumed", self, "_on_purchase_consumed")
	assert (e == OK)
	
	e = api.connect("purchase_consumption_error", self, "_on_purchase_consumption_error")
	assert (e == OK)
	
















func api_start_connection():
	if api:
		api.startConnection()
	else:
		_print_unsupported_error()

func api_end_connection():
	if api:
		api.endConnection()
	else:
		_print_unsupported_error()

func api_confirm_price_change(sku: String) -> Dictionary:
	if api:
		return api.confirmPriceChange(sku)
	else:
		_print_unsupported_error()
		return {}

func api_purchase(sku: String) -> Dictionary:
	if api:
		return api.purchase(sku)
	else:
		_print_unsupported_error()
		return {}

func api_update_subscription(old_token: String, sku: String, proration_mode: int) -> Dictionary:
	if api:
		return api.updateSubscription(old_token, sku, proration_mode)
	else:
		_print_unsupported_error()
		return {}

func api_query_sku_details(skus: Array, type: String):
	if api:
		return api.querySkuDetails(skus, type)
	else:
		_print_unsupported_error()

func api_is_ready() -> bool:
	if api:
		return api.isReady()
	return false

func api_get_connection_state() -> int:
	if api:
		return api.getConnectionState()
	return - 1

func api_query_purchases(type: String):
	if api:
		api.queryPurchases(type)

func api_acknowledge_purchase(purchase_token: String):
	if api:
		api.acknowledgePurchase(purchase_token)
	else:
		_print_unsupported_error()

func api_consume_purchase(purchase_token: String):
	if api:
		api.consumePurchase(purchase_token)
	else:
		_print_unsupported_error()
