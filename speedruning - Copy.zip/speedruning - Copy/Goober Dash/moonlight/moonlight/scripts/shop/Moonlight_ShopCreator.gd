extends Reference
class_name Moonlight_ShopCreator



const moonlight_shopgoogleplay: = "res://moonlight/moonlight/scripts/shop/Moonlight_ShopGooglePlay.gd"
const moonlight_shopapple: = "res://moonlight/moonlight/scripts/shop/Moonlight_ShopApple.gd"
const moonlight_shopsteam: = "res://moonlight/moonlight/scripts/shop/Moonlight_ShopSteam.gd"
const moonlight_shopxsolla: = "res://moonlight/moonlight/scripts/shop/Moonlight_ShopXsolla.gd"
const moonlight_shopdiscord: = "res://moonlight/moonlight/scripts/shop/Moonlight_ShopDiscord.gd"

static func create_shop() -> Moonlight_Shop:
	var should_test_steam: = OS.has_feature("editor") and Engine.has_singleton("Steam")
	
	if OS.has_feature("Android"):
		if ResourceLoader.exists(moonlight_shopgoogleplay, "Script"):
			var s: = load(moonlight_shopgoogleplay) as Script
			if s != null:
				return s.new()
	elif should_test_steam or OS.has_feature("steam"):
		if ResourceLoader.exists(moonlight_shopsteam, "Script"):
			var s: = load(moonlight_shopsteam) as Script
			if s != null:
				return s.new()
	elif OS.has_feature("iOS") or OS.has_feature("OSX"):
		if ResourceLoader.exists(moonlight_shopapple, "Script"):
			var s: = load(moonlight_shopapple) as Script
			if s != null:
				return s.new()
	elif OS.has_feature("web") and HTMLRequestParams.get_request_params().has("instance_id"):
		if ResourceLoader.exists(moonlight_shopdiscord, "Script"):
			var s: = load(moonlight_shopdiscord) as Script
			if s != null:
				return s.new()
	elif (OS.has_feature("xsolla")):
		if ResourceLoader.exists(moonlight_shopxsolla, "Script"):
			var s: = load(moonlight_shopxsolla) as Script
			if s != null:
				return s.new()
	
	return Moonlight_Shop.new()
