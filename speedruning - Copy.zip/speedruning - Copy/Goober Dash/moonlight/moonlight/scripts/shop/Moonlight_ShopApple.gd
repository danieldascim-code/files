extends Moonlight_Shop
class_name Moonlight_ShopApple

const api_methods: = ["request_product_info", "restore_purchases", "purchase", "get_pending_event_count", "pop_pending_event", "finish_transaction", "set_auto_finish_transaction", "request_review"]
const product_type_iap: = "inapp"
const product_type_subs: = "subs"

var api: Object = null
var products_loaded: = false

func _init():
	print("[Moonlight_ShopApple] _init")
	if Engine.has_singleton("InAppStore"):
		_init_api()
	else:
		printerr("[Moonlight_ShopApple] InAppStore not compiled in.")
		return

func run_callbacks():
	if api == null:
		return
	
	while api.get_pending_event_count() > 0:
		var event = api.pop_pending_event()
		var event_dict: = event as Dictionary
		if (event_dict):
			if event_dict["type"] == "product_info":
				if event_dict["result"] == "error":
					printerr("[Moonlight_ShopApple] product_info error(%s)" % [event_dict["error"]])
				elif event_dict["result"] == "ok":
					print("[Moonlight_ShopApple] product_info %s " % [event_dict])
					var ids: Array = event_dict["ids"]
					if ids != null:
						for i in ids.size():
							var sku: String = ids[i]
							var title: String = event_dict["titles"][i]
							var desc: String = event_dict["descriptions"][i]
							var price: String = event_dict["prices"][i]
							var localized_price: String = event_dict["localized_prices"][i]
							var currency_code: String = event_dict["currency_codes"][i]
							var product_id: = get_product_id_for_sku(sku)
							if products.has(product_id):
								var shop_product: = products[product_id] as Moonlight_ShopProduct
								shop_product._apply_platform_properties(title, desc, localized_price, currency_code)
							else:
								printerr("[Moonlight_ShopApple] product with product_id %s and sku %s not found" % [product_id, sku])
					products_loaded = true
					emit_signal("products_loaded")
						
			elif event_dict["type"] == "purchase" or event_dict["type"] == "restore":
				var product_id: String = event_dict["product_id"]
				if event_dict["result"] == "ok":
					
					var receipt: String = event_dict["receipt"]["receipt"]
					print("[Moonlight_ShopApple] sending receipt\n%s\nfor purchase:\n%s\n" % [receipt])
					var rpc_response: Dictionary = yield(_validate_receipt(receipt, "apple"), "completed")
					if rpc_response.has("error"):
						print("[Moonlight_ShopApple] failed to validate receipt: " + str(rpc_response))
						emit_signal("product_purchase_error", product_id)
					else:
						print("[Moonlight_ShopApple] successfully validated receipt")
						emit_signal("product_purchase_complete", product_id)
				elif event_dict["result"] == "progress":
					
					pass
				elif event_dict["result"] == "error":
					printerr("[Moonlight_ShopApple] purchase error(%s)" % [event_dict["error"]])
					emit_signal("product_purchase_error", product_id)
				elif event_dict["result"] == "unhandled":
					printerr("[Moonlight_ShopApple] purchase unhandled")
					emit_signal("product_purchase_error", product_id)

func restore_purchases():
	if api != null:
		api.restore_purchases()


func buy_product(product_id: String):
	print("[Moonlight_ShopApple] buy_product(%s)" % [product_id])
	var err = api.purchase({"product_id": product_id})
	if err != OK:
		printerr("[Moonlight_ShopApple] buy_product error, unimplemented (%d)" % [int(err)])
		emit_signal("product_purchase_error", product_id)


func load_platform_product_data():
	print("[Moonlight_ShopApple] load_platform_product_data()")
	var product_ids_dict: = {
		"product_ids": skus.keys()
	}
	
	if api != null:
		api.set_auto_finish_transaction(true)
		api.request_product_info(product_ids_dict)

func are_products_loaded() -> bool:
	return products_loaded

func _print_unsupported_error():
	printerr("[Moonlight_ShopApple] Apple billing is not supported.")
	
func request_review():
	if (api):
		api.request_review()

func _init_api():
	api = Engine.get_singleton("InAppStore")
	if not api:
		_print_unsupported_error()
		return
	Moonlight.get_tree().connect("idle_frame", self, "run_callbacks")

