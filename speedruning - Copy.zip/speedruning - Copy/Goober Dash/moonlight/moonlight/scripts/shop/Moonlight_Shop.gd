extends Reference
class_name Moonlight_Shop



signal products_loaded()


signal product_purchase_error(sku)
signal product_purchase_progress(sku)
signal product_purchase_complete(sku)

var products: = {}
var shop_data: = {}
var skus: = {}

func _parse_shop_data(storage_data: Dictionary):
	if storage_data.has("shop"):
		var new_shop_data: Dictionary = storage_data.get("shop", {})
		if new_shop_data.hash() != shop_data.hash() or not are_products_loaded():
			shop_data = new_shop_data.duplicate(true)
			products.clear()
			skus.clear()
			
			skus = shop_data.get("skus", {}).duplicate(true)
			var products_data: Dictionary = shop_data.get("products", {})
			for product_id in products_data:
				var product_data: Dictionary = products_data[product_id]
				products[product_id] = Moonlight_ShopProduct.new(product_id, product_data)
			emit_signal("products_loaded")

func load_platform_product_data():
	if not OS.has_feature("editor"):
		printerr("[Moonlight_Shop] load_platform_product_data not overridden in class: %s" % [self])

func buy_product(sku: String):
	
	pass

func buy_virtual_product(product_id: String):
	
	var result: Dictionary = yield(Moonlight.call_rpc("purchase_virtual_product", {"product_id": product_id}, true), "completed")

func buy_product_id(product_id: String):
	if not products.has(product_id):
		printerr("[Moonlight_Shop] buy_product_id couldnt find product with product_id: %s" % [product_id])
		return
	var product: Moonlight_ShopProduct = products[product_id]
	if product.has_wallet_cost:
		buy_virtual_product(product_id)
	else:
		var sku: = get_sku_for_product_id(product_id)
		print("[Moonlight_Shop] buy_product_id(%s) buying sku %s" % [product_id, sku])
		buy_product(sku)

func _validate_receipt(receipt: String, platform: String) -> Dictionary:
	var rpc_response: Dictionary = yield(Moonlight.call_rpc("validate_receipt", {"receipt": receipt, "platform": platform}), "completed")
	return rpc_response

func restore_purchases():
	
	
	pass

func active_deal_ids() -> Array:
	var active_deals: = []
	for product_id in Moonlight.shop.products:
		var product: = Moonlight.shop.products[product_id] as Moonlight_ShopProduct
		if product.is_active_deal() and not get_sku_for_product_id(product.product_id).empty():
			active_deals.append(product_id)
	return active_deals

func get_product_id_for_sku(sku: String) -> String:
	if not skus.has(sku):
		printerr("[Moonlight_Shop] get_product_id_for_sku() couldnt find product_id for sku: " + sku)
		return ""
	var product_id: = skus[sku] as String
	return product_id

func get_product_for_sku(sku: String) -> Moonlight_ShopProduct:
	var product_id: = get_product_id_for_sku(sku)
	return products.get(product_id)

func get_sku_for_product_id(product_id: String) -> String:
	for sku in skus:
		var sku_product_id: = skus[sku] as String
		if sku_product_id == product_id:
			return sku
	
	return ""

func are_products_loaded() -> bool:
	if not OS.has_feature("editor"):
		printerr("[Moonlight_Shop] are_products_loaded not overridden in class: %s" % [self])
	return false
