extends Node
class_name MoonlightShop_DealAlertIcon

onready var parent: = get_parent() as Control

func _ready() -> void :
	_refresh()

func _process(delta: float) -> void :
	_refresh()

func _refresh():
	parent.visible = Moonlight.shop.has_deal_available() and not Moonlight.discord_api.discord_platform_is_mobile()
