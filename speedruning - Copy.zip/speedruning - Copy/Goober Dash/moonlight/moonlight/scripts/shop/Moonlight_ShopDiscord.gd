extends Moonlight_Shop

var discord_sku_to_internal_sku: = {}
var discord_products_loaded: = false

func load_platform_product_data():
	discord_sku_to_internal_sku.clear()
	var discord_sku_map: Dictionary = yield(Moonlight.call_rpc("discord_get_sku_map", {}, false), "completed")
	if discord_sku_map.has("error"):
		printerr("[Moonlight_ShopDiscord] failed to load sku map")
		return
	
	print("[Moonlight_ShopDiscord] retrieved internal sku map")
	discord_sku_to_internal_sku = discord_sku_map
	
	print("[Moonlight_ShopDiscord] calling discordLoadSkus()")
	JavaScript.eval("discordLoadSkus()")
	print("[Moonlight_ShopDiscord] yielding for callback")
	var sku_datas: Dictionary = yield(DiscordAuth, "on_discordSkusLoaded")
	print("[Moonlight_ShopDiscord] on_discordSkusLoaded() %s" % sku_datas)
	var discord_skus: Array = sku_datas.get("skus", [])
	for _discord_sku_data in discord_skus:
		var discord_sku_data: Dictionary = _discord_sku_data
		var discord_sku: String = discord_sku_data.get("id", "")
		if not discord_sku_to_internal_sku.has(discord_sku):
			printerr("[Moonlight_ShopDiscord] couldnt map discord sku %s to internal sku" % [discord_sku])
			continue
		var internal_sku: String = discord_sku_to_internal_sku[discord_sku]
		var product_id: = get_product_id_for_sku(internal_sku)
		if not products.has(product_id):
			
			continue
		var product: Moonlight_ShopProduct = products[product_id]
		
		var discord_price: Dictionary = discord_sku_data.get("price", {})
		var discord_price_value: float = discord_price.get("amount", 0.0)
		var discord_price_currency: String = discord_price.get("currency", "")
		var fallback_price: = "%.2f %s" % [discord_price_value / 100.0, discord_price_currency.to_upper()]
		
		
		var formatted_price: String = discord_sku_data.get("formatted_price", fallback_price)
		
		product._apply_platform_properties("", "", formatted_price, discord_price_currency)
		print("[Moonlight_ShopDiscord] processed product: %s with price: %s" % [product.product_id, product.product_price])
	
	print("[Moonlight_ShopDiscord] loaded %s products" % [discord_skus.size()])
	discord_products_loaded = true
	emit_signal("products_loaded")
	DiscordAuth.async_process_purchases()

func buy_product(sku: String):
	var discord_sku: = ""
	for _discord_sku in discord_sku_to_internal_sku:
		if sku == discord_sku_to_internal_sku[_discord_sku]:
			discord_sku = _discord_sku
	if discord_sku.empty():
		printerr("[Moonlight_ShopDiscord] buy_product(%s) couldnt map sku to discord sku" % [sku])
		return
	
	JavaScript.eval("discordPurchaseSku(\'%s\')" % [discord_sku])

func are_products_loaded():
	return discord_products_loaded
