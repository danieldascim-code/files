extends Moonlight_Shop
class_name Moonlight_ShopXsolla

const api_methods: = ["request_product_info", "restore_purchases", "purchase", "get_pending_event_count", "pop_pending_event", "finish_transaction", "set_auto_finish_transaction"]
const product_type_iap: = "inapp"
const product_type_subs: = "subs"

var api: Object = null
var products_loaded: = false


func buy_product(product_id: String):
	print("[Moonlight_ShopXsolla] buy_product(%s)" % [product_id])
	
	var payload: = {"product_id": product_id, "platform": "default"}
	if (AdManager.get_ad_driver() == "crazygames"):
		payload["platform"] = "crazygames"
	var rpc_result: = yield(Moonlight.client.rpc_async(Moonlight.session, "rpc_xsolla_get_access_token", to_json(payload)), "completed") as NakamaAPI.ApiRpc
		
	if rpc_result != null and not rpc_result.is_exception():
		var access_token_response: = parse_json(rpc_result.payload) as Dictionary
		if access_token_response:
			
			var token = access_token_response.token
			var sandbox = access_token_response.sandbox
			WPLog.logi("[Moonlight_ShopXsolla] rpc_xsolla_get_access_token %s" % [token])
			
			var is_sandbox: String = "false"
			if sandbox:
				is_sandbox = "true"
			
			if OS.has_feature("xsolla"):
				var js_eval: String = "xsollaBuy(\"" + token + "\", " + is_sandbox + ", \"" + product_id + "\")"
				JavaScript.eval(js_eval)
			
		else:
			WPLog.loge("[Moonlight_ShopXsolla] rpc_xsolla_get_access_token couldnt parse json: %s" % [rpc_result.payload])
	

func load_platform_product_data():
	print("[Moonlight_ShopXsolla] load_platform_product_data()")
	var product_ids_dict: = {
		"product_ids": skus.duplicate()
	}
	
	var payload: = {"platform": "default"}
	if (AdManager.get_ad_driver() == "crazygames"):
		payload["platform"] = "crazygames"
	var rpc_result: = yield(Moonlight.client.rpc_async(Moonlight.session, "rpc_xsolla_get_virtual_items", to_json(payload)), "completed") as NakamaAPI.ApiRpc
		
	if rpc_result != null and not rpc_result.is_exception():
		var virtual_items_response: = parse_json(rpc_result.payload) as Dictionary
		if virtual_items_response:
			
			var items_array = virtual_items_response.items
			WPLog.logi("[Moonlight_ShopXsolla] rpc_xsolla_get_virtual_items %s" % [items_array])
			
			for product_data in items_array:
				var sku = product_data["sku"]
				var product_id: = get_product_id_for_sku(sku)
				if product_id != null and not product_id.empty() and products.has(product_id):
					var shop_product: = products[product_id] as Moonlight_ShopProduct
					var platform_name: = product_data.get("name", "") as String
					var description = product_data.get("description", "") as String
					var price: Dictionary = product_data.get("price") as Dictionary
					var price_string: = ""
					var currency_code: = ""
					if price:
						price_string = price.get("amount", "") as String
						currency_code = price.get("currency", "") as String
					shop_product._apply_platform_properties(platform_name, description, price_string, currency_code)
				else:
					
					pass
			products_loaded = true
			emit_signal("products_loaded")
		else:
			WPLog.loge("[Moonlight_ShopXsolla] rpc_xsolla_get_virtual_items no dict")
	else:
		WPLog.loge("[Moonlight_ShopXsolla] rpc_xsolla_get_virtual_items couldnt parse json: %s" % [rpc_result.payload])

func are_products_loaded() -> bool:
	return products_loaded
