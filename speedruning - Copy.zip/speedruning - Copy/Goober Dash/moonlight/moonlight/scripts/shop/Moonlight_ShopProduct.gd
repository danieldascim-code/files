extends Reference
class_name Moonlight_ShopProduct


var product_data: = {}
var product_id: = ""
var product_name: = ""
var is_consumable: = false
var is_deal: = false
var deal_duration: = 0
var deal_end: = 0
var deal_start: = 0
var has_wallet_cost: = false
var wallet_cost: = {}
var hidden: = false


var product_platform_name: = ""
var product_description: = ""
var product_price: = ""
var product_currency_code: = ""

func is_time_limited_deal() -> bool:
	return is_active_deal() and deal_start != 0 and deal_end != 0

func is_active_deal() -> bool:
	if hidden:
		return false
	if not is_deal:
		return false
	if deal_start == 0 or deal_end == 0:
		return true
	var current_time: = OS.get_unix_time()
	return current_time >= deal_start and current_time <= deal_end

func _init(_product_id: String, _nakama_product_data: Dictionary):
	product_id = _product_id
	product_data = _nakama_product_data.duplicate(true)
	product_name = _nakama_product_data.get("name", "")
	is_consumable = _nakama_product_data.get("is_consumable", "")
	is_deal = _nakama_product_data.get("is_deal", false)
	deal_duration = _nakama_product_data.get("deal_duration", 0)
	deal_end = _nakama_product_data.get("deal_end", 0)
	deal_start = _nakama_product_data.get("deal_start", 0)
	wallet_cost = _nakama_product_data.get("wallet_cost", {})
	hidden = _nakama_product_data.get("hidden", false)
	has_wallet_cost = not wallet_cost.empty()

func _apply_platform_properties(name: String, description: String, price: String, currency_code: String):
	product_platform_name = name
	product_description = description
	product_price = price
	product_currency_code = currency_code
