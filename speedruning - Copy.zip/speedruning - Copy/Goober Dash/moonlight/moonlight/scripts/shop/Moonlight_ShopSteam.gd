extends Moonlight_Shop
class_name Moonlight_ShopSteam

var steam_products_loaded: = false

func _init():
	print("[Moonlight_ShopSteam] _init")
	if not Engine.has_singleton("Steam"):
		printerr("[Moonlight_ShopSteam] _init Steam singleton does not exist")

	if not Steam.isSteamRunning():
		printerr("[Moonlight_ShopSteam] _init steam not initialized")
	
	if not Steam.loggedOn():
		printerr("[Moonlight_ShopSteam] _init not logged in to Steam server! shop will not work")
	
	Steam.connect("microstransaction_auth_response", self, "_microtxn_authorization_response")
	Moonlight.connect("on_authentication_succeeded", self, "on_authentication_succeeded")

func on_authentication_succeeded():
	_fetch_steam_products()

func load_platform_product_data():
	pass

func buy_product(sku: String):
	var steam_id: = Steam.getSteamID()
	var language: = Steam.getCurrentGameLanguage()
	var payload: = {
		"steam_id": str(steam_id), 
		"language_code": language, 
		"sku": sku
	}
	print("[Moonlight_ShopSteam] buy_product steam_shop_begin_purchase(%s)" % [sku])
	var rpc_result: Dictionary = yield(Moonlight.call_rpc("steam_shop_begin_purchase", payload, false), "completed")
	if rpc_result.has("error"):
		printerr("[Moonlight_ShopSteam] buy_product steam_shop_begin_purchase(%s) failed: %s" % [sku, rpc_result])
	else:
		print("[Moonlight_ShopSteam] buy_product steam_shop_begin_purchase(%s) succeeded" % [sku])

func are_products_loaded() -> bool:
	return steam_products_loaded

func _fetch_steam_products() -> void :
	var rpc_result: Dictionary = yield(Moonlight.call_rpc("steam_shop_get_skus", {}, false), "completed")
	if rpc_result.has("error"):
		printerr("[Moonlight_ShopSteam] _fetch_steam_products error %s" % [rpc_result])
		return
		
	var currency: String = rpc_result.get("currency", "USD")
	var steam_products: Dictionary = rpc_result.get("products")
	
	for sku in steam_products:
		var product_data: Dictionary = steam_products[sku]
		var product_id: = get_product_id_for_sku(sku)
		_parse_product(product_id, product_data, currency)
	
	steam_products_loaded = true
	emit_signal("products_loaded")

func _parse_product(product_id: String, product_data: Dictionary, currency: String):
	var shop_product: = products[product_id] as Moonlight_ShopProduct
	if shop_product:
		var name: = ""
		var description: = ""
		var price: = product_data.get("price_strings").get(currency) as String
		var currency_code: = currency
		shop_product._apply_platform_properties(name, description, price, currency_code)

func _microtxn_authorization_response(app_id: int, order_id: int, authorized: bool):
	if app_id != Steam.getAppID():
		printerr("[Moonlight_ShopSteam] _microtxn_authorization_response app_id does not match")
		return
	
	if authorized:
		var rpc_response: Dictionary = Moonlight.call_rpc("steam_shop_finalize_purchase", {"order_id": str(order_id)}, true)
		if rpc_response.has("error"):
			printerr("[Moonlight_ShopSteam] _microtxn_authorization_response() rpc failed %s" % [rpc_response])
		else:
			print("[Moonlight_ShopSteam] _microtxn_authorization_response() purchase rpc succeeded")
			emit_signal("product_purchase_complete", "steam_sku_unknown")
	else:
		var rpc_response: Dictionary = Moonlight.call_rpc("steam_shop_cancel_purchase", {"order_id": str(order_id)}, false)
		if rpc_response.has("error"):
			printerr("[Moonlight_ShopSteam] _microtxn_authorization_response rpc failed %s" % [rpc_response])
		else:
			print("[Moonlight_ShopSteam] _microtxn_authorization_response cancel purchase rpc succeeded")
