extends Node
class_name Moonlight_LoggedInVisibility

export  var visible_when_guest_account: = false
export  var visible_when_email_account: = false
export  var visible_when_linked_to_platform: = false
export  var visible_when_logged_out: = false

export  var invert: = false

onready var parent: = get_parent() as CanvasItem

func _ready():
	assert (parent != null)
	Moonlight.connect("on_authentication_succeeded", self, "update_label")
	Moonlight.connect("on_log_out", self, "update_label")
	Moonlight.storage.observe("account", self, "on_account_changed")
	update_label()

func on_account_changed(diff: Moonlight_StorageDiff):
	update_label()

func update_label():
	if Moonlight.auth.is_logged_in():
		if Moonlight.auth.is_guest_account():
			parent.visible = visible_when_guest_account
		elif Moonlight.auth.is_account_linked_to_email():
			parent.visible = visible_when_email_account
		elif Moonlight.auth.is_account_linked_to_platform():
			parent.visible = visible_when_linked_to_platform
		else:
			parent.visible = not visible_when_logged_out
	else:
		parent.visible = visible_when_logged_out

	if invert:
		parent.visible = not parent.visible
