extends Reference
class_name Moonlight_Heartbeat

var heartbeat_timer: = 0.0
const heartbeat_duration: = 300.0
var is_waiting_for_api_call: = false
const heartbeat_enabled: = false

func update(delta: float):
	if heartbeat_enabled:
		heartbeat_timer += delta
		if heartbeat_timer > heartbeat_duration:
			heartbeat_timer = 0.0
			heartbeat()

func heartbeat():
	if not is_waiting_for_api_call:
		is_waiting_for_api_call = true
		var result: = yield(Moonlight.socket.rpc_async("winterpixel_heartbeat", "{}"), "completed") as NakamaAPI.ApiRpc
		if result.is_exception():
			printerr("[Moonlight_Heartbeat] heartbeat failed %s" % [result])
		is_waiting_for_api_call = false
