extends Node

signal on_authentication_succeeded()
signal on_log_out()

signal on_socket_message(nakama_notification)
signal on_socket_message_parsed(nakama_notification, content_json)
signal on_chat_request(user_name)
signal on_friend_request(user_name)
signal on_friend_accepted(user_name)
signal on_group_accepted(group_name)
signal on_group_request(group_name)
signal on_friend_joined_game(user_name)
signal on_account_update(account)

onready var auth: = Moonlight_AuthCreator.create_authenticator()
onready var nakama_host: String = OS.get_environment("NAKAMA_HTTP_HOST") if OS.has_environment("NAKAMA_HTTP_HOST") else GoodConfig.get_config_value("nakama_host")
onready var nakama_path_prefix: String = GoodConfig.get_config_value("nakama_path_prefix", "")
onready var nakama_key: String = GoodConfig.get_config_value("nakama_key")
onready var nakama_scheme: String = OS.get_environment("NAKAMA_HTTP_PROTOCOL") if OS.has_environment("NAKAMA_HTTP_PROTOCOL") else GoodConfig.get_config_value("nakama_protocol")
onready var nakama_http_key: String = OS.get_environment("NAKAMA_HTTP_KEY") if OS.has_environment("NAKAMA_HTTP_KEY") else GoodConfig.get_config_value("nakama_http_key")
onready var nakama_port: int = int(OS.get_environment("NAKAMA_HTTP_PORT")) if OS.has_environment("NAKAMA_HTTP_PORT") else GoodConfig.get_config_value("nakama_port")
onready var nakama_auth_require_tutorial: bool = GoodConfig.get_config_value("nakama_auth_require_tutorial", false)
onready var nakama_enable_auth: bool = not OS.has_feature("server") and GoodConfig.get_config_value("nakama_enable_auth", true)
onready var rpc_logging: bool = GoodConfig.get_config_value("moonlight_rpc_logging", false)

onready var nakama_dont_auth_immediately: bool = OS.has_environment("ROBOT_AUTH_SECRET")
onready var nakama_force_allow_create: bool = OS.has_environment("ROBOT_AUTH_SECRET")

var client: NakamaClient
var socket: NakamaSocket
var session: NakamaSession
var local_account: NakamaAPI.ApiAccount
var local_player_profile: = {}
var saved_data: = MoonlightSavedData.new()
var seasons: = Moonlight_Seasons.new()
var party: Moonlight_Party
var friends: Moonlight_Friends
var lobby: = Moonlight_Lobby.new()
var discord_api: = Moonlight_DiscordAPI.new()

onready var storage: = Moonlight_Storage.new()

var time_delta_between_client_server: = 0
onready var heartbeat: = Moonlight_Heartbeat.new()
onready var shop: = Moonlight_ShopCreator.create_shop()

const client_version_error_string_key: = "[invalid_client_version]"
const min_time_before_token_expiry: = 30
const seconds_before_expiry_to_refresh: = 10
const http_request_timeout: = 10

enum SocketCode{
	
	ChatRequest = - 1
	FriendRequest = - 2
	FriendAccepted = - 3
	GroupAccepted = - 4
	GroupRequest = - 5
	FriendJoinedGame = - 6, 
	
	AccountUpdate = 1000, 
	WalletUpdate = 1100, 
	LeaderboardUpdate = 1200, 
	PurchasesUpdate = 1300, 
	PartyInvite = 1400, 
}

func _ready():
	if discord_api.is_in_discord():
		print("[Moonlight] running in discord")
		GoodConfig._parse_config("discord")
		rpc_logging = GoodConfig.get_config_value("moonlight_rpc_logging", false)
		nakama_host = GoodConfig.get_config_value("nakama_host")
		nakama_port = int(GoodConfig.get_config_value("nakama_port"))
		nakama_path_prefix = GoodConfig.get_config_value("nakama_path_prefix", "")
	
	
	_create_client(nakama_host, nakama_port, nakama_key, nakama_scheme, nakama_path_prefix)
	_create_socket(client)
	connect("on_authentication_succeeded", self, "_on_authentication_succeeded")
	if is_auth_enabled() and not nakama_dont_auth_immediately:
		auth.authenticate()


func _exit_tree() -> void :
	if socket:
		socket.close()
		socket = null

func is_auth_enabled() -> bool:
	if discord_api.is_in_discord():
		
		return nakama_enable_auth
	var tutorial_check: bool = not nakama_auth_require_tutorial or SavedSettings.get_value("tutorial_started", false)
	return nakama_enable_auth and tutorial_check
	

func is_logged_in() -> bool:
	return auth != null and auth.is_logged_in()

func get_client_version() -> int:
	return GoodConfig.get_config_value("client_version", 0)

func auth_failure_is_client_version() -> bool:
	if session != null and session.is_exception():
		return client_version_error_string_key in session.exception.message
	return false

func auth_failure_is_banned() -> bool:
	if session != null and session.is_exception():
		return "User account banned." in session.exception.message
	return false

func _create_client(host: String, port: int, server_key: String, scheme: String, path_prefix: String):
	var log_level: int = NakamaLogger.LOG_LEVEL.INFO
	if OS.is_debug_build():
		log_level = NakamaLogger.LOG_LEVEL.INFO
	
	client = Nakama.create_client(server_key, host, port, scheme, path_prefix, http_request_timeout, log_level)
	client.connect("http_request_failed", self, "_on_http_request_failed")

func _on_http_request_failed(exception: NakamaException, url: String):
	printerr("[Moonlight] _on_http_request_failed()\nurl: %s\nexception: %s" % [url, exception])
	if exception.status_code == 403:
		session = NakamaSession.new(null, false, null, exception)

func local_user_id() -> String:
	if not is_logged_in():
		return ""
	return local_account.user.id

func _fetch_local_account() -> bool:
	
	var initial_data: Dictionary = yield(call_rpc("player_fetch_data", {}, true, false, false, true), "completed")
	if initial_data == null or initial_data.has("error"):
		return false
	seasons._parse_seasons(storage)
	var user_id: String = storage.storage_get("account.user.id", "")
	print(user_id)
	if discord_api.is_in_discord():
		discord_api.cache_local_player_discord_data(storage)
	
	return true

func _process(delta: float):
	if is_auth_enabled():
		if client != null and session != null:
			if not auth.is_attempting_authentication:
				var current_time: = OS.get_unix_time()
				var after_minimum: = current_time - auth.last_authentication_time > min_time_before_token_expiry
				var near_expiry: = (session.expire_time + time_delta_between_client_server) - seconds_before_expiry_to_refresh < current_time
				if session.is_exception():
					pass
				elif after_minimum and (near_expiry):
					print("[Moonlight] refresh_token")
					auth.authenticate(false)
				elif session == null or not session.is_valid():
					pass
	
	if auth.is_logged_in():
		seasons.update(delta)
		heartbeat.update(delta)
	
	if discord_api.avatar_cache:
		discord_api.avatar_cache.pump_retrieval_queue()

func _create_socket(p_client: NakamaClient):
	socket = Nakama.create_socket_from(p_client)
	socket.connect("connected", self, "_on_socket_connected")
	socket.connect("closed", self, "_on_socket_closed")
	socket.connect("received_error", self, "_on_socket_error")
	socket.connect("received_notification", self, "_on_socket_notification")
	party = Moonlight_Party.new(socket)
	friends = Moonlight_Friends.new(socket)

func _on_socket_connected():
	print("[Moonlight] on socket connected")

func _on_socket_closed():
	printerr("[Moonlight] on socket closed")

func _on_socket_error(error):
	printerr("[Moonlight] on socket error " + str(error))

func _on_socket_notification(nakama_notification: NakamaAPI.ApiNotification):
	if not is_logged_in():
		
		print("[Moonlight] _on_socket_notification received while not logged in.")
		return
	
	
	emit_signal("on_socket_message", nakama_notification)
	var content_json = parse_json(nakama_notification.content)
	if not content_json is Dictionary:
		printerr("[Moonlight] couldn\'t parse notification content")
		content_json = {}
	emit_signal("on_socket_message_parsed", nakama_notification, content_json)
	
	match nakama_notification.code:
		SocketCode.ChatRequest:
			var user_name: = content_json["username"] as String
			emit_signal("on_chat_request", user_name)
		SocketCode.FriendAccepted:
			var user_name: = content_json["username"] as String
			emit_signal("on_friend_accepted", user_name)
		SocketCode.FriendJoinedGame:
			var user_name: = content_json["username"] as String
			emit_signal("on_friend_joined_game", user_name)
		SocketCode.FriendRequest:
			var user_name: = content_json["username"] as String
			emit_signal("on_friend_request", user_name)
		SocketCode.GroupAccepted:
			emit_signal("on_group_accepted", "")
		SocketCode.GroupRequest:
			emit_signal("on_group_request", "")
		SocketCode.AccountUpdate:
			
			parse_into_storage("player_fetch_data", content_json)
			emit_signal("on_account_update", content_json)
		SocketCode.PurchasesUpdate:
			print("[Moonlight] _on_socket_notification() purchase update")
			var sku: String = content_json.get("sku", "")
			shop.emit_signal("product_purchase_complete", sku)


		SocketCode.PartyInvite:
			
			pass
		_:
			printerr("[Moonlight] _on_socket_notification unknown code " + str(nakama_notification))



func connect_socket():
	if socket.is_connected_to_host():
		print("[Moonlight] connect_socket() already connected")
		return null
	
	print("[Moonlight_AuthBase] connect_socket() connecting socket...")
	
	var appear_online: = true
	var result = yield(socket.connect_async(session, appear_online, http_request_timeout), "completed")
	if result.is_exception():
		printerr("[Moonlight] connect_socket() exception an error occured: %s" % result)
		return null
	
	while socket.is_connecting_to_host():
		yield(get_tree(), "idle_frame")

func parse_into_storage(rpc_id: String, payload_parsed: Dictionary) -> void :
	var account_data = payload_parsed.get("account", null)
	if account_data != null and account_data is Dictionary:
		var parsed_account: NakamaAPI.ApiAccount = NakamaSerializer.deserialize(NakamaAPI, "ApiAccount", account_data)
		if parsed_account and not parsed_account.is_exception():
			local_account = parsed_account
		else:
			var payload_printable = JSON.print(payload_parsed, "  ")
			printerr("[Moonlight] parse_result_into_storage() failed to parse account \n\trpc_id: %s\n\tpayload: %s)" % [rpc_id, payload_parsed])
	storage._parse_rpc_response(rpc_id, payload_parsed)
	shop._parse_shop_data(storage.data)

func call_rpc_with_server_key(rpc_id: String, payload: Dictionary):
	if nakama_http_key.empty():
		yield(get_tree(), "idle_frame")
		return {
			"error": "No http_key.", 
			"error_code": 403, 
		}
	var payload_string: = to_json(payload)
	var result: NakamaAPI.ApiRpc = yield(client.rpc_async_with_key(nakama_http_key, rpc_id, payload_string), "completed")
	if result.is_exception():
		printerr("[Moonlight] call_rpc_with_server_key()\n\terror:%s\n\trpc_id: %s\n\tpayload: %s)" % [result.exception, rpc_id, payload_string])
		return {
			"error": result.exception.message, 
			"error_code": result.exception.status_code, 
		}
	var payload_parsed = parse_json(result.payload)
	if not payload_parsed is Dictionary:
		printerr("[Moonlight] call_rpc_with_server_key() response wasnt dictionary\n\trpc_id: %s\n\tpayload: %s\n\tresponse:\n%s)" % [rpc_id, payload_string, result.payload])
		return {}
	
	if rpc_logging:
		var payload_printable = JSON.print(payload_parsed, "  ")
		print("[Moonlight] call_rpc_with_server_key()\n\trpc_id: %s\n\tpayload: %s\n\tresponse:\n%s)" % [rpc_id, payload_string, payload_printable])
	
	return payload_parsed

func call_rpc(rpc_id: String, payload: Dictionary, parse_result_into_storage: = true, attempt_reauth: = false, force_http: = false, is_authing: = false) -> Dictionary:
	if attempt_reauth:
		if not auth.is_logged_in():
			if Moonlight.auth_failure_is_client_version():
				printerr("[Moonlight] call_rpc() %s not authenticated, client version failure. not attempting to authenticate." % [rpc_id])
				yield(get_tree(), "idle_frame")
				return {
					"error": "Failed to authenticate.\nYou must update your game!", 
					"error_code": 403
				}
			else:
				if Moonlight.auth.is_attempting_authentication:
					printerr("[Moonlight] call_rpc() %s not authenticated. waiting for authentication to complete." % [rpc_id])
					while Moonlight.auth.is_attempting_authentication:
						yield(get_tree(), "idle_frame")
				
				printerr("[Moonlight] call_rpc() %s not authenticated. trying to authenticate." % [rpc_id])
				if not auth.is_logged_in():
					printerr("[Moonlight] call_rpc() %s not authenticated. trying to authenticate." % [rpc_id])
					yield(Moonlight.auth.authenticate(), "completed")
					if not auth.is_logged_in():
						printerr("[Moonlight] call_rpc() %s failed to authenticate." % [rpc_id])
						return {
							"error": "Failed to authenticate.", 
							"error_code": 403
						}
	
	if not auth.is_logged_in() and not is_authing:
		printerr("[Moonlight] call_rpc() not authenticated.")
		yield(get_tree(), "idle_frame")
		return {
			"error": "Unauthenticated.", 
			"error_code": 403
		}
	
	var payload_string: = to_json(payload)
	
	var result: NakamaAPI.ApiRpc
	var use_socket: = not force_http
	if use_socket and socket != null and socket.is_connected_to_host():
		result = yield(socket.rpc_async(rpc_id, payload_string), "completed")
	else:
		result = yield(client.rpc_async(session, rpc_id, payload_string), "completed")
	if result.is_exception():
		printerr("[Moonlight] call_rpc()\n\terror:%s\n\trpc_id: %s\n\tpayload: %s)" % [result.exception, rpc_id, payload_string])
		return {
			"error": result.exception.message, 
			"error_code": result.exception.status_code, 
		}
	
	
	var payload_parsed = parse_json(result.payload)
	if not payload_parsed is Dictionary:
		printerr("[Moonlight] call_rpc() response wasnt dictionary\n\trpc_id: %s\n\tpayload: %s\n\tresponse:\n%s)" % [rpc_id, payload_string, result.payload])
		return {}
	
	if rpc_logging:
		var payload_printable = JSON.print(payload_parsed, "  ")
		print("[Moonlight] call_rpc()\n\trpc_id: %s\n\tpayload: %s\n\tresponse:\n%s)" % [rpc_id, payload_string, payload_printable])
	
	if parse_result_into_storage:
		parse_into_storage(rpc_id, payload_parsed)
	return payload_parsed

func _on_authentication_succeeded():
	shop.load_platform_product_data()
