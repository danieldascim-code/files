extends Reference
class_name ReplayDownloader

static func async_download_replay(level_id: String, user_id: String) -> Dictionary:
	var payload: = {"level_id": level_id, "user_id": user_id}
	var result: Dictionary = yield(Moonlight.call_rpc("replay_download", payload, false, false, true), "completed")
	return result
