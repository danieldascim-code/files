extends TextureRect
class_name FullScreenLevelRect

export (NodePath) var _viewport
onready var viewport: = get_node(_viewport) as ViewportSDF

onready var shader_material: = material as ShaderMaterial
export  var texture_scale: = 1.0


var level_theme: BaseTheme

func _ready():
	texture = viewport.get_texture()
	var sdf_texture: = viewport.get_sdf_texture()
	VisualServer.texture_set_flags(sdf_texture.get_rid(), Texture.FLAG_FILTER)
	shader_material.set_shader_param("sdf_texture", sdf_texture)

func set_level_theme(new_theme: BaseTheme):
	level_theme = new_theme

func _process(delta):
	var xform: = viewport.canvas_transform.affine_inverse()
	var xform_scale: = xform.get_scale()
	
	
	
	self.rect_position = xform.origin
	self.rect_size = viewport.size * xform_scale
	self.rect_pivot_offset = self.rect_size * 0.5
	self.rect_rotation = xform.get_rotation()
	
	shader_material.set_shader_param("u_window_scale", xform_scale.x)
	
	var window_offset: = xform.origin
	shader_material.set_shader_param("u_window_offset", window_offset)
	
	var window_size: = viewport.get_visible_rect().size * xform_scale
	shader_material.set_shader_param("u_window_size", window_size)
	
	if level_theme:
		var terrain_texture: = level_theme.terrain_texture
		var pattern_to_screen_ratio: = texture_scale * window_size / terrain_texture.get_size()
		shader_material.set_shader_param("u_terrain_pattern_view_ratio", pattern_to_screen_ratio);
		shader_material.set_shader_param("u_terrain_pattern", terrain_texture)
		
		shader_material.set_shader_param("u_terrain_stroke_1", level_theme.terrain_color_1)
		shader_material.set_shader_param("u_terrain_stoke_1_width", level_theme.terrain_color_1_thickness)
		shader_material.set_shader_param("u_terrain_stroke_2", level_theme.terrain_color_2)
		shader_material.set_shader_param("u_terrain_stoke_2_width", level_theme.terrain_color_2_thickness)
		shader_material.set_shader_param("u_terrain_stroke_3", level_theme.terrain_color_3)
		shader_material.set_shader_param("u_terrain_stoke_3_width", level_theme.terrain_color_3_thickness)
	
