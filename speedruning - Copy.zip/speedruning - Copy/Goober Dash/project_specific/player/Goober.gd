tool 
extends SpineSprite
class_name Goober

const enable_hats: = true

export (Array, Gradient) var gradients: Array
export  var gradient_name: String setget set_gradient
var gradient: Gradient
onready var gradient_material: ShaderMaterial = normal_material
export  var enable_gradient_tint: = true setget set_enable_gradient_tint
export  var enable_sounds: = true
export  var use_card_prefix: = false
export  var enable_blink: = true
export  var _editor_refresh_tint: = false setget _set_editor_refresh_tint

var slot_nodes: = []

signal spine_event(event_name)
signal skin_data_changed()

var goober_skin_data: = {} setget set_goober_skin_data
var dance_ids: = []
export  var apply_defaults: = false

const default_goober_skin_data: = {
	"color": "color_default"
}
var blink_timer: = 0.0
func _enter_tree() -> void :
	if slot_nodes.empty():
		for c in get_child_count():
			var child = get_child(c) as SpineSlotNode
			if child != null:
				slot_nodes.append(child)

func _ready():
	self.connect("animation_event", self, "on_spine_animation_event")
	if Engine.editor_hint:
		pass

var _blink_s: = "blink"
func _blink():
		var state: = get_animation_state()
		
		
		state.set_animation(_blink_s, false, 1)

func on_spine_animation_event(spine_sprite: SpineSprite, animation_state: SpineAnimationState, track_entry: SpineTrackEntry, event: SpineEvent):
	
	emit_signal("spine_event", event.get_data().get_event_name())

func set_goober_skin_data(p_goober_skin_data: Dictionary):
	if p_goober_skin_data.hash() == goober_skin_data.hash():
		return
	goober_skin_data = p_goober_skin_data.duplicate()
	apply_skin_data()

func add_cosmetic(cosmetic_id: String) -> bool:
	var cosmetic_data: = CosmeticsCollection.lookup_cosmetic_id(cosmetic_id)
	if cosmetic_data.empty():
		return false
	
	var cosmetic_type: String = cosmetic_data["type"]
	if goober_skin_data.get(cosmetic_type) == cosmetic_id:
		return false
	
	goober_skin_data[cosmetic_type] = cosmetic_id
	apply_skin_data()
	return true

func set_cosmetic(cosmetic_id: String) -> bool:
	var cosmetic_data: = CosmeticsCollection.lookup_cosmetic_id(cosmetic_id)
	if cosmetic_data.empty():
		return false
	
	goober_skin_data.clear()
	var cosmetic_type: String = cosmetic_data["type"]
	goober_skin_data[cosmetic_type] = cosmetic_id
	apply_skin_data()
	return true

func apply_skin_data():
	
	dance_ids.clear()
	var merged_skin_data: Dictionary
	if apply_defaults:
		merged_skin_data = default_goober_skin_data.duplicate()
	else:
		merged_skin_data = {}
	merged_skin_data.merge(goober_skin_data, true)
	
	
	var new_custom_skin: = new_skin("custom_skin")
	var gradient_name: = ""
	var ordered_keys: = merged_skin_data.keys()
	ordered_keys.sort()
	var applied_color: = false
	for cosmetic_key in ordered_keys:
		var cosmetic_id: String = merged_skin_data[cosmetic_key]
		if cosmetic_id.empty():
			continue
		var cosmetic_value = CosmeticsCollection.lookup_cosmetic_id(cosmetic_id)
		if cosmetic_value == null:
			printerr("[Goober] couldnt find cosmetic for %s" % [cosmetic_id])
			continue
		if cosmetic_value.has("spine"):
			var spine_ref: String = cosmetic_value["spine"]
			if use_card_prefix:
				spine_ref = "card" + spine_ref
			var cosmetic_spine_skin: = skeleton_data_res.find_skin(spine_ref)
			if cosmetic_spine_skin == null:
				continue
				
			new_custom_skin.copy_skin(cosmetic_spine_skin)
		if cosmetic_key == "color":
			applied_color = true
			gradient_name = cosmetic_value.get("color", "")
		if cosmetic_value.has("dance"):
			var dance_id: String = cosmetic_value["dance"]
			if not dance_id.empty():
				dance_ids.append(dance_id)
	
	if apply_defaults and not applied_color:
		
		printerr("[Goober] didnt apply a color for skin set. falling back to blue default. input skin: %s" % [merged_skin_data])
		var default_spine_skin: = skeleton_data_res.find_skin("body/Normal")
		gradient_name = "blue"
		new_custom_skin.copy_skin(default_spine_skin)
		
	
	_apply_tint_to_face()
	var a: = get_animation_state()
	get_skeleton().set_skin(new_custom_skin)
	get_skeleton().set_slots_to_setup_pose()
	a.apply(get_skeleton())
	set_gradient(gradient_name)
	emit_signal("skin_data_changed")

func _process(delta: float) -> void :
	if enable_blink:
		blink_timer -= delta
		if blink_timer <= 0.0:
			_blink()
			blink_timer = rand_range(0.5, 3.0)

func _apply_tint_to_face():
	
	
	pass

func get_tint() -> Color:
	if gradient_name.empty():
		return Color.white
	var primary_color: = gradient.colors[ - 1]
	return primary_color

func get_dark_tint() -> Color:
	if gradient == null:
		return Color(0.25, 0.25, 0.25, 1.0)
	var primary_color: = gradient.colors[0]
	return primary_color

func _should_tint(slot_name: String) -> bool:
	if not enable_gradient_tint:
		return false
	var body_slot: = get_skeleton().find_slot(slot_name)
	if not body_slot:
		
		return false
	var attachment: = body_slot.get_attachment()
	if not attachment:
		
		return false
	var attachment_name: = attachment.get_attachment_name()
	return attachment_name.find("-tint") != - 1

func set_gradient(g: String):
	gradient_name = g
	if not enable_gradient_tint:
		return
	if is_inside_tree():
		gradient = load_gradient(g)
		_apply_tint_to_face()
		apply_gradient_tint()

var _gradient_s: = "gradient"
func apply_gradient_tint():


	var slots: = get_skeleton().get_slots()
	for s in slots:
		var slot: SpineSlot = s
		var attachment: SpineAttachment = slot.get_attachment()
		if not attachment:
			
			continue
		var should_tint: = attachment.get_attachment_name().find("-tint") != - 1
		if should_tint and not gradient_name.empty():
			
			var y_coordinate: = PlayerGradients.uv_index_of_gradient_name(gradient_name)
			var tint_color: = Color(0.0, y_coordinate, 0.0, 1.0)
			
			slot.set_color(tint_color)
		else:
			
			slot.set_color(Color.white)

func load_gradient(gradient_name: String) -> Gradient:
	if gradient_name.empty():
		
		return null
	var r = load("res://project_specific/gfx/player_gradients/%s.tres" % [gradient_name]) as Gradient
	if r == null:
		printerr("[Goober] load_gradient() couldnt load gradient \'%s\'" % [gradient_name])
	return r

func _set_editor_refresh_tint(b: bool):
	if b:
		set_gradient(gradient_name)

func set_enable_gradient_tint(b: bool):
	enable_gradient_tint = b
	apply_skin_data()
