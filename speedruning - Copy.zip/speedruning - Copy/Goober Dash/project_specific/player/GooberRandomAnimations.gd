extends Node
class_name GooberRandomAnimations

onready var goober: Goober = get_parent()

export (Array, String) var animations: = ["meditate", "yawn", "Idle-kick"]
var _animations: = []
export  var play_special_dances: = true
var idle_timer: = 0.0
export  var interupt_on_input: = true
export  var random_animation_timer: = 10.0

func _ready() -> void :
	goober.connect("skin_data_changed", self, "on_skin_data_changed")
	on_skin_data_changed()
	_play_idle_animation(0.0)

func on_skin_data_changed():
	_animations = animations.duplicate()
	if play_special_dances:
		_animations.append_array(goober.dance_ids)

func _input(event: InputEvent) -> void :
	if interupt_on_input:
		_play_idle_animation()

func _process(delta: float) -> void :
	var animation_state: = goober.get_animation_state()
	var current_track: = animation_state.get_current(0)
	if current_track == null:
		return
	
	if current_track.get_animation().get_name() == "Idle":
		idle_timer += delta
	else:
		idle_timer = 0.0
	
	if idle_timer > random_animation_timer:
		if _animations.size() > 0:
			var animation_key: = randi() %_animations.size()
			var random_animation: String = _animations[animation_key]
			
			var is_special_dance: bool = animation_key >= animations.size()
			var is_loop: = random_animation == "meditate"
			var delay: = 0.0
			if is_loop:
				delay = rand_range(15.0, 32.0)
			animation_state.set_animation(random_animation, is_loop, 0).set_mix_duration(0.5)
			animation_state.add_animation("Idle", delay, true, 0).set_mix_duration(0.5)

func _play_idle_animation(mix_duration: = 0.5):
	idle_timer = 0.0
	var animation_state: = goober.get_animation_state()
	if not _is_playing_idle(animation_state):
		animation_state.set_animation("Idle", true, 0).set_mix_duration(mix_duration)

func _is_playing_idle(animation_state: SpineAnimationState) -> bool:
	var track_entry: = animation_state.get_current(0)
	if not track_entry:
		return false
	var animation: = track_entry.get_animation()
	if not animation:
		return false
	if animation.get_name() != "Idle":
		return false
	return true
