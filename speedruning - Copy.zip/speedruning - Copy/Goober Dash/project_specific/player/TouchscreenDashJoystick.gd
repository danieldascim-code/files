extends Node

export  var _virtual_joystick: NodePath
onready var virtual_joystick: = get_node(_virtual_joystick) as GoodVirtualAnalogStick

var is_aiming: = false
var is_over_threshold: = false
var has_gone_over_threshold: = false

func _ready() -> void :
	virtual_joystick.connect("knob_grabbed", self, "on_knob_grabbed")
	virtual_joystick.connect("knob_moved", self, "on_knob_moved")
	virtual_joystick.connect("knob_released", self, "on_knob_released")

func on_knob_grabbed(v: Vector2):
	pass

func on_knob_moved(v: Vector2):
	pass

func _process(delta: float) -> void :
	pass

func on_knob_released(v: Vector2):
	is_aiming = false
	is_over_threshold = false
	has_gone_over_threshold = false
