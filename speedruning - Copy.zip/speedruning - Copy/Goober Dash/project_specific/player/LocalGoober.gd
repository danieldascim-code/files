extends Node
class_name LocalGoober

onready var parent_goober: = get_parent() as Goober

func _ready():
	Moonlight.storage.observe("player.profile.skin", self, "on_skin_changed")
	
	_apply()

func on_skin_changed(diff: Moonlight_StorageDiff):
	_apply()

func _apply():
	parent_goober.set_goober_skin_data(Moonlight.storage.storage_get("player.profile.skin", {}))
