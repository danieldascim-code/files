extends Control
class_name ProfileStatRow

onready var title: SDFLabel = $HBox / Title
onready var value: SDFLabel = $HBox / Value
onready var focusable: Focusable = $Focusable
