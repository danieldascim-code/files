tool 
extends Node2D
class_name PlayerSpawnParticles

export  var _particles_one: NodePath
onready var particles_one: = get_node(_particles_one)

export  var _particles_two: NodePath
onready var particles_two: = get_node(_particles_two)
onready var particles: = [particles_one, particles_two]

export  var _rotation_anchor: NodePath
onready var rotation_anchor: Node2D = get_node(_rotation_anchor)

export  var _run: = false setget _set_run

export  var spins: = 1.0
export  var emission_time: = 3.0

export  var distance_max: = 15.0
export  var distance_min: = 5.0

var is_running: = false
var run_timer: = 0.0

func _ready() -> void :
	_fetch_particles()

func _init():
	if is_inside_tree():
		_fetch_particles()

func set_color_one(c: Color):
	particles_one.self_modulate = c

func set_color_two(c: Color):
	particles_two.self_modulate = c

func _fetch_particles():
	particles_one = get_node(_particles_one)
	particles_two = get_node(_particles_two)
	particles = [particles_one, particles_two]
	rotation_anchor = get_node(_rotation_anchor)

func _process(delta: float) -> void :
	for p in particles:
		p.emitting = is_running
	
	if is_running:
		rotation_anchor.rotation += delta * (TAU * spins / emission_time)
		var distance_factor: = range_lerp(run_timer, 0.0, emission_time, distance_min, distance_max)
		particles_one.position = Vector2.LEFT * distance_factor
		particles_two.position = Vector2.RIGHT * distance_factor
	run_timer += delta
	if run_timer > emission_time:
		is_running = false

func _set_run(b: bool):
	_fetch_particles()
	play()

func play():
	is_running = true
	run_timer = 0.0
	rotation_anchor.rotation = 0.0
	particles_one.position = Vector2.ZERO
	particles_two.position = Vector2.ZERO
