extends Control
class_name AwardMedalIcon

export  var _tool_tip_target_control: NodePath
onready var tool_tip_target_control: Control = get_node_or_null(_tool_tip_target_control)

onready var icon: TextureRect = $TextureRect
onready var count_label: SDFLabel = $CountPanel / CountLabel
onready var tool_tip_label: SDFLabel = $ToolTipPanel / ToolTipLabel
onready var tool_tip_panel: Control = $ToolTipPanel

func _ready():
	tool_tip_panel.visible = false
	if tool_tip_target_control:
		tool_tip_panel.get_parent().remove_child(tool_tip_panel)
		tool_tip_target_control.add_child(tool_tip_panel)
	
func _process(delta):
	if tool_tip_panel.visible:
		var x_offset: = 0.5 * rect_size.x - tool_tip_panel.rect_size.x * 0.5
		tool_tip_panel.rect_global_position = rect_global_position + Vector2(x_offset, - 100.0)
	
func populate_from_award_dict(award_dict: Dictionary, count: int):
	var icon_name: String = award_dict.get("icon", "")
	icon.texture = load_award_icon(icon_name)
	count_label.text = "x" + str(count)
	tool_tip_label.text = award_dict.get("desc", "")

static func load_award_icon(icon_name: String):
	if icon_name.empty():
		printerr("[AwardMedalIcon] load_award_icon() failed to load empty icon name")
		return null
	var icon_path: String = "res://project_specific/gfx/awards/" + icon_name
	var tex = load(icon_path)
	if tex == null or not tex is Texture:
		printerr("[AwardMedalIcon] load_award_icon() failed to load icon at path: %s" % [icon_path])
		return null
	return tex
