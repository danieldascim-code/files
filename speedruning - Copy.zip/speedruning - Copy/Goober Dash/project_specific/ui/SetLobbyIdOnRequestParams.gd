extends Node
class_name SetLobbyIdOnRequestParams

func _ready() -> void :
	if OS.has_feature("web"):
		Moonlight.party.connect("party_id_changed", self, "on_party_id_changed")
		Moonlight.lobby.connect("lobby_code_changed", self, "on_lobby_code_changed")
		SavedSettings.connect("on_value_changed", self, "on_value_changed")
		_refresh()

func on_value_changed(key: String, value):
	if key == "hide_lobby_code":
		_refresh()

func _refresh():
	var hide_code: bool = SavedSettings.get_value("hide_lobby_code", false)
	if hide_code:
		HTMLRequestParams.clear_request_params(["lobby"])
		return
	
	if Moonlight.party.is_in_lobby():
		if not Moonlight.lobby.lobby_code.empty():
			HTMLRequestParams.set_request_params({"lobby": Moonlight.lobby.lobby_code})
	else:
		HTMLRequestParams.clear_request_params(["lobby"])

func on_lobby_code_changed():
	_refresh()

func on_party_id_changed(party_id: String):
	_refresh()
