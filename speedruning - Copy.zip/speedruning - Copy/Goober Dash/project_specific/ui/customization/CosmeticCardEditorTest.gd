tool 
extends Node

onready var cosmetic_card_scene: = get_parent() as CosmeticCard


func _ready():
	if OS.has_feature("editor") and get_tree().current_scene == get_parent():
		yield(get_tree().create_timer(0.05), "timeout")
		
		
		
		var card_data: = {
			"quantity": 5
		}
		cosmetic_card_scene.show_cosmetic("emote_pig", card_data)
		
