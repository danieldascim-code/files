extends Control
class_name CosmeticGridSection

export  var _section_title: NodePath
onready var section_title: Label = get_node(_section_title)

export  var _coin_cost_to_unlock_value_label: NodePath
onready var coin_cost_to_unlock_value_label: Label = get_node(_coin_cost_to_unlock_value_label)

export  var _xp_earned_label: NodePath
onready var xp_earned_label: Label = get_node(_xp_earned_label)

export  var _grid_container: NodePath
onready var grid_container: GridContainer = get_node(_grid_container)

export  var _lock_icon: NodePath
onready var lock_icon: TextureRect = get_node(_lock_icon)

export  var _line: NodePath
onready var line: Control = get_node(_line)

export  var _section_header: NodePath
onready var section_header: = get_node(_section_header) as Control

var child_cards: = []
var rendering_level: = 0

func add_card(card: CosmeticCard):
	child_cards.append(card)
	grid_container.add_child(card)

func remove_card(card: CosmeticCard):
	child_cards.erase(card)
	grid_container.remove_child(card)

func hide_header():
	section_header.visible = false

func show_section_header_for_level(item_level: int, player_level: int):
	rendering_level = item_level
	section_header.visible = true
	var xp_gained: = CosmeticsCollection.xp_gain_for_item_level(item_level)
	var coin_cost: = CosmeticsCollection.coin_cost_for_item_level(item_level)
	
	section_title.text = "LEVEL " + str(item_level)
	xp_earned_label.text = str(xp_gained)
	coin_cost_to_unlock_value_label.text = str(coin_cost)
	
	var is_locked: = item_level > player_level
	lock_icon.visible = is_locked
	line.visible = not is_locked
