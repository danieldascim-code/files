extends Control
class_name CosmeticCard_Description

export  var _level_label: NodePath
onready var level_label: Label = get_node(_level_label)

export  var _rarity_label: NodePath
onready var rarity_label: SDFLabel = get_node(_rarity_label)

export  var _title_label: NodePath
onready var title_label: Label = get_node(_title_label)


func show_cosmetic_data(cosmetic_data: Dictionary):
	var rarity: String = cosmetic_data.get("rarity", "common")
	var type: String = cosmetic_data.get("type", "")
	var title: String = cosmetic_data.get("name", "").to_upper()
	var level: int = int(cosmetic_data.get("level", 0))
	
	title_label.text = title
	rarity_label.text = rarity + " " + type
	level_label.text = "LEVEL " + str(level)
	rarity_label.color = CosmeticCard.rarity_to_color[rarity]
