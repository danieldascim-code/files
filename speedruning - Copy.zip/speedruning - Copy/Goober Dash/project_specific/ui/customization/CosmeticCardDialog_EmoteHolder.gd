extends BaseButton
class_name CosmeticCardDialog_EmoteHolder

onready var empty_panel: = $Control as Control
onready var emote_spine_sprite: = $SpineSprite as EmoteSpineSprite
onready var plus_label: = $Control / SDFLabel as Label
export  var enable_focus: bool = false

func _ready() -> void :
	if not enable_focus:
		var f: Focusable = get_node("Focusable")
		f.force_disable_focus = true

func show_emote(cosmetic_id: String):
	empty_panel.visible = true
	emote_spine_sprite.visible = false
	
	if not cosmetic_id.empty():
		var cosmetic_data: = CosmeticsCollection.lookup_cosmetic_id(cosmetic_id)
		if cosmetic_data.empty():
			return
		var emote_spine: String = cosmetic_data.get("spine", "")
		if emote_spine.empty():
			printerr("couldnt find emote_spine for cosmetic_id: %s" % [cosmetic_id])
			return
		
		empty_panel.visible = false
		emote_spine_sprite.visible = true
		emote_spine_sprite.show_static_frame(emote_spine)
