extends Control


export  var _show_emotes: NodePath
onready var show_emotes: GoodTweener = get_node(_show_emotes)

export  var _hide_emotes: NodePath
onready var hide_emotes: GoodTweener = get_node(_hide_emotes)

export  var _customize_goober: NodePath
onready var customize_goober: SkinSelector = get_node(_customize_goober)

export (Array, NodePath) var _emote_slots: Array

var emote_slots: = []
var is_showing: = false

func _ready() -> void :
	customize_goober.connect("showing_cosmetic_type", self, "on_showing_cosmetic_type")
	for e in _emote_slots:
		var node = get_node(e) as CosmeticCardDialog_EmoteHolder
		if node:
			emote_slots.append(node)
	Moonlight.storage.observe("player.profile.emotes", self, "on_emotes_updated")
	var emotes: Array = Moonlight.storage.storage_get("player.profile.emotes", [])
	_update_emotes(emotes)

func on_emotes_updated(diff: Moonlight_StorageDiff):
	var emote_data: Array = diff.value
	_update_emotes(emote_data)

func _update_emotes(emotes: Array):
	var has_shown_empty: = false
	for i in emote_slots.size():
		var emote_holder: CosmeticCardDialog_EmoteHolder = emote_slots[i]
		var emote_id: = ""
		emote_holder.visible = true
		if i < emotes.size():
			emote_id = emotes[i]
			emote_holder.show_emote(emote_id)
		else:
			
			emote_holder.show_emote(emote_id)
			
			
			has_shown_empty = true

func on_showing_cosmetic_type(cosmetic_type: String):
	var should_show: = cosmetic_type == "emote"
	if should_show != is_showing:
		if should_show:
			animate_in_emotes()
		else:
			animte_out_emotes()
		is_showing = should_show

func animate_in_emotes():
	show_emotes.play()

func animte_out_emotes():
	hide_emotes.play()
