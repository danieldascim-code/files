tool 
extends Control
class_name CosmeticCard
signal button_pressed()

export  var border_color: Color
export  var unlockable_border_color: Color

export  var _bg: NodePath
onready var bg: TextureRect = get_node(_bg)
onready var bg_shader_material: ShaderMaterial = bg.material

export  var _bg_unlocked: NodePath
onready var bg_unlocked: TextureRect = get_node(_bg_unlocked)

export  var _border: NodePath
onready var border: TextureRect = get_node(_border)

export  var _border_locked: NodePath
onready var border_locked: TextureRect = get_node(_border_locked)
onready var border_locked_shader_material: ShaderMaterial = border_locked.material

export  var disable_button: bool setget set_disable_button
signal quantity_changed()

export  var _button: NodePath
onready var button: BaseButton = get_node(_button)

export  var _button_focusable: NodePath
onready var button_focusable: Focusable = get_node(_button_focusable)

export  var _progress: NodePath
onready var progress: TextureProgress = get_node(_progress)

export  var _progress_label: NodePath
onready var progress_label: SDFLabel = get_node(_progress_label)

export  var _progress_icon: NodePath
onready var progress_icon: TextureRect = get_node(_progress_icon)

export  var _unlock_alert: NodePath
onready var unlock_alert: TextureRect = get_node(_unlock_alert)

export  var _goober: NodePath
onready var goober: Goober = get_node(_goober)

export  var _goober_container: NodePath
onready var goober_container: Control = get_node(_goober_container)

export  var _emote_spine: NodePath
onready var emote_spine: EmoteSpineSprite = get_node(_emote_spine)

export  var _emote_container: NodePath
onready var emote_container: Control = get_node(_emote_container)

var unlocktween1: SceneTreeTween
var unlocktween2: SceneTreeTween

func _ready() -> void :
	set_disable_button(disable_button)
	var animation_state: = goober.get_animation_state()
	animation_state.set_animation("Card", true)
	var current_track: = animation_state.get_current(0)
	current_track.set_mix_duration(0.0)
	button.connect("pressed", self, "emit_signal", ["button_pressed"])

const rarity_to_gradient: = {
	"common": "res://project_specific/cards/gradients/common_gradient.tres", 
	"rare": "res://project_specific/cards/gradients/rare_gradient.tres", 
	"epic": "res://project_specific/cards/gradients/epic_gradient.tres", 
	"legendary": "res://project_specific/cards/gradients/legendary_gradient.tres", 
}
const rarity_to_locked_gradient: = {
	"common": "res://project_specific/cards/gradients/common_gradient_locked.tres", 
	"rare": "res://project_specific/cards/gradients/rare_gradient_locked.tres", 
	"epic": "res://project_specific/cards/gradients/epic_gradient_locked.tres", 
	"legendary": "res://project_specific/cards/gradients/legendary_gradient_locked.tres", 
}
const rarity_to_color: = {
	"common": Color(0.458824, 0.654902, 0.878431), 
	"rare": Color(0.6, 1, 0.568627), 
	"epic": Color(0.780392, 0.52549, 0.960784), 
	"legendary": Color(1, 0.537255, 0.313726), 
}
const rarity_to_tex: = {
	"common": preload("res://project_specific/gfx/cards/card-bg-unlocked-common.png"), 
	"rare": preload("res://project_specific/gfx/cards/card-bg-unlocked-rare.png"), 
	"epic": preload("res://project_specific/gfx/cards/card-bg-unlocked-legendary.png"), 
	"legendary": preload("res://project_specific/gfx/cards/card-bg-unlocked-legendary.png"), 
}
const default_rarity: = "common"

const rarity_importance: = ["common", "rare", "epic", "legendary"]

var rendering_quantity: int = 0
var quantity_denominator: int = 0
var is_unlocked: bool = false
var item_level: int = 0
var cosmetic_id: String = ""
func show_cosmetic(_cosmetic_id: String, card_data: Dictionary):
	cosmetic_id = _cosmetic_id
	var cosmetic_data: = CosmeticsCollection.lookup_cosmetic_id(cosmetic_id)
	if cosmetic_data.empty():
		printerr("[CosmeticCard] show_cosmetic(%s) cant find cosmetic data" % [cosmetic_id])
		return
	
	var rarity: String = cosmetic_data.get("rarity", "common")
	is_unlocked = card_data.get("unlocked", false)
	rendering_quantity = int(card_data.get("quantity", 0))
	item_level = int(cosmetic_data.get("level", 0))
	quantity_denominator = CosmeticsCollection.card_cost_for_item_level(item_level, rarity)
	if not is_unlocked:
		set_quantity(rendering_quantity)
	
	set_rarity(rarity)
	
	
	var cosmetic_type: String = cosmetic_data["type"]
	var is_emote: = cosmetic_type == "emote"
	goober_container.visible = not is_emote
	emote_container.visible = is_emote
	if is_emote:
		var spine_reference: String = cosmetic_data["spine"]
		emote_spine.show_loop_animation(spine_reference)
	else:
		emote_spine._reset_everything()
		goober.set_cosmetic(cosmetic_id)
	
	progress_icon.visible = not is_unlocked
	if is_unlockable():
		unlock_alert.visible = true
		border_locked_shader_material.set_shader_param("on", true)
		if (unlocktween1 == null):
			unlocktween1 = create_tween()
			unlocktween1.tween_interval(1.0)
			unlocktween1.tween_property(unlock_alert, "rect_scale", 0.8 * Vector2.ONE, 0.2).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
			unlocktween1.tween_property(unlock_alert, "rect_scale", 1.3 * Vector2.ONE, 0.2).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
			unlocktween1.tween_property(unlock_alert, "rect_scale", Vector2.ONE, 0.2).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
			unlocktween1.set_loops()
			
	else:
		border_locked_shader_material.set_shader_param("on", false)
		unlock_alert.visible = false
		if unlocktween1 != null:
			unlocktween1.kill()
			unlocktween1 = null
	
	progress.visible = not is_unlocked
	bg_unlocked.visible = is_unlocked
	border.visible = is_unlocked
	border_locked.visible = not is_unlocked

func set_rarity(rarity: String):
	var rarity_color: Color = rarity_to_color[rarity]
	var rarity_tex: Texture = rarity_to_tex[rarity]
	
	bg_unlocked.set_texture(rarity_tex)
	bg_shader_material.set_shader_param("color_bottom", rarity_color)
	border_locked_shader_material.set_shader_param("color", rarity_color)
	progress.tint_progress = rarity_color

func set_quantity(quantity: int):
	if quantity >= quantity_denominator:
		progress_label.text = "UNLOCK!"
	else:
		progress_label.text = "%d/%d" % [quantity, quantity_denominator]
	if quantity_denominator > 0:
		progress.value = clamp(float(quantity) / quantity_denominator, 0.0, 1.0)
	
	if rendering_quantity != quantity:
		rendering_quantity = quantity
		emit_signal("quantity_changed", rendering_quantity, quantity_denominator)

func set_disable_button(b: bool):
	disable_button = b
	if button:
		if disable_button:
			button.mouse_filter = MOUSE_FILTER_IGNORE
			button.disabled = true
			button_focusable.force_disable_focus = true
		else:
			button.mouse_filter = MOUSE_FILTER_PASS
			button.disabled = false
			button_focusable.force_disable_focus = false

func is_unlockable() -> bool:
	return not is_unlocked and rendering_quantity >= quantity_denominator
