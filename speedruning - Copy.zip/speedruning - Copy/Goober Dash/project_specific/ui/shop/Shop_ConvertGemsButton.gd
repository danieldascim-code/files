extends BaseButton
class_name ShopConvertGemsButton

export  var _coin_label: NodePath
onready var coin_label: Label = get_node(_coin_label)

export  var _gem_cost_label: NodePath
onready var gem_cost_label: Label = get_node(_gem_cost_label)

export  var _focusable: NodePath
onready var focusable: Focusable = get_node(_focusable)

export  var _coin_stack_icon: NodePath
onready var coin_stack_icon: TextureRect = get_node(_coin_stack_icon)

export  var coin_stack_icon_1: Texture
export  var coin_stack_icon_2: Texture

func set_gems_and_coins(gems: int, coins: int):
	coin_label.text = "%d" % coins
	gem_cost_label.text = "%d" % gems
	if coins > 500:
		coin_stack_icon.texture = coin_stack_icon_2
