extends Control

export  var convert_button_scene: PackedScene
export  var gems_button_scene: PackedScene
export  var prizeround_button_scene: PackedScene

export  var _gems_buttons_parent: NodePath
onready var gems_buttons_parent: = get_node(_gems_buttons_parent)

export  var _converts_buttons_parent: NodePath
onready var converts_buttons_parent: = get_node(_converts_buttons_parent)

export  var _prizeround_buttons_parent: NodePath
onready var prizeround_buttons_parent: = get_node(_prizeround_buttons_parent)

export  var _fullwidth_offers: NodePath
onready var fullwidth_offers: = get_node(_fullwidth_offers)

export  var _rewarded_ad_offer: NodePath
onready var rewarded_ad_offer: = get_node(_rewarded_ad_offer) as ShopRewardedAdOfferGenericButton

export  var _buttons_parent: NodePath
onready var buttons_parent: Control = get_node(_buttons_parent)

export  var _deals_panel: NodePath
onready var deals_panel: Shop_DealsPanel = get_node(_deals_panel)

export  var _rewarded_ad_offer_shortcut_button: NodePath
onready var rewarded_ad_offer_shortcut_button: RewardedAdsHomeSceneButton = get_node(_rewarded_ad_offer_shortcut_button)

var gem_buttons: = []
var prizeround_buttons: = []
var coin_conversion_buttons: = []

var spinner_dialog
var ad_placement: = ""

func _ready() -> void :
	Moonlight.shop.connect("products_loaded", self, "on_products_loaded")
	rewarded_ad_offer.connect("pressed", self, "on_rewarded_ad_offer_pressed")
	rewarded_ad_offer_shortcut_button.connect("pressed", self, "on_rewarded_ad_offer_pressed")
	_render_products()
	_clear_rewarded_ad_offers()
	
	if AdManager.supports_rewarded_ads() or OS.has_feature("editor"):
		_fetch_offers()
	else:
		GlobalEvent.emit_signal("UI_REWARDED_AD_UNAVAILABLE")
	
	FocusGlobal.connect("focus_lost", self, "on_focus_lost")
	connect("visibility_changed", self, "on_visibility_changed")
	Moonlight.shop.connect("product_purchase_complete", self, "on_purchase_product_complete")

func on_purchase_product_complete(sku: String):
	thank_you_dialog()

func on_visibility_changed():
	if is_visible_in_tree():
		_give_focus()

func on_focus_lost(c: Control):
	if c != null and is_a_parent_of(c):
		_give_focus()

func _give_focus():
	if deals_panel._give_focus():
		return
	if gem_buttons.size() > 0:
		FocusGlobal.focus_on_control(gem_buttons[0])
		return

func _fetch_offers() -> void :
	ad_placement = ""
	var rpc_result: Dictionary = yield(Moonlight.call_rpc("get_current_available_offers", {}, false), "completed")
	if not rpc_result.has("error"):
		var offers: Dictionary = rpc_result.get("offers", {})
		var rewarded_ad: Dictionary = offers.get("rewardedad", {})
		if rewarded_ad.has("type"):
			var rewarded_ad_type: String = rewarded_ad["type"]
			var rewarded_ad_count: int = rewarded_ad["count"]
			ad_placement = rewarded_ad_type
			if AdManager.is_rewarded_video_ready():
				rewarded_ad_offer.set_ad_placement(ad_placement, rewarded_ad_count)
				fullwidth_offers.visible = true
				rewarded_ad_offer_shortcut_button.show()
				rewarded_ad_offer_shortcut_button.show_ad_placement(ad_placement, rewarded_ad_count)
				
				GlobalEvent.emit_signal("UI_REWARDED_AD_AVAILABLE")


func on_rewarded_ad_offer_pressed():
	_show_rewarded_ad(ad_placement)

func _show_rewarded_ad(ad_placement: String):
	var success: bool = yield(AdManager.show_rewarded_ad(), "completed")
	if not success:
		_rewarded_ad_error(ad_placement)
	else:
		_rewarded_ad_finished(ad_placement)

func _rewarded_ad_error(ad_placement: String):
	
	var dialog: = GoodResourceLoader.load_resource(GoodSceneRegistry.notification_dialog_scene).instance() as UINotifyDialog
	dialog.text = "Unable to get offer at this time"
	get_tree().current_scene.add_child(dialog)
	dialog.dialog.dialog_title_label.text = "ERROR"
	dialog.dialog.animate_in()
	
	_clear_rewarded_ad_offers()

func _rewarded_ad_finished(ad_placement: String):
	
	var rpc_result: Dictionary = yield(Moonlight.call_rpc("claim_rewarded_ad", {"ad_placement": ad_placement}, true), "completed")
	_clear_rewarded_ad_offers()
	if rpc_result.has("error"):
		
		var dialog: = GoodResourceLoader.load_resource(GoodSceneRegistry.notification_dialog_scene).instance() as UINotifyDialog
		dialog.text = "Unknown error claiming prize"
		get_tree().current_scene.add_child(dialog)
		dialog.dialog.dialog_title_label.text = "ERROR"
		dialog.dialog.animate_in()
	else:
		if ad_placement == "free_spin":
			var free_spin_dialog: FreeSpinDialog = load("res://project_specific/ui/wheel/FreeSpinDialog.tscn").instance()
			get_tree().current_scene.add_child(free_spin_dialog)
		else:
			
			
			var prize_text = "Success!"
			if ad_placement == "prize_round":
				prize_text = "You got a prize round!"

			var dialog: = GoodResourceLoader.load_resource(GoodSceneRegistry.notification_dialog_scene).instance() as UINotifyDialog
			dialog.text = prize_text
			get_tree().current_scene.add_child(dialog)
			dialog.dialog.dialog_title_label.text = "SUCCESS"
			dialog.dialog.background_override = true
			dialog.dialog.animate_in()

func thank_you_dialog():
	var dialog: = GoodResourceLoader.load_resource(GoodSceneRegistry.notification_dialog_scene).instance() as UINotifyDialog
	dialog.text = "Thank you for making a purchase!\n\nWinterpixel Games is a small studio and we appreciate your support!"
	get_tree().current_scene.add_child(dialog)
	dialog.dialog.dialog_title_label.text = "THANK YOU"
	dialog.dialog.background_override = true
	var sdf_label: SDFLabel = dialog.label
	sdf_label.font_size = SDFLabel.FontSize._48
	dialog.dialog.animate_in()

func _clear_rewarded_ad_offers():
	fullwidth_offers.hide()
	rewarded_ad_offer_shortcut_button.hide()
	GlobalEvent.emit_signal("UI_REWARDED_AD_UNAVAILABLE")

func on_products_loaded():
	_render_products()
	
	

func _render_products():
	_delete_gem_buttons()
	_delete_prizeround_buttons()
	_delete_coin_conversion_buttons()
	if not Moonlight.discord_api.discord_platform_is_mobile():
		
		for p in Moonlight.shop.products:
			var product_id: String = p
			var product: Moonlight_ShopProduct = Moonlight.shop.products[product_id]
			if product.product_id.begins_with("gooberdashgems"):
				var gem_button: ShopGemsButton = gems_button_scene.instance()
				gems_buttons_parent.add_child(gem_button)
				gem_button.set_product_id(product.product_id)
				gem_button.connect("pressed", self, "on_gem_button_pressed", [product_id])
				gem_button.title_label.text = product.product_name
				if product.product_price.empty():
					gem_button.price_label.text = ""
				else:
					gem_button.price_label.text = product.product_price
				
				gem_buttons.append(gem_button)
	
	var prizerounds: Dictionary = Moonlight.storage.storage_get("shop.offers.prizerounds", {})
	for prizeroundkey in prizerounds:
		var prizeRoundDict = prizerounds[prizeroundkey]
		var gem_cost: int = prizeRoundDict["gemcost"]
		var round_count: int = prizeRoundDict["rounds"]
		
		var prizeround_button: ShopPrizeroundButton = prizeround_button_scene.instance()
		prizeround_buttons_parent.add_child(prizeround_button)
		prizeround_button.set_cost_and_rounds(gem_cost, round_count)
		prizeround_button.connect("pressed", self, "on_prizeround_button_pressed", [prizeroundkey])
		prizeround_buttons.append(prizeround_button)
	
	var gemconversions: Dictionary = Moonlight.storage.storage_get("shop.offers.gemconversions", {})
	for gemconversionkey in gemconversions:
		var gemConversionDict = gemconversions[gemconversionkey]
		var gem_cost: int = gemConversionDict["gems"]
		var coin_value: int = gemConversionDict["coins"]
		
		var convert_button: ShopConvertGemsButton = convert_button_scene.instance()
		converts_buttons_parent.add_child(convert_button)
		convert_button.set_gems_and_coins(gem_cost, coin_value)
		convert_button.connect("pressed", self, "on_convertgems_button_pressed", [gemconversionkey])
		coin_conversion_buttons.append(convert_button)

func _delete_prizeround_buttons():
	for g in prizeround_buttons:
		prizeround_buttons_parent.remove_child(g)
		g.queue_free()
	prizeround_buttons.clear()
	
func _delete_coin_conversion_buttons():
	for g in coin_conversion_buttons:
		converts_buttons_parent.remove_child(g)
		g.queue_free()
	coin_conversion_buttons.clear()

func _delete_gem_buttons():
	for g in gem_buttons:
		gems_buttons_parent.remove_child(g)
		g.queue_free()
	gem_buttons.clear()

func on_gem_button_pressed(product_id: String):
	if AdManager.get_ad_driver() == "crazygames":
		if Moonlight.auth.is_guest_account():
			var message_is_guest: = "Sign up to to buy gems!"
			var notification_dialog_scene: PackedScene = load("res://goodoh/ui/nodes/UINotifyDialog.tscn")
			var notification_dialog: = notification_dialog_scene.instance() as UINotifyDialog
			notification_dialog.set_label_text(message_is_guest)
			get_tree().current_scene.add_child(notification_dialog)
			notification_dialog.dialog.dialog_title_label.text = "SIGN UP"
			return
	
	if not OS.has_feature("steam") and (OS.has_feature("iOS") or OS.has_feature("OSX")):
		if not Moonlight.shop.is_connected("product_purchase_complete", self, "_on_apple_product_purchased"):
			Moonlight.shop.connect("product_purchase_complete", self, "_on_apple_product_purchased", [product_id])
			Moonlight.shop.connect("product_purchase_error", self, "_on_apple_product_error", [product_id])
			
		spinner_dialog = GoodResourceLoader.load_resource(GoodSceneRegistry.spinner_dialog_scene).instance() as UISpinnerDialog
		add_child(spinner_dialog)
		spinner_dialog.text = "Purchasing..."
		Moonlight.shop.buy_product_id(product_id)
	else:
		Moonlight.shop.buy_product_id(product_id)
	
func _on_apple_product_purchased(product_id, target_product_id):
	if spinner_dialog and product_id == target_product_id:
		remove_child(spinner_dialog)
		spinner_dialog.queue_free()
		spinner_dialog = null
	
func _on_apple_product_error(product_id, target_product_id):
	if spinner_dialog and product_id == target_product_id:
		remove_child(spinner_dialog)
		spinner_dialog.queue_free()
		spinner_dialog = null

func _exit_tree():
	if Moonlight.shop.is_connected("product_purchase_complete", self, "_on_apple_product_purchased"):
		Moonlight.shop.disconnect("product_purchase_complete", self, "_on_apple_product_purchased")
		Moonlight.shop.disconnect("product_purchase_complete", self, "_on_apple_product_purchased")

func on_convertgems_button_pressed(convertid: String):
	var conversions: Dictionary = Moonlight.storage.storage_get("shop.offers.gemconversions", {})
	var conversionDict = conversions[convertid]
	var gem_cost: int = conversionDict["gems"]
	var coins: int = conversionDict["coins"]
	
	var current_gem_balance: int = Moonlight.storage.storage_get("wallet.gems", 0)
	if current_gem_balance < gem_cost:
		var popup: = GoodResourceLoader.load_resource(GoodSceneRegistry.notification_dialog_scene).instance() as UINotifyDialog
		popup.text = "Get more gems to buy this!"
		get_tree().current_scene.add_child(popup)
		popup.dialog.dialog_title_label.text = "NOT ENOUGH GEMS"
		popup.dialog.animate_in()
		return

	
	var confirm_dialog: UIConfirmationDialog = GoodResourceLoader.load_resource(GoodSceneRegistry.confirmation_dialog_scene).instance()
	confirm_dialog.text = "Spend %d gems to convert to  %d coins?" % [gem_cost, coins]
	get_tree().current_scene.add_child(confirm_dialog)
	var confirmed: bool = yield(confirm_dialog, "confirm_or_cancel")
	if confirmed:
		on_convertgems_button_spend_confirmed(convertid)

func on_convertgems_button_spend_confirmed(convertid: String):
	var response: Dictionary = yield(Moonlight.call_rpc("convert_gems", {
		"coinvertid": convertid
	}), "completed")
	
	if response == null or response.has("error"):
		printerr("[PlayerProfileDialog] buy_prize_rounds failed")
		
		var popup: = GoodResourceLoader.load_resource(GoodSceneRegistry.notification_dialog_scene).instance() as UINotifyDialog
		if response:
			popup.text = response["error"]
		else:
			popup.text = "Unknown error"
		get_tree().current_scene.add_child(popup)
		popup.dialog.dialog_title_label.text = "ERROR"
		popup.dialog.animate_in()

func on_prizeround_button_pressed(prizeroundid: String):
	var prizerounds: Dictionary = Moonlight.storage.storage_get("shop.offers.prizerounds", {})
	var prizeRoundDict = prizerounds[prizeroundid]
	var gem_cost: int = prizeRoundDict["gemcost"]
	var prizeroundcount: int = prizeRoundDict["rounds"]
	
	var current_gem_balance: int = Moonlight.storage.storage_get("wallet.gems", 0)
	if current_gem_balance < gem_cost:
		var popup: = GoodResourceLoader.load_resource(GoodSceneRegistry.notification_dialog_scene).instance() as UINotifyDialog
		popup.text = "Get more gems to buy additional prize rounds!"
		get_tree().current_scene.add_child(popup)
		popup.dialog.dialog_title_label.text = "NOT ENOUGH GEMS"
		popup.dialog.animate_in()
		return
	
	
	var confirm_dialog: UIConfirmationDialog = GoodResourceLoader.load_resource(GoodSceneRegistry.confirmation_dialog_scene).instance()
	confirm_dialog.text = "Spend %s gems to buy %s prize rounds?" % [gem_cost, prizeroundcount]
	get_tree().current_scene.add_child(confirm_dialog)
	var confirmed: bool = yield(confirm_dialog, "confirm_or_cancel")
	if confirmed:
		on_prizeround_button_spend_confirmed(prizeroundid)

func on_prizeround_button_spend_confirmed(prizeroundid: String):
	var response: Dictionary = yield(Moonlight.call_rpc("buy_prize_rounds", {
		"prizeroundid": prizeroundid
	}), "completed")
	
	if response == null or response.has("error"):
		printerr("[PlayerProfileDialog] buy_prize_rounds failed")
		
		var popup: = GoodResourceLoader.load_resource(GoodSceneRegistry.notification_dialog_scene).instance() as UINotifyDialog
		if response:
			popup.text = response["error"]
		else:
			popup.text = "Unknown error"
		get_tree().current_scene.add_child(popup)
		popup.dialog.dialog_title_label.text = "ERROR"
		popup.dialog.animate_in()
	else:
		var popup: = GoodResourceLoader.load_resource(GoodSceneRegistry.notification_dialog_scene).instance() as UINotifyDialog
		popup.text = "You got Prize Rounds!\nGo play to unlock new Cards!"
		get_tree().current_scene.add_child(popup)
		popup.dialog.dialog_title_label.text = "SUCCESS"
		popup.dialog.animate_in()
