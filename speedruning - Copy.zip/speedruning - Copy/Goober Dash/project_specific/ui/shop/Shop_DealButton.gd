extends Control
class_name Shop_DealButton

signal button_pressed()

var product_id: String = ""

export  var _title_label: NodePath
onready var title_label: Label = get_node_or_null(_title_label)

export  var _price_label: NodePath
onready var price_label: Label = get_node(_price_label)

export  var _time_label: NodePath
onready var time_label: Label = get_node(_time_label)

export  var _time_panel: NodePath
onready var time_panel: Control = get_node(_time_panel)

export  var _goober: NodePath
onready var goober: Goober = get_node(_goober)

export  var _goober_parent: NodePath
onready var goober_parent: Control = get_node(_goober_parent)

export  var _description_label: NodePath
onready var description_label: Label = get_node_or_null(_description_label)

export  var _emote_and_currencies: NodePath
onready var emote_and_currencies: Control = get_node_or_null(_emote_and_currencies)

export  var _emote: NodePath
onready var emote: EmoteSpineSprite = get_node_or_null(_emote)

export  var _gems_parent: NodePath
onready var gems_parent: Control = get_node_or_null(_gems_parent)

export  var _gems_value_label: NodePath
onready var gems_value_label: Label = get_node_or_null(_gems_value_label)

export  var _coins_parent: NodePath
onready var coins_parent: Control = get_node_or_null(_coins_parent)

export  var _coins_value_label: NodePath
onready var coins_value_label: Label = get_node_or_null(_coins_value_label)

export  var _cost_coin_icon: NodePath
onready var cost_coin_icon: TextureRect = get_node(_cost_coin_icon)

export  var _cost_gem_icon: NodePath
onready var cost_gem_icon: TextureRect = get_node(_cost_gem_icon)

export  var _button: NodePath
onready var button: Button = get_node(_button)
export  var shop_purchase_on_press: = false

var has_seconds_left: = false
var seconds_left: = 0.0

func _ready() -> void :
	button.connect("pressed", self, "on_button_pressed")
	button.connect("pressed", self, "emit_signal", ["button_pressed"])

func on_button_pressed():
	if AdManager.get_ad_driver() == "crazygames":
		if Moonlight.auth.is_guest_account():
			var message_is_guest: = "Sign up to make purchases!"
			var notification_dialog_scene: PackedScene = load("res://goodoh/ui/nodes/UINotifyDialog.tscn")
			var notification_dialog: = notification_dialog_scene.instance() as UINotifyDialog
			notification_dialog.set_label_text(message_is_guest)
			get_tree().current_scene.add_child(notification_dialog)
			notification_dialog.dialog.dialog_title_label.text = "SIGN UP"
			return
	
	if product_id.empty():
		return
	if not shop_purchase_on_press:
		return
	var product: Moonlight_ShopProduct = Moonlight.shop.products.get(product_id, null)
	if not product:
		return
	if product.has_wallet_cost:
		return
	
	Moonlight.shop.buy_product_id(product_id)

func render_product(product: Moonlight_ShopProduct):
	product_id = product.product_id
	has_seconds_left = product.deal_start != 0 and product.deal_end != 0
	seconds_left = product.deal_end - Time.get_unix_time_from_system()
	if title_label != null:
		title_label.text = product.product_name
		
	if time_panel:
		time_panel.visible = has_seconds_left
	
	var coin_gain: int = Moonlight_Storage.nested_get("wallet.coins", product.product_data, 0)
	var gem_gain: int = Moonlight_Storage.nested_get("wallet.gems", product.product_data, 0)
	var cosmetics: Array = Moonlight_Storage.nested_get("data.cosmetics", product.product_data, [])
	var color_ids: = []
	var skin_ids: = []
	var emote_ids: = []
	var dance_ids: = []
	
	for c in cosmetics:
		var cosmetic_data: Dictionary = CosmeticsCollection.lookup_cosmetic_id(c)
		if cosmetic_data.has("dance"):
			var dance: String = cosmetic_data["dance"]
			if not dance.empty():
				dance_ids.append(dance)
		var cosmetic_type: String = cosmetic_data.get("type", "")
		if cosmetic_type == "color":
			color_ids.append(c)
		if cosmetic_type == "emote":
			emote_ids.append(c)
		else:
			skin_ids.append(c)
	
	if description_label:
		var description_fields: = PoolStringArray()
		
		if skin_ids.size() > 0:
			description_fields.append("LEGENDARY GOOBER!")
		if emote_ids.size() > 0:
			description_fields.append("EXCLUSIVE EMOTE!")
		if dance_ids.size() > 0:
			description_fields.append("UNIQUE DANCE!")
		if coin_gain > 0:
			description_fields.append("%d COINS!" % [coin_gain])
		if gem_gain > 0:
			description_fields.append("%d GEMS!" % [gem_gain])
		description_label.text = description_fields.join("\n")
	
	goober_parent.visible = skin_ids.size() > 0
	if goober_parent.visible:
		var goober_skin_data: = {}
		if color_ids.size() == 0:
			var self_color: String = Moonlight.storage.storage_get("player.profile.skin.color", "")
			if self_color.empty():
				self_color = CosmeticsCollection.color_yellow_id
			goober_skin_data["color"] = self_color
		for c in skin_ids:
			var cosmetic_data: = CosmeticsCollection.lookup_cosmetic_id(c)
			if cosmetic_data.empty():
				printerr("[ShopDealButton] couldnt render cosmetic id %s" % [c])
				assert (false)
				continue
			goober_skin_data[cosmetic_data["type"]] = c
		goober.set_goober_skin_data(goober_skin_data)
	
	if emote_and_currencies != null:
		emote_and_currencies.visible = coin_gain > 0 or gem_gain > 0 or emote_ids.size() > 0
		if emote_and_currencies.visible:
			if gems_parent != null:
				gems_parent.visible = gem_gain > 0
				if gems_parent.visible:
					gems_value_label.text = "+" + str(gem_gain)
			
			if coins_parent != null:
				coins_parent.visible = coin_gain > 0
				if coins_parent.visible:
					coins_value_label.text = "+" + str(coin_gain)
			
			if emote != null:
				emote.visible = emote_ids.size() > 0
				if emote.visible:
					var first_emote_id: String = emote_ids[0]
					var emote_data: = CosmeticsCollection.lookup_cosmetic_id(first_emote_id)
					var emote_anim: String = emote_data.get("spine", "")
					if not emote_anim.empty():
						emote.show_loop_animation(emote_anim)
					
					if not coins_parent.visible and not gems_parent.visible:
						emote.position = Vector2(100.0, 100.0)
						if not goober_parent.visible:
							emote.scale = Vector2(1.0, 1.0)
						
	
	on_shop_prices_loaded()


func on_shop_prices_loaded():
	cost_coin_icon.visible = false
	cost_gem_icon.visible = false
	price_label.text = ""
	
	var product: Moonlight_ShopProduct = Moonlight.shop.products.get(product_id, null)
	if product != null:
		if not product.has_wallet_cost:
			price_label.text = product.product_price
		else:
			var coin_cost: int = Moonlight_Storage.nested_get("coins", product.wallet_cost, 0)
			var gem_cost: int = Moonlight_Storage.nested_get("gems", product.wallet_cost, 0)
			if gem_cost > 0 and coin_cost > 0:
				printerr("[Moonlight_ShopProduct] cant effectively display both coin and gem cost at once")
				price_label.text = "%dG & %dC" % [gem_cost, coin_cost]
				assert (false)
			elif gem_cost > 0:
				cost_gem_icon.visible = true
				price_label.text = str(gem_cost)
			elif coin_cost > 0:
				cost_coin_icon.visible = true
				price_label.text = str(coin_cost)

func _process(delta: float) -> void :
	if not product_id.empty() and has_seconds_left:
		seconds_left -= delta
		if seconds_left <= 0.0:
			hide()
		else:
			time_label.text = DateTimeUtils.format_time_shorter(int(ceil(seconds_left)))
