extends Control

signal button_pressed()

export  var _shop_deal_alert_button: NodePath
onready var shop_deal_alert_button: Shop_DealButton = get_node(_shop_deal_alert_button)

func _ready() -> void :
	shop_deal_alert_button.connect("button_pressed", self, "emit_signal", ["button_pressed"])
	shop_deal_alert_button.hide()

func _process(delta: float) -> void :
	if not Moonlight.auth.is_logged_in():
		return
	if Moonlight.discord_api.discord_platform_is_mobile():
		return
	
	var deal_ids: = Moonlight.shop.active_deal_ids()
	if deal_ids.size() == 0:
		shop_deal_alert_button.visible = false
	else:
		shop_deal_alert_button.visible = true
		var deal_id: = ""
		if deal_ids.size() == 1:
			deal_id = deal_ids[0]
		else:
			deal_id = deal_ids[0]
			var temporary_deal_ids: = []
			for active_deal_id in deal_ids:
				var product: Moonlight_ShopProduct = Moonlight.shop.products.get(active_deal_id, null)
				if product.is_time_limited_deal():
					temporary_deal_ids.append(active_deal_id)
			if temporary_deal_ids.size() > 0:
				deal_id = temporary_deal_ids[0]
		
		var product: Moonlight_ShopProduct = Moonlight.shop.products.get(deal_id, null)
		shop_deal_alert_button.render_product(product)
