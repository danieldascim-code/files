extends ToolButton
class_name ShopRewardedAdOfferGenericButton

var ad_placement: = ""

export  var prize_round_tex: Texture
export  var free_spin_tex: Texture
export  var free_gem_tex: Texture
export  var free_coin_tex: Texture


export  var _large_icon: NodePath
onready var large_icon: = get_node(_large_icon) as TextureRect

export  var _large_text: NodePath
onready var large_text: = get_node(_large_text) as SDFLabel

export  var _small_text: NodePath
onready var small_text: = get_node(_small_text) as SDFLabel


func _ready():
	set_ad_placement("free_gem", 5)

func set_ad_placement(p_ad: String, count: int) -> void :
	ad_placement = p_ad
	
	if ad_placement == "prize_round":
		large_text.text = "PRIZE ROUND!"
		small_text.text = "Activate a Prize Round!"
		large_icon.texture = prize_round_tex
	elif ad_placement == "free_spin":
		large_text.text = "FREE SPIN!"
		small_text.text = "Spin the Wheel!!"
		large_icon.texture = free_spin_tex
	elif ad_placement == "free_gem":
		large_text.text = "FREE GEMS!"
		small_text.text = "Get %d Free Gems!" % count
		large_icon.texture = free_gem_tex
	elif ad_placement == "free_coin":
		large_text.text = "FREE COINS!"
		small_text.text = "Get %d Free Coins!" % count
		large_icon.texture = free_coin_tex
