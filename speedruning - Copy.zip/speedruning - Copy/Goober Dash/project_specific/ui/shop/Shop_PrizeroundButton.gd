extends ToolButton
class_name ShopPrizeroundButton

export  var _round_label: NodePath
onready var round_label: Label = get_node(_round_label)

export  var _gem_label: NodePath
onready var gem_label: Label = get_node(_gem_label)

func set_cost_and_rounds(cost: int, rounds: int):
	round_label.text = String(rounds)
	gem_label.text = String(cost)
