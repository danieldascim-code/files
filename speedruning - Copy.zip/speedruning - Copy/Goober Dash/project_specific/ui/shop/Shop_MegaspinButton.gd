extends ToolButton
class_name ShopMegaspinButton


func _ready():
	pass

func _pressed():
	var gem_cost: = 100
	var current_gem_balance: int = Moonlight.storage.storage_get("wallet.gems", 0)
	if current_gem_balance < gem_cost:
		var popup: = GoodResourceLoader.load_resource(GoodSceneRegistry.notification_dialog_scene).instance() as UINotifyDialog
		popup.text = "Get more gems to buy a mega spin!"
		get_tree().current_scene.add_child(popup)
		popup.dialog.dialog_title_label.text = "NOT ENOUGH GEMS"
		popup.dialog.animate_in()
		return
	
	
	
	var confirm_dialog_scene: PackedScene = GoodResourceLoader.load_resource(GoodSceneRegistry.confirmation_dialog_scene)
	var popup: = confirm_dialog_scene.instance() as UIConfirmationDialog
	popup.text = "Are you sure you want to spend %d gems for this mega spin?" % [gem_cost]
	add_child(popup)
	var confirmed: bool = yield(popup, "confirm_or_cancel")
	if confirmed:
		
		
		var rpc_result: Dictionary = yield(Moonlight.call_rpc("mega_spin", {}, true), "completed")
		if not rpc_result.has("error"):
			
			var spin_results: Dictionary = Moonlight_Storage.nested_get("metadata.spin_results", rpc_result, {})
			var free_spin_dialog: FreeSpinDialog = load("res://project_specific/ui/wheel/FreeSpinDialog.tscn").instance()
			free_spin_dialog.show_manual_spin_results = true
			get_tree().current_scene.add_child(free_spin_dialog)
			free_spin_dialog.show_spin_results(spin_results)
			free_spin_dialog.dialog.animate_in()
		else:
			
			var dialog: = GoodResourceLoader.load_resource(GoodSceneRegistry.notification_dialog_scene).instance() as UINotifyDialog
			dialog.text = "Failed to buy Mega Spin."
			get_tree().current_scene.add_child(dialog)
			dialog.dialog.dialog_title_label.text = "ERROR"
			dialog.dialog.animate_in()
	else:
		
		
		pass
	
	
	
