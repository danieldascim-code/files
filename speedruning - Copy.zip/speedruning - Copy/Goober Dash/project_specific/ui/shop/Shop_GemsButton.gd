extends BaseButton
class_name ShopGemsButton

var product_id: String = ""

export  var _icon: NodePath
onready var icon: TextureRect = get_node(_icon)

export  var gem_icon_negative_1: Texture
export  var gem_icon_0: Texture
export  var gem_icon_1: Texture
export  var gem_icon_2: Texture
export  var gem_icon_3: Texture
export  var gem_icon_4: Texture


export  var _title_label: NodePath
onready var title_label: Label = get_node(_title_label)

export  var _price_label: NodePath
onready var price_label: Label = get_node(_price_label)

export  var _focusable: NodePath
onready var focusable: Focusable = get_node(_focusable)

func _ready():
	Moonlight.shop.connect("products_loaded", self, "_on_shop_products_loaded")

func set_product_id(id: String):
	product_id = id
	match product_id:
		"gooberdashgems0":
			icon.texture = gem_icon_negative_1
		"gooberdashgems1":
			icon.texture = gem_icon_0
		"gooberdashgems2":
			icon.texture = gem_icon_1
		"gooberdashgems3":
			icon.texture = gem_icon_2
		"gooberdashgems4":
			icon.texture = gem_icon_3
		"gooberdashgems5":
			icon.texture = gem_icon_4
		_:
			printerr("[ShopGemsButton] set_product_id() unknown product id %s" % [product_id])
	
	icon.rect_size = Vector2.ZERO
	
	_on_shop_products_loaded()

func _on_shop_products_loaded():
	var product: Moonlight_ShopProduct = Moonlight.shop.products.get(product_id, null)
	if product != null:
		price_label.text = product.product_price
	
