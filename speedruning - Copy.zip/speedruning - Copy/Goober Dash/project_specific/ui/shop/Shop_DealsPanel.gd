extends Control
class_name Shop_DealsPanel

export  var deal_node_path: String

export  var _deal_nodes_parent: NodePath
onready var deal_nodes_parent: Control = get_node(_deal_nodes_parent)

var test_products: = [
	"judge_deal"
]

var deal_nodes: = []

func _ready() -> void :
	if Moonlight.discord_api.discord_platform_is_mobile():
		hide()
		return
	
	Moonlight.shop.connect("products_loaded", self, "_create_deal_nodes")
	_create_deal_nodes()

func _create_deal_nodes():
	for c in deal_nodes:
		
		c.visible = false
	
	for c in deal_nodes:
		c.get_parent().remove_child(c)
		c.free()
	deal_nodes.clear()
	
	var deal_ids: = Moonlight.shop.active_deal_ids()
	var testing_deal_ids: = []
	if OS.has_feature("editor"):
		for t in test_products:
			if not deal_ids.has(t):
				deal_ids.append(t)
				testing_deal_ids.append(t)
	
	for deal_id in deal_ids:
		var product: Moonlight_ShopProduct = Moonlight.shop.products.get(deal_id, null)
		if product:
			_create_deal_node(product)
	visible = deal_nodes.size() > 0

func _create_deal_node(product: Moonlight_ShopProduct):
	var deal_node_scene: PackedScene = load(deal_node_path)
	var deal_node: Shop_DealButton = deal_node_scene.instance()
	deal_nodes_parent.add_child(deal_node)
	deal_nodes.append(deal_node)
	deal_node.render_product(product)
	deal_node.connect("pressed", self, "on_deal_button_pressed", [product])

func on_deal_button_pressed(product: Moonlight_ShopProduct):
	
	var product_id: = product.product_id
	if not product.has_wallet_cost:
		
		if AdManager.get_ad_driver() == "crazygames" and Moonlight.auth.is_guest_account():
			var message_is_guest: = "Sign in to to purchase this!"
			var notification_dialog_scene: PackedScene = load("res://goodoh/ui/nodes/UINotifyDialog.tscn")
			var notification_dialog: = notification_dialog_scene.instance() as UINotifyDialog
			notification_dialog.set_label_text(message_is_guest)
			get_tree().current_scene.add_child(notification_dialog)
			notification_dialog.dialog.dialog_title_label.text = "SIGN UP"
			return
		
		
		Moonlight.shop.buy_product_id(product_id)
	else:
		
		
		for currency_key in product.wallet_cost:
			var currency_cost: = int(product.wallet_cost[currency_key])
			var wallet_currency: = int(Moonlight.storage.storage_get("wallet." + currency_key, 0))
			if wallet_currency < currency_cost:
				
				
				var notify_dialog_scene: PackedScene = GoodResourceLoader.load_resource("res://goodoh/ui/nodes/UINotifyDialog.tscn")
				var notify_dialog: UINotifyDialog = notify_dialog_scene.instance()
				var currency_display: String = String(currency_key).capitalize()
				
				notify_dialog.text = "Not enough %s!\nBuy more %s to purchase this deal!" % [currency_display, currency_display]
				get_tree().current_scene.add_child(notify_dialog)
				notify_dialog.dialog.dialog_title_label.text = "NOT ENOUGH"
				notify_dialog.dialog.background_override = true
				return
		
		
		var confirm_dialog_scene: PackedScene = GoodResourceLoader.load_resource("res://goodoh/ui/nodes/UIConfirmationDialog.tscn")
		var confirm_dialog: UIConfirmationDialog = confirm_dialog_scene.instance()
		var spend_message: String = ""
		for currency_key in product.wallet_cost:
			var currency_cost: = int(product.wallet_cost[currency_key])
			var currency_display: String = String(currency_key).capitalize()
			if spend_message.empty():
				spend_message = "%d %s" % [currency_cost, currency_display]
			else:
				spend_message = spend_message + " and %d %s" % [currency_cost, currency_display]
		confirm_dialog.text = "Spend %s to purchase %s?" % [spend_message, product.product_name]
		get_tree().current_scene.add_child(confirm_dialog)
		confirm_dialog.dialog.background_override = true
		var confirmed: bool = yield(confirm_dialog, "confirm_or_cancel")
		if confirmed:
			Moonlight.shop.buy_product_id(product_id)

func _give_focus() -> bool:
	for d in deal_nodes:
		var deal_node: Shop_DealButton = d
		if deal_node.visible:
			FocusGlobal.focus_on_control(deal_node)
			return true
	return false

