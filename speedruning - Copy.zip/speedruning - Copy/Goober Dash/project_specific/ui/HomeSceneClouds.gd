extends Node

export (Array, NodePath) var _home_scene_cloud_anchors
var home_scene_cloud_anchors: Array = []

export  var _button_grouper: NodePath
onready var button_grouper: ButtonGrouper = get_node(_button_grouper)

onready var tween: = $Tween as Tween
var is_showing: = true

func _ready() -> void :
	for h in _home_scene_cloud_anchors:
		var cloud = get_node(h) as GoodAnchorPoint
		if cloud:
			home_scene_cloud_anchors.append(cloud)
	button_grouper.connect("changed", self, "on_button_grouper_changed")

func on_button_grouper_changed():
	var should_show: bool = button_grouper.selected == 2
	
	if should_show != is_showing:
		is_showing = should_show
		if should_show:
			_show_clouds()
		else:
			_hide_clouds()

func _show_clouds():
	
	tween.remove_all()
	for h in home_scene_cloud_anchors:
		var cloud_anchor: GoodAnchorPoint = h as GoodAnchorPoint
		tween.interpolate_property(h, "pivot", null, Vector2(cloud_anchor.pivot.x, 1.0), 0.4, Tween.TRANS_QUINT, Tween.EASE_OUT)
	tween.start()

func _hide_clouds():
	
	tween.remove_all()
	for h in home_scene_cloud_anchors:
		var cloud_anchor: GoodAnchorPoint = h as GoodAnchorPoint
		tween.interpolate_property(h, "pivot", null, Vector2(cloud_anchor.pivot.x, 0.0), 0.1, Tween.TRANS_QUINT, Tween.EASE_IN)
	tween.start()
