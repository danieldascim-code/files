extends Node
class_name LevelTheme_Color

onready var parent_node: = get_parent() as Node
export  var _themed_color_name: = "ui_accent_color"
export  var property_color_name: = "modulate"
onready var game: = Utilities.find_game(self) as WPGame

func _ready():
	assert (property_color_name in parent_node)
	assert (game)
	if game:
		game.level.connect("theme_changed", self, "on_theme_changed")
		on_theme_changed(game.level.level_theme)

func on_theme_changed(theme: BaseTheme):
	if theme:
		var c = theme.get(_themed_color_name)
		if c is Color:
			parent_node.set(property_color_name, c)
		else:
			printerr("[LevelTheme_FontOutlineColor] couldnt get _themed_color_name %s off theme" % [_themed_color_name])
