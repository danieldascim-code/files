extends CanvasLayer
class_name UILevelUpDialog





onready var dialog = $UIDialog as UIDialog
onready var in1Sfx: = $In1 as AudioStreamPlayer
onready var in2Sfx: = $In2 as AudioStreamPlayer
onready var wheel_transition_material: = ($WheelTransition as ColorRect).material as ShaderMaterial

export (NodePath) var _levelup_label
onready var levelup_label: = get_node(_levelup_label) as SDFLabel
export (NodePath) var _levelup_label_anchor_point
onready var levelup_label_anchor_point: = get_node(_levelup_label_anchor_point) as GoodAnchorPoint

export (NodePath) var _level_number_label
onready var level_number_label: = get_node(_level_number_label) as SDFLabel

export (NodePath) var _level_badge
onready var level_badge: = get_node(_level_badge) as Control

export (NodePath) var _circular_god_rays
onready var circular_god_rays: = get_node(_circular_god_rays) as CircularGodRays

export (NodePath) var _ok_button
onready var ok_button: = get_node(_ok_button) as Button

export (NodePath) var _ui_background_text_rect
onready var ui_background_text_rect: = get_node(_ui_background_text_rect) as TextureRect



export  var wheel_color_1_full = 0.0
export  var wheel_color_2_full = 0.0
export  var wheel_color_3_full = 0.0
export  var wheel_color_4_full = 0.0
export  var anim_invert = 0.0


func _ready():
	ok_button.connect("pressed", self, "_ok_pressed")
	dialog.visible = false
	circular_god_rays.alpha = 0.0
	level_badge.visible = false
	dialog.visible = false
	ok_button.visible = false
	levelup_label.rect_scale = Vector2(0, 0)
	ui_background_text_rect.visible = false
	
	pass

func show():
	
	var level: int = Moonlight.storage.storage_get("player.profile.level_ack", 1) + 1
	level_number_label.text = "%d" % level
	_play_entry_sound()
	circular_god_rays.alpha = 0.0
	level_badge.visible = false
	dialog.visible = true
	ok_button.visible = false
	levelup_label.rect_scale = Vector2(0, 0)
	_tween_wheel()
	
	if level == 4 or level == 8:
		ReviewRequester.request_review()
	
	var tween: = create_tween()
	tween.tween_interval(0.3)
	tween.tween_property(levelup_label, "rect_scale", Vector2(1.0, 1.0), 0.5).set_ease(Tween.EASE_IN_OUT).set_trans(Tween.TRANS_BACK)
	tween.tween_interval(0.5)
	tween.tween_property(levelup_label_anchor_point, "anchor_to_parent", Vector2(0.5, 0.3), 0.2).set_ease(Tween.EASE_IN_OUT).set_trans(Tween.TRANS_EXPO)
	
	
	
	var tween2: = create_tween()
	tween2.tween_interval(1.1)
	tween2.tween_callback(self, "_anim_out_fullrays")
	tween2.tween_interval(0.5)
	tween2.tween_callback(self, "_anim_in_badge")
	tween2.tween_interval(0.5)
	tween2.tween_callback(self, "_show_ok")
	
func _tween_wheel():
	wheel_color_1_full = 0.0
	var wheelColor1Tween = create_tween()
	wheelColor1Tween.tween_property(self, "wheel_color_1_full", 1.0, 0.4).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_CUBIC)
	
	wheel_color_2_full = 0.0
	var wheelColor2Tween = create_tween()
	wheelColor2Tween.tween_interval(0.15)
	wheelColor2Tween.tween_property(self, "wheel_color_2_full", 1.0, 0.4).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_CUBIC)
	
	wheel_color_3_full = 0.0
	var wheelColor3Tween = create_tween()
	wheelColor3Tween.tween_interval(0.3)
	wheelColor3Tween.tween_property(self, "wheel_color_3_full", 1.0, 0.4).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_CUBIC)
	
	wheel_color_4_full = 0.0
	var wheelColor4Tween = create_tween()
	wheelColor4Tween.tween_interval(0.3)
	wheelColor4Tween.tween_property(self, "wheel_color_4_full", 1.0, 0.4).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_CUBIC)


func _anim_in_badge():
	
	level_badge.visible = true
	level_badge.rect_scale = Vector2(0, 0)
	var tween = create_tween()
	tween.tween_property(level_badge, "rect_scale", Vector2(1.6, 1.6), 0.2).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_CUBIC)
	tween.tween_property(level_badge, "rect_scale", Vector2(1.0, 1.0), 0.3).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)
	
	var raysTw = create_tween()
	raysTw.tween_property(circular_god_rays, "alpha", 1.0, 0.2).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_CUBIC)

	circular_god_rays.rect_scale = Vector2(0, 0)
	var raysTw2 = create_tween()
	raysTw2.tween_property(circular_god_rays, "rect_scale", Vector2(1.0, 1.0), 0.3).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_CUBIC)


func _anim_out_fullrays():
	ui_background_text_rect.visible = true
	anim_invert = 1.0
	_tween_wheel()
	_play_ping_sound()

func _play_entry_sound():
	in1Sfx.play()

func _play_ping_sound():
	in2Sfx.play()

func _show_ok():
	ok_button.visible = true
	var tween = create_tween()
	ok_button.rect_scale = Vector2(0, 0)
	tween.tween_property(ok_button, "rect_scale", Vector2(1.0, 1.0), 0.5).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_BACK)

func _process(delta):
	wheel_transition_material.set_shader_param("color_rect_size", ($WheelTransition as ColorRect).rect_size)
	wheel_transition_material.set_shader_param("color1_full", wheel_color_1_full)
	wheel_transition_material.set_shader_param("color2_full", wheel_color_2_full)
	wheel_transition_material.set_shader_param("color3_full", wheel_color_3_full)
	wheel_transition_material.set_shader_param("color4_full", wheel_color_4_full)
	wheel_transition_material.set_shader_param("anim_invert", anim_invert)

func _ok_pressed():
	var rpc_result: Dictionary = yield(Moonlight.call_rpc("ack_level", {}, true), "completed")
	
	
	if get_tree().current_scene == self:
		ScreenTransitions.fade_to_scene_path("res://scenes/HomeScene.tscn")
	else:
		self.get_parent().remove_child(self)
