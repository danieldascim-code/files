extends Node
class_name LevelTheme_MultiOutlineLabelSDF


onready var parent_label: = get_parent() as SDFLabel
export  var outline_1_color_name: = "ui_accent_color_dark"
export  var outline_2_color_name: = "ui_accent_color"

onready var game: = Utilities.find_game(self, false) as WPGame

func _ready():
	if game:
		game.level.connect("theme_changed", self, "on_theme_changed")
		call_deferred("on_theme_changed", game.level.level_theme)

func on_theme_changed(theme: BaseTheme):
	if theme:
		_apply_themed_outline_color(theme, 0, outline_1_color_name)
		_apply_themed_outline_color(theme, 1, outline_2_color_name)

func _apply_themed_outline_color(theme: BaseTheme, i: int, k: String):
	var c = theme.get(k)
	if c is Color:
		parent_label.set_outline_color(i, c)
	else:
		printerr("[LevelTheme_FontOutlineColor] couldnt get themed color name %s off theme" % [k])
