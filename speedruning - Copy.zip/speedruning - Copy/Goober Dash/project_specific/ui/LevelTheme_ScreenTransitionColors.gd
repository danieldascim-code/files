extends Node
class_name LevelTheme_ScreenTransitionColors

const color_1_name: = "ui_accent_color_dark"
const color_2_name: = "ui_accent_color"

onready var game: = Utilities.find_game(self) as WPGame

func _ready():
	if game:
		game.level.connect("theme_changed", self, "on_theme_changed")
		on_theme_changed(game.level.level_theme)
		

func on_theme_changed(theme: BaseTheme):
	if theme:
		ScreenTransitions.transition_1.pink_transition_material.set_shader_param("color", theme.ui_accent_color)
		ScreenTransitions.transition_1.blue_transition_material.set_shader_param("color", theme.ui_accent_color_dark)
	else:
		ScreenTransitions.transition_1.apply_default_colors()

func _exit_tree():
	ScreenTransitions.transition_1.apply_default_colors()
