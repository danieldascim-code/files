extends Node

onready var alert_icon: AlertIcon = get_parent()

func _ready() -> void :
	Moonlight.storage.observe("player.profile.cards", self, "on_cards_changed")
	call_deferred("update_alert_icon")

func on_cards_changed(_diff: Moonlight_StorageDiff):
	update_alert_icon()

func update_alert_icon():
	var unlockable_cards: = CosmeticsCollection.count_unlockable_cards()
	if unlockable_cards > 0:
		alert_icon.animate_in()
	else:
		alert_icon.animate_out()
