extends Control

export  var _time_left_label: NodePath
onready var time_left_label: = get_node(_time_left_label) as Label

export  var _player_count_label: NodePath
onready var player_count_label: = get_node_or_null(_player_count_label) as Label

export  var _round_schedule_container: NodePath
onready var round_schedule_container: = get_node_or_null(_round_schedule_container) as Control

export  var _round_32_level_label: NodePath
onready var round_32_level_label: = get_node_or_null(_round_32_level_label) as Label

export  var _round_16_level_label: NodePath
onready var round_16_level_label: = get_node_or_null(_round_16_level_label) as Label

export  var _round_8_level_label: NodePath
onready var round_8_level_label: = get_node_or_null(_round_8_level_label) as Label

export  var _round_4_level_label: NodePath
onready var round_4_level_label: = get_node_or_null(_round_4_level_label) as Label

export  var _hud: NodePath
onready var hud: = get_node_or_null(_hud) as GameHUD

onready var sfx_tick: AudioStreamPlayer = $AudioTick as AudioStreamPlayer
onready var sfx_tock: AudioStreamPlayer = $AudioTock as AudioStreamPlayer

onready var tween: Tween = $Tween

var last_shown_seconds_left: = - 1
var is_showing: = false

func _ready() -> void :
	rect_scale = Vector2(0.0, 1.0)
	hide()
	if round_schedule_container:
		round_schedule_container.visible = false

func _process(delta):
	if not hud or not hud.game:
		return
	
	var game: WPGame = hud.game
	if game.is_in_lobby_or_lobby_post():
		var seconds_left: = int(game.wp_game_data.state_time)
		if game.is_in_lobby():
			seconds_left += int(game.wp_game_data.transition_timer_postplay_time)
		animate_in()
		player_count_label.text = str(game.wp_game_data.total_start_players)
		_update_round_schedule_labels(game)
		if seconds_left != last_shown_seconds_left:
			if seconds_left < 10:
				if seconds_left >= 3:
					sfx_tock.play()
				else:
					sfx_tick.play()
			time_left_label.text = str(seconds_left)
		last_shown_seconds_left = seconds_left
	else:
		animate_out()
		if round_schedule_container:
			round_schedule_container.visible = false

func _update_round_schedule_labels(game: WPGame) -> void :
	if not round_schedule_container:
		return
	
	var should_show_round_schedule: bool = game.is_in_lobby()
	round_schedule_container.visible = should_show_round_schedule
	if not should_show_round_schedule:
		return
	
	var level_data = game.game_metadata.get("level_data", null)
	if not level_data is Dictionary:
		level_data = {}
	
	_update_round_level_label(round_32_level_label, level_data, "32")
	_update_round_level_label(round_16_level_label, level_data, "16")
	_update_round_level_label(round_8_level_label, level_data, "8")
	_update_round_level_label(round_4_level_label, level_data, "4")

func _update_round_level_label(level_label: Label, level_data: Dictionary, key: String) -> void :
	if not level_label:
		return
	level_label.text = _level_name_for_key(level_data, key)

func _level_name_for_key(level_data: Dictionary, key: String) -> String:
	if not level_data.has(key):
		return "Unknown"
	
	var level_data_string = level_data.get(key, "")
	if typeof(level_data_string) != TYPE_STRING:
		return "Unknown"
	
	var parse_result = JSON.parse(level_data_string)
	if parse_result.error != OK:
		return "Unknown"
	
	var level_dictionary = parse_result.result
	if not level_dictionary is Dictionary:
		return "Unknown"
	
	var metadata = level_dictionary.get("metadata", null)
	if not metadata is Dictionary:
		return "Unknown"
	
	var level_name: String = str(metadata.get("name", "")).strip_edges()
	if level_name.empty():
		return "Unknown"
	
	return level_name

func animate_in():
	if is_showing:
		return
	is_showing = true
	
	tween.remove_all()
	tween.interpolate_callback(self, 0.0, "show")
	tween.interpolate_property(self, "rect_scale", null, Vector2(1.0, 1.0), 0.5, Tween.TRANS_EXPO, Tween.EASE_OUT)
	tween.start()
	

func animate_out():
	if not is_showing:
		return
	is_showing = false
	tween.remove_all()
	tween.interpolate_property(self, "rect_scale", null, Vector2(0.0, 1.0), 0.5, Tween.TRANS_EXPO, Tween.EASE_OUT)
	tween.interpolate_callback(self, 0.5, "hide")
	tween.start()
