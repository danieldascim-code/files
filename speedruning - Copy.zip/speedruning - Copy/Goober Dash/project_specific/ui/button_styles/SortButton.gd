tool 
class_name SortButton
extends GoodButton

onready var sort_arrow: = $SortArrow
onready var sort_dash: = $SortDash
