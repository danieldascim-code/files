extends Node
class_name Rotate

export  var speed: float = 4.0

onready var parent_node: Control = get_parent()

var parent_is_visible: = false

func _ready() -> void :
	parent_is_visible = parent_node.is_visible_in_tree()
	parent_node.connect("visibility_changed", self, "on_visibility_changed")

func on_visibility_changed():
	parent_is_visible = parent_node.is_visible_in_tree()

func _process(delta):
	if parent_is_visible:
		parent_node.set_rotation(parent_node.get_rotation() + delta * speed)
