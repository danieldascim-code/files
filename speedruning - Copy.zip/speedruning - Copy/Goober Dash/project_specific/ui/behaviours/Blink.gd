extends Node
class_name Blink

onready var parent: CanvasItem = get_parent()

func _ready() -> void :
	var t: = create_tween()
	t.tween_interval(0.4)
	t.tween_property(parent, "modulate", Color.transparent, 0.4)
	t.tween_property(parent, "modulate", Color.white, 0.4)
	t.set_loops()
