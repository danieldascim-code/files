extends Node
class_name GestureRecognizer

signal pan_gesture(pan_factor)
signal zoom_gesture(zoom_factor, average_position)






var touch_data: = {}

var has_both_touch_indexes: = false
var distance_between_touches: = 0.0
var average_position: = Vector2.ZERO
var touch_index_a: = - 1
var touch_index_b: = - 1
var is_dirty: = false

onready var parent_control: Control = get_parent()

const _down_position: = "down_position"
const _position: = "position"
const _relative: = "relative"
const verbose: = false

func _ready() -> void :
	parent_control.connect("gui_input", self, "on_parent_gui_input")

func _input(event: InputEvent) -> void :
	event = parent_control.make_input_local(event)
	
	if event is InputEventScreenTouch:
		if not event.pressed:
			if verbose:
				print("[GestureRecognizer] %s gui_input touch up %s " % [Engine.get_frames_drawn(), event.index])
			touch_data.erase(event.index)
			_mark_dirty()
	
	
	if event is InputEventScreenDrag:
		if touch_data.has(event.index):
			var t: Dictionary = touch_data[event.index]
			t[_position] = event.position
			t[_relative] = event.relative
			if verbose:
				print("[GestureRecognizer] touch move:%s %s" % [event.index, event.position])
			_mark_dirty()

func on_parent_gui_input(event: InputEvent) -> void :
	
	if event is InputEventScreenTouch:
		if event.pressed:
			if verbose:
				print("[GestureRecognizer] %s gui_input touch down %s %s" % [Engine.get_frames_drawn(), event.index, event.position])
			touch_data[event.index] = {
				_down_position: event.position, 
				_position: event.position, 
				_relative: Vector2.ZERO
			}
			var s: = touch_data.size()
			if s == 1:
				touch_index_a = event.index
			elif s == 2:
				touch_index_b = event.index
			_mark_dirty()

func _mark_dirty():
	if not is_dirty:
		is_dirty = true
		call_deferred("_process_touches")

func _process_touches() -> void :
	if touch_data.has(touch_index_a) and touch_data.has(touch_index_b):
		var position_a: Vector2 = touch_data[touch_index_a][_position]
		var position_b: Vector2 = touch_data[touch_index_b][_position]
		
		var new_distance_between_touches: = position_a.distance_to(position_b)
		var new_average_position: = (position_a + position_b) * 0.5
		if has_both_touch_indexes:
			var pan_factor: = new_average_position - average_position
			emit_signal("pan_gesture", pan_factor)
			
			var zoom_factor: = - (new_distance_between_touches - distance_between_touches)
			emit_signal("zoom_gesture", zoom_factor, new_average_position)
		if verbose:
			print("[GestureRecognizer] _process_touches %s has_both_touch_indexes:%s average_position:%s new_average_position:%s position_a:%s position_b:%s" % [
				Engine.get_frames_drawn(), 
				has_both_touch_indexes, 
				average_position, 
				new_average_position, 
				position_a, 
				position_b
			])
		average_position = new_average_position
		distance_between_touches = new_distance_between_touches
		has_both_touch_indexes = true
	else:
		has_both_touch_indexes = false
	is_dirty = false

func is_recognizing_gesture() -> bool:
	return touch_data.size() > 1
