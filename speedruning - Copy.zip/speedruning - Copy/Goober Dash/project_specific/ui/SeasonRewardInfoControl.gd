extends Control
class_name SeasonRewardInfoControl

	

func _ready():
	pass





