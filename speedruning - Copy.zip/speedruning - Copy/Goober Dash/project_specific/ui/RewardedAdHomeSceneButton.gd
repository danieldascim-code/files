extends BaseButton
class_name RewardedAdsHomeSceneButton

export  var _prize_round_holder: NodePath
onready var prize_round_holder: Control = get_node(_prize_round_holder)

export  var _free_coins_holder: NodePath
onready var free_coins_holder: Control = get_node(_free_coins_holder)

export  var _free_coins_label: NodePath
onready var free_coins_label: Label = get_node(_free_coins_label)

export  var _free_gems_holder: NodePath
onready var free_gems_holder: Control = get_node(_free_gems_holder)

export  var _free_gems_label: NodePath
onready var free_gems_label: Label = get_node(_free_gems_label)

export  var _free_spin_holder: NodePath
onready var free_spin_holder: Control = get_node(_free_spin_holder)

func show_ad_placement(ad_placement: String, count: int):
	prize_round_holder.hide()
	free_coins_holder.hide()
	free_gems_holder.hide()
	free_spin_holder.hide()
	if ad_placement == "prize_round":
		prize_round_holder.show()
	elif ad_placement == "free_spin":
		free_spin_holder.show()
	elif ad_placement == "free_gem":
		free_gems_holder.show()
		free_gems_label.text = "%d\nGEMS" % [count]
	elif ad_placement == "free_coin":
		free_coins_holder.show()
		free_coins_label.text = "%d\nCOINS" % [count]
