extends Control
class_name PlayerNameRow

export  var _name_label: NodePath
onready var name_label: SDFLabel = get_node(_name_label)

export  var _discord_avatar: NodePath
onready var discord_avatar: DiscordAvatar = get_node(_discord_avatar)

export  var local_player: = false

func _ready() -> void :
	if local_player:
		Moonlight.storage.observe("account.user.display_name", self, "on_username_changed")
		Moonlight.storage.observe("player.discord", self, "on_discord_data_changed")
		update_local_username_label()
		update_local_discord_avatar()

func on_discord_data_changed(_diff):
	update_local_discord_avatar()
	update_local_username_label()

func on_username_changed(_diff):
	update_local_username_label()

func update_local_discord_avatar():
	var avatar_url: String = Moonlight.storage.storage_get("player.discord.avatar_url", "")
	render_discord_avatar(avatar_url)

func update_local_username_label():
	var real_display_name: String = Moonlight.storage.storage_get("account.user.display_name", "")
	var discord_display_name: String = Moonlight.storage.storage_get("player.discord.display_name", "")
	if not discord_display_name.empty():
		render_player_name(discord_display_name)
	else:
		render_player_name(real_display_name)

func render_player_name(player_name: String):
	name_label.text = player_name

func render_discord_avatar(avatar_url: String):
	discord_avatar.set_discord_avatar_uri(avatar_url)
