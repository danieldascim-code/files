tool 
extends Node

export  var color: = Color.white
export  var run: = false setget _set_run

func _set_run(b: bool):
	if b and is_inside_tree():
		set_all_colors()

func set_all_colors():
	var children: = get_parent().get_children()
	var edited_root: = get_tree().edited_scene_root
	while children.size() > 0:
		var child = children.pop_front()
		if child is SDFLabel:
			if child.owner == edited_root:
				child.color = color
		children.append_array(child.get_children())
