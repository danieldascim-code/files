extends Node
class_name LevelTheme_FontColor

onready var parent_label: = get_parent() as SDFLabel
export  var _themed_color_name: = "ui_accent_color"

onready var game: = Utilities.find_game(self) as WPGame

func _ready():
	if game:
		game.level.connect("theme_changed", self, "on_theme_changed")
		on_theme_changed(game.level.level_theme)

func on_theme_changed(theme: BaseTheme):
	if theme:
		var c = theme.get(_themed_color_name)
		if c is Color:
			parent_label.color = theme.get(_themed_color_name)
		else:
			printerr("[LevelTheme_FontOutlineColor] couldnt get _themed_color_name %s off theme" % [_themed_color_name])
