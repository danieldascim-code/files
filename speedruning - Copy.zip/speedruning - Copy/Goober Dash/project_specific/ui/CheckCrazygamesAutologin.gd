extends Node
class_name CheckCrazygamesAutoLogin

func _ready():
	
	
	var on_crazy_games: = AdManager.get_ad_driver() == "crazygames"
	var is_guest: = Moonlight.auth.is_guest_account()
	var seen_home_screen: bool = SavedSettings.get_value("crazygames_seen_home_screen", false)
	
	if on_crazy_games and is_guest and not seen_home_screen:
		SavedSettings.set_value("crazygames_seen_home_screen", true)
		
		var result: Dictionary = yield(CrazyAuth.async_get_user(), "get_user_response")
		if (result.has("error")):
			
			_get_user_response_no_user()
		else:
			_get_user_response_success(result)


func _get_user_response_no_user():
	pass
	

func _get_user_response_success(result: Dictionary):
	var user_dict: Dictionary = result["user"]
	_get_user_token(user_dict)

func _get_user_token(user_dict: Dictionary):

	
	var result: Dictionary = yield(CrazyAuth.async_get_user_token(), "get_user_token_response")
	if (result.has("error")):
		_user_token_error(result["error"])
	else:
		_user_token_success(result)

func _user_token_error(errString: String):
	pass
	
	
func _user_token_success(result: Dictionary):
	print("crazy _user_token_success")
	var token: String = result["token"]
	
	var payload: = {"token": token}
	var rpc_result: Dictionary = yield(Moonlight.call_rpc("crazygames_auth", payload), "completed")
	if rpc_result.has("error"):
		printerr("rpc err")
	else:
		var customcrazyid: String = rpc_result.get("customcrazyid", "")
		print(customcrazyid)
		Moonlight.auth.log_out()
		Moonlight.saved_data.set_crazygames_device_id_credentials(customcrazyid)
		get_tree().change_scene(GoodSceneRegistry.connecting_scene)

