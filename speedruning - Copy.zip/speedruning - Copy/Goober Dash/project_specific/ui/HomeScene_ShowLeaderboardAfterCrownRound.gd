extends Node

export  var _button_grouper: NodePath
onready var button_grouper: ButtonGrouper = get_node(_button_grouper)

export  var _matchmaker: NodePath
onready var matchmaker: GameMatchmaker = get_node(_matchmaker)

export  var leaderboard_page_index: = 3

const scratchpad_key: = "last_match_request_type"

func _ready() -> void :
	matchmaker.connect("entering_matchmaking_with_request_type", self, "on_entering_matchmaking")
	var last_match_request_type: String = SavedSettings.scratchpad.get(scratchpad_key, "")
	if last_match_request_type == WPGame.MatchTypeCrown:
		button_grouper.initial_selected = leaderboard_page_index
	SavedSettings.scratchpad.erase(scratchpad_key)

func on_entering_matchmaking(match_request_type: String):
	SavedSettings.scratchpad[scratchpad_key] = match_request_type
