extends Node
class_name LevelTheme_FontOutlineColor

onready var parent_label: = get_parent() as Label
export  var _themed_color_name: = "ui_accent_color"

onready var game: = Utilities.find_game(self) as WPGame

export  var outline: = true
export  var shadow: = true

func _ready():
	if game:
		game.level.connect("theme_changed", self, "on_theme_changed")
		on_theme_changed(game.level.level_theme)

func on_theme_changed(theme: BaseTheme):
	if theme:
		var c = theme.get(_themed_color_name)
		if c is Color:
			if outline:
				parent_label.add_color_override("font_outline_modulate", c)
			if shadow:
				parent_label.add_color_override("font_color_shadow", c)
		else:
			printerr("[LevelTheme_FontOutlineColor] couldnt get _themed_color_name %s off theme" % [_themed_color_name])
