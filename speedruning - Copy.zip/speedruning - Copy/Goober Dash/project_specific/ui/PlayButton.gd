extends Node
class_name PlayButton

signal play_button_pressed()

export  var _play_button: NodePath
onready var play_button: GoodButton = get_node(_play_button)

export  var _star_pack_indicator: NodePath
onready var star_pack_indicator: StarPackIndicator = get_node(_star_pack_indicator)

export  var _discord_play_message: NodePath
onready var discord_play_message: Control = get_node(_discord_play_message)

func _ready() -> void :
	play_button.connect("pressed", self, "emit_signal", ["play_button_pressed"])
	if Moonlight.discord_api.is_in_discord():
		discord_play_message.visible = true
		play_button.label_text = ""
