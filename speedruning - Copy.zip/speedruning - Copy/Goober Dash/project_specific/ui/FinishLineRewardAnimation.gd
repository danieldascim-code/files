extends Control
class_name FinishLineRewardAnimation

onready var rank_label: = $RankLabel

onready var coin_icon: TextureRect = $HBoxContainer / Icons / CoinTextureRect
onready var crown_icon: TextureRect = $HBoxContainer / Icons / CrownTextureRect
onready var notch_icon: TextureRect = $HBoxContainer / Icons / NotchTextureRect
onready var gold_notch_icon: TextureRect = $HBoxContainer / Icons / GoldNotchTextureRect
onready var icon_plus_label: Label = $HBoxContainer / IconPlusLabel
onready var icons: Control = $HBoxContainer

onready var stars_container: HBoxContainer = $StarsContainer
onready var star_label: SDFLabel = $StarsContainer / StarLabel

func show_star():
	stars_container.visible = true

func show_as_rank(rank: int):
	stars_container.visible = false
	icons.visible = false
	rank_label.text = DateTimeUtils.number_to_ordinal_string(rank)

func show_as_time(time: float):
	stars_container.visible = false
	rank_label.text = "%.2f" % time
	icons.visible = false
	crown_icon.visible = false
	notch_icon.visible = false
	gold_notch_icon.visible = false
	coin_icon.visible = false
	icon_plus_label.text = ""

func show_as_coins(rank: int, coins: int):
	stars_container.visible = false
	rank_label.text = DateTimeUtils.number_to_ordinal_string(rank)
	icons.visible = true
	crown_icon.visible = false
	notch_icon.visible = false
	gold_notch_icon.visible = false
	coin_icon.visible = true
	icon_plus_label.text = "+" + str(coins)

func show_as_crowns(rank: int, crowns: int):
	stars_container.visible = false
	rank_label.text = DateTimeUtils.number_to_ordinal_string(rank)
	icons.visible = true
	crown_icon.visible = true
	notch_icon.visible = false
	gold_notch_icon.visible = false
	coin_icon.visible = false
	
	icon_plus_label.text = "+" + str(crowns)
	
func show_as_notches(rank: int, notches: int):
	stars_container.visible = false
	rank_label.text = DateTimeUtils.number_to_ordinal_string(rank)
	icons.visible = true
	icon_plus_label.text = "+" + str(notches)
	crown_icon.visible = false
	if (rank == 1):
		notch_icon.visible = false
		gold_notch_icon.visible = true
	else:
		notch_icon.visible = true
		gold_notch_icon.visible = false
	coin_icon.visible = false
	
