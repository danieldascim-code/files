extends Control
class_name GameHUD

signal show_level_editor_button_pressed()
signal level_browser_button_pressed()
signal retry_button_pressed()
signal leaderboard_button_pressed()
signal play_ghost_button_pressed()

export  var _game: NodePath
export  var _show_hud_tweener: NodePath
export  var _hide_hud_tweener: NodePath
export  var _qualified_pill: NodePath
export  var _qualified_numerator_label: NodePath
export  var _qualified_of_label: NodePath
export  var _qualified_denominator_label: NodePath
export  var _qualified_description_label: NodePath
export  var _level_info_show_button: NodePath
export  var _level_info_panel: NodePath
export  var _settings_dialog_scene: PackedScene
export  var _prize_round_control_widget: NodePath
export  var _crown_round_control_widget: NodePath
export  var _home_button: NodePath
onready var home_button: Button = get_node(_home_button)

export  var _level_browser_button: NodePath
onready var level_browser_button: Button = get_node(_level_browser_button)

onready var game: = get_node(_game) as WPGame

export  var _show_level_editor_button: NodePath
onready var show_level_editor_button: BaseButton = get_node(_show_level_editor_button)

export  var _retry_button: NodePath
onready var retry_button: BaseButton = get_node(_retry_button)

onready var show_hud_tweener: = get_node(_show_hud_tweener) as GoodTweener
onready var hide_hud_tweener: = get_node(_hide_hud_tweener) as GoodTweener
onready var qualified_pill: Control = get_node(_qualified_pill)
onready var qualified_numerator_label: = get_node(_qualified_numerator_label) as Label
onready var qualified_denominator_label: = get_node(_qualified_denominator_label) as Label
onready var qualified_of_label: = get_node(_qualified_of_label) as Label
onready var qualified_description_label: = get_node(_qualified_description_label) as Label

onready var level_info_show_button: = get_node(_level_info_show_button) as BaseButton
onready var level_info_panel: = get_node(_level_info_panel) as LevelInfoPanel

export  var _time_trial_panel: NodePath
onready var time_trial_panel: = get_node(_time_trial_panel) as TimeTrialFinishLayer

export  var _time_trial_pill_containers: NodePath
onready var time_trial_pill_containers: = get_node(_time_trial_pill_containers) as Control

export  var _replay_indicator: NodePath
onready var replay_indicator: = get_node(_replay_indicator) as Control

export  var _level_info_tab: NodePath
onready var level_info_tab: LevelInfoTab = get_node(_level_info_tab)

export  var _leaderboard_button: NodePath
onready var leaderboard_button: BaseButton = get_node(_leaderboard_button)

onready var prize_round_control_widget: = get_node(_prize_round_control_widget) as Control
onready var crown_round_control_widget: = get_node(_crown_round_control_widget) as Control

var showing_hud: = true
var top_right_panel_time_showing: = false
var level_info_panel_auto_showing: = false
var level_info_auto_open_round_index: = - 1

func _ready() -> void :
	visible = true
	level_info_show_button.connect("pressed", self, "on_level_info_show_button_pressed")
	level_info_panel.rect_scale = Vector2(0.0, 1.0)
	level_info_panel.hide()
	time_trial_panel.rect_scale = Vector2(0.0, 1.0)
	time_trial_panel.hide()
	
	if game:
		game.level.connect("loaded_level", self, "on_level_loaded")
		level_info_show_button.visible = not game.wp_game_data.is_tutorial
		
		show_level_editor_button.visible = game.wp_game_data.is_level_editor
		show_level_editor_button.connect("pressed", self, "emit_signal", ["show_level_editor_button_pressed"])
		
		home_button.visible = game.wp_game_data.is_tutorial
		home_button.connect("pressed", self, "on_home_button_pressed")
		
		retry_button.visible = game.wp_game_data.is_time_trial or game.wp_game_data.is_level_editor
		retry_button.connect("pressed", self, "on_retry_button_pressed")
		
		level_browser_button.visible = game.wp_game_data.is_time_trial and not game.wp_game_data.is_level_editor
		level_browser_button.connect("pressed", self, "emit_signal", ["level_browser_button_pressed"])

		leaderboard_button.visible = game.wp_game_data.is_time_trial and not game.wp_game_data.is_level_editor
		leaderboard_button.connect("pressed", self, "emit_signal", ["leaderboard_button_pressed"])

func on_retry_button_pressed():
	
	emit_signal("retry_button_pressed")

func on_home_button_pressed():
	LoadHomeOnPress.go_home(get_tree())

func on_level_info_show_button_pressed():
	level_info_panel.toggle_pop()

func on_level_info_hide_button_pressed():
	level_info_panel.pop_out()

func _process(delta: float) -> void :
	if game:
		
		var should_show_hud: = true
		if game.is_game_over():
			should_show_hud = false
		if should_show_hud != showing_hud:
			showing_hud = should_show_hud
			if should_show_hud:
				show_hud_tweener.play()
			else:
				hide_hud_tweener.play()
			
		crown_round_control_widget.visible = game.is_crown_round_for_local_player()
		prize_round_control_widget.visible = game.is_prize_round_for_local_player()
		
		replay_indicator.visible = game.wp_game_data.is_replay
		
		if game.is_in_lobby_or_lobby_post():
			qualified_pill.visible = false
		elif game.wp_game_data.is_time_trial:
			qualified_pill.visible = false
		elif game.wp_game_data.is_tutorial:
			qualified_pill.visible = false
		else:
			
			qualified_pill.visible = true
			qualified_of_label.visible = true
			qualified_denominator_label.visible = true
			match game.level.loaded_level.level_type:
				LevelUtils.LevelType.RACE:
					qualified_description_label.text = "QUALIFIED"
					qualified_numerator_label.text = str(game.wp_game_data.players_finished)
					qualified_denominator_label.text = str(game.wp_game_data.players_qualify)
				LevelUtils.LevelType.LAST_ONE_STANDING:
					qualified_description_label.text = "REMAINING"
					qualified_numerator_label.text = str(game.wp_game_data.players_left)
					qualified_denominator_label.text = str(game.wp_game_data.players_qualify)
		
			
			var enable_auto_open: = false
			if enable_auto_open:
				var close_auto_open_level_info: = true
				if game.is_in_regular_pre_play():
					if level_info_auto_open_round_index < game.wp_game_data.gameplay_round_counter:
						level_info_auto_open_round_index = game.wp_game_data.gameplay_round_counter
						if game.wp_game_data.state_time > 7.0:
							level_info_panel_auto_showing = true
							on_level_info_show_button_pressed()
					
					close_auto_open_level_info = game.wp_game_data.state_time < 5.5
				
				if close_auto_open_level_info and level_info_panel_auto_showing:
					level_info_panel_auto_showing = false
					on_level_info_hide_button_pressed()

func on_level_loaded():
	_apply_level_info()

func _settings_button_pressed():
	var scene: = _settings_dialog_scene.instance() as UISettingsDialog
	get_tree().current_scene.add_child(scene)

func _apply_level_info():
	if game and game.level.loaded_level:
		var level_type_string: = "RACE"
		match game.level.loaded_level.level_type:
			LevelUtils.LevelType.RACE:
				level_type_string = "RACE"
			LevelUtils.LevelType.LAST_ONE_STANDING:
				level_type_string = "ELIMINATION"
		
		time_trial_panel.render_level_instance(game.level.loaded_level)
		level_info_panel.render_level_instance(game.level.loaded_level)
		
		if game.level.loaded_level.level_type != LevelUtils.LevelType.LOBBY:
			level_info_tab.pop_in_level_info(game.level.loaded_level.level_name, game.level.loaded_level.author_name)

func _input(event):
	if level_info_panel.is_showing:
		if event is InputEventMouseButton or event is InputEventScreenTouch:
			if event.pressed:
				var should_close_level_info_panel: = true
				if level_info_show_button.get_global_rect().has_point(event.position):
					should_close_level_info_panel = false
				if level_info_panel.get_global_rect().has_point(event.position):
					should_close_level_info_panel = false
				if should_close_level_info_panel:
					call_deferred("on_level_info_hide_button_pressed")
