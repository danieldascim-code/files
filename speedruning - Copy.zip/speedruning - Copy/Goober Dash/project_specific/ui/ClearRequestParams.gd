extends Node
class_name ClearRequestParams

export (Array, String) var params: = []

func _ready() -> void :
	if OS.has_feature("web"):
		if params.size() > 0:
			HTMLRequestParams.clear_request_params(params)
