extends Control
class_name LevelInfoPanel

export  var _title_label: NodePath
onready var title_label: SDFLabel = get_node(_title_label)

export  var _type_label: NodePath
onready var type_label: SDFLabel = get_node(_type_label)

export  var _rating_label: NodePath
onready var rating_label: SDFLabel = get_node(_rating_label)

export  var _rating_count_label: NodePath
onready var rating_count_label: SDFLabel = get_node(_rating_count_label)

export  var _rating_thumb: NodePath
onready var rating_thumb: TextureRect = get_node(_rating_thumb)

export  var _designer_label: NodePath
onready var designer_label: SDFLabel = get_node(_designer_label)

export  var _rating_buttons: NodePath
onready var rating_buttons: Control = get_node(_rating_buttons)

export  var _upvote_button: NodePath
onready var upvote_button: BaseButton = get_node(_upvote_button)

export  var _downvote_button: NodePath
onready var downvote_button: BaseButton = get_node(_downvote_button)

export  var _already_rated_container: NodePath
onready var already_rated_container: Control = get_node(_already_rated_container)

export  var _favorite_checkbox: NodePath
onready var favorite_checkbox: BaseButton = get_node(_favorite_checkbox)

export  var _favorite_heart_icon: NodePath
onready var favorite_heart_icon: TextureRect = get_node(_favorite_heart_icon)

export  var favorite_heart_tex_full: Texture
export  var favorite_heart_tex_empty: Texture

export  var _time_renderer: NodePath
onready var time_renderer: LevelInfoPanel_Times = get_node(_time_renderer)

export  var positive_rating_color: Color
export  var medium_rating_color: Color
export  var negative_rating_color: Color
export  var unknown_rating_color: Color

var level_id: String = ""
var is_favorited: bool = false
onready var can_vote: = false
var is_requesting: = false
var tween: SceneTreeTween
var is_showing: = false

func _ready():
	rating_buttons.visible = true
	already_rated_container.visible = false
	favorite_checkbox.connect("pressed", self, "on_favorite_checkbox_pressed")
	is_favorited = false
	_render_favorite_heart_icon()
	upvote_button.connect("pressed", self, "on_upvote_button_pressed")
	downvote_button.connect("pressed", self, "on_downvote_button_pressed")
	time_renderer.hide()

func render_level_instance(level_instance: LevelInstance):
	level_id = level_instance.level_id
	title_label.text = level_instance.level_name
	designer_label.text = "By: " + level_instance.author_name
	
	var level_type_name: = LevelUtils.string_for_level_type(level_instance.level_type)
	type_label.text = "%s (%d)" % [level_type_name, level_instance.max_players]
	set_rating(level_instance.rating, level_instance.rating_count)
	
	query_player_level_info(level_id)

func set_rating(rating: float, rating_count: int):
	rating_label.text = _rating_format(rating)
	rating_count_label.text = _rating_count_format(rating_count)
	var rating_color: = _rating_color(rating)
	rating_label.color = rating_color
	rating_thumb.self_modulate = rating_color

func on_favorite_checkbox_pressed():
	is_favorited = not is_favorited
	_render_favorite_heart_icon()
	if is_favorited:
		print("[LevelInfoPanel] on_favorite_checkbox_pressed() favoriting")
		LevelCloudLoader.async_favorite_level(level_id)
	else:
		print("[LevelInfoPanel] on_favorite_checkbox_pressed() unfavoriting")
		LevelCloudLoader.async_unfavorite_level(level_id)

func _render_favorite_heart_icon():
	favorite_heart_icon.texture = favorite_heart_tex_full if is_favorited else favorite_heart_tex_empty

func on_upvote_button_pressed():
	on_rate_button_pressed(true)

func on_downvote_button_pressed():
	on_rate_button_pressed(false)

func on_rate_button_pressed(thumbs_up: bool):
	if rating_buttons.visible:
		var value: = 1
		if thumbs_up:
			value = 5
			
		var payload: = {
			"id": level_id, 
			"vote": value
		}
		
		rating_buttons.visible = false
		already_rated_container.visible = true
		
		
		var response: Dictionary = yield(Moonlight.call_rpc("levels_vote", payload, false), "completed")
		if response.has("error"):
			printerr("[LevelInfoPanel] failed to vote: %s" % [response])
			return
		
		var new_rating: float = response.get("rating", 0.0)
		var new_rating_count: int = int(response.get("rating_count", 0))
		set_rating(new_rating, new_rating_count)

func pop_out():
	if not is_showing:
		return
	is_showing = false
	if tween != null and tween.is_valid():
		tween.kill()
	tween = create_tween()
	tween.tween_property(self, "rect_scale", Vector2(0.0, 1.0), 0.15).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_EXPO)
	tween.tween_callback(self, "hide")

func toggle_pop():
	if is_showing:
		pop_out()
	else:
		pop_in()

func pop_in(delay: float = 0.0):
	if is_showing:
		return
	is_showing = true
	if tween != null and tween.is_valid():
		tween.kill()
	rect_scale = Vector2(0.0, 1.0)
	tween = create_tween()
	tween.set_parallel(true)
	tween.tween_callback(self, "show").set_delay(delay + 0.01)
	tween.tween_property(self, "rect_scale", Vector2(1.0, 1.0), 0.2).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_EXPO).set_delay(delay)

func query_player_level_info(p_level_id: String):
	if p_level_id.empty():
		return
	var payload: = {
		"level_id": p_level_id
	}
	var response_data: Dictionary = yield(Moonlight.call_rpc("levels_query_player_metadata", payload, false), "completed")
	if response_data.has("error"):
		printerr("[LevelInfoPanel] query_level_info() failed with error. %s" % [response_data["error"]])
	is_favorited = response_data.get("favorite", false)
	_render_favorite_heart_icon()
	
	if response_data.has("rating"):
		can_vote = false
		rating_buttons.visible = false
		already_rated_container.visible = true
		var rating: = float(response_data.get("rating", 5.0))




	else:
		can_vote = true
		rating_buttons.visible = true
		already_rated_container.visible = false

func _rating_color(rating: float) -> Color:
	if is_zero_approx(rating):
		return unknown_rating_color
	if rating > 4.0:
		return positive_rating_color
	elif rating > 2.5:
		return medium_rating_color
	return negative_rating_color

func _rating_format(rating: float) -> String:
	if is_zero_approx(rating):
		return "-"
	var rating_percent: = 25.0 * (rating - 1.0)
	return "%d%%" % [rating_percent]

func _rating_count_format(rating_count: int) -> String:
	if rating_count > 0:
		return "(%d)" % [rating_count]
	return "(-)"
