tool 
extends Panel
class_name CoinRewardRow

onready var margin_container: = $MarginContainer
onready var hbox_container: = $MarginContainer / HBoxContainer

export  var _completed_coins_label: NodePath
onready var completed_coins_label: = get_node(_completed_coins_label) as Label

func _process(delta):
	margin_container.rect_size = hbox_container.rect_size
	self.rect_size = margin_container.rect_size

func show_coin_count(collected_coins: int):
	completed_coins_label.text = "+" + str(collected_coins)
	
