extends Node
class_name DiscordActivityVisibility

onready var parent: Control = get_parent()

export  var show_in_discord_activity: = true

func _ready() -> void :
	if Moonlight.discord_api.is_in_discord():
		parent.visible = show_in_discord_activity
	else:
		parent.visible = not show_in_discord_activity
