extends Node
class_name CheckDisplayNameSetter

export  var username_dialog: PackedScene


func _ready():
	Moonlight.connect("on_socket_message_parsed", self, "on_socket_message_parsed")
	
	
	if Moonlight.auth.is_logged_in() and not Moonlight.auth.is_guest_account() and not Moonlight.discord_api.is_in_discord():
		if Moonlight_Auth.is_guest_username(Moonlight.local_account.user.display_name):
			_show_display_name_setter()
	
func _show_display_name_setter():
	var popup: = username_dialog.instance() as EnterDisplayNameDialog
	add_child(popup)
	
func on_socket_message_parsed(nakama_notification: NakamaAPI.ApiNotification, content_json: Dictionary):
	if nakama_notification.subject == "EMAIL_VERIFIED":
		_show_display_name_setter()
