extends Control

export  var _matchmaker: NodePath
onready var matchmaker: GameMatchmaker = get_node(_matchmaker)

export  var _crown_play_button: NodePath
onready var crown_play_button: Button = get_node(_crown_play_button)

func _ready() -> void :
	crown_play_button.connect("pressed", self, "crown_play_button_pressed")

func crown_play_button_pressed():
	yield(AdManager.show_interstitial_ad(), "completed")
	connect_to_matchmaker()

func connect_to_matchmaker():
	matchmaker.connect_to_matchmaker(WPGame.MatchTypeCrown)
