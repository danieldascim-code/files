extends Control
class_name LeaderboardRow
signal pressed()

onready var rank_label: Label = $MarginContainer / HBoxContainer / RankContainer / Rank
onready var name_label: Label = $MarginContainer / HBoxContainer / NameContainer / Name
onready var value_label: Label = $MarginContainer / HBoxContainer / ValueContainer / Value
onready var country_flag: TextureRect = $MarginContainer / HBoxContainer / CountryIcon / TextureRect
onready var background: Control = $Background
onready var button: BaseButton = $Button
onready var focusable: Focusable = $Button / Focusable

func _ready() -> void :
	button.connect("pressed", self, "on_button_pressed")

func show_local_data():
	if Moonlight.is_logged_in():
		show_data(Moonlight.local_account.user.display_name, "-", "-", {"country": Moonlight.storage.storage_get("player.profile.country", "")}, false)
	else:
		show_data("-", "-", "-", {}, false)

func show_data(p_name: String, p_rank: String, p_value: String, p_metadata: Dictionary, p_show_background: bool):
	name_label.text = p_name
	rank_label.text = p_rank
	value_label.text = p_value
	if p_value.empty():
		value_label.text = "0"
	background.visible = p_show_background
	var country_code: String = p_metadata.get("country", "US")
	country_flag.texture = load_country_flag(country_code)
	
func on_button_pressed():
	emit_signal("pressed")

static func load_country_flag(country_code: String) -> Texture:
	if country_code.empty():
		return null
	
	var country_icon_resource: = "res://project_specific/gfx/countryflags/" + country_code + ".png"
	if not ResourceLoader.exists(country_icon_resource):
		printerr("[CountryFlag] load_country_flag() no flag for country code \'%s\'" % [country_code])
		return null
	
	var t: Texture = load(country_icon_resource) as Texture
	if t == null:
		printerr("[CountryFlag] load_country_flag() failed to load flag for country code \'%s\'" % [country_code])
		return null
	return t
