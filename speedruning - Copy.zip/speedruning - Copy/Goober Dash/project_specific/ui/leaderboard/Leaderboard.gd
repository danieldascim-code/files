extends Control

export  var row_scene: PackedScene

export  var _scroll_container: NodePath
onready var scroll_container: = get_node(_scroll_container) as ScrollContainer

export  var _rows_parent: NodePath
onready var rows_parent: Control = get_node(_rows_parent)

export  var _spinner: NodePath
onready var spinner: Control = get_node(_spinner)

export  var _button_grouper: NodePath
onready var button_grouper: ButtonGrouper = get_node(_button_grouper)

export  var _row_self: NodePath
onready var row_self: LeaderboardRow = get_node(_row_self)

export  var _row_focus_dump: NodePath
onready var row_focus_dump: Control = get_node(_row_focus_dump)

export  var player_profile_dialog_path: String

var rows: = []
var leaderboard_request_index: = 0

func _ready():
	connect("visibility_changed", self, "on_visibility_changed")
	button_grouper.connect("changed", self, "on_button_grouper_changed")
	if not Moonlight.is_logged_in():
		return
	var my_user_id: = Moonlight.local_account.user.id
	row_self.connect("pressed", self, "on_leaderboard_row_pressed", [my_user_id])
	row_self.call_deferred("show_local_data")

func on_button_grouper_changed():
	if is_visible_in_tree():
		query_leaderboard()

func on_visibility_changed():
	if is_visible_in_tree():
		query_leaderboard()

func query_leaderboard():
	_query_leaderboard(active_leaderboard_id())

func active_leaderboard_id() -> String:
	var base_leaderboard_id: = ""
	if button_grouper.selected == 0:
		base_leaderboard_id = "global"
	else:
		var country_code: String = Moonlight.storage.storage_get("player.profile.country", "US")
		base_leaderboard_id = "country." + country_code
	var season_number: = Moonlight.seasons.season_number
	return base_leaderboard_id + "." + str(season_number)

func _query_leaderboard(leaderboard_id: String):
	print("[Leaderboard] querying leaderboard_id %s" % [leaderboard_id])
	var my_user_id: = Moonlight.local_account.user.id
	
	rows_parent.visible = false
	spinner.visible = true
	clear_rows()
	var request_id: = leaderboard_request_index
	leaderboard_request_index += 1
	var leaderboard_list: NakamaAPI.ApiLeaderboardRecordList = yield(
		Moonlight.client.list_leaderboard_records_async(
			Moonlight.session, 
			leaderboard_id, 
			[my_user_id], 
			null, 
			100), 
		"completed")
	if leaderboard_request_index != request_id + 1:
		print("[Leaderboard] skipping processing of results as another request is in flight")
		return
	rows_parent.visible = true
	spinner.visible = false
	
		
	
	if leaderboard_list.is_exception():
		printerr("[Leaderboard] failed querying leaderboards %s" % [leaderboard_list])
	
	print("[Leaderboard] found %s leaderboard records" % [leaderboard_list.records.size()])
	for r in leaderboard_list.records:
		var record: NakamaAPI.ApiLeaderboardRecord = r
		var new_row: LeaderboardRow = row_scene.instance()
		rows_parent.add_child(new_row)
		new_row.focusable.focus_dump = row_focus_dump
		new_row.connect("pressed", self, "on_leaderboard_row_pressed", [record.owner_id])
		
		new_row.show_data(record.username, record.rank, record.score, _parse_leaderboard_metadata(record.metadata), rows.size() %2 == 0)
		rows.append(new_row)
	
	if leaderboard_list.owner_records.size() == 1:
		var owner_record: NakamaAPI.ApiLeaderboardRecord = leaderboard_list.owner_records[0]
		row_self.show_data(owner_record.username, owner_record.rank, owner_record.score, _parse_leaderboard_metadata(owner_record.metadata), false)
	else:
		row_self.show_local_data()

func clear_rows():
	for r in rows:
		r.queue_free()
	rows.clear()

func on_leaderboard_row_pressed(user_id: String):
	if not player_profile_dialog_path.empty():
		var player_profile_dialog_scene = load(player_profile_dialog_path) as PackedScene
		var player_profile_dialog: = player_profile_dialog_scene.instance() as UIPlayerProfileDialog
		get_tree().current_scene.add_child(player_profile_dialog)
		player_profile_dialog.show_player_profile_dialog(user_id)

static func _parse_leaderboard_metadata(metadata: String) -> Dictionary:
	if metadata.empty():
		return {}
	var d: Dictionary = parse_json(metadata)
	if d == null:
		return {}
	return d
