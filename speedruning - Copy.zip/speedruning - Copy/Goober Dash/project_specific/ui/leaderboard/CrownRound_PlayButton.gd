extends Node

signal play_button_pressed

export  var _play_button: NodePath
onready var play_button: Button = get_node(_play_button)

export (Array, NodePath) var _crowns
var crowns: Array

export  var _time_label: NodePath
onready var time_label: Label = get_node(_time_label)

var reset_timer: = 0.0
var showing_num_tokens: = 0
var showing_reset_time: = 0

func _ready() -> void :
	for c in _crowns:
		var crown: TextureRect = get_node(c)
		crowns.append(crown)
		crown.visible = false
	play_button.disabled = true
	assert (crowns.size() == 3)
	_refresh()
	play_button.connect("pressed", self, "on_play_button_pressed")

func _refresh():
	var crowns_data: Dictionary = Moonlight.storage.storage_get("player.crowns", {})
	if crowns_data.empty():
		return
	var num_tokens: int = crowns_data.get("tokens", 0)
	_show_num_tokens(num_tokens)
	var reset_timestamp: int = crowns_data.get("reset_time", 0)
	var now: = OS.get_unix_time()
	reset_timer = reset_timestamp - now

func _show_num_tokens(n: int):
	if showing_num_tokens != n:
		assert (n >= 0)
		assert (n <= crowns.size())
		for i in crowns.size():
			var crown: Control = crowns[i]
			crown.visible = i < n
		showing_num_tokens = n
	
	play_button.disabled = showing_num_tokens == 0

func _show_reset_time(seconds_left: int):
	if showing_reset_time != seconds_left:
		showing_reset_time = seconds_left
		time_label.text = DateTimeUtils.format_time_shorter(seconds_left)

func _process(delta: float) -> void :
	if reset_timer > 0.0:
		reset_timer -= delta
		if reset_timer <= 0.0:
			_show_num_tokens(0)
			reset_timer = 60 * 60 * 24
	
	_show_reset_time(int(reset_timer))

func on_play_button_pressed():
	emit_signal("play_button_pressed")
