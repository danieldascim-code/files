tool 
extends GoodButton
class_name DoubleButton

export (String, MULTILINE) var subtitle_text: = "" setget set_subtitle_text

export  var _subtitle: NodePath
onready var subtitle: Label = get_node(_subtitle)

func _ready() -> void :
	set_subtitle_text(subtitle_text)

func set_subtitle_text(t: String):
	subtitle_text = t
	if is_inside_tree():
		subtitle.text = t
