extends Control
class_name PlaygroundPage

export  var _time_trial_button: NodePath
onready var time_trial_button: BaseButton = get_node(_time_trial_button)
var _level_select_dialog: LevelEditor_LevelBrowser

export  var _load_scene_path_on_press: NodePath
onready var load_scene_path_on_press: LoadScenePathOnPress = get_node(_load_scene_path_on_press)

var is_loading: bool = false

func _ready() -> void :
	time_trial_button.connect("pressed", self, "on_time_trial_button_pressed")

func on_time_trial_button_pressed():
	if _level_select_dialog == null:
		var packed_scene: = load("res://project_specific/level_editor/ui/LevelEditor_LevelBrowserDialog.tscn")
		_level_select_dialog = packed_scene.instance()
		_level_select_dialog.allow_editor_info_message = true
		
		
		
		_level_select_dialog.connect("play_level", self, "on_level_selected")
		_level_select_dialog.connect("new_level", self, "on_new_level_selected")
		_level_select_dialog.game_mode_filter.append("Race")
		get_tree().current_scene.add_child(_level_select_dialog)
		get_tree().current_scene.move_child(_level_select_dialog, 0)
	_level_select_dialog.button_grouper.selected = LevelEditor_LevelBrowser.TabIds.Curated
	_level_select_dialog.button_grouper.initial_selected = LevelEditor_LevelBrowser.TabIds.Curated
	_level_select_dialog.dialog.animate_in()
	
func on_level_selected(level_id: String, level_data: Dictionary):
	if is_loading:
		return
	is_loading = true
	yield(ScreenTransitions.fade_in(), "completed")
	yield(AdManager.show_interstitial_ad(), "completed")
	var game_scene: TimeTrialGameplayScene = GoodResourceLoader.load_resource("res://scenes/TimeTrialGameplayScene.tscn").instance()
	game_scene.parameters = TimeTrialSceneParameters.new()
	game_scene.parameters.level_id = level_id
	ScreenTransitions.swap_to_scene_node(game_scene)

func on_new_level_selected():
	load_scene_path_on_press.on_button_pressed()
