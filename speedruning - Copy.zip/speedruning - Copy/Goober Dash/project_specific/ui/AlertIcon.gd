class_name AlertIcon
extends Control

var tween: SceneTreeTween
onready var icon: TextureRect = $TextureRect
var is_showing: = false

export  var show_on_ready: = false

func _ready() -> void :
	hide()
	icon.rect_scale = Vector2.ZERO
	if show_on_ready:
		animate_in()
	if get_tree().current_scene == self:
		_run_editor_tests()

func animate_in():
	if is_showing:
		return
	is_showing = true
	reset_tween()
	tween.tween_callback(self, "show")
	tween.tween_property(icon, "rect_scale", Vector2.ONE, 0.2).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	tween.tween_callback(self, "animate_loop")

func animate_loop():
	reset_tween()
	tween.tween_interval(1.0)
	tween.tween_property(icon, "rect_scale", 0.9 * Vector2.ONE, 0.2).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	tween.tween_property(icon, "rect_scale", 1.1 * Vector2.ONE, 0.2).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	tween.tween_property(icon, "rect_scale", Vector2.ONE, 0.2).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	tween.set_loops()

func animate_out():
	if not is_showing:
		return
	is_showing = false
	reset_tween()
	tween.tween_property(icon, "rect_scale", Vector2.ZERO, 0.2).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_BACK)
	tween.tween_callback(self, "hide")

func reset_tween():
	if tween != null:
		tween.kill()
	tween = create_tween()

func _run_editor_tests():
	while true:
		var show_time: = rand_range(0.0, 1.0)
		print("waiting %s to show" % [show_time])
		yield(get_tree().create_timer(show_time), "timeout")
		print("showing after %s" % [show_time])
		animate_in()
		
		var hide_time: = rand_range(0.0, 5.0)
		print("waiting %s to hide" % [hide_time])
		yield(get_tree().create_timer(hide_time), "timeout")
		print("hiding after %s" % [hide_time])
		animate_out()
