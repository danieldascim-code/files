extends UITextEntryDialog
class_name EnterDisplayNameDialog

signal name_changed()

export  var _error_message_label: NodePath
onready var error_message_label: = get_node(_error_message_label) as Label

var is_submitting: = false

func _ready():
	connect("text_entered", self, "on_text_entered")
	var username: = Moonlight.local_account.user.display_name
	
	if username.begins_with("Guest"):
		if Engine.has_singleton("Steam"):
			var steam_api: = Engine.get_singleton("Steam")
			var steam_name: String = steam_api.getPersonaName()
			if not steam_name.empty():
				username = steam_name
	
	if username.begins_with("Guest"):
		for i in 8:
			var silly_name: = Moonlight_RandomName.silly_name()
			username = silly_name.substr(0, 16)
			if silly_name.length() <= 16:
				break
				
	error_message_label.text = ""
	line_edit.placeholder_text = username
	

func on_text_entered(t: String):
	if is_submitting:
		return
	if t.empty():
		t = line_edit.placeholder_text
	is_submitting = true
	error_message_label.text = ""
	ok_button.disabled = true
	var result: Dictionary = yield(Moonlight.call_rpc("display_name_update", {"display_name": t}), "completed")
	ok_button.disabled = false
	is_submitting = false
	if result.has("error"):
		error_message_label.text = result.get("error", "")
	else:
		
		emit_signal("name_changed")
		dialog.animate_out()
