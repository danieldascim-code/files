extends Control

export  var _game: NodePath
onready var game: = get_node(_game) as WPGame

onready var sound_player: AudioStreamPlayer = $AudioStreamPlayer

func _ready():
	game.connect("player_eliminated", self, "on_player_eliminated")

func on_player_eliminated(player_id: int):
	if game.is_local_player(player_id):
		sound_player.play()
