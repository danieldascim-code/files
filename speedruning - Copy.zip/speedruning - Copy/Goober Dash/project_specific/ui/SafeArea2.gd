extends Control

onready var safe_area: Rect2 = OS.get_window_safe_area()
export  var horizontally_centered: = true

func _ready():
	if is_inside_tree():
		get_tree().root.connect("size_changed", self, "_on_viewport_size_changed")
	_update_safe_area_size()

func _process(_delta: float) -> void :
	var new_safe_area: = OS.get_window_safe_area()
	if safe_area != new_safe_area:
		safe_area = new_safe_area
		_update_safe_area_size()

func _on_viewport_size_changed():
	safe_area = OS.get_window_safe_area()
	_update_safe_area_size()

func _update_safe_area_size():
	var window_margin_top_left: = safe_area.position
	var window_margin_bottom_right: = safe_area.end - OS.window_size
	
	var window_to_viewport: = get_viewport().get_final_transform().affine_inverse()
	var margin_top_left = window_to_viewport.xform(window_margin_top_left)
	var margin_bottom_right = window_to_viewport.xform(window_margin_bottom_right)
	
	margin_top = margin_top_left.y
	margin_bottom = margin_bottom_right.y
	margin_left = margin_top_left.x
	margin_right = margin_bottom_right.x
	if horizontally_centered:
		var largest_horizontal_margin: = max(margin_top_left.x, - margin_bottom_right.x)
		margin_left = largest_horizontal_margin
		margin_right = - largest_horizontal_margin
	












