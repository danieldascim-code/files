extends Control
class_name RoundStartLabelAnimation

signal animation_sequence_finished()

export  var _label: NodePath
onready var label: = get_node(_label) as SDFLabel

export  var _animation_player: NodePath
onready var animation_player: = get_node(_animation_player) as AnimationPlayer

export  var max_width: = 1080.0

onready var root: = $Root as Control
onready var label_anchor: = $Root / LabelAnchor as Control

const enter_animation: = "enter"
const exit_animation: = "exit"
const pulse_animation: = "pulse_1s"
const orbit_animation: = "orbit"

var free_after: = false
var animation_type: = 0
var s1_orbit_sequence_counter: = 0
var s2_orbit_sequence_counter: = 0
var string_1_orbit_sequence: = []
var string_2_orbit_sequence: = []
var max_orbit_sequence: = 0
var is_animating: = false

enum AnimationType{
	Simple, 
	Pulse_1s, 
	Orbit, 
	OrbitSequence, 
}

func _ready():
	animation_player.connect("animation_finished", self, "on_animation_finished")
	root.visible = false

func animate_in_orbit_sequence(string1_sequence: Array, string2_sequence: Array, _free_after: bool):
	s1_orbit_sequence_counter = 0
	s2_orbit_sequence_counter = 0
	string_1_orbit_sequence = string1_sequence
	string_2_orbit_sequence = string2_sequence
	max_orbit_sequence = int(max(string_1_orbit_sequence.size(), string_2_orbit_sequence.size()))
	animate_in_message(string_1_orbit_sequence[0], string_2_orbit_sequence[0], free_after, AnimationType.OrbitSequence)

func _apply_labels(string1: String, string2: String):
	var width: = _apply_label_text(string1, label)
	if width > max_width:
		root.rect_scale = Vector2.ONE * max_width / width

func animate_in_message(string1: String, string2: String, _free_after: bool, _animation_type: int):
	if animation_player.is_playing():
		animation_player.stop(true)
	
	_apply_labels(string1, string2)
	free_after = _free_after
	animation_type = _animation_type
	animation_player.play(enter_animation)
	is_animating = true

func on_animation_finished(animation_name):
	match animation_name:
		enter_animation:
			match animation_type:
				AnimationType.Pulse_1s:
					animation_player.play(pulse_animation)
				AnimationType.Orbit, AnimationType.OrbitSequence:
					animation_player.play(orbit_animation)
				AnimationType.Simple:
					animation_player.play(exit_animation)
				_:
					animation_player.play(exit_animation)
		orbit_animation:
			if animation_type == AnimationType.OrbitSequence:
				s1_orbit_sequence_counter = s1_orbit_sequence_counter + 1
				s2_orbit_sequence_counter = s2_orbit_sequence_counter + 1
				if s1_orbit_sequence_counter < max_orbit_sequence and s2_orbit_sequence_counter < max_orbit_sequence:
					var _s1_safe: = s1_orbit_sequence_counter % string_1_orbit_sequence.size()
					var _s2_safe: = s2_orbit_sequence_counter % string_2_orbit_sequence.size()
					var s1: String = string_1_orbit_sequence[_s1_safe]
					var s2: String = string_2_orbit_sequence[_s2_safe]
					_apply_labels(s1, s2)
					animation_player.play(orbit_animation)
					print("playing orbit sequence with s1 %s %s s2 %s %s" % [s1_orbit_sequence_counter, s1, s2_orbit_sequence_counter, s2])
				else:
					animation_player.play(exit_animation)
			else:
				animation_player.play(exit_animation)
		
		exit_animation:
			is_animating = false
			emit_signal("animation_sequence_finished")
			if free_after:
				queue_free()
		_:
			animation_player.play(exit_animation)

func _apply_label_text(s: String, l: SDFLabel) -> float:
	if s.empty():
		l.visible = false
		return 0.0
	l.visible = true
	l.text = s
	return l.rect_size.x
