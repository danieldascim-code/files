tool 
extends Control
class_name Panel_TwoTone

export  var title_text: = "PANEL" setget set_title_text

export  var _title_label: NodePath
onready var title_label: Label = get_node(_title_label)

func _ready() -> void :
	set_title_text(title_text)
	
func set_title_text(t: String):
	title_text = t
	if is_inside_tree():
		title_label.text = title_text
