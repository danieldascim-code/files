extends Control
class_name UIPartyRow

export (NodePath) var _name_label
onready var name_label: = get_node(_name_label) as Label

export (NodePath) var _discord_avatar
onready var discord_avatar: = get_node(_discord_avatar) as DiscordAvatar

export (NodePath) var _status_icon
onready var status_icon: = get_node(_status_icon) as TextureRect

export (NodePath) var _party_leader_icon
onready var party_leader_icon: = get_node(_party_leader_icon) as TextureRect

export (NodePath) var _kick_button
onready var kick_button: = get_node(_kick_button) as BaseButton

export (NodePath) var _kick_button_focusable
onready var kick_button_focusable: = get_node(_kick_button_focusable) as Focusable

export (NodePath) var _empty_container
onready var empty_container: = get_node_or_null(_empty_container) as Control

export (NodePath) var _player_container
onready var player_container: = get_node_or_null(_player_container) as Control

export (NodePath) var _empty_number_label
onready var empty_number_label: = get_node_or_null(_empty_number_label) as Label

export (NodePath) var _invite_friend_container
onready var invite_friend_container: = get_node_or_null(_invite_friend_container) as Control

export (NodePath) var _panel_button
onready var panel_button: = get_node(_panel_button) as BaseButton

export (NodePath) var _panel_button_focusable
onready var panel_button_focusable: = get_node(_panel_button_focusable) as Focusable

export  var _background_color_rect: NodePath
onready var background_color_rect: ColorRect = get_node(_background_color_rect)




export (NodePath) var _team_button
onready var team_button: = get_node_or_null(_team_button) as GoodButton

export  var player_icon: Texture
export  var spectator_icon: Texture

export (NodePath) var _team_button_focusable
onready var team_button_focusable: = get_node_or_null(_team_button_focusable) as Focusable

export  var open_player_profile: = true
export  var player_profile_dialog_scene_path: String
export  var invite_friend_dialog_scene_path: String

export (Texture) var ready_texture
export (Texture) var in_game_texture



var user_id: = ""
var is_party_leader: = false
var display_name: = ""
var is_self: = false
var is_showing_x_button: = false

const enable_kick_button: = false

func _ready() -> void :
	kick_button.connect("pressed", self, "on_kick_button_pressed")
	panel_button.connect("pressed", self, "on_panel_button_pressed")

func show_empty(number: int, show_invite: bool):
	if invite_friend_container != null:
		invite_friend_container.visible = show_invite
	if empty_container != null:
		empty_container.visible = not show_invite
	if player_container != null:
		player_container.visible = false
	if empty_number_label != null:
		empty_number_label.text = str(number)
	panel_button.visible = show_invite
	is_showing_x_button = false
	user_id = ""
	is_party_leader = false
	is_self = false
	display_name = ""
	
	if status_icon:
		status_icon.texture = null

func show_party_member_data(party_member_data: Dictionary, team_id: int, enable_x_button: bool, enable_profile_button: bool):
	if invite_friend_container != null:
		invite_friend_container.visible = false
	if player_container != null:
		player_container.visible = true
	if empty_container != null:
		empty_container.visible = false
	display_name = party_member_data.get("display_name", "")
	user_id = party_member_data.get("user_id", "")
	is_party_leader = party_member_data.get("is_leader", false)
	is_self = party_member_data.get("is_self", false)
	

	name_label.text = display_name
	
	party_leader_icon.visible = is_party_leader
	team_button.visible = enable_x_button
	
	
	
	
	
	
	is_showing_x_button = enable_x_button
	kick_button.visible = is_showing_x_button
	panel_button.visible = enable_profile_button
	if team_id != 0:
		team_button.icon_tex = player_icon
	else:
		team_button.icon_tex = spectator_icon
	
	if status_icon:
		status_icon.texture = null
	update_display(party_member_data)


func update_display(party_member_data: Dictionary):
	if status_icon != null:
		if party_member_data.has("status"):
			var party_member_status: String = party_member_data["status"]
			if party_member_status == "in_game":
				status_icon.texture = in_game_texture
			elif party_member_status == "ready":
				status_icon.texture = ready_texture
			else:
				status_icon.texture = null
		else:
			pass
			
	else:
		pass
		
	
	if party_member_data.has("discord"):
		var discord_data: Dictionary = party_member_data.get("discord", {})
		var discord_avatar_url: String = discord_data.get("avatar_url", "")
		var discord_display_name: String = discord_data.get("display_name", "")
		if not discord_display_name.empty():
			name_label.text = discord_display_name
		if not discord_avatar_url.empty():
			discord_avatar.visible = true
			discord_avatar.set_discord_avatar_uri(discord_avatar_url)
		else:
			discord_avatar.visible = false
		
	










func set_party_member_data(data: Dictionary):
	update_display(data)

func on_kick_button_pressed():
	kick_button.disabled = true
	var result = null
	if is_self:
		result = Moonlight.party.leave_party()
	else:
		result = Moonlight.party.remove_player_from_party(user_id)
	
	if result is GDScriptFunctionState:
		yield(result, "completed")
	
	kick_button.disabled = false

func on_panel_button_pressed():
	if open_player_profile:
		if user_id.empty():
			
			pass
			
			
			
		else:
			
			var player_profile_dialog_scene: PackedScene = load(player_profile_dialog_scene_path)
			var player_profile_dialog: = player_profile_dialog_scene.instance() as UIPlayerProfileDialog
			get_tree().current_scene.add_child(player_profile_dialog)
			player_profile_dialog.player_profile.show_player_profile(user_id)
	emit_signal("panel_button_pressed")

func get_focus_state() -> String:
	if kick_button == FocusGlobal.focused_control:
		return "kick"
	elif team_button == FocusGlobal.focused_control:
		return "team"
	elif panel_button == FocusGlobal.focused_control:
		return "panel"
	return ""

func set_focus_state(f: String):
	match f:
		"kick":
			if kick_button.visible:
				kick_button_focusable.focus_me()
				return
		"team":
			if team_button.visible:
				team_button_focusable.focus_me()
				return
	panel_button_focusable.focus_me()
