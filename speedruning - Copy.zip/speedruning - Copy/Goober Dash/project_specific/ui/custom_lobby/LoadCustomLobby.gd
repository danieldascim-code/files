extends Node
class_name LoadCustomLobbyScene
export  var lobby_ui_scene_path: String

func _enter_tree() -> void :
	_refresh()

func _ready() -> void :
	Moonlight.party.connect("party_id_changed", self, "on_party_id_changed")
	_refresh()

func on_party_id_changed(party_id: String):
	_refresh()

func _refresh():
	if Moonlight.party and Moonlight.party.is_in_lobby():
		if not lobby_ui_scene_path.empty():
			get_tree().change_scene(lobby_ui_scene_path)
