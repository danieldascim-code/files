extends Control
class_name UICustomLobbyPlayersPanel

signal change_team_button_pressed(user_id)
signal panel_button_pressed(user_id)

export  var player_row_scene: PackedScene

export  var _title_label_one: NodePath
onready var title_label_one: = get_node(_title_label_one) as Label

export  var _title_label_two: NodePath
onready var title_label_two: = get_node(_title_label_two) as Label

export  var _members_container: NodePath
onready var members_container: = get_node(_members_container) as Control

export  var color_one: Color = Color.white
export  var color_two: Color = Color.white

var team_id: = 0
var players: = []
var rows: = []
var rows_map: = {}

func show_party_members(is_teams: bool, _team_id: int, _players: Array):
	players = _players
	team_id = _team_id
	
	var is_spectator_team: = team_id == 0
	
	
	
	var team_color: = Color.white
	var team_name: = ""
	if is_teams or is_spectator_team:
		
		
		pass
	else:
		team_name = "PLAYER"
	
	
	if is_spectator_team:
		title_label_one.text = "SPECTATORS (%s)" % [_players.size()]
		title_label_two.text = ""
	elif is_teams:
		title_label_one.text = team_name
		title_label_two.text = "TEAM (%s)" % [_players.size()]
	else:
		title_label_one.text = "PLAYERS (%s)" % [_players.size()]
		title_label_two.text = ""
	
	
	delete_member_rows()
	var counter: = 0
	for d in players:
		var party_member_data: = d as Dictionary
		
		var party_row: = player_row_scene.instance() as UIPartyRow
		party_row.open_player_profile = false
		var user_id: = d["user_id"] as String
		members_container.add_child(party_row)
		party_row.show_party_member_data(party_member_data, team_id, Moonlight.party.is_leader, true)
		if Moonlight.party.party_member_data.has(user_id):
			party_row.set_party_member_data(Moonlight.party.party_member_data[user_id])
		party_row.team_button.connect("pressed", self, "emit_signal", ["change_team_button_pressed", user_id])
		party_row.panel_button.connect("pressed", self, "emit_signal", ["panel_button_pressed", user_id])
		party_row.background_color_rect.color = color_one if counter % 2 == 0 else color_two
		rows_map[user_id] = party_row
		rows.append(party_row)
		counter = counter + 1

func delete_member_rows():
	for r in rows:
		r.queue_free()
	rows.clear()
	rows_map.clear()
