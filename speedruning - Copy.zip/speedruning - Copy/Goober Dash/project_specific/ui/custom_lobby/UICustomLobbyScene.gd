extends Control

export  var _members_list: NodePath
onready var members_list: = get_node(_members_list) as Control

export  var _teams_toggle: NodePath
onready var teams_toggle: = get_node_or_null(_teams_toggle) as CheckButton

export  var _friends_only_toggle: NodePath
onready var friends_only_toggle: = get_node_or_null(_friends_only_toggle) as CheckButton

export  var _lobby_code_label: NodePath
onready var lobby_code_label: = get_node(_lobby_code_label) as Label

export  var players_panel_scene: PackedScene

export  var _lobby_code_tween: NodePath
onready var lobby_code_tween: = get_node(_lobby_code_tween) as Tween

export  var _lobby_code_copy_button: NodePath
onready var lobby_code_copy_button: = get_node(_lobby_code_copy_button) as BaseButton

export  var _lobby_code_animated_label: NodePath
onready var lobby_code_animated_label: = get_node_or_null(_lobby_code_animated_label) as Label
onready var lobby_code_animated_label_anchor_point: GoodAnchorPoint = lobby_code_animated_label.get_node("GoodAnchorPoint")

export  var _start_button: NodePath
onready var start_button: = get_node(_start_button) as GoodButton

export  var _start_disabled_label: NodePath
onready var start_disabled_label: = get_node(_start_disabled_label) as Label

export  var _in_lobby_exit_button: NodePath
onready var in_lobby_exit_button: = get_node(_in_lobby_exit_button) as GoodButton

export  var _exit_button: NodePath
onready var exit_button: = get_node(_exit_button) as BaseButton

export  var _join_lobby_code_line_edit: NodePath
onready var join_lobby_code_line_edit: = get_node(_join_lobby_code_line_edit) as LineEdit

export  var _join_lobby_code_button: NodePath
onready var join_lobby_code_button: = get_node(_join_lobby_code_button) as BaseButton

export  var _join_lobby_code_button_focusable: NodePath
onready var join_lobby_code_button_focusable: = get_node(_join_lobby_code_button_focusable) as Focusable

export  var _create_lobby_button: NodePath
onready var create_lobby_button: = get_node(_create_lobby_button) as BaseButton

export  var _create_or_join_container: NodePath
onready var create_or_join_container: = get_node(_create_or_join_container) as Control

export  var _in_lobby_container: NodePath
onready var in_lobby_container: = get_node(_in_lobby_container) as Control

export  var _matchmaker: NodePath
onready var matchmaker: = get_node(_matchmaker) as GameMatchmaker

export  var _game_settings_button: NodePath
onready var game_settings_button: = get_node(_game_settings_button) as GoodButton

export  var _info_panel_game_mode_label: NodePath
onready var info_panel_game_mode_label: = get_node_or_null(_info_panel_game_mode_label) as Label

export  var _info_panel_friends_only_label: NodePath
onready var info_panel_friends_only_label: = get_node_or_null(_info_panel_friends_only_label) as Label

export  var _select_my_team_button: NodePath
onready var select_my_team_button: = get_node(_select_my_team_button) as GoodButton

export  var _locked_teams_container: NodePath
onready var locked_teams_container: = get_node(_locked_teams_container) as Control

export  var _locked_teams_toggle: NodePath
onready var locked_teams_toggle: = get_node(_locked_teams_toggle) as CheckButton

export  var _locked_teams_info_label: NodePath
onready var locked_teams_info_label: = get_node_or_null(_locked_teams_info_label) as Label

export  var _locked_teams_info_container: NodePath
onready var locked_teams_info_container: = get_node_or_null(_locked_teams_info_container) as Control

export  var _friends_only_info_label: NodePath
onready var friends_only_info_label: = get_node_or_null(_friends_only_info_label) as Label

export  var _player_container_title_label: NodePath
onready var player_container_title_label: = get_node(_player_container_title_label) as Label

export  var _join_lobby_error_message_container: NodePath
onready var join_lobby_error_message_container: = get_node(_join_lobby_error_message_container) as Control

export  var _join_lobby_error_message_label: NodePath
onready var join_lobby_error_message_label: = get_node(_join_lobby_error_message_label) as Label

export  var _join_request_rejected_tween: NodePath
onready var join_request_rejected_tween: = get_node(_join_request_rejected_tween) as Tween

export  var _countdown_container: NodePath
onready var countdown_container: = get_node(_countdown_container) as Control

export  var _countdown_label: NodePath
onready var countdown_label: = get_node(_countdown_label) as Label

export  var _countdown_beep: NodePath
onready var countdown_beep: = get_node(_countdown_beep) as AudioStreamPlayer

export  var _countdown_tween: NodePath
onready var countdown_tween: = get_node(_countdown_tween) as Tween

export  var player_profile_dialog_scene: PackedScene
export  var select_team_dialog_scene: PackedScene

export  var _level_browser_dialog: NodePath
onready var level_browser_dialog: LevelEditor_LevelBrowser = get_node(_level_browser_dialog)

export  var _customize_level_dialog: NodePath
onready var customize_level_dialog: CustomizeGameModeDialog = get_node(_customize_level_dialog)

export  var _level_info_container: NodePath
onready var level_info_container: Control = get_node(_level_info_container)

export  var _level_info_level_name: NodePath
onready var level_info_level_name: Label = get_node(_level_info_level_name)

export  var _level_info_player_count_label: NodePath
onready var level_info_player_count_label: Label = get_node(_level_info_player_count_label)

export  var _show_hide_lobby_code_button: NodePath
onready var show_hide_lobby_code_button: GoodButton = get_node(_show_hide_lobby_code_button)

export  var _lobby_code_container: NodePath
onready var lobby_code_container: Control = get_node(_lobby_code_container)

export  var spectator_icon: Texture
export  var player_icon: Texture

signal team_assignments_changed
signal game_mode_changed

const party_size: = 32

var member_panels: = {}
var player_panels: = {}


var team_assignments: = {}
var teams_locked: = false
var countdown_to_start: = - 1.0
var is_counting_down: = false
var host_is_matchmaking: = false
var is_loading_home_scene: = false

var restore_bouncer_state: = 0

const regular_game_mode: = "Solo"
onready var single_map_game_mode: String = Utilities.enum_reverse(WPGame.GameModes, WPGame.GameModes.SingleMapRace)
onready var game_mode: = single_map_game_mode
var game_mode_enum: int = CustomizeGameModeDialog.GameMode.SingleRace

var map_player_count: = party_size
var map_game_mode: = "Race"

var map_id: = ""
var map_name: = "Random"

const num_initial_teams: = 4
const join_request_rejected_timer: = 1.0
const countdown_duration: = 5.0
const start_button_text: = "START"
const cancel_button_text: = "CANCEL"

func is_teams() -> bool:
	
	return false

func _ready():
	lobby_code_copy_button.connect("pressed", self, "on_lobby_code_copy_button_pressed")
	start_button.connect("pressed", self, "on_start_button_pressed")
	in_lobby_exit_button.connect("pressed", self, "on_exit_button_pressed")
	exit_button.connect("pressed", self, "load_home_scene")
	join_lobby_code_button.connect("pressed", self, "on_join_lobby_code_button_pressed")
	join_lobby_code_line_edit.connect("text_entered", self, "on_join_lobby_code_line_edit_text_entered")
	create_lobby_button.connect("pressed", self, "on_create_lobby_button_pressed")
	if teams_toggle:
		teams_toggle.connect("pressed", self, "on_teams_toggle_pressed")
	if friends_only_toggle:
		friends_only_toggle.connect("pressed", self, "on_friends_only_pressed")
	select_my_team_button.connect("pressed", self, "on_select_my_team_button_pressed")
	if locked_teams_toggle:
		locked_teams_toggle.connect("pressed", self, "on_locked_teams_toggle_pressed")
	
	game_settings_button.connect("pressed", self, "on_map_select_button_pressed")
	
	matchmaker.connect("cancel_button_pressed", self, "on_matchmaker_cancel_button_pressed")
	matchmaker.connect("connection_closed", self, "on_matchmaker_connection_closed")
	
	show_hide_lobby_code_button.connect("pressed", self, "on_show_hide_lobby_code_button_pressed")
	
	level_browser_dialog.button_grouper.selected = LevelEditor_LevelBrowser.TabIds.Curated
	level_browser_dialog.button_grouper.initial_selected = LevelEditor_LevelBrowser.TabIds.Curated
	level_browser_dialog.disable_level_creation = true
	
	level_browser_dialog.connect("play_level", self, "on_level_browser_dialog_map_selected")
	level_browser_dialog.dialog.background_override = true
	customize_level_dialog.connect("game_mode_selected", self, "on_customize_level_dialog_game_mode_selected")
	
	connect("team_assignments_changed", self, "on_team_assignments_changed")
	connect("game_mode_changed", self, "on_game_mode_changed")
	
	Moonlight.party.connect("party_members_changed", self, "on_party_members_changed")
	Moonlight.party.connect("party_member_joined", self, "on_party_member_joined")
	Moonlight.party.connect("party_member_left", self, "on_party_member_left")
	Moonlight.party.connect("party_id_changed", self, "on_party_id_changed")
	Moonlight.lobby.connect("lobby_code_changed", self, "refresh_lobby_code_label")
	Moonlight.party.connect("party_data_received", self, "on_party_data_received")
	Moonlight.party.connect("party_member_data_changed", self, "on_party_member_data_changed")
	Moonlight.party.connect("party_bouncer_state_changed", self, "on_party_bouncer_state_changed")
	Moonlight.party.connect("party_leader_changed", self, "on_party_leader_changed")
	matchmaker.connect("match_made", self, "on_matchmaker_match_made")
	SavedSettings.connect("on_value_changed", self, "on_saved_setting_changed")
	FocusGlobal.connect("focused_control_changed", self, "on_focus_changed")
	

	
	start_button.label_text = start_button_text
	join_lobby_error_message_container.visible = false
	lobby_code_label.text = ""
	countdown_container.visible = false
	if Moonlight.party.is_in_lobby():
		on_party_data_received(Moonlight.party.party_data)
		set_ready_status()
		if Moonlight.party.is_leader:
			for user_id in Moonlight.party.party_members:
				assign_random_team(user_id)
	
	
	if Moonlight.discord_api.is_in_discord():
		for user_id in Moonlight.party.party_member_data:
			var data: Dictionary = Moonlight.party.party_member_data[user_id]
			if data.has("discord"):
				var discord_data: Dictionary = data["discord"]
				var display_name: String = discord_data.get("display_name", "")
				var avatar_url: String = discord_data.get("avatar_url", "")
				Moonlight.discord_api.cache_player_data(user_id, display_name, avatar_url)
	
	
	if Moonlight.discord_api.is_in_discord() and Moonlight.party.is_in_party():
		var discord_data: Dictionary = Moonlight.storage.storage_get("player.discord", {})
		Moonlight.party.merge_local_member_data({"discord": discord_data})
	
	on_game_mode_changed()
	on_party_bouncer_state_changed(Moonlight.party.bouncer_state)
	show_appropriate_ui()
	show_party_members()
	refresh_lobby_code_label()
	
func _exit_tree():
	CrazyAuth.hide_invite_button()

func on_show_hide_lobby_code_button_pressed():
	var setting_value: bool = SavedSettings.get_value("hide_lobby_code", false)
	setting_value = not setting_value
	SavedSettings.set_value("hide_lobby_code", setting_value)
	refresh_lobby_code_label()

func on_map_select_button_pressed():
	customize_level_dialog.dialog.animate_in()
	customize_level_dialog.render(game_mode_enum, map_name)

func on_customize_level_dialog_game_mode_selected(p_game_mode_enum: int):
	game_mode_enum = p_game_mode_enum
	match game_mode_enum:
		CustomizeGameModeDialog.GameMode.Royale:
			game_mode = regular_game_mode
			map_id = ""
			map_game_mode = "Race Royale"
			map_player_count = party_size
			map_name = "-"
		CustomizeGameModeDialog.GameMode.SingleRace:
			game_mode = single_map_game_mode
			map_id = ""
			map_game_mode = "Race"
			map_player_count = party_size
			map_name = "Random"
	send_lobby_data()
	on_game_mode_changed()

func on_level_browser_dialog_map_selected(level_id: String, level_metadata: Dictionary):
	level_browser_dialog.dialog.animate_out()
	customize_level_dialog.dialog.animate_out()
	map_id = level_id
	map_game_mode = level_metadata.get("game_mode", "Race")
	map_player_count = int(level_metadata.get("player_count", 1))
	var player_count: = 0
	for user_id in Moonlight.party.party_members:
		
		if team_assignments.get(user_id, 1) != 0:
			player_count += 1
	
	var players_to_move_to_spectating: = player_count - map_player_count
	var party_member_index: = 0
	var party_member_user_ids: = Moonlight.party.party_members.keys()
	while players_to_move_to_spectating > 0 and party_member_index < party_member_user_ids.size():
		var user_id: String = party_member_user_ids[party_member_index]
		party_member_index += 1
		if user_id == Moonlight.local_account.user.id:
			continue
		if team_assignments.get(user_id, 1) != 0:
			
			team_assignments[user_id] = 0
			players_to_move_to_spectating -= 1
	map_name = level_metadata.get("name", "-")
	on_team_assignments_changed()
	send_lobby_data()
	on_game_mode_changed()

func on_matchmaker_connection_closed():
	if Moonlight.party.is_in_lobby() and Moonlight.party.is_leader:
		host_is_matchmaking = false
		is_counting_down = false
		Moonlight.party.set_bouncer_state(restore_bouncer_state)
		send_lobby_data()
		start_button.label_text = start_button_text
	show_appropriate_ui()

func on_party_leader_changed():
	if Moonlight.party.is_in_lobby() and Moonlight.party.is_leader:
		host_is_matchmaking = false
		send_lobby_data()
	show_appropriate_ui()

var focus_data: Dictionary
func on_focus_changed(c: Control):
	if is_inside_tree():
		save_focus_data()
		if c == null:
			restore_focus()

func on_party_bouncer_state_changed(b: int):
	match Moonlight.party.bouncer_state:
		Moonlight_Party.PartyBouncerState.Friends:
			if friends_only_info_label:
				friends_only_info_label.text = "YES"
			if friends_only_toggle:
				friends_only_toggle.pressed = true
		Moonlight_Party.PartyBouncerState.Public:
			if friends_only_info_label:
				friends_only_info_label.text = "NO"
			if friends_only_toggle:
				friends_only_toggle.pressed = false
		Moonlight_Party.PartyBouncerState.Closed:
			pass

func on_locked_teams_toggle_pressed():
	if teams_locked != locked_teams_toggle.pressed:
		teams_locked = locked_teams_toggle.pressed
		on_game_mode_changed()
		send_lobby_data()
		
func on_select_my_team_button_pressed():
	pass
	change_users_team(Moonlight.local_account.user.id)


func on_row_team_button_pressed(user_id: String):
	change_users_team(user_id)


func change_users_team(user_id: String):
	var current_team_assignment: = team_assignments.get(user_id, 1) as int
	var selected_team: = 0
	if current_team_assignment == 0:
		selected_team = 1
	if Moonlight.party.is_leader:
		team_assignments[user_id] = selected_team
		emit_signal("team_assignments_changed")
		send_lobby_data()
	else:
		if user_id == Moonlight.local_account.user.id:
			Moonlight.party.merge_local_member_data({"team_assignment": selected_team})





















func show_player_profile_dialog(user_id: String):
	
	var player_profile_dialog: = player_profile_dialog_scene.instance() as UIPlayerProfileDialog
	get_tree().current_scene.add_child(player_profile_dialog)
	player_profile_dialog.show_player_profile_dialog(user_id)

func on_saved_setting_changed(key, value):
	if key == "hide_lobby_code":
		refresh_lobby_code_label()

func on_party_member_data_changed(user_id: String, data: Dictionary):
	print("[UICustomLobby] on_party_member_data_changed(%s, %s)" % [user_id, data])
	
	if Moonlight.party.is_leader:
		if not teams_locked and not is_counting_down:
			if data.has("team_assignment"):
				var t = data["team_assignment"]
				print("[CustomLobby] on_party_member_data_changed(%s, %s)" % [user_id, data])
				if t is int or t is float:
					team_assignments[user_id] = int(t)
					emit_signal("team_assignments_changed")
					send_lobby_data()
	
	if member_panels.has(user_id):
		var panel: = member_panels[user_id] as UICustomLobbyPlayersPanel
		if panel.rows_map.has(user_id):
			var row: = panel.rows_map[user_id] as UIPartyRow
			row.set_party_member_data(data)
		else:
			print("[CustomLobby] rows_map doesnt contain user_id %s" % [user_id])
	else:
		print("[CustomLobby] member_panels doesnt contain user_id %s" % [user_id])
	
	
	if Moonlight.discord_api.is_in_discord():
		if data.has("discord"):
			var discord_data: Dictionary = data["discord"]
			var display_name: String = discord_data.get("display_name", "")
			var avatar_url: String = discord_data.get("avatar_url", "")
			Moonlight.discord_api.cache_player_data(user_id, display_name, avatar_url)

func on_party_member_left(user_id: String):
	if Moonlight.party.is_leader:
		if team_assignments.has(user_id):
			team_assignments.erase(user_id)
			emit_signal("team_assignments_changed")
		send_lobby_data()

func on_party_member_joined(user_id: String):
	if Moonlight.party.is_leader:
		if teams_locked:
			
			assign_spectator_team(user_id)
		else:
			assign_random_team(user_id)

func assign_random_team(user_id: String):
	
	if not team_assignments.has(user_id):
		
		team_assignments[user_id] = 1
		emit_signal("team_assignments_changed")
		send_lobby_data()

func assign_spectator_team(user_id: String):
	team_assignments[user_id] = 0
	emit_signal("team_assignments_changed")
	send_lobby_data()

func on_party_data_received(data: Dictionary):
	
	
	
	
	
	
	
	
	print("[UICustomLobbyScene] on_party_data_received(%s)" % [data])
	var has_game_mode_changed: = false
	if data.has("game_mode"):
		if game_mode.empty() or game_mode != data["game_mode"]:
			game_mode = data["game_mode"]
			if teams_toggle:
				
				teams_toggle.pressed = false
			has_game_mode_changed = true
	if data.has("game_mode_enum"):
		game_mode_enum = data["game_mode_enum"]
		has_game_mode_changed = true
	if data.has("map_game_mode"):
		map_game_mode = data["map_game_mode"]
		has_game_mode_changed = true
	if data.has("map_id"):
		map_id = data["map_id"]
		has_game_mode_changed = true
	if data.has("map_name"):
		map_name = data["map_name"]
		has_game_mode_changed = true
	if data.has("map_player_count"):
		map_player_count = data["map_player_count"]
		has_game_mode_changed = true
	if has_game_mode_changed:
		emit_signal("game_mode_changed")
	
	if data.has("team_assignments"):
		team_assignments = data["team_assignments"]
		emit_signal("team_assignments_changed")
	
	if data.has("teams_locked"):
		teams_locked = data["teams_locked"]
		locked_teams_toggle.pressed = teams_locked
		emit_signal("game_mode_changed")
	
	if data.has("countdown"):
		countdown_to_start = float(data["countdown"])
	
	if data.has("is_counting_down"):
		is_counting_down = bool(data["is_counting_down"])
	
	if data.has("host_is_matchmaking"):
		host_is_matchmaking = bool(data["host_is_matchmaking"])
		
	show_appropriate_ui()


func on_team_assignments_changed():
	show_party_members()
	refresh_start_button()
	var my_team: = int(team_assignments.get(Moonlight.local_account.user.id, 1))
	select_my_team_button.icon_tex = player_icon if my_team == 0 else spectator_icon
	
func on_game_mode_changed():
	var _is_teams: = is_teams()
	
	
	
	select_my_team_button.disabled = is_counting_down or teams_locked
	
	
	if locked_teams_info_label:
		locked_teams_info_label.text = "YES" if teams_locked else "NO"
	
	if locked_teams_info_container:
		locked_teams_info_container.visible = true
	if teams_toggle:
		teams_toggle.pressed = _is_teams
	
	
	level_info_container.visible = game_mode == single_map_game_mode
	level_info_level_name.text = map_name
	level_info_player_count_label.text = str(map_player_count)
	info_panel_game_mode_label.text = map_game_mode
	show_party_members()
	refresh_start_button()
	
func on_teams_toggle_pressed():
	if Moonlight.party.is_leader:
		var game_mode_before: = game_mode






		
		if game_mode != game_mode_before:
			emit_signal("game_mode_changed")
		
		send_lobby_data()

func send_lobby_data():
	if Moonlight.party.is_in_lobby() and Moonlight.party.is_leader:
		var payload: = {
			"game_mode": game_mode, 
			"game_mode_enum": game_mode_enum, 
			"map_id": map_id, 
			"map_name": map_name, 
			"map_game_mode": map_game_mode, 
			"map_player_count": map_player_count, 
			"team_assignments": team_assignments, 
			"teams_locked": teams_locked, 
			"countdown": countdown_to_start, 
			"is_counting_down": is_counting_down, 
			"host_is_matchmaking": host_is_matchmaking
		}
		var result = Moonlight.party.send_party_data(payload)
		if result is GDScriptFunctionState:
			yield(result, "completed")

func on_friends_only_pressed():
	if friends_only_toggle.pressed:
		Moonlight.party.set_bouncer_state(Moonlight_Party.PartyBouncerState.Friends)
	else:
		Moonlight.party.set_bouncer_state(Moonlight_Party.PartyBouncerState.Public)

func on_party_id_changed(_party_id: String):
	print("[CustomLobby] on_party_id_changed()")
	if Moonlight.party.is_in_lobby():
		send_lobby_data()
	
	set_ready_status()
	stop_countdown_to_join_request_rejected()
	show_appropriate_ui()
	show_party_members()

func refresh_lobby_code_label():
	if Moonlight.lobby.lobby_code.begins_with("discord") or Moonlight.discord_api.is_in_discord():
		print("[CustomLobbyScene] hiding lobby code")
		lobby_code_label.visible = false
		show_hide_lobby_code_button.visible = false
		lobby_code_copy_button.visible = false
		lobby_code_container.visible = false
		return
	
	lobby_code_label.visible = true
	show_hide_lobby_code_button.visible = true
	lobby_code_copy_button.visible = true
	lobby_code_container.visible = true

	if Moonlight.party.is_in_lobby():
		
		CrazyAuth.async_get_invite_button({"lobby": Moonlight.lobby.lobby_code})
	
	if SavedSettings.get_value("hide_lobby_code", false):
		lobby_code_label.text = "*******"
		show_hide_lobby_code_button.label_text = "SHOW"
	else:
		lobby_code_label.text = Moonlight.lobby.lobby_code
		show_hide_lobby_code_button.label_text = "HIDE"

func set_ready_status():
	print("[CustomLobby] set_ready_status()")
	if Moonlight.party.is_in_lobby():
		Moonlight.party.merge_local_member_data({"status": "ready"})

func show_appropriate_ui():
	if is_loading_home_scene:
		return
	
	var is_in_lobby: = Moonlight.party.is_in_lobby()
	var is_in_matchmaker: = matchmaker.connecting or host_is_matchmaking
	var is_leader: = Moonlight.party.is_leader
	print("[CustomLobby] show_appropriate_ui() is_in_lobby: %s matchmaker.connecting: %s host_is_matchmaking: %s is_leader: %s" % [is_in_lobby, matchmaker.connecting, host_is_matchmaking, is_leader])
	
	matchmaker.visible = is_in_matchmaker
	in_lobby_container.visible = not is_in_matchmaker and is_in_lobby
	create_or_join_container.visible = not is_in_matchmaker and not is_in_lobby
	game_settings_button.visible = is_leader
	start_button.visible = is_leader
	locked_teams_container.visible = is_leader
	if is_in_lobby:
		join_lobby_code_line_edit.text = ""
	
	on_party_bouncer_state_changed(Moonlight.party.bouncer_state)
	refresh_lobby_code_label()

func on_create_lobby_button_pressed():
	if Moonlight.auth.is_guest_account():
		notify_is_guest()
	else:
		Moonlight.lobby.create_lobby(party_size)

const message_is_guest: = "Sign up to create CUSTOM MATCHES to play with your friends!"
func notify_is_guest():
	var notification_dialog_scene: PackedScene = load("res://goodoh/ui/nodes/UINotifyDialog.tscn")
	var notification_dialog: = notification_dialog_scene.instance() as UINotifyDialog
	notification_dialog.set_label_text(message_is_guest)
	get_tree().current_scene.add_child(notification_dialog)

func on_join_lobby_code_line_edit_text_entered(text: String):
	join_lobby_code(text)

func on_join_lobby_code_button_pressed():
	join_lobby_code(join_lobby_code_line_edit.text)

func join_lobby_code(lobby_code: String):
	if not join_lobby_code_button.disabled:
		stop_countdown_to_join_request_rejected()
		join_lobby_error_message_container.visible = false
		join_lobby_code_button.disabled = true
		var join_result: Dictionary = yield(Moonlight.lobby.join_lobby_code(lobby_code), "completed")
		if join_result.has("error"):
			stop_countdown_to_join_request_rejected()
			render_join_lobby_code_failure(join_result["error"])
		else:
			start_countdown_to_join_request_rejected()
		join_lobby_code_button.disabled = false

func render_join_request_rejected():
	join_lobby_error_message_container.visible = true
	join_lobby_error_message_label.text = "join request rejected"
	
func start_countdown_to_join_request_rejected():
	join_request_rejected_tween.interpolate_callback(self, join_request_rejected_timer, "render_join_request_rejected")
	join_request_rejected_tween.start()

func stop_countdown_to_join_request_rejected():
	join_request_rejected_tween.remove_all()

func render_join_lobby_code_failure(error_message: String):
	printerr("[UICustomLobby] couldn\'t join lobby: %s" % [error_message])
	join_lobby_error_message_container.visible = true
	if "couldnt find party_id" in error_message:
		join_lobby_error_message_label.text = "lobby code not found"
	else:
		join_lobby_error_message_label.text = "failed to join lobby"

func on_matchmaker_cancel_button_pressed():
	show_appropriate_ui()
	confirm_exit_to_home()

func on_exit_button_pressed():
	confirm_exit_to_home()

func confirm_exit_to_home():
	var confirm_dialog_scene: PackedScene = load("res://goodoh/ui/nodes/UIConfirmationDialog.tscn")
	var confirm_dialog: = confirm_dialog_scene.instance() as UIConfirmationDialog
	confirm_dialog.text = "Are you sure you want to exit the custom match?"
	get_tree().current_scene.add_child(confirm_dialog)
	var confirmed: = yield(confirm_dialog, "confirm_or_cancel") as bool
	if confirmed:
		leave_party_load_home_scene()

func leave_party_load_home_scene():
	if not is_loading_home_scene:
		is_loading_home_scene = true
		if Moonlight.party.is_leader:
			host_is_matchmaking = false
			is_counting_down = false
			Moonlight.party.set_bouncer_state(restore_bouncer_state)
			send_lobby_data()
		
		var leave_result = Moonlight.party.leave_party()
		if leave_result is GDScriptFunctionState:
			yield(leave_result, "completed")
		load_home_scene()

func load_home_scene():
	LoadHomeOnPress.go_home(get_tree())

func on_start_button_pressed():
	if Moonlight.party.is_leader:
		if not matchmaker.connecting:
			is_counting_down = not is_counting_down
			countdown_to_start = countdown_duration
			
			if is_counting_down:
				start_button.label_text = cancel_button_text
				restore_bouncer_state = Moonlight.party.bouncer_state
				Moonlight.party.set_bouncer_state(Moonlight_Party.PartyBouncerState.Closed)
			else:
				start_button.label_text = start_button_text
				Moonlight.party.set_bouncer_state(restore_bouncer_state)
			send_lobby_data()

func connect_to_matchmaker():
	matchmaker.network_matchmaker.game_mode = game_mode
	matchmaker.network_matchmaker.custom_config = {
		"team_assignments": team_assignments, 
		"map_id": map_id
	}
	
	var match_request: = WPGame.MatchTypeCustom
	matchmaker.connect_to_matchmaker(match_request)
	show_appropriate_ui()

func on_lobby_code_copy_button_pressed():
	
	if AdManager.get_ad_driver() == "crazygames":
		var lobby_code: = Moonlight.lobby.lobby_code
		var share_dialog_scene: PackedScene = load("res://project_specific/level_editor/ShareLevelDialog.tscn")
		var share_dialog: ShareLevelDialog = share_dialog_scene.instance()
		get_tree().current_scene.add_child(share_dialog)
		share_dialog.dialog.dialog_title_label.text = "LOBBY INVITE"
		share_dialog.dialog.background_override = true
		var invite_link_response: Dictionary = yield(CrazyAuth.async_get_invite_link({"lobby": lobby_code}), "get_crazygames_invite_link")
		var crazy_games_invite_link: String = invite_link_response.get("link", "")
		if not crazy_games_invite_link.empty():
			share_dialog.share_url = crazy_games_invite_link
		else:
			share_dialog.share_url = ShareLevelDialog.share_url_lobby(lobby_code)
	else:
		OS.clipboard = Moonlight.lobby.lobby_code
		
		var duration: = 0.6
		var fade_delay: = 0.5
		lobby_code_tween.remove_all()
		lobby_code_tween.interpolate_callback(lobby_code_animated_label, 0.0, "show")
		lobby_code_tween.interpolate_callback(lobby_code_animated_label, 0.0, "set_modulate", Color.white)
		lobby_code_tween.interpolate_property(lobby_code_animated_label, "modulate", Color.white, Color.transparent, duration - fade_delay, Tween.TRANS_LINEAR, Tween.EASE_OUT, fade_delay)
		lobby_code_tween.interpolate_property(lobby_code_animated_label_anchor_point, "offset", Vector2(0.0, - 10.0), Vector2(0.0, - 40.0), duration, Tween.TRANS_EXPO, Tween.EASE_OUT)
		lobby_code_tween.start()

func on_party_members_changed():
	print("[UICustomLobbyScene] on_party_members_changed()")
	show_party_members()
	show_appropriate_ui()
	refresh_start_button()

func delete_member_panels():
	for team_id in player_panels:
		player_panels[team_id].queue_free()
	player_panels.clear()
	member_panels.clear()

func save_focus_data() -> Dictionary:
	var row_with_focus = find_row_with_focus()
	if row_with_focus != null and row_with_focus is UIPartyRow:
		focus_data["user_id_with_focus"] = row_with_focus.user_id
		focus_data["row_focus_state"] = row_with_focus.get_focus_state()
	return focus_data

func restore_focus():
	
	if focus_data.has("user_id_with_focus"):
		var panel_id: = - 1
		var user_id_with_focus: String = focus_data["user_id_with_focus"]
		if is_teams() and team_assignments.has(user_id_with_focus):
			panel_id = team_assignments[user_id_with_focus]
		if player_panels.has(panel_id):
			var panel: = player_panels[panel_id] as UICustomLobbyPlayersPanel
			if panel.rows_map.has(user_id_with_focus):
				var row: = panel.rows_map[user_id_with_focus] as UIPartyRow
				row.set_focus_state(focus_data["row_focus_state"])
				return
	
	
	if join_lobby_code_button.is_visible_in_tree():
		join_lobby_code_button_focusable.focus_me()
	elif matchmaker.cancel_button.is_visible_in_tree():
		matchmaker.cancel_button.focusable.focus_me()
	elif in_lobby_exit_button.is_visible_in_tree():
		in_lobby_exit_button.focusable.focus_me()
	else:
		printerr("[UICustomLobbyScene] lost focus")

func show_party_members():
	if is_loading_home_scene:
		return
	print("[UICustomLobby] show_party_members() %s" % [Moonlight.party.party_members])
	player_container_title_label.text = "%d" % [Moonlight.party.party_members.size()]
	
	
	delete_member_panels()
	
	var sorted_user_ids: = team_assignments.keys()
	
	
	for user_id in Moonlight.party.party_members:
		if not team_assignments.has(user_id):
			sorted_user_ids.append(user_id)
	sorted_user_ids.sort_custom(self, "cmp_user_ids")
	
	var default_team_id: = - 1
	if is_teams():
		default_team_id = 1
		
	
	
	
	
	
	var inverse_team_assignments: = {}
	for user_id in sorted_user_ids:
		if not Moonlight.party.party_members.has(user_id):
			printerr("[UICustomLobby] show_party_members() user_id %s isnt in party" % [user_id])
			continue
		
		
		
			
			
		var team_id: = int(team_assignments.get(user_id, default_team_id))
		
		
		if not is_teams():
			
			
			
			if team_id > 0:
				team_id = 1
		
		if not inverse_team_assignments.has(team_id):
			inverse_team_assignments[team_id] = []
		var team_list: = inverse_team_assignments[team_id] as Array
		var party_member_data: = Moonlight.party.party_members[user_id] as Dictionary
		team_list.append(party_member_data)
	
	var sorted_team_ids: = inverse_team_assignments.keys()
	sorted_team_ids.sort_custom(self, "cmp_team_ids")
	
	for team_id in sorted_team_ids:
		var players_panel: = players_panel_scene.instance() as UICustomLobbyPlayersPanel
		members_list.add_child(players_panel)
		players_panel.connect("panel_button_pressed", self, "show_player_profile_dialog")
		players_panel.connect("change_team_button_pressed", self, "on_row_team_button_pressed")
		player_panels[team_id] = players_panel
		players_panel.show_party_members(is_teams(), team_id, inverse_team_assignments[team_id])
		for user_id in players_panel.rows_map:
			member_panels[user_id] = players_panel

func refresh_start_button():
	var should_enable_start_button: = true
	if is_teams():
		var inverse_team_assignments: = {}
		for user_id in team_assignments:
			var team_id: = int(team_assignments[user_id])
			if team_id != 0:
				
				inverse_team_assignments[team_id] = true
		var number_of_teams: = inverse_team_assignments.size()
		if number_of_teams <= 1:
			start_disabled_label.text = "Not enough teams!"
			should_enable_start_button = false
	else:
		var player_count: = 0
		for user_id in Moonlight.party.party_members:
			var team_id: = int(team_assignments.get(user_id, 1))
			if team_id != 0:
				
				player_count += 1
		
		var max_player_count: = map_player_count
		if player_count > max_player_count:
			start_disabled_label.text = "Too many players for map!"
			should_enable_start_button = false
		elif player_count <= 1:
			start_disabled_label.text = "Not enough players!"
			should_enable_start_button = false
	start_button.disabled = not should_enable_start_button
	start_disabled_label.visible = start_button.disabled
	
func on_matchmaker_match_made():
	if Moonlight.party.is_in_party() and Moonlight.party.is_leader:
		host_is_matchmaking = false
		is_counting_down = false
		Moonlight.party.set_bouncer_state(restore_bouncer_state)
		send_lobby_data()

func _process(delta):
	if Moonlight.party.is_in_lobby():
		
		select_my_team_button.disabled = is_counting_down or teams_locked
		if is_counting_down and not matchmaker.connecting and not host_is_matchmaking:
			var was_visible: = countdown_container.visible
			countdown_container.visible = true
			var countdown_render_offset: = - 1
			if Moonlight.party.is_leader:
				countdown_render_offset = - 1
			var countdown_int_before: = ceil(max(0, countdown_to_start + countdown_render_offset))
			countdown_to_start -= delta
			if countdown_to_start <= 0.0:
				if Moonlight.party.is_leader:
					connect_to_matchmaker()
					is_counting_down = false
					countdown_to_start = countdown_duration
					host_is_matchmaking = true
					send_lobby_data()
			countdown_to_start = max(0, countdown_to_start)
			var countdown_int: = ceil(max(0, countdown_to_start + countdown_render_offset))
			countdown_label.text = String(countdown_int)
			
			if not was_visible or countdown_int_before != countdown_int and is_counting_down:
				if countdown_int == 0:
					countdown_beep.pitch_scale = 1.25
				else:
					countdown_beep.pitch_scale = 1.0
				countdown_beep.play()
				countdown_tween.remove_all()
				countdown_tween.interpolate_property(countdown_label, "rect_scale:y", 0.1, 1.0, 0.35, Tween.TRANS_BOUNCE, Tween.EASE_OUT)
				countdown_tween.interpolate_property(countdown_label, "rect_scale:x", - 2.001, 1.0, 0.35, Tween.TRANS_BACK, Tween.EASE_OUT)
				countdown_tween.start()
		else:
			countdown_container.visible = false

func find_row_with_focus():
	var current_focus: = FocusGlobal.focused_control
	var root: = members_list
	if current_focus != null:
		if root.is_a_parent_of(current_focus):
			while current_focus != null and members_list.is_a_parent_of(current_focus):
				if current_focus is UIPartyRow:
					return current_focus
				current_focus = current_focus.get_parent() as Control
				if current_focus == root:
					break
	return null

static func cmp_user_ids(user_id_a: String, user_id_b: String) -> bool:
	if Moonlight.party.leader_user_id == user_id_a or Moonlight.party.leader_user_id == user_id_b:
		return Moonlight.party.leader_user_id == user_id_a
	return user_id_a < user_id_b

func cmp_team_ids(team_id_a, team_id_b) -> bool:
	var team_id_a_int: = int(team_id_a)
	var team_id_b_int: = int(team_id_b)
	var host_team: int = int(team_assignments.get(Moonlight.party.leader_user_id, - 1))
	if team_id_a_int == host_team or team_id_b_int == host_team:
		return team_id_a_int == host_team
	if team_id_a_int == 0 or team_id_b_int == 0:
		return team_id_b_int == 0
	return team_id_a_int <= team_id_b_int
