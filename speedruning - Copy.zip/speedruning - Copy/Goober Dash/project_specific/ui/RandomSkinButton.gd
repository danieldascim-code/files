extends Node

onready var parent_button: = get_parent() as BaseButton

export  var _goober: NodePath
onready var goober: = get_node(_goober) as Goober

func _ready() -> void :
	parent_button.connect("pressed", self, "on_button_pressed")

func on_button_pressed():
	goober.apply_random_skin(randi())
	_submit_skin_to_nakama()

func _submit_skin_to_nakama():
	var payload: = to_json(goober.goober_skin_data)
	var result: = yield(Moonlight.client.rpc_async(Moonlight.session, "upguys_set_skin", payload), "completed") as NakamaAPI.ApiRpc
	print(result)
	if result and not result.is_exception():
		
		
		
		
		
		
		
		pass
	else:
		printerr("failed")

