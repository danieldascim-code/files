extends Node
class_name CheckLevelAcker


func _ready():
	var level = Moonlight.storage.storage_get("player.profile.level", 1)
	var levelAck = Moonlight.storage.storage_get("player.profile.level_ack", 1)
	if levelAck < level:
		call_deferred("_on_level_changed");
	
	
	Moonlight.storage.observe("player.profile.level", self, "_on_react_level_changed")
	
func _on_react_level_changed(diff: Moonlight_StorageDiff):
	_on_level_changed()
	
func _on_level_changed():
	var dialog: = GoodResourceLoader.load_resource("res://project_specific/ui/LevelUpDialog.tscn").instance() as UILevelUpDialog
	get_tree().current_scene.add_child(dialog)
	dialog.show()
	
