extends Control
class_name PlayerHeader

export  var _play_button: NodePath
onready var play_button: PlayButton = get_node(_play_button)

export  var _exploding_start_point: NodePath
onready var exploding_start_point: = get_node(_exploding_start_point) as Control

export  var _tween: NodePath
onready var tween: Tween = get_node(_tween)

export  var _xp_progress_label: NodePath
onready var xp_progress_label: = get_node(_xp_progress_label) as Label

export  var _xp_progress_denominator_label: NodePath
onready var xp_progress_denominator_label: Label = get_node(_xp_progress_denominator_label)

export  var _xp_progress_tweenable_label: NodePath
onready var xp_progress_tweenable_label: TweenableLabel = get_node(_xp_progress_tweenable_label) as TweenableLabel

export  var _xp_destination: NodePath
onready var xp_destination: = get_node(_xp_destination) as Control

export  var _xp_progress: NodePath
onready var xp_progress: NinePatchRect = get_node(_xp_progress)

export  var _level_label: NodePath
onready var level_label: = get_node(_level_label) as Label

export  var _gems_destination: NodePath
onready var gems_destination: Control = get_node(_gems_destination)

export  var _gems_tweenable_label: NodePath
onready var gems_tweenable_label: TweenableLabel = get_node(_gems_tweenable_label)

export  var _gems_icon_animation: NodePath
onready var gems_icon_animation: ExplodingIconAnimation = get_node(_gems_icon_animation)

export  var _coins_destination: NodePath
onready var coins_destination: Control = get_node(_coins_destination)

export  var _coins_tweenable_label: NodePath
onready var coins_tweenable_label: TweenableLabel = get_node(_coins_tweenable_label)

export  var _coins_icon_animation: NodePath
onready var coins_icon_animation: ExplodingIconAnimation = get_node(_coins_icon_animation)

export  var _xp_icon_animation: NodePath
onready var xp_icon_animation: ExplodingIconAnimation = get_node(_xp_icon_animation)

export  var _show_my_player_profile_button: NodePath
onready var show_my_player_profile_button: BaseButton = get_node(_show_my_player_profile_button)


export  var player_profile_dialog_path: String

onready var enable_tests: = OS.has_feature("editor") and false

var dirty: = false

var disabled: = false setget set_disabled

var test_data: = {
	"wallet.gems": 0, 
	"wallet.coins": 20, 
	"player.profile.total_xp": 0, 
	"player.profile.stars": 8, 
	"player.profile.prize_rounds": 0, 
}
var test_last_seen_data: = {
	"wallet.gems": 0, 
	"wallet.coins": 0, 
	"player.profile.total_xp": 0, 
	"player.profile.stars": 0, 
	"player.profile.prize_rounds": 0, 
}

const scratchpad_keys: = [
	"last_seen.wallet.gems", 
	"last_seen.wallet.coins", 
	"last_seen.player.profile.total_xp", 
	"last_seen.player.profile.stars", 
	"last_seen.player.profile.prize_rounds", 
]

func _ready() -> void :
	Moonlight.storage.observe("player.profile.level", self, "on_data_changed")
	Moonlight.storage.observe("player.profile.xp", self, "on_data_changed")
	Moonlight.storage.observe("wallet.gems", self, "on_data_changed")
	Moonlight.storage.observe("wallet.coins", self, "on_data_changed")
	Moonlight.storage.observe("player.profile.prize_rounds", self, "on_data_changed")

	Moonlight.connect("on_log_out", self, "on_log_out")
	xp_progress_tweenable_label.connect("int_changed", self, "on_xp_changed")
	dirty = true
	show_my_player_profile_button.connect("pressed", self, "on_show_my_player_profile_button_pressed")
	call_deferred("_initial_show")
	
	get_tree().current_scene.connect("child_entered_tree", self, "on_child_entered_tree")
	get_tree().current_scene.connect("child_exiting_tree", self, "on_child_exited_tree")

func on_child_entered_tree(c: Node):
	if c is FreeSpinDialog:
		disabled = true

func on_child_exited_tree(c: Node):
	if c is FreeSpinDialog:
		set_disabled(false)
	
func set_disabled(b: bool):
	disabled = b
	if not disabled:
		if dirty:
			call_deferred("_refresh")

func on_data_changed(d: Moonlight_StorageDiff):
	if not dirty:
		dirty = true
		call_deferred("_refresh")

func _initial_show():
	_refresh(0.5)

func on_xp_changed():
	var total_xp: = xp_progress_tweenable_label.last_int
	var level: = CosmeticsCollection.level_for_total_xp(total_xp)
	var actual_level: int = Moonlight.storage.storage_get("player.profile.level", 1)
	
	level = min(level, actual_level)
	var xp_for_next_level: = CosmeticsCollection.compute_xp_total_cost(level + 1)
	var xp_for_current_level: = CosmeticsCollection.compute_xp_total_cost(level)
	var xp_into_current_level: = total_xp - xp_for_current_level
	
	var xp_delta_for_next_level: = xp_for_next_level - xp_for_current_level
	xp_into_current_level = min(xp_into_current_level, xp_delta_for_next_level)
	var fraction_into_current_level = float(xp_into_current_level) / xp_delta_for_next_level
	
	
	xp_progress.rect_size.x = range_lerp(fraction_into_current_level, 0.0, 1.0, 64.0, 280.0)
	xp_progress_denominator_label.text = str(xp_into_current_level) + "/" + str(xp_delta_for_next_level)
	level_label.text = str(level)

func _refresh(delay: float = 0.0):
	if disabled:
		return
	
	
	delay += _render_animated_value("wallet.gems", delay, gems_tweenable_label, gems_icon_animation, gems_destination)
	
	
	delay += _render_animated_value("wallet.coins", delay, coins_tweenable_label, coins_icon_animation, coins_destination)
	
	
	var level: int = Moonlight.storage.storage_get("player.profile.level", 0)
	var xp: int = Moonlight.storage.storage_get("player.profile.xp", 0)
	var total_xp: int = CosmeticsCollection.compute_xp_total_cost(level) + xp
	delay += _render_animated_value2("player.profile.total_xp", total_xp, delay, xp_progress_tweenable_label, xp_icon_animation, xp_destination)
	on_xp_changed()
	
	
	delay += animate_stars(delay)
	
	tween.start()
	dirty = false

func _render_animated_value(key: String, delay: float, tweenable_label: TweenableLabel, exploding_icon_animation: ExplodingIconAnimation, destination: Control) -> float:
	var value: int = Moonlight.storage.storage_get(key, 0)
	return _render_animated_value2(key, value, delay, tweenable_label, exploding_icon_animation, destination)

func _render_animated_value2(key: String, value: int, delay: float, tweenable_label: TweenableLabel, exploding_icon_animation: ExplodingIconAnimation, destination: Control) -> float:
	var last_seen_key: String = "last_seen." + key
	var has_last_seen_value: bool = SavedSettings.scratchpad.has(last_seen_key)
	var last_seen_value: int = SavedSettings.scratchpad.get(last_seen_key, 0)
	SavedSettings.scratchpad[last_seen_key] = value
	
	if enable_tests:
		value = test_data.get(key, value)
		has_last_seen_value = test_last_seen_data.has(key)
		last_seen_value = test_last_seen_data.get(key, last_seen_value)
	
	if has_last_seen_value:
		tweenable_label.set_int(last_seen_value, false)
		if value != last_seen_value:
			if value > last_seen_value:
				
				var start_point: Vector2 = Vector2.ZERO
				if exploding_start_point:
					start_point = center(exploding_start_point)
				return show_animation(last_seen_value, value, tweenable_label, exploding_icon_animation, start_point, destination, get_tree().current_scene, delay, true)
			else:
				
				var label_animation_duration: = 0.5
				tweenable_label.tween_int(tween, value, label_animation_duration, delay)
				return delay + label_animation_duration
	
	
	tweenable_label.set_int(value, false)
	return 0.0

func show_animation(start: int, end: int, tweenable_label: TweenableLabel, exploding_icon_animation: ExplodingIconAnimation, starting_point: Vector2, ending_point: Control, parent_node: Node, initial_delay: float, play_start_sound: bool) -> float:
	var num_to_animate: = min(100, abs(end - start))
	var explosion_delay: = ExplodingIconAnimation.animation_duration_for_icon(0)
	var explosion_end_delay: = ExplodingIconAnimation.animation_duration_for_icon(num_to_animate - 1)
	var label_animation_duration: = explosion_end_delay - explosion_delay
	var label_start_delay: = 0.0
	if end > start:
		label_start_delay = explosion_delay
		exploding_icon_animation.spawn_exploding_icon(num_to_animate, starting_point, ending_point, parent_node, initial_delay, play_start_sound)

	if tweenable_label:
		tweenable_label.tween_int(tween, end, label_animation_duration, initial_delay + label_start_delay)
	
	return explosion_end_delay

static func center(c: Control) -> Vector2:
	return c.rect_global_position + c.rect_size * 0.5

func animate_stars(delay: float) -> float:
	
	var stars_last_seen_key: = "last_seen.player.profile.stars"
	var stars_storage_key: = "player.profile.stars"
	var stars: int = Moonlight.storage.storage_get(stars_storage_key, 0)
	var last_seen_stars: int = SavedSettings.scratchpad.get(stars_last_seen_key, stars)
	SavedSettings.scratchpad[stars_last_seen_key] = stars
	
	if enable_tests:
		last_seen_stars = test_last_seen_data.get(stars_storage_key, 0)
		stars = test_data.get(stars_storage_key, 0)
	
	var prize_rounds_last_seen_key: = "last_seen.player.profile.prize_rounds"
	var prize_rounds_storage_key: = "player.profile.prize_rounds"
	var prize_rounds: int = Moonlight.storage.storage_get(prize_rounds_storage_key, 0)
	var last_seen_prize_rounds: int = SavedSettings.scratchpad.get(prize_rounds_last_seen_key, prize_rounds)
	SavedSettings.scratchpad[prize_rounds_last_seen_key] = prize_rounds
	
	if enable_tests:
		last_seen_prize_rounds = test_last_seen_data.get(prize_rounds_storage_key, 0)
		prize_rounds = test_data.get(prize_rounds_storage_key, 0)
		
	return play_button.star_pack_indicator.animate_stars(tween, last_seen_stars, stars, last_seen_prize_rounds, prize_rounds, delay)

func on_log_out():
	for s in scratchpad_keys:
		SavedSettings.scratchpad.erase(s)

func on_show_my_player_profile_button_pressed():
	var user_id: String = Moonlight.local_account.user.id
	var player_profile_dialog_scene = load(player_profile_dialog_path) as PackedScene
	var player_profile_dialog: = player_profile_dialog_scene.instance() as UIPlayerProfileDialog
	get_tree().current_scene.add_child(player_profile_dialog)
	player_profile_dialog.show_player_profile_dialog(user_id)
