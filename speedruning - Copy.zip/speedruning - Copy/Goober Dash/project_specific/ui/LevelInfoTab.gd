extends Control
class_name LevelInfoTab

export  var _level_info_tab_title: NodePath
onready var level_info_tab_title: SDFLabel = get_node(_level_info_tab_title)

export  var _level_info_tab_author: NodePath
onready var level_info_tab_author: SDFLabel = get_node(_level_info_tab_author)

onready var default_size: = rect_size
onready var shrink_size: = Vector2(0.0, rect_size.y)

var tween: SceneTreeTween
var is_showing: bool = false
var show_timer: = 0.0
const show_duration: = 6.0
const animation_time: = 0.5

func _ready() -> void :
	visible = false

func pop_in_level_info(title: String, author_name: String):
	level_info_tab_title.text = title
	level_info_tab_author.text = author_name
	pop_in()
	show_timer = 0.0

func toggle_pop():
	if is_showing:
		pop_out()
	else:
		pop_in()

func pop_out():
	if not is_showing:
		return
	is_showing = false
	if tween != null and tween.is_valid():
		tween.kill()
	tween = create_tween()
	tween.tween_property(self, "rect_size", shrink_size, animation_time).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_EXPO)
	tween.tween_callback(self, "hide")

func pop_in():
	if is_showing:
		return
	is_showing = true
	if tween != null and tween.is_valid():
		tween.kill()
	visible = true
	rect_size = shrink_size
	tween = create_tween()
	tween.tween_property(self, "rect_size", default_size, animation_time).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_EXPO)

func _process(delta: float) -> void :
	if is_showing:
		show_timer += delta
		if show_timer >= show_duration:
			pop_out()
