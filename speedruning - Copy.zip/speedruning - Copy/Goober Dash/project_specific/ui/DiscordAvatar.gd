extends TextureRect
class_name DiscordAvatar

var showing_uri: = ""

func _ready():
	Moonlight.discord_api.avatar_cache.connect("avatar_ready", self, "on_avatar_ready")
	Moonlight.discord_api.avatar_cache.connect("avatar_failed", self, "on_avatar_failed")

func set_discord_avatar_uri(avatar_uri: String):
	if not Moonlight.discord_api.is_in_discord():
		texture = null
		return
	showing_uri = avatar_uri
	if avatar_uri.empty():
		texture = null
	else:
		Moonlight.discord_api.avatar_cache.retrieve_avatar(avatar_uri)
	
func on_avatar_ready(uri: String, tex: Texture):
	if showing_uri == uri:
		texture = tex

func on_avatar_failed(uri: String):
	if showing_uri == uri:
		texture = null
