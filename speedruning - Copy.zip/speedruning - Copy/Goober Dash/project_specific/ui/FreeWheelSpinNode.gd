extends Control

onready var rear_wheel: Control = $RearWheel
onready var front_wheel: Control = $FrontWheel
onready var free_spin_label: Label = $FreeSpin
onready var next_spin_label: Label = $NextSpin
onready var next_spin_timer_label: Label = $NextSpinTimer
onready var button: BaseButton = $Button
var countdown_timer: = 0.0

export  var free_spin_results_dialog_path: String

func _ready() -> void :
	Moonlight.storage.observe("player.profile.last_free_spin_time", self, "on_last_free_wheel_time_changed")
	_refresh()
	button.connect("pressed", self, "on_button_pressed")

func on_last_free_wheel_time_changed(diff: Moonlight_StorageDiff):
	_refresh()

func _refresh():
	var last_free_time: int = Moonlight.storage.storage_get("player.profile.last_free_spin_time", 0)
	var free_wheel_timer: int = Moonlight.storage.storage_get("metadata.progression.free_wheel_timer", 0)
	var now: = OS.get_unix_time()
	countdown_timer = last_free_time + free_wheel_timer - now
	_process(0.0)

func _process(delta: float) -> void :
	if countdown_timer > 0.0:
		countdown_timer -= delta
	
	var wheel_available: = countdown_timer <= 0.0
	front_wheel.visible = wheel_available
	free_spin_label.visible = wheel_available
	rear_wheel.visible = not wheel_available
	next_spin_label.visible = not wheel_available
	next_spin_timer_label.visible = not wheel_available
	button.disabled = not wheel_available
	if not wheel_available:
		next_spin_timer_label.text = DateTimeUtils.format_time_shorter(int(ceil(countdown_timer)))


func on_button_pressed():
	var free_spin_dialog: FreeSpinDialog = load(free_spin_results_dialog_path).instance()
	get_tree().current_scene.add_child(free_spin_dialog)
