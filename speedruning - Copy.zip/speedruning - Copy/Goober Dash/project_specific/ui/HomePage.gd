extends Control
class_name HomePage

export  var _matchmaker_node: NodePath
onready var matchmaker_node: GameMatchmaker = get_node(_matchmaker_node) as GameMatchmaker

export  var _play_button: NodePath
onready var play_button: PlayButton = get_node(_play_button)

func _ready() -> void :
	play_button.connect("play_button_pressed", self, "on_play_button_pressed")

func on_play_button_pressed():
	yield(AdManager.show_interstitial_ad(), "completed")
	connect_to_matchmaker()

func connect_to_matchmaker():
	var available_prize_rounds: int = Moonlight.storage.storage_get("player.profile.prize_rounds", 0)
	if available_prize_rounds > 0:
		matchmaker_node.connect_to_matchmaker(WPGame.MatchTypePrize)
	else:
		matchmaker_node.connect_to_matchmaker(WPGame.MatchTypeRegular)
