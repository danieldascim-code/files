extends Control
class_name CircularGodRays





export  var alpha: = 1.0


func _ready():
	pass



func _process(delta):
	var child_count: = self.get_child_count()
	for i in child_count:
		var c: = get_child(i) as Control
		if (c):
			var b: = c.get_child(0) as Control
			if (b):
				b.modulate = Color(1, 1, 1, alpha)

