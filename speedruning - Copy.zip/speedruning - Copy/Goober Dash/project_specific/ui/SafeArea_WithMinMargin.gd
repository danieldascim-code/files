extends Control

onready var safe_area: Rect2 = get_safe_area()
export  var horizontally_centered: = true

func _ready():
	if is_inside_tree():
		get_tree().root.connect("size_changed", self, "_on_viewport_size_changed")
	_update_safe_area_size()

func _parse_px(s: String) -> float:
	return float(s.trim_suffix("px"))

func get_safe_area() -> Rect2:
	if OS.has_feature("web"):
		
		var top: String = JavaScript.eval("getComputedStyle(document.documentElement).getPropertyValue(\"--sait\")")
		var bottom: String = JavaScript.eval("getComputedStyle(document.documentElement).getPropertyValue(\"--saib\")")
		var left: String = JavaScript.eval("getComputedStyle(document.documentElement).getPropertyValue(\"--sail\")")
		var right: String = JavaScript.eval("getComputedStyle(document.documentElement).getPropertyValue(\"--sair\")")
		
		var top_f: = _parse_px(top)
		var bottom_f: = _parse_px(bottom)
		var left_f: = _parse_px(left)
		var right_f: = _parse_px(right)
		
		return OS.get_window_safe_area().grow_individual( - left_f, - top_f, - right_f, - bottom_f)

	if OS.has_feature("web") and AdManager.is_web_mobile():
		
		var _safe_area: = OS.get_window_safe_area()
		var web_safe_horizontal: = 50.0
		var web_safe_top: = 50.0
		_safe_area = _safe_area.grow_individual( - web_safe_horizontal, - web_safe_top, - web_safe_horizontal, 0.0)
		return _safe_area
	return OS.get_window_safe_area()

func _process(_delta: float) -> void :
	var new_safe_area: = get_safe_area()
	if safe_area != new_safe_area:
		safe_area = new_safe_area
		_update_safe_area_size()

func _on_viewport_size_changed():
	safe_area = get_safe_area()
	_update_safe_area_size()

func _update_safe_area_size():
	var window_margin_top_left: = safe_area.position
	var window_margin_bottom_right: = safe_area.end - OS.window_size
	
	
	var window_to_viewport: = get_viewport().get_final_transform().affine_inverse()
	var margin_top_left = window_to_viewport.xform(window_margin_top_left)
	var margin_bottom_right = window_to_viewport.xform(window_margin_bottom_right)
	margin_left = margin_top_left.x
	margin_top = margin_top_left.y
	margin_right = margin_bottom_right.x
	var enable_banner_height: = true
	if enable_banner_height:
		var banner_height: = get_viewport_rect().size.y * 0.115
		margin_bottom = min(margin_bottom_right.y, - banner_height)
	else:
		margin_bottom = margin_bottom_right.y
	
	if horizontally_centered:
		var largest_horizontal_margin: = max(margin_top_left.x, - margin_bottom_right.x)
		margin_left = largest_horizontal_margin
		margin_right = - largest_horizontal_margin
	
	












