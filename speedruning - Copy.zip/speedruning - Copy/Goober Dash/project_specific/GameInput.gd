extends Control
class_name GameInput

signal input_mode_changed(input_mode)

export  var _game: NodePath
onready var game: = get_node(_game) as WPGame

export  var _emote_picker_touchscreen: NodePath
onready var emote_picker_touchscreen: = get_node(_emote_picker_touchscreen) as Control

export  var _emote_picker_keyboard: NodePath
onready var emote_picker_keyboard: = get_node(_emote_picker_keyboard) as EmotePickerButton

onready var emote_pickers: = [emote_picker_keyboard, emote_picker_touchscreen]

export  var _touch_screen_controls: NodePath
onready var touch_screen_controls: = get_node(_touch_screen_controls) as Control

export  var _touch_screen_dash_button: NodePath
onready var touch_screen_dash_button: BaseButton = get_node(_touch_screen_dash_button)

export  var _touch_screen_jump_button: NodePath
onready var touch_screen_jump_button: BaseButton = get_node(_touch_screen_jump_button)

export  var _touch_screen_move_buttons_container: NodePath
onready var touch_screen_move_buttons_container: Control = get_node(_touch_screen_move_buttons_container)

export  var _touch_screen_dash_progress: NodePath
onready var touch_screen_dash_progress: TextureProgress = get_node(_touch_screen_dash_progress)

export  var _touch_screen_dash_and_jump: NodePath
onready var touch_screen_dash_and_jump: Control = get_node(_touch_screen_dash_and_jump)

export  var _touch_screen_jump_container: NodePath
onready var touch_screen_jump_container: Control = get_node(_touch_screen_jump_container)

export  var _touch_screen_cheer_button_container: NodePath
onready var touch_screen_cheer_button_container: Control = get_node(_touch_screen_cheer_button_container)

export  var _touch_screen_cheer_button: NodePath
onready var touch_screen_cheer_button: BaseButton = get_node(_touch_screen_cheer_button)

onready var touch_screen_visible_when_alive: = [touch_screen_jump_container, touch_screen_dash_button, touch_screen_move_buttons_container]

var is_right_click: = false
var is_left_click: = false

enum InputMode{
	VOID, 
	KBM, 
	TOUCHSCREEN, 
	JOYPAD, 
}
var input_mode: int = InputMode.VOID setget set_input_mode
var is_touchscreen: = false
var auto_spectate_timer: = 0.0
const joystick_deadzone: = 0.1
const auto_spectate_duration: = 1.5

var cheers_sent: = false

export  var _cheer_button: NodePath
onready var cheer_button: GoodButton = get_node(_cheer_button)

onready var cheer_buttons: = [touch_screen_cheer_button, cheer_button]
onready var emote_array: Array = Moonlight.storage.storage_get("player.profile.emotes", [])

func on_cheer_button_pressed():
	game.client_send_message_to_server({"cheers": ""})
	cheers_sent = true

func _ready():
	
	grab_focus()
	SavedSettings.connect("on_value_changed", self, "_on_saved_settings_value_changed")
	_on_saved_settings_value_changed("touchscreen_mode", SavedSettings.get_value("touchscreen_mode", false))
	game.connect("level_loaded", self, "on_level_loaded")
	for c in cheer_buttons:
		c.connect("pressed", self, "on_cheer_button_pressed")
	GlobalEvent.connect("UI_EMOTE_BUTTON_PRESSED", self, "_on_emote_selected")

func on_level_loaded():
	cheers_sent = false

func _on_emote_selected(emote_name: String):
	game.client_send_message_to_server({"emote": emote_name})

func _on_saved_settings_value_changed(k: String, v):
	if k == "touchscreen_mode":
		var enabled: = v as bool
		is_touchscreen = enabled or OS.has_feature("mobile")
		touch_screen_controls.visible = is_touchscreen
		if is_touchscreen:
			input_mode = InputMode.TOUCHSCREEN
		else:
			input_mode = InputMode.KBM

func set_input_mode(i: int):
	if input_mode != i:
		input_mode = i
		emit_signal("input_mode_changed", input_mode)
	
func is_joystick_input() -> bool:
	return get_joystick_input().length() > 0.0

func get_joystick_input() -> Vector2:
	if JoypadInputBlocker.should_block_input():
		return Vector2(0, 0)
	var y: = Input.get_action_strength("player_joystick_move_down") - Input.get_action_strength("player_joystick_move_up")
	var x: = Input.get_action_strength("player_joystick_move_right") - Input.get_action_strength("player_joystick_move_left")
	var input: = Vector2(x, y)
	if input.length() < joystick_deadzone:
		input = Vector2.ZERO
	return input.limit_length(1.0)



func _gui_input(event):
	var touch_event: = event as InputEventScreenTouch
	var mouse_button_event: = event as InputEventMouseButton
	var mouse_motion_event: = event as InputEventMouseMotion
	
	if mouse_button_event:
		if mouse_button_event.pressed and mouse_button_event.button_index == BUTTON_RIGHT:
			is_right_click = true
		if mouse_button_event.pressed and mouse_button_event.button_index == BUTTON_LEFT:
			is_left_click = true
			if not is_touchscreen:
				
				set_input_mode(InputMode.KBM)
	elif touch_event:
		
		if touch_event.pressed and is_touchscreen:
			set_input_mode(InputMode.TOUCHSCREEN)
		

func _input(event):
	
	var drag_event: = event as InputEventScreenDrag
	var touch_event: = event as InputEventScreenTouch
	var mouse_motion: = event as InputEventMouseMotion
	var mouse_button: = event as InputEventMouseButton
	var joypad_button: = event as InputEventJoypadButton
	var joypad_motion: = event as InputEventJoypadMotion
	
	if mouse_button:
		
		if not mouse_button.pressed and mouse_button.button_index == BUTTON_LEFT:
			is_left_click = false
		if not mouse_button.pressed and mouse_button.button_index == BUTTON_RIGHT:
			is_right_click = false
		
	if mouse_motion:
		
		if input_mode == InputMode.KBM:
			var mouse_position_from_center: = (get_tree().root.get_mouse_position() - (get_viewport_rect().size * 0.5)).normalized()
			
	
	if mouse_motion and not is_touchscreen:
		self.input_mode = InputMode.KBM
	
	if joypad_button or joypad_motion:
		if is_joystick_input():
			self.input_mode = InputMode.JOYPAD
	
	
	
	match input_mode:
		InputMode.TOUCHSCREEN:
			_process_input(event)
	
	if event.is_action_pressed("emote_1"):
		send_emote_at_index(0)
	elif event.is_action_pressed("emote_2"):
		send_emote_at_index(1)
	elif event.is_action_pressed("emote_3"):
		send_emote_at_index(2)
	elif event.is_action_pressed("emote_4"):
		send_emote_at_index(3)

func send_emote_at_index(emote_index: int):
	if emote_index >= 0 and emote_index < emote_array.size():
		var emote_id: String = emote_array[emote_index]
		if not emote_id.empty():
			game.client_send_message_to_server({"emote": emote_id})

func _process(delta: float):
	var disable_emote_picker: = game.wp_game_data.is_time_trial or game.wp_game_data.is_tutorial or game.wp_game_data.is_replay
	
	var local_player: = game.get_local_player() as WPPlayer
	if local_player == null:
		return
	
	var is_spectating: = not game.is_game_over() and local_player.spectator_object_id != 0
	var is_spectating_self: = is_spectating and local_player.spectator_object_id == local_player.object_id
	var is_spectating_not_self: = is_spectating and local_player.spectator_object_id != local_player.object_id
	var is_playing: = not game.is_game_over() and local_player.spectator_object_id == 0
	
	if disable_emote_picker:
		emote_picker_touchscreen.visible = false
		emote_picker_keyboard.visible = false
	else:
		emote_picker_touchscreen.visible = is_playing or is_spectating_self
		emote_picker_keyboard.visible = input_mode != InputMode.TOUCHSCREEN and (is_playing or is_spectating_self)
	
	for c in cheer_buttons:
		c.disabled = not (is_spectating and not cheers_sent)
	cheer_button.visible = input_mode != InputMode.TOUCHSCREEN and is_spectating_not_self
	touch_screen_cheer_button_container.visible = is_spectating_not_self
	
	if touch_screen_controls.visible:
		var should_show_controls: = not game.wp_game_data.is_replay and local_player and not local_player.eliminated and not game.is_game_over() and local_player.rank == 0
		for node in touch_screen_visible_when_alive:
			node.visible = should_show_controls
		touch_screen_dash_progress.value = 1.0 - float(local_player.dash_cooldown) / game.wp_game_data.player_dash_cooldown_ticks

func _unhandled_input(event: InputEvent):
	
	
	
	match input_mode:
		InputMode.JOYPAD, InputMode.KBM:
			_process_input(event)

func _process_input(event: InputEvent):
	var local_player: = game.get_local_player() as WPPlayer
	if not local_player:
		return
	
	var move: = sign(Input.get_action_strength("player_right") - Input.get_action_strength("player_left"))
	var joystick_move: = get_joystick_input()
	if abs(joystick_move.x) > joystick_deadzone:
		move = joystick_move.x
	var jump = Input.is_action_pressed("player_up")
	
	_player_move(move)
	_player_set_jumping(jump)
	
	
	var is_dash = Input.is_action_just_pressed("player_dash")
	if is_dash:
		var dash_dir: = true
		if move != 0:
			dash_dir = move > 0
		elif not local_player.facing_dir:
			dash_dir = local_player.facing_dir
		_player_dash(dash_dir)

func _player_dash(dash: bool):
	game.local_input_dash(dash)

func _player_move(dir: float):
	game.set_local_continuous_input(WPGameData.ContinuousInputKeys_MOVEMENT, dir)

func _player_set_jumping(jumping: bool):
	game.set_local_continuous_input(WPGameData.ContinuousInputKeys_JUMP, jumping)
