extends Node
class_name Level_InterpolateRenderers

export  var _level: NodePath
onready var level: = get_node(_level) as Level

export  var _game: NodePath
onready var game: = get_node(_game) as WPGame

const time_property_key: = "play_time"

func _process(delta):
	if game and game.client_renderer:
		var interpolated_time: float = game.client_renderer.get_interpolated_property(game.wp_game_data.object_id, time_property_key)
		level.interpolate_renderers(interpolated_time)
