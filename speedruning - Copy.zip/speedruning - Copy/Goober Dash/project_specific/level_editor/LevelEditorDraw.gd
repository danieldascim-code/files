extends Node2D
class_name LevelEditorDraw
onready var level_editor: = get_parent() as LevelEditor

func _process(delta):
	update()

func _draw():
	pass
