extends CanvasLayer
class_name LevelEditor_ThemesDialog

onready var dialog: UIDialog = $UIDialog

const level_themes_directory: = "res://project_specific/level_themes"
export  var _themes_parent: NodePath
onready var themes_parent: Control = get_node(_themes_parent)

export  var theme_button_scene: PackedScene

var themes: = []
var buttons: = []

signal select_theme(t)

func _ready():
	themes = parse_themes()
	_clear_buttons()
	var is_first: = true
	for t in themes:
		var _theme: = t as BaseTheme
		var b: = _create_button(_theme)
		if is_first:
			is_first = false
			b.focusable.grab_focus_on_visible = true

func _create_button(t: BaseTheme) -> GoodButton:
	var new_button: GoodButton = theme_button_scene.instance()
	themes_parent.add_child(new_button)
	new_button.label_text = t.resource_name.to_upper()
	var texture_rect: TextureRect = new_button.get_node("ThemeTexture")
	texture_rect.texture = t.terrain_texture
	new_button.connect("pressed", self, "on_theme_button_pressed", [t])
	return new_button

func on_theme_button_pressed(t: BaseTheme):
	emit_signal("select_theme", t)
	dialog.animate_out()

func _clear_buttons():
	for b in buttons:
		b.queue_free()
	buttons.clear()

func parse_themes() -> Array:
	var a: = []
	
	var directory: = Directory.new()
	var err: = directory.open(level_themes_directory)
	if err != OK:
		printerr("[LevelThemeList] _parse_scene_cache(%s) open error: %d" % [level_themes_directory, err])
		return a
	err = directory.list_dir_begin(true, true)
	if err != OK:
		printerr("[LevelThemeList] _parse_scene_cache(%s) list_dir_begin error: %d" % [level_themes_directory, err])
		return a
	
	var file_name: = directory.get_next()
	while file_name != "":
		if directory.current_is_dir():
			var theme_name: = file_name
			var directory_path: = level_themes_directory.plus_file(file_name)
			var theme_path: = directory_path.plus_file("theme.tres")
			var loaded_theme: = ResourceLoader.load(theme_path, "Resource") as BaseTheme
			if loaded_theme:
				loaded_theme.resource_name = theme_name
				a.append(loaded_theme)
			else:
				printerr("[LevelThemeList] _parse_scene_cache() error loading %s" % [theme_path])

		file_name = directory.get_next()
	directory.list_dir_end()
	
	
	
	return a
