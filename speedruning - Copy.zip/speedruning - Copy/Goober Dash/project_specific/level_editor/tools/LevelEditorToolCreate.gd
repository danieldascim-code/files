extends LevelEditorTool
class_name LevelEditorToolCreate

export  var _node_type_button_parent: NodePath
onready var node_type_button_parent: = get_node(_node_type_button_parent) as Control

export  var node_type_button_scene: PackedScene

var active_node: LevelNode
var active_node_type: = ""
onready var node_type_button_group: = ButtonGroup.new()
var node_type_buttons: = []

var winterpixel_only_nodes: = []

func _ready():
	call_deferred("_load_buttons")
	call_deferred("_connect_theme_changed")
	call_deferred("_connect_ui_root_event")

func _connect_ui_root_event():
	level_editor.ui_root.connect("gui_input", self, "on_ui_root_gui_input_all")

func _connect_theme_changed():
	level_editor.level.connect("theme_changed", self, "on_theme_changed")

func on_theme_changed(level_theme: BaseTheme):
	if active_node:
		active_node.apply_theme(level_theme)

func _load_buttons():
	
	var num_node_types: = level_editor.node_factory.node_types.size()
	print("[LevelEditorToolCreate] num node types %d" % [num_node_types])
	for i in num_node_types:
		var node_type: String = level_editor.node_factory.node_types[i]
		if node_type in winterpixel_only_nodes:
			if not (WinterpixelUser.is_winterpixel_user() or OS.has_feature("editor")):
				continue
		var node_type_button: GoodButton = node_type_button_scene.instance()
		node_type_button.toggle_mode = true
		node_type_button.group = node_type_button_group
		node_type_button.visible = true
		node_type_button.hint_tooltip = node_type.to_upper().replace("_", " ")
		node_type_button_parent.add_child(node_type_button)
		var texture_rect: TextureRect = node_type_button.get_node("TextureRect")
		texture_rect.texture = level_editor.node_factory.icon_cache.get(node_type)
		node_type_button.connect("pressed", self, "on_node_type_button_pressed", [node_type])
		
		node_type_buttons.append(node_type_button)

func _stop_tool():
	if active_node != null:
		active_node.queue_free()
		active_node = null
	var pressed_button: = node_type_button_group.get_pressed_button()
	if pressed_button != null:
		pressed_button.pressed = false

func _start_tool():
	pass

func on_node_type_button_pressed(node_type: String):
	active_node_type = node_type
	level_editor.select_tool(LevelEditor.Tool.Create)

func _create_active_node(node_type: String):
	if active_node != null:
		active_node.queue_free()
		active_node = null
	if not node_type.empty():
		active_node = level_editor.node_factory.create_node(node_type)
		if active_node != null:
			active_node.modulate = Color(1.0, 1.0, 1.0, 0.5)
			level_editor.level.add_child(active_node)
			active_node.apply_theme(level_editor.level.level_theme)
			if active_node.body and active_node.rigid_body:
				active_node.body.enabled = false

func _process_tool(delta: float) -> void :
	if active_node == null or active_node.node_type != active_node_type:
		_create_active_node(active_node_type)

	
	if active_node != null:
		active_node.set_world_bounding_box(mouse_down_position, mouse_position)
			
		active_node.visible = level_editor.is_mouse_present
		
		if not is_mouse_down and was_mouse_down:
			create_node(mouse_down_position, mouse_position, active_node.shape_rotation, active_node.node_type)

func _ui_root_gui_input(event: InputEvent) -> void :
	_detect_rotation_hotkey(event)

func on_ui_root_gui_input_all(event: InputEvent) -> void :
	_detect_create_node_hotkeys(event)

func _detect_rotation_hotkey(event: InputEvent) -> void :
	if event is InputEventKey:
		if event.pressed and not event.echo:
			if event.scancode == KEY_R:
				if active_node != null:
					active_node.shape_rotation = (active_node.shape_rotation + 1) %4

func _detect_create_node_hotkeys(event: InputEvent):
	if event is InputEventKey:
		if event.pressed:
			for i in 10:
				
				var key_code: = KEY_1 + int(i)
				if i == 9:
					key_code = KEY_0
				if event.scancode == key_code:
					if i >= 0 and i < node_type_buttons.size():
						var button: = node_type_buttons[i] as BaseButton
						if not button.pressed:
							button.pressed = true
							button.emit_signal("pressed")
					break

func _draw() -> void :
	if level_editor.is_mouse_present:
		if active_node != null:
			draw_grid_cells(active_node.world_rect, Color.aquamarine, false, true)
			pass
		else:
			draw_mouse_cell(mouse_down_position, mouse_position)

func create_node(block_start: Vector2, block_end: Vector2, block_rotation: int, node_type: String) -> void :
	var next_level_node_index: int = level_editor.level.next_level_node_index()
	level_editor.undo.create_action("Create Node")
	level_editor.undo.add_do_method(self, "_do_create_node", block_start, block_end, block_rotation, node_type, next_level_node_index)
	level_editor.undo.add_undo_method(self, "_undo_create_node", next_level_node_index)
	level_editor.undo.commit_action()

func _do_create_node(block_start: Vector2, block_end: Vector2, block_rotation: int, node_type: String, level_node_index: int) -> void :
	var block: = level_editor.node_factory.create_node(node_type)
	if block == null:
		printerr("[LevelEditor] create_node() couldnt create node type %s" % [node_type])
		return
	
	block.level_node_index = level_node_index
	block.set_world_bounding_box(block_start, block_end)
	block.shape_rotation = block_rotation
	level_editor.level.add_level_node(block)
	if block.node_type == LevelNodeFactory.physics_block_key:
		
		
		level_editor.level.sync_physics_blocks()

func _undo_create_node(level_node_index: int):
	var level_node: = level_editor.level.get_level_node(level_node_index)
	if not level_node:
		printerr("[LevelEditorToolCreate] _undo_create_node() cannot find level_node with id: %d" % [level_node_index])
		return
	level_editor.level.remove_level_node(level_node)
