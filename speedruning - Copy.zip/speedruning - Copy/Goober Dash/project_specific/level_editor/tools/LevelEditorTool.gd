extends LevelEditorToolInterface
class_name LevelEditorTool

export  var _level_editor: NodePath
onready var level_editor: = get_node(_level_editor) as LevelEditor

var is_mouse_down: = false
var was_mouse_down: = false
var mouse_position: = Vector2.ZERO
var mouse_down_position: = Vector2.ZERO
var was_visible: = false
const mouse_cell_color: = Color.wheat

func _ready():
	
	call_deferred("_connect_level_signals")

func _connect_level_signals():
	level_editor.level.connect("unloading_level", self, "on_unloading_level")
	level_editor.level.connect("removed_node", self, "on_removed_node")
	level_editor.ui_root.connect("gui_input", self, "on_ui_root_gui_input")

func _process(delta: float) -> void :
	var is_visible: = is_visible_in_tree()
	
	if is_visible:
		
		
		if level_editor.gesture_recognizer.touch_data.size() > 1:
			is_mouse_down = false
			was_mouse_down
		
		mouse_position = level_editor.level.get_local_mouse_position()
		
		
		if not is_mouse_down and not was_mouse_down:
			
			mouse_down_position = mouse_position
		
		if is_mouse_down and not was_mouse_down:
			
			mouse_down_position = mouse_position
		
		if is_visible and not was_visible:
			_start_tool()
		
		_process_tool(delta)
		
		update()
	else:
		if was_visible:
			is_mouse_down = false
			_stop_tool()
	
	was_mouse_down = is_mouse_down
	was_visible = is_visible

func on_ui_root_gui_input(event: InputEvent) -> void :
	if event is InputEventMouseButton:
		if event.button_index == BUTTON_LEFT:
			is_mouse_down = event.pressed
			_process(0.0)

func _input(event: InputEvent) -> void :
	if event is InputEventMouseButton:
		if event.button_index == BUTTON_LEFT:
			if not event.pressed:
				is_mouse_down = false
				_process(0.0)

func draw_mouse_cell(world_point_a: Vector2, world_point_b: Vector2) -> void :
	var grid_rect: = LevelGrid2.world_to_enclosing_grid_rect(world_point_a, world_point_b)
	var rect: = LevelGrid2.grid_rect_to_world_rect(grid_rect)
	draw_grid_cells(rect, mouse_cell_color, false, false)

func draw_grid_cells(rect: Rect2, c: Color, filled: bool, outside: bool):
	var fill_color: = Color(0.0, 0.0, 0.0, 0.25)
	var width: = _constant_size(10.0)
	var black_width: = _constant_size(6.0)
	var smaller_rect: = Rect2()
	if outside:
		
		smaller_rect = rect.grow(width * 0.5)
	else:
		
		smaller_rect = rect.grow(width * - 0.5)
	_apply_canvas_transform()
	if filled:
		draw_rect(rect, fill_color, true, 1.0, false)
	
	var black_rect: = smaller_rect.grow((width * - 0.5) + (black_width * - 0.5))
	
	if not outside:
		draw_rect(black_rect, Color(0.2, 0.2, 0.2), false, black_width, false)
	draw_rect(smaller_rect, c, false, width, false)

func draw_transformed_grid_cells(rect: Rect2, c: Color, filled: bool, outside: bool, transform: Transform2D):
	var fill_color: = Color(0.0, 0.0, 0.0, 0.25)
	var width: = _constant_size(10.0)
	var black_width: = _constant_size(6.0)
	var smaller_rect: = Rect2()
	if outside:
		
		smaller_rect = rect.grow(width * 0.5)
	else:
		
		smaller_rect = rect.grow(width * - 0.5)
	draw_set_transform_matrix(get_viewport().canvas_transform * transform)
	if filled:
		draw_rect(rect, fill_color, true, 1.0, false)
	
	var black_rect: = smaller_rect.grow((width * - 0.5) + (black_width * - 0.5))
	
	if not outside:
		draw_rect(black_rect, Color(0.2, 0.2, 0.2), false, black_width, false)
	draw_rect(smaller_rect, c, false, width, false)

func draw_bounding_box_edge(rect: Rect2, face: int, c: Color):
	var width: = _constant_size(10.0)
	
	rect = rect.grow(width * - 0.5)
	var first_point: = LevelGrid2.first_point_of_edge_of_rect(rect, face)
	var second_point: = LevelGrid2.second_point_of_edge_of_rect(rect, face)
	_apply_canvas_transform()
	draw_line(first_point, second_point, c, width, false)

func _constant_size(width: float) -> float:
	var canvas_scale: = get_viewport().canvas_transform.get_scale()
	return width / canvas_scale.x

func _apply_canvas_transform():
	
	
	
	draw_set_transform_matrix(get_viewport().canvas_transform)

func on_unloading_level():
	pass

func on_removed_node(l: LevelNode):
	pass
