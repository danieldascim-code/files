extends LevelEditorTool
class_name LevelEditorToolSelect

signal selected_nodes_changed(level_nodes)

var hovering_node: LevelNode
var hovering_node_edge_mask: = 0
var hovering_multiple_index: = 0
var boxed_nodes: = []
var selected_nodes: = []
var selected_nodes_move_root: = Vector2.ZERO
var selected_nodes_move_accumulator: = Vector2.ZERO
var selected_nodes_rect: = Rect2()
var clicked_node: LevelNode
var clicked_node_edge_mask: = 0
var clicked_node_edge_original_rect: = Rect2()
var copied_nodes: = []

export  var hovering_outline_color: = Color.yellow
export  var will_unselect_outline_color: = Color.red
export  var selected_outline_color: = Color.chartreuse
export  var interacting_outline_color: = Color.green
export  var interactable_outline_color: = Color.whitesmoke

export  var _inspector: NodePath
onready var inspector: = get_node(_inspector) as LevelEditor_Inspector

export  var _level_editor_camera: NodePath
onready var level_editor_camera: = get_node(_level_editor_camera) as LevelEditorCamera

export  var _right_click_popup_menu: NodePath
onready var right_click_popup_menu: = get_node(_right_click_popup_menu) as PopupMenu

var right_click_down_position: = Vector2.ZERO
var right_click_dragging: = false

enum RightClickMenu{
	Copy, 
	Paste, 
	Delete, 
	Undo, 
	Redo
}

enum ClickState{
	None, 
	ClickedNothing, 
	ClickedEdge, 
	ClickedNode
}
var click_state: int = 0

func _ready():
	inspector.connect("rotate_pressed", self, "on_rotate_button_pressed")
	inspector.connect("delete_pressed", self, "on_delete_button_pressed")
	inspector.connect("copy_pressed", self, "on_copy_button_pressed")
	inspector.connect("paste_pressed", self, "on_paste_button_pressed")
	right_click_popup_menu.connect("id_pressed", self, "on_right_click_menu_id_pressed")

func _exit_tree() -> void :
	delete_clipboard()

func on_rotate_button_pressed():
	for i in selected_nodes.size():
		var selected_node: = selected_nodes[i] as LevelNode
		selected_node.shape_rotation = (selected_node.shape_rotation + 1) %4
		

func on_delete_button_pressed():
	var node_ids_to_delete: = []
	for i in selected_nodes.size():
		var node_to_delete: LevelNode = selected_nodes[i]
		node_ids_to_delete.append(node_to_delete.level_node_index)
	
	var deleted_node_datas: = []
	for i in node_ids_to_delete.size():
		var deleting_node_id: int = node_ids_to_delete[i]
		var deleting_node: = level_editor.level.get_level_node(deleting_node_id)
		var deleted_node_data: = deleting_node.serialize_level_node()
		deleted_node_data["level_node_index"] = deleting_node.level_node_index
		deleted_node_datas.append(deleted_node_data)
	
	level_editor.undo.create_action("Delete Node")
	level_editor.undo.add_do_method(self, "do_delete", node_ids_to_delete)
	level_editor.undo.add_undo_method(self, "undo_delete", deleted_node_datas)
	level_editor.undo.commit_action()

func do_delete(node_ids_to_delete: Array):
	for i in node_ids_to_delete.size():
		var deleting_node_id: int = node_ids_to_delete[i]
		var deleting_node: = level_editor.level.get_level_node(deleting_node_id)
		level_editor.level.remove_level_node(deleting_node)

func undo_delete(deleted_data: Array):
	if deleted_data.empty():
		printerr("[LevelEditorToolSelect] undo_delete() no data to recreate deleted nodes")
		return
	
	for i in deleted_data.size():
		var serialized_deleted_node: Dictionary = deleted_data[i]
		var recreated_deleted_node: = LevelJson.deserialize_level_node(serialized_deleted_node, level_editor.node_factory)
		recreated_deleted_node.level_node_index = serialized_deleted_node["level_node_index"]
		level_editor.level.add_level_node(recreated_deleted_node)

func _paste_at_grid_location(target_grid_cell: Vector2, to_target_cell: bool):
	var paste_nodes: = _deep_copy_nodes(copied_nodes)
	if to_target_cell:
		
		var aabb: = Rect2(0, 0, 0, 0)
		for p in paste_nodes:
			var level_node: = p as LevelNode
			if aabb == Rect2(0, 0, 0, 0):
				aabb = level_node.grid_rect
			else:
				aabb = aabb.merge(level_node.grid_rect)
	
		
		var aabb_pos: = aabb.position
		var target_aabb_pos = target_grid_cell - Vector2(round(aabb.size.x / 2.0), round(aabb.size.y / 2.0))
		var offset = target_aabb_pos - aabb_pos
		for p in paste_nodes:
			var level_node: = p as LevelNode
			level_node.grid_rect.position += (offset)
			level_editor.level.add_level_node(p)
	else:
		var paste_distance: = 2
		for p in paste_nodes:
			var level_node: = p as LevelNode
			level_node.grid_rect.position += Vector2(paste_distance, - paste_distance)
			level_editor.level.add_level_node(p)
	set_selected_nodes(paste_nodes)

func on_paste_button_pressed():
	_paste_at_grid_location(Vector2(0, 0), false)

func on_copy_button_pressed():
	delete_clipboard()
	copied_nodes = _deep_copy_nodes(selected_nodes)

func _deep_copy_nodes(nodes: Array) -> Array:
	var c: = []
	for s in nodes:
		var node: = s as LevelNode
		var copied_node: = level_editor.node_factory.create_node(node.node_type)
		copied_node.grid_rect = node.grid_rect
		copied_node.shape_rotation = node.shape_rotation
		copied_node.fetch_sub_nodes()
		if node.animation:
			copied_node.create_animation_node()
			copied_node.animation.set_animation_data(node.animation.animation_data.deep_copy())
		copied_node.properties = node.properties.duplicate(true)
		copied_node.pivot = node.pivot
		copied_node.rot = node.rot
		
		c.append(copied_node)
	return c

func delete_clipboard():
	for c in copied_nodes:
		c.free()
	copied_nodes.clear()

func _stop_tool() -> void :
	_clear()

func _start_tool() -> void :
	_clear()

func _ui_root_gui_input(event: InputEvent) -> void :
	if event is InputEventKey:
		if event.pressed and not event.echo:
			match event.scancode:
				KEY_DELETE, KEY_BACKSPACE:
					on_delete_button_pressed()
				KEY_R:
					on_rotate_button_pressed()
				KEY_ESCAPE:
					selected_nodes.clear()
					_selected_nodes_changed()
				KEY_TAB:
					hovering_multiple_index += 1
	
	if event is InputEventMouseMotion:
		if event.button_mask & BUTTON_MASK_RIGHT != 0:
			if not right_click_dragging:
				if right_click_down_position.distance_to(get_global_mouse_position()) > 50.0:
					right_click_dragging = true
	
	if event is InputEventMouseButton:
		if event.button_index == BUTTON_RIGHT:
			if event.pressed:
				right_click_down_position = get_global_mouse_position()
				right_click_dragging = false
			if not event.pressed:
				if not right_click_dragging:
					right_click_popup_menu.clear()
					right_click_popup_menu.set_as_minsize()
					
					
					
					
					
					
					
					
					
					
					right_click_popup_menu.add_item("Copy", RightClickMenu.Copy)
					right_click_popup_menu.add_item("Paste", RightClickMenu.Paste)
					right_click_popup_menu.add_item("Delete", RightClickMenu.Delete)
					right_click_popup_menu.add_item("Undo", RightClickMenu.Undo)
					right_click_popup_menu.add_item("Redo", RightClickMenu.Redo)
					right_click_popup_menu.set_item_disabled(0, selected_nodes.size() == 0)
					right_click_popup_menu.set_item_disabled(1, copied_nodes.size() == 0)
					right_click_popup_menu.set_item_disabled(2, selected_nodes.size() == 0)
					right_click_popup_menu.set_item_disabled(3, not level_editor.undo.has_undo())
					right_click_popup_menu.set_item_disabled(4, not level_editor.undo.has_redo())
					
					right_click_popup_menu.set_position(get_global_mouse_position())
					right_click_popup_menu.popup()

func on_right_click_menu_id_pressed(id: int):
	match id:
		RightClickMenu.Copy:
			on_copy_button_pressed()
		RightClickMenu.Paste:
			_paste_at_grid_location(LevelGrid2.world_to_grid_2d(level_editor.level.get_local_mouse_position()), true)
		RightClickMenu.Delete:
			on_delete_button_pressed()
		RightClickMenu.Undo:
			level_editor.undo.undo()
		RightClickMenu.Redo:
			level_editor.undo.redo()
		_:
			printerr("[LevelEditorToolSelect] on_right_click_menu_id_pressed() unknown id: %s" % [id])

func _process_tool(delta: float) -> void :
	if level_editor.gesture_recognizer.is_recognizing_gesture():
		return
	
	var edge_detect_buffer: = 15.0
	
	var overlapping_nodes: = []
	if level_editor.is_mouse_present:
		overlapping_nodes = level_editor.level.overlap_point(mouse_position)
	
	
	hovering_node = null
	if hovering_multiple_index >= overlapping_nodes.size():
		hovering_multiple_index = 0
	if overlapping_nodes.size() > 0:
		hovering_node = overlapping_nodes[hovering_multiple_index]
	
	
	hovering_node_edge_mask = 0
	if not Input.is_key_pressed(KEY_SHIFT):
		
		
		if hovering_node != null and selected_nodes.has(hovering_node):
			for i in LevelGrid2.FACE_MAX:
				var distance_to_edge: = LevelGrid2.distance_to_edge_of_rect(hovering_node.world_rect, mouse_position, i)
				if distance_to_edge <= edge_detect_buffer:
					hovering_node_edge_mask = hovering_node_edge_mask | 1 << i
	
	
	if is_mouse_down and not was_mouse_down:
		selected_nodes_move_accumulator = Vector2.ZERO
		selected_nodes_move_root = LevelGrid2.world_to_grid_2d(mouse_position)
		clicked_node = hovering_node
		clicked_node_edge_mask = hovering_node_edge_mask
		if hovering_node:
			clicked_node_edge_original_rect = hovering_node.grid_rect
		else:
			clicked_node_edge_original_rect = Rect2()
		if not Input.is_key_pressed(KEY_SHIFT) and clicked_node != null and selected_nodes.has(clicked_node):
			if clicked_node_edge_mask > 0:
				
				click_state = ClickState.ClickedEdge
			else:
				click_state = ClickState.ClickedNode
		else:
			click_state = ClickState.ClickedNothing

	
	
















		
	
	if click_state == ClickState.ClickedNothing:
		if is_mouse_down:
			
			var mouse_distance: = mouse_down_position.distance_to(mouse_position)
			if mouse_distance > 10.0:
				var mouse_rect: = LevelGrid2.grid_rect_to_world_rect(LevelGrid2.world_to_enclosing_grid_rect(mouse_down_position, mouse_position))
				boxed_nodes = level_editor.level.overlap_rect(mouse_rect)
			elif hovering_node != null:
				boxed_nodes = [hovering_node]
			else:
				boxed_nodes = []
		
		
		if not is_mouse_down and was_mouse_down:
			if Input.is_key_pressed(KEY_SHIFT):
				var any_unselected: = false
				for b in boxed_nodes:
					if not selected_nodes.has(b):
						any_unselected = true
						break
				
				for b in boxed_nodes:
					if any_unselected:
						if not selected_nodes.has(b):
							selected_nodes.append(b)
					else:
						if selected_nodes.has(b):
							selected_nodes.erase(b)
				
				_selected_nodes_changed()
			else:
				
				
				
				set_selected_nodes(boxed_nodes)
	
	
	if is_mouse_down:
		match click_state:
			ClickState.ClickedEdge:
				
				
				
				var mouse_grid_position_rounded: = LevelGrid2.world_to_grid_rounded_2d(mouse_position)
				_move_selected_edge_mask(clicked_node, clicked_node_edge_mask, mouse_grid_position_rounded)
				update_selected_nodes_rect()
				
				level_editor.level.recalculate_aabb()
			ClickState.ClickedNode:
				
				var mouse_grid_position: = LevelGrid2.world_to_grid_2d(mouse_position)
				var selected_node_move_delta: = mouse_grid_position - selected_nodes_move_root
				selected_nodes_move_root = mouse_grid_position
				selected_nodes_move_accumulator += selected_node_move_delta
				if abs(selected_node_move_delta.x) > 0 or abs(selected_node_move_delta.y) > 0:
					var selected_node_ids: = _create_selected_node_ids_array()
					_move_node_ids(selected_node_ids, selected_node_move_delta)
	
	if not is_mouse_down:
		match click_state:
			ClickState.ClickedEdge:
				
				var clicked_node_id: = clicked_node.level_node_index
				var grid_rect: = clicked_node.grid_rect
				level_editor.undo.create_action("Resize Node")
				level_editor.undo.add_do_method(self, "_set_node_id_grid_rect", clicked_node_id, grid_rect)
				level_editor.undo.add_undo_method(self, "_set_node_id_grid_rect", clicked_node_id, clicked_node_edge_original_rect)
				level_editor.undo.commit_action()
				
			ClickState.ClickedNode:
				var selected_node_ids: = _create_selected_node_ids_array()
				var new_positions: = []
				var old_positions: = []
				for i in selected_nodes.size():
					var level_node: LevelNode = selected_nodes[i]
					new_positions.append(level_node.grid_rect.position)
					old_positions.append(level_node.grid_rect.position - selected_nodes_move_accumulator)
				level_editor.undo.create_action("Move Nodes")
				level_editor.undo.add_do_method(self, "_move_node_ids_to", selected_node_ids, new_positions)
				level_editor.undo.add_undo_method(self, "_move_node_ids_to", selected_node_ids, old_positions)
				level_editor.undo.commit_action()
	
	if not is_mouse_down:
		
		boxed_nodes.clear()
		clicked_node_edge_mask = 0
		clicked_node = null
		click_state = ClickState.None
		selected_nodes_move_accumulator = Vector2.ZERO
		
	was_mouse_down = is_mouse_down

func _set_node_id_grid_rect(node_id: int, grid_rect: Rect2):
	var level_node: LevelNode = level_editor.level.get_level_node(node_id)
	if not level_node:
		printerr("[LevelEditorToolSelect] _set_node_id_grid_rect() couldnt find node with id %s" % [node_id])
		return
	level_node.grid_rect = grid_rect

static func _move_selected_edge_mask(selected_node: LevelNode, clicked_node_edge_mask: int, mouse_grid_position: Vector2):
	if selected_node == null:
		printerr("[LevelEditorToolSelect] _move_selected_edge_mask() cannot move a null node")
		return
	for edge in UpGuys_LevelGrid.FACE_MAX:
		var edge_mask: = 1 << int(edge)
		if clicked_node_edge_mask & edge_mask > 0:
			_move_selected_edge(selected_node, edge, mouse_grid_position)

static func _move_selected_edge(selected_node: LevelNode, selected_node_edge: int, mouse_grid_position: Vector2):
	var extract_margin: = 0.0
	match selected_node_edge:
		UpGuys_LevelGrid.FACE_UP:
			extract_margin = - (mouse_grid_position.y - selected_node.grid_rect.position.y)
		UpGuys_LevelGrid.FACE_LEFT:
			extract_margin = - (mouse_grid_position.x - selected_node.grid_rect.position.x)
		UpGuys_LevelGrid.FACE_RIGHT:
			extract_margin = mouse_grid_position.x - selected_node.grid_rect.end.x
		UpGuys_LevelGrid.FACE_DOWN:
			extract_margin = mouse_grid_position.y - selected_node.grid_rect.end.y
	if not is_zero_approx(extract_margin):
		
		selected_node.grid_rect = selected_node.grid_rect.grow_margin(selected_node_edge, extract_margin)
		pass

func _move_node_ids_to(node_ids: Array, positions: Array):
	assert (node_ids.size() == positions.size())
	for i in node_ids.size():
		var node_id: int = node_ids[i]
		var node: LevelNode = level_editor.level.get_level_node(node_id)
		if not node:
			continue
		var p: Vector2 = positions[i]
		node.grid_rect.position = p
	
	
	update_selected_nodes_rect()
	level_editor.level.recalculate_aabb()

func _move_node_ids(node_ids: Array, delta: Vector2):
	if is_zero_approx(delta.x) and is_zero_approx(delta.y):
		return
	for i in node_ids.size():
		var node_id: int = node_ids[i]
		var node: LevelNode = level_editor.level.get_level_node(node_id)
		if not node:
			continue
		node.grid_rect.position = node.grid_rect.position + delta
	
	
	update_selected_nodes_rect()
	level_editor.level.recalculate_aabb()

func _draw_dynamic_rect(level_node: LevelNode, color: Color):
	if level_node.body:
		var body_type: = level_node.body.type
		if body_type == Box2DPhysicsBody.MODE_KINEMATIC or body_type == Box2DPhysicsBody.MODE_RIGID:
			var node_size: = level_node.world_rect.size
			var centered_rect: = Rect2( - node_size * 0.5, node_size)
			var node_transform: = Transform2D(level_node.body.rotation, level_node.body.position)
			draw_transformed_grid_cells(centered_rect, color, false, false, node_transform)

func _draw() -> void :
	
	for i in selected_nodes.size():
		var selected_node: = selected_nodes[i] as LevelNode
		draw_grid_cells(selected_node.world_rect, selected_outline_color, false, false)
		_draw_dynamic_rect(selected_node, selected_outline_color)
	
	for i in boxed_nodes.size():
		var boxed_node: = boxed_nodes[i] as LevelNode
		if not selected_nodes.has(boxed_node):
			draw_grid_cells(boxed_node.world_rect, hovering_outline_color, false, false)
			_draw_dynamic_rect(boxed_node, hovering_outline_color)
	
	if click_state == ClickState.ClickedEdge:
		for edge in LevelGrid2.FACE_MAX:
			var edge_mask: = 1 << int(edge)
			if clicked_node_edge_mask & edge_mask > 0:
				draw_bounding_box_edge(clicked_node.world_rect, edge, interacting_outline_color)
	
	
	var drawing_hovering_edge: = false
	if click_state == ClickState.None:
		if hovering_node:
			if not selected_nodes.has(hovering_node) and not boxed_nodes.has(hovering_node):
				
				draw_grid_cells(hovering_node.world_rect, hovering_outline_color, false, false)
				_draw_dynamic_rect(hovering_node, hovering_outline_color)
		if hovering_node_edge_mask > 0:
			
			for edge in LevelGrid2.FACE_MAX:
				var edge_mask: = 1 << int(edge)
				if hovering_node_edge_mask & edge_mask > 0:
					draw_bounding_box_edge(hovering_node.world_rect, edge, interactable_outline_color)
	if level_editor.is_mouse_present:
		
		if hovering_node_edge_mask == 0 and \
		click_state != ClickState.ClickedNode and \
		click_state != ClickState.ClickedEdge:
			draw_mouse_cell(mouse_down_position, mouse_position)

func on_unloading_level():
	_clear()

func on_removed_node(l: LevelNode):
	if selected_nodes.has(l):
		selected_nodes.erase(l)
		_selected_nodes_changed()
	if hovering_node == l:
		hovering_node = null
	if clicked_node == l:
		clicked_node = null
	boxed_nodes.erase(l)

func _clear():
	selected_nodes.clear()
	_selected_nodes_changed()
	hovering_node = null
	clicked_node = null
	boxed_nodes.clear()

func set_selected_nodes(n: Array):
	selected_nodes = n.duplicate()
	_selected_nodes_changed()

func _selected_nodes_changed():
	update_selected_nodes_rect()
	inspector.render_nodes(selected_nodes)
	
	emit_signal("selected_nodes_changed", selected_nodes)

func update_selected_nodes_rect():
	selected_nodes_rect = Rect2()
	for i in selected_nodes.size():
		var boxed_node: = selected_nodes[i] as LevelNode
		selected_nodes_rect = selected_nodes_rect.expand(boxed_node.world_rect.position)
		selected_nodes_rect = selected_nodes_rect.expand(boxed_node.world_rect.end)

func _create_selected_node_ids_array() -> Array:
	var selected_node_ids: = []
	for i in selected_nodes.size():
		var selected_node: LevelNode = selected_nodes[i]
		selected_node_ids.append(selected_node.level_node_index)
	return selected_node_ids
