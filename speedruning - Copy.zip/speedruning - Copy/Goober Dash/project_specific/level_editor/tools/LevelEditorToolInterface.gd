extends Control
class_name LevelEditorToolInterface

func _process_tool(delta: float):
	pass

func _start_tool():
	pass

func _stop_tool():
	pass

func _ui_root_gui_input(event: InputEvent) -> void :
	pass
