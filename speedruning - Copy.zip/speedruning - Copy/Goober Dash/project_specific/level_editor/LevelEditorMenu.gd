extends Control
export  var _button: NodePath
onready var menu_button: = get_node(_button) as BaseButton

export  var _level_editor: NodePath
onready var level_editor: = get_node(_level_editor) as LevelEditor

export  var _themes_menu: NodePath
onready var themes_menu: = get_node(_themes_menu) as Control

export  var _save_dialog: NodePath
onready var save_dialog: = get_node(_save_dialog) as LevelEditor_SaveDialog

export  var _load_dialog: NodePath
onready var load_dialog: = get_node(_load_dialog) as LevelEditor_LevelBrowser

onready var menu_button_popup: = PopupMenu.new()
enum MenuButtonId{
	New, 
	Save, 
	Load, 
	ResetPlayers, 
	SelectTheme, 
	Exit, 
}

func _ready() -> void :
	menu_button_popup.add_item("NEW LEVEL", MenuButtonId.New)
	menu_button_popup.add_item("SELECT THEME", MenuButtonId.SelectTheme)
	menu_button_popup.add_separator()
	menu_button_popup.add_item("SAVE", MenuButtonId.Save)
	
	menu_button_popup.add_item("LOAD", MenuButtonId.Load)
	




	menu_button_popup.add_separator()
	menu_button_popup.add_item("RESET PLAYERS", MenuButtonId.ResetPlayers)
	menu_button_popup.add_separator()
	menu_button_popup.add_item("EXIT", MenuButtonId.Exit)
	menu_button_popup.connect("id_pressed", self, "on_menu_button_item_pressed")
	add_child(menu_button_popup)
	
	menu_button.connect("pressed", self, "on_menu_button_pressed")

func on_menu_button_pressed():
	var delta: = Vector2(50.0, 30.0 + menu_button.rect_size.y)
	menu_button_popup.rect_position = menu_button.rect_position + delta
	menu_button_popup.popup()

func on_menu_button_item_pressed(id: int):
	match id:
		MenuButtonId.New:
			level_editor.new_level()
		MenuButtonId.Save:
			save_dialog.dialog.animate_in()
		MenuButtonId.Load:
			load_dialog.dialog.animate_in()
		MenuButtonId.SelectTheme:
			themes_menu.visible = true
		MenuButtonId.ResetPlayers:
			level_editor.reset_players()
		MenuButtonId.Exit:
			yield(ScreenTransitions.fade_in(), "completed")
			get_tree().change_scene_to(GoodResourceLoader.load_resource("res://scenes/HomeScene.tscn"))
		_:
			printerr("on_menu_button_item_pressed() unknown menu button id %s" % [id])

func on_load_panel_focus_lost(c: Control):
	var f: = menu_button.get_node("Focusable") as Focusable
	f.focus_me()
