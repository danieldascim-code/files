extends Control
class_name LevelEditor_InspectorPanel

var level_editor: LevelEditor
func render_nodes(nodes: Array):
	printerr("[LevelEditor_InspectorPanel] render_node() must be overridden")
