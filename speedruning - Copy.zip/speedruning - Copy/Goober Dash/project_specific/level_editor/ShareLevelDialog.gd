extends CanvasLayer
class_name ShareLevelDialog

onready var dialog: UIDialog = $UIDialog

export  var share_url: String = "" setget set_share_url

export  var _url_text_edit: NodePath
onready var url_text_edit: TextEdit = get_node(_url_text_edit)

export  var _direct_share_button: NodePath
onready var direct_share_button: BaseButton = get_node(_direct_share_button)

export  var _copy_button: NodePath
onready var copy_button: BaseButton = get_node(_copy_button)

func _ready():
	set_share_url(share_url)
	direct_share_button.visible = AdManager.is_sharing_supported("Goober Dash!", "I just created a level in Goober Dash!  Can you beat it?", "https://www.google.com")
	direct_share_button.connect("pressed", self, "on_share_button_pressed")
	copy_button.connect("pressed", self, "on_copy_button_pressed")

func set_share_url(s: String):
	share_url = s
	if url_text_edit:
		url_text_edit.text = share_url

func on_share_button_pressed():
	
	AdManager.share("Goober Dash!", "I just created a level in Goober Dash!  Can you beat it?", url_text_edit.text)
	
func on_copy_button_pressed():
	OS.set_clipboard(url_text_edit.text)
	dialog.animate_out()

static func share_host() -> String:
	if AdManager.get_ad_driver() == "crazygames":
		return GoodConfig.get_config_value("crazygames_public_url")
	return GoodConfig.get_config_value("public_url")

static func share_url_play_level_id(level_id: String) -> String:
	return "%s?play=%s" % [share_host(), level_id]

static func share_url_play_time_level_id(level_id: String, time_seconds: float) -> String:
	return "%s?play=%s&time=%s" % [share_host(), level_id, time_seconds]

static func share_url_watch_replay(level_id: String, user_id: String) -> String:
	return "%s?play=%s&replay=%s" % [share_host(), level_id, user_id]

static func share_url_race_ghost(level_id: String, user_id: String) -> String:
	return "%s?play=%s&ghost=%s" % [share_host(), level_id, user_id]

static func share_url_lobby(lobby_code: String) -> String:
	return "%s?lobby=%s" % [share_host(), lobby_code]
