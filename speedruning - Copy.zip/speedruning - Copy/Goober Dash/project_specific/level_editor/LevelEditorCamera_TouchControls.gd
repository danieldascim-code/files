extends Node
class_name LevelEditorCamera_TouchControls

onready var camera: = get_parent() as LevelEditorCamera

export  var _gesture_recognizer: NodePath
onready var gesture_recognizer: GestureRecognizer = get_node(_gesture_recognizer)

var mouse_is_over_editor_ui: = false
export  var _ui_root: NodePath
onready var ui_root: Control = get_node(_ui_root)

const pan_scalar: = - 1.0
const zoom_scalar: = 0.001
const offcenter_zoom_pans_scalar: = 1.0

const mac_track_pad_pan_scalar: = - 1.0
const mac_track_pad_zoom_scalar: = 1.0
const verbose: = false

func _ready() -> void :
	ui_root.connect("gui_input", self, "on_ui_root_gui_input")
	gesture_recognizer.connect("pan_gesture", self, "on_pan_gesture")
	gesture_recognizer.connect("zoom_gesture", self, "on_zoom_gesture")

func on_pan_gesture(pan_factor: Vector2):
	if verbose:
		print("[TouchControls] custom pan gesture delta %s" % [pan_factor])
	camera.target_position = camera.target_position + (pan_factor * pan_scalar)

func on_zoom_gesture(zoom_factor: float, average_position: Vector2):
	if verbose:
		print("[TouchControls] custom zoom gesture %s" % [zoom_factor])
	camera.target_zoom = camera.target_zoom + (zoom_factor * zoom_scalar)
	
	
	
	

func on_ui_root_gui_input(event: InputEvent) -> void :
	if event is InputEventPanGesture:
		if verbose:
			print("[TouchControls] pan gesture delta %s" % [event.delta])
		camera.target_position = camera.target_position + (event.delta * mac_track_pad_pan_scalar)
	if event is InputEventMagnifyGesture:
		camera.target_zoom = camera.target_zoom + (event.factor * mac_track_pad_zoom_scalar)
		if verbose:
			print("[TouchControls] magnify gesture %s" % [event.factor])
