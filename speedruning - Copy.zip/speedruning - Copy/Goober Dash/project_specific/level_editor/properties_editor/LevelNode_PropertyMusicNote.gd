tool 
extends LevelNode_PropertyDefinition
class_name LevelNode_PropertyMusicNote

export  var default_value: = 0
export (Array, String) var note_values: Array
export (Array, String) var octave_values: Array

func validate(value):
	var t: = typeof(value)
	if t == TYPE_REAL:
		value = int(value)
	elif t != TYPE_INT:
		return default_value()
	return _validate(value)

func _validate(value: int):
	if value < 0 or value >= _total_number_of_values():
		value = 0
	return value

func _default_value():
	return default_value

func _total_number_of_values() -> int:
	return note_values.size() * octave_values.size()
