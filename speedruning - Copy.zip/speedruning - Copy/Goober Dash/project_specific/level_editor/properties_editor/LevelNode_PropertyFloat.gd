tool 
extends LevelNode_PropertyDefinition
class_name LevelNode_PropertyFloat

export  var has_min_value: = false
export  var min_value: = 0.0
export  var has_max_value: = false
export  var max_value: = 0.0
export  var step: = 0.1
export  var allow_slider: = true

export  var default_value: = 0.0

func _validate(value: float):
	value = stepify(value, step)
	if has_min_value:
		value = max(value, min_value)
	elif has_max_value:
		value = min(value, max_value)
	return value
	
func _default_value():
	return default_value
