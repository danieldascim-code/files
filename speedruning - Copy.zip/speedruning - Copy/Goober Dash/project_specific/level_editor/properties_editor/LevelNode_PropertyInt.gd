tool 
extends LevelNode_PropertyDefinition
class_name LevelNode_PropertyInt

export  var default_value: = 0
export  var has_min_value: = false
export  var min_value: = 0
export  var has_max_value: = false
export  var max_value: = 0
export  var step: = 0
export  var allow_slider: = true

func validate(value):
	var t: = typeof(value)
	if t == TYPE_REAL:
		value = int(value)
	elif t != TYPE_INT:
		return default_value()
	return _validate(value)

func _validate(value: int):
	value = int(stepify(value, step))
	if has_min_value:
		value = int(max(value, min_value))
	elif has_max_value:
		value = int(min(value, max_value))
	return value

func _default_value():
	return default_value
