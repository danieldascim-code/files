tool 
extends LevelNode_PropertyDefinition
class_name LevelNode_PropertyEnum

export  var default_value: = 0
export (Array, String) var enum_values: Array

func validate(value):
	var t: = typeof(value)
	if t == TYPE_REAL:
		value = int(value)
	elif t != TYPE_INT:
		return default_value()
	return _validate(value)

func _validate(value: int):
	if value < 0 or value >= enum_values.size():
		value = 0
	return value

func _default_value():
	return default_value
