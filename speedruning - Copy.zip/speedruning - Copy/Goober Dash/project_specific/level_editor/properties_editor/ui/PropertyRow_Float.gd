extends PropertyRow
class_name PropertyRow_Float

export  var _slider_container: NodePath
onready var slider_container: = get_node(_slider_container) as Control

export  var _slider: NodePath
onready var slider: = get_node(_slider) as HSlider

export  var _line_edit: NodePath
onready var line_edit: = get_node(_line_edit) as LineEditNumeric

var stop_recursion: = false

func _ready():
	slider.connect("value_changed", self, "on_slider_changed")
	line_edit.connect("number_changed", self, "on_line_edit_number_changed")

func on_line_edit_number_changed(number: float):
	emit_changed(number)
	if slider.value != number:
		slider.value = number

func on_slider_changed(value: float):
	emit_changed(value)
	var s: = str(value)
	if line_edit.text != s:
		line_edit.text = s

func show_property(property_definition: LevelNode_PropertyDefinition, property_value):
	.show_property(property_definition, property_value)
	
	assert (property_value is float)
	assert (property_definition is LevelNode_PropertyFloat)
	
	var property_value_float: float = property_value
	var property_definition_float: = property_definition as LevelNode_PropertyFloat
	
	var show_as_slider: = property_definition_float.allow_slider and property_definition_float.has_min_value and property_definition_float.has_max_value
	slider.visible = show_as_slider
	
	slider.step = property_definition_float.step
	slider.min_value = property_definition.min_value
	slider.max_value = property_definition.max_value
	slider.value = property_value_float
	line_edit.step = property_definition_float.step
	line_edit.minimum = property_definition_float.min_value
	line_edit.maximum = property_definition_float.max_value
	line_edit.do_minimum = property_definition_float.has_min_value
	line_edit.do_maximum = property_definition_float.has_max_value
	line_edit.set_number(property_value_float)
