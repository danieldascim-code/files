extends PropertyRow
class_name PropertyRow_MusicNote

export  var _octave_options_button: NodePath
onready var octave_options_button: = get_node(_octave_options_button) as OptionButton

export  var _note_options_button: NodePath
onready var note_options_button: = get_node(_note_options_button) as OptionButton

func _ready():
	note_options_button.connect("item_selected", self, "on_note_selected")
	octave_options_button.connect("item_selected", self, "on_octave_selected")

func on_note_selected(item: int):
	emit_changed(compute_value())

func on_octave_selected(item: int):
	var i = compute_value()
	emit_changed(i)

func show_property(property_definition: LevelNode_PropertyDefinition, property_value):
	.show_property(property_definition, property_value)
	
	assert (property_value is int)
	assert (property_definition is LevelNode_PropertyMusicNote)
	
	var property_value_int: int = property_value
	var property_definition_music_note: = property_definition as LevelNode_PropertyMusicNote
	assert (property_value_int >= 0 and property_value_int < property_definition_music_note._total_number_of_values())
	
	for i in property_definition_music_note.note_values.size():
		var value_name: String = property_definition_music_note.note_values[i]
		note_options_button.add_item(value_name)
	
	for i in property_definition_music_note.octave_values.size():
		var value_name: String = property_definition_music_note.octave_values[i]
		octave_options_button.add_item(value_name)
	
	var octave: = compute_octave_for_value(property_value_int, property_definition_music_note.note_values.size())
	octave_options_button.select(octave)

	var note: = compute_note_for_value(property_value_int, property_definition_music_note.note_values.size())
	note_options_button.select(note)

func compute_value() -> int:
	var octave_selected: = octave_options_button.selected
	var num_notes: = note_options_button.get_item_count()
	var note_selected: = note_options_button.selected
	var result: = octave_selected * num_notes + note_selected
	return result

func compute_octave_for_value(v: int, num_notes: int) -> int:
	return int(v / num_notes)

func compute_note_for_value(v: int, num_notes: int) -> int:
	return v % num_notes
