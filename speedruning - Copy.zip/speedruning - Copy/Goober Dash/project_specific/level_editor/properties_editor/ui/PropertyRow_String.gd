extends PropertyRow
class_name PropertyRow_String

export  var _line_edit: NodePath
onready var line_edit: LineEdit = get_node(_line_edit)



func _ready():
	var e = line_edit.connect("text_changed", self, "on_text_changed")
	print("[PropertyRow_String] connect result: %s" % [e])
	assert (e == OK)

func on_text_changed(t: String):
	print("[PropertyRow_String] changed: %s" % [line_edit.text])
	emit_changed(line_edit.text)

func show_property(property_definition: LevelNode_PropertyDefinition, property_value):
	.show_property(property_definition, property_value)
	
	assert (property_value is String)
	
	line_edit.text = property_value
