extends Control
class_name PropertyRow

signal property_changed(_property_value)

export  var _name_label: NodePath
onready var name_label: = get_node(_name_label) as Label

func show_property(property_definition: LevelNode_PropertyDefinition, property_value):
	name_label.text = property_definition.property_name.replace("_", " ").to_upper()

func emit_changed(v):
	emit_signal("property_changed", v)
