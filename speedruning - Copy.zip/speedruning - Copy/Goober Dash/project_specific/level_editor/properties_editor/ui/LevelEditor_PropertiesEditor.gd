extends LevelEditor_InspectorPanel
class_name LevelEditor_PropertiesEditor

signal rotate_pressed()
signal copy_pressed()
signal paste_pressed()
signal delete_pressed()

export  var _row_parent: NodePath
export  var _row_template_float: NodePath
export  var _row_template_vector2: NodePath
export  var _row_template_int: NodePath
export  var _row_template_enum: NodePath
export  var _row_template_bool: NodePath
export  var _row_template_string: NodePath
export  var _row_template_music_note: NodePath
export  var _default_properties: NodePath

onready var row_parent: = get_node(_row_parent) as Control
onready var row_template_float: = get_node(_row_template_float) as PropertyRow
onready var row_template_vector2: = get_node(_row_template_vector2) as PropertyRow
onready var row_template_int: = get_node(_row_template_int) as PropertyRow
onready var row_template_enum: = get_node(_row_template_enum) as PropertyRow
onready var row_template_bool: = get_node(_row_template_bool) as PropertyRow
onready var row_template_string: = get_node(_row_template_string) as PropertyRow
onready var row_template_music_note: = get_node(_row_template_music_note) as PropertyRow

onready var default_properties: = get_node(_default_properties)

var default_property_definitions: = {}

onready var template_rows: = [
	row_template_float, 
	row_template_vector2, 
	row_template_int, 
	row_template_bool, 
	row_template_string, 
	row_template_enum, 
	row_template_music_note, 
]

onready var types_to_rows: = {
	TYPE_VECTOR2: row_template_vector2, 
	TYPE_REAL: row_template_float, 
	TYPE_INT: row_template_int, 
	TYPE_BOOL: row_template_bool, 
	TYPE_STRING: row_template_string, 
}

const disable_default_properties_map: = {
	"block": ["z_order"], 
	"ramp": ["z_order"]
}

var rows: = {}
var showing_level_node_id: = - 1
func _ready():
	for template_row in template_rows:
		template_row.visible = false
	
	for i in default_properties.get_child_count():
		var c: = default_properties.get_child(i)
		var property_definition: = c as LevelNode_PropertyDefinition
		if property_definition:
			default_property_definitions[property_definition.property_name] = property_definition

func _clear_rows():
	for row_key in rows:
		var r = rows[row_key]
		r.queue_free()
	rows.clear()

func render_nodes(level_nodes: Array):
	showing_level_node_id = - 1
	_clear_rows()
	if level_nodes.size() != 1:
		return
	
	var level_node: LevelNode = level_nodes[0]
	if not level_node:
		return
	showing_level_node_id = level_node.level_node_index
	
	var disabled_default_properties: Array = disable_default_properties_map.get(level_node.node_type, [])
	var property_definitions: = default_property_definitions.duplicate()
	property_definitions.merge(level_node.property_definitions)
	
	for i in property_definitions:
		var property_definition: LevelNode_PropertyDefinition = property_definitions[i]
		var is_default_property: = int(i) < default_property_definitions.size()
		if is_default_property:
			if disabled_default_properties.has(property_definition.property_name):
				continue
			if not property_definition.link_property.empty():
				property_definition.link_target = level_node
		var value = property_definition.get_value(level_node.properties)
		var row_template: PropertyRow
		if property_definition is LevelNode_PropertyEnum:
			row_template = row_template_enum
		elif property_definition is LevelNode_PropertyMusicNote:
			row_template = row_template_music_note
		else:
			var value_type: = typeof(value)
			row_template = types_to_rows.get(value_type)
		
		if row_template == null:
			printerr("[LevelEditor_PropertiesEditor] cant edit property with property_name %s" % [property_definition.property_name])
			continue
		
		var row_instance: PropertyRow = row_template.duplicate()
		row_instance.visible = true
		row_parent.add_child(row_instance)
		row_instance.show_property(property_definition, value)
		rows[property_definition.property_name] = row_instance
		row_instance.connect("property_changed", self, "on_property_changed", [level_node, property_definition, row_instance])

var is_applying_level_node_property: = false
func on_property_changed(value, level_node: LevelNode, property_definition: LevelNode_PropertyDefinition, row: PropertyRow):
	if is_applying_level_node_property:
		
		return
	var current_value = level_node.get_level_node_property(property_definition.property_name)
	level_editor.undo.create_action("Change Property", UndoRedo.MERGE_ENDS)
	level_editor.undo.add_do_method(self, "apply_level_node_property", level_node.level_node_index, property_definition.property_name, value)
	level_editor.undo.add_undo_method(self, "apply_level_node_property", level_node.level_node_index, property_definition.property_name, current_value)
	level_editor.undo.commit_action()

func apply_level_node_property(level_node_index: int, property_definition_name: String, value):
	var level_node: LevelNode = level_editor.level.get_level_node(level_node_index)
	var property_definition: LevelNode_PropertyDefinition = level_node.property_definitions.get(property_definition_name)
	if not property_definition:
		property_definition = default_property_definitions.get(property_definition_name)
		if not property_definition.link_property.empty():
			property_definition.link_target = level_node
	if not property_definition:
		printerr("[LevelEditor_PropertiesEditor] apply_level_node_property() couldnt find property_definition with name " + property_definition_name)
		return
	level_node.apply_property(property_definition, value)
	if not level_editor.undo.is_commiting_action():
		
		if showing_level_node_id == level_node.level_node_index:
			var row: PropertyRow = rows.get(property_definition.property_name)
			if row:
				is_applying_level_node_property = true
				row.show_property(property_definition, value)
				is_applying_level_node_property = false
