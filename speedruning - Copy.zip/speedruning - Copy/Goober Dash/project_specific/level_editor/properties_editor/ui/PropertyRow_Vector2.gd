extends PropertyRow
class_name PropertyRow_Vector2

export  var _line_edit_x: NodePath
onready var line_edit_x: = get_node(_line_edit_x) as LineEditNumeric

export  var _line_edit_y: NodePath
onready var line_edit_y: = get_node(_line_edit_y) as LineEditNumeric

func _ready():
	line_edit_x.connect("number_changed", self, "on_line_edit_y_number_changed")
	line_edit_y.connect("number_changed", self, "on_line_edit_y_number_changed")

func show_property(property_definition: LevelNode_PropertyDefinition, property_value):
	.show_property(property_definition, property_value)
	
	assert (property_value is Vector2)
	assert (property_definition is LevelNode_PropertyVector2)
	
	var property_value_vector2: Vector2 = property_value
	var property_definition_vector2: = property_definition as LevelNode_PropertyVector2
	
	line_edit_x.do_minimum = property_definition_vector2.has_min_x_value
	line_edit_x.minimum = property_definition_vector2.min_value.x
	line_edit_x.do_maximum = property_definition_vector2.has_max_x_value
	line_edit_x.maximum = property_definition_vector2.max_value.x
	line_edit_x.step = property_definition_vector2.step.x
	line_edit_x.initial_value = property_value_vector2.x
	line_edit_x.set_number_no_signal(property_value_vector2.x)

	line_edit_y.do_minimum = property_definition_vector2.has_min_y_value
	line_edit_y.minimum = property_definition_vector2.min_value.y
	line_edit_y.do_maximum = property_definition_vector2.has_max_y_value
	line_edit_y.maximum = property_definition_vector2.max_value.y
	line_edit_y.step = property_definition_vector2.step.y
	line_edit_y.initial_value = property_value_vector2.y
	line_edit_y.set_number_no_signal(property_value_vector2.y)

func on_line_edit_x_number_changed(_number: float):
	_process_changes()

func on_line_edit_y_number_changed(_number: float):
	_process_changes()

func _process_changes():
	var v: = Vector2(line_edit_x.number, line_edit_y.number)
	emit_changed(v)
