extends PropertyRow
class_name PropertyRow_Int

export  var _slider_container: NodePath
onready var slider_container: = get_node(_slider_container) as Control

export  var _slider: NodePath
onready var slider: = get_node(_slider) as HSlider

export  var _slider_label: NodePath
onready var slider_label: = get_node(_slider_label) as Label

export  var _line_edit_container: NodePath
onready var line_edit_container: = get_node(_line_edit_container) as Control

export  var _line_edit: NodePath
onready var line_edit: = get_node(_line_edit) as LineEditNumeric

func _ready():
	slider.connect("value_changed", self, "on_slider_changed")
	line_edit.connect("number_changed", self, "on_line_edit_number_changed")

func on_line_edit_number_changed(number: float):
	emit_changed(number)

func on_slider_changed(value: float):
	var i: = int(value)
	emit_changed(i)
	slider_label.text = str(i)

func show_property(property_definition: LevelNode_PropertyDefinition, property_value):
	.show_property(property_definition, property_value)
	
	assert (property_value is int)
	assert (property_definition is LevelNode_PropertyInt)
	
	var property_value_int: int = property_value
	var property_definition_int: = property_definition as LevelNode_PropertyInt
	
	var show_as_slider: = property_definition_int.allow_slider and property_definition_int.has_min_value and property_definition_int.has_max_value
	slider_container.visible = show_as_slider
	line_edit_container.visible = not show_as_slider
	
	if slider_container.visible:
		slider.step = max(1.0, property_definition_int.step)
		slider.min_value = property_definition.min_value
		slider.max_value = property_definition.max_value
		slider.value = property_value_int
		slider_label.text = str(property_value_int)
	elif line_edit_container.visible:
		line_edit.step = max(1.0, property_definition_int.step)
		line_edit.minimum = property_definition_int.min_value
		line_edit.maximum = property_definition_int.max_value
		line_edit.do_minimum = property_definition_int.has_min_value
		line_edit.do_maximum = property_definition_int.has_max_value
		line_edit.set_number(property_value_int)
