extends PropertyRow
class_name PropertyRow_Bool

export  var _checkbutton: NodePath
onready var checkbutton: = get_node(_checkbutton) as CheckButton

func _ready():
	checkbutton.connect("toggled", self, "on_button_toggled")

func on_button_toggled(v: bool):
	emit_changed(v)

func show_property(property_definition: LevelNode_PropertyDefinition, property_value):
	.show_property(property_definition, property_value)
	
	assert (property_value is bool)
	
	checkbutton.pressed = property_value
