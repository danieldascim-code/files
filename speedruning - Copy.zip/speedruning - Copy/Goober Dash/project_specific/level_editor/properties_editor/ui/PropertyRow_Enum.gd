extends PropertyRow
class_name PropertyRow_Enum

export  var _options_button: NodePath
onready var options_button: = get_node(_options_button) as OptionButton

func _ready():
	options_button.connect("item_selected", self, "on_item_selected")

func on_item_selected(item: int):
	emit_changed(item)

func show_property(property_definition: LevelNode_PropertyDefinition, property_value):
	.show_property(property_definition, property_value)
	
	assert (property_value is int)
	assert (property_definition is LevelNode_PropertyEnum)
	
	var property_value_int: int = property_value
	var property_definition_enum: = property_definition as LevelNode_PropertyEnum
	assert (property_value_int >= 0 and property_value_int < property_definition_enum.enum_values.size())
	for i in property_definition_enum.enum_values.size():
		var value_name: String = property_definition_enum.enum_values[i]
		options_button.add_item(value_name)
	options_button.select(property_value_int)
