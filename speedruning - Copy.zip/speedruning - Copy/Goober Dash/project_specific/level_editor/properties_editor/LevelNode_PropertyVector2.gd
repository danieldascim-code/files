tool 
extends LevelNode_PropertyDefinition
class_name LevelNode_PropertyVector2

export  var has_min_x_value: = false
export  var has_min_y_value: = false
export  var min_value: = Vector2.ZERO

export  var has_max_x_value: = false
export  var has_max_y_value: = false
export  var max_value: = Vector2.ZERO

export  var step: = Vector2(0.1, 0.1)

export  var default_value: = Vector2(0.0, 0.0)

func _validate(value: Vector2):
	value.x = stepify(value.x, step.x)
	value.y = stepify(value.y, step.y)
	if has_min_x_value:
		value.x = max(value.x, min_value.x)
	elif has_max_x_value:
		value.x = min(value.x, min_value.x)
	
	if has_min_x_value:
		value.y = max(value.y, min_value.y)
	elif has_max_x_value:
		value.y = min(value.y, min_value.y)
	
	return value

func _default_value():
	return default_value
