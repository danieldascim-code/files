tool 
extends LevelNode_PropertyDefinition
class_name LevelNode_PropertyBool

export  var default_value: = false

func _default_value():
	return default_value
