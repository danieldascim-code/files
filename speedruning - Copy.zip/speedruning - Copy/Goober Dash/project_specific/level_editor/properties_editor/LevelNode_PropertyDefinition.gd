tool 
extends Node
class_name LevelNode_PropertyDefinition

export  var property_name: = ""
export  var _link_target: = NodePath("../")
export  var link_property: = ""

onready var link_target: = get_node_or_null(_link_target)
export  var serialized: = true

func get_value(data: Dictionary):
	if is_linked_property():
		return link_target.get(link_property)
	else:
		return data.get(property_name, default_value())

func set_value(data: Dictionary, value):
	var validated_value = validate(value)
	if is_linked_property():
		link_target.set(link_property, validated_value)
	if serialized and not Engine.editor_hint:
		data[property_name] = validated_value

func validate(value):
	if typeof(value) != typeof(default_value()):
		return default_value()
	return _validate(value)

func default_value():
	return _default_value()

func is_linked_property() -> bool:
	return not link_property.empty() and link_target != null


func _validate(value):
	return value

func _default_value():
	printerr("[LevelNode_PropertyDefinition] _default_value() each implementation must override this and return something")
	return null
