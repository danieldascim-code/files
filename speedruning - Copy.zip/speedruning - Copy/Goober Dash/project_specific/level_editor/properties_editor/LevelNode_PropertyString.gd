tool 
extends LevelNode_PropertyDefinition
class_name LevelNode_PropertyString

export  var max_length: = - 1

func _validate(value: String):
	if max_length >= 0:
		if value.length() > max_length:
			value = value.substr(0, max_length)
	return value

func _default_value():
	return ""
