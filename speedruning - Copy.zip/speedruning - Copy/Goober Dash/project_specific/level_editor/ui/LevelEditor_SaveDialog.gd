extends CanvasLayer
class_name LevelEditor_SaveDialog

signal save_button_pressed()
signal share_button_pressed()
signal fork_button_pressed()

onready var dialog: UIDialog = $UIDialog

export  var _name_line_edit: NodePath
onready var name_line_edit: LineEdit = get_node(_name_line_edit)

export  var _player_count_line_edit: NodePath
onready var player_count_line_edit: LineEdit = get_node(_player_count_line_edit)

export  var _mode_options: NodePath
onready var mode_options: OptionButton = get_node(_mode_options)

export  var _curated_option_button: NodePath
onready var curated_option_button: OptionButton = get_node(_curated_option_button)

export  var _curated_parent: NodePath
onready var curated_parent: Control = get_node(_curated_parent)

export  var _save_button: NodePath
onready var save_button: BaseButton = get_node(_save_button)

export  var _fork_button: NodePath
onready var fork_button: BaseButton = get_node(_fork_button)

export  var _share_button: NodePath
onready var share_button: BaseButton = get_node(_share_button)

export  var _download_button: NodePath
onready var download_button: BaseButton = get_node(_download_button)

export  var _publish_button: NodePath
onready var publish_button: GoodButton = get_node(_publish_button)

export  var _delete_button: NodePath
onready var delete_button: GoodButton = get_node(_delete_button)

export  var _author_overwrite_container: NodePath
onready var author_overwrite_container: Control = get_node(_author_overwrite_container)

export  var _author_overwrite_line_edit: NodePath
onready var author_overwrite_line_edit: LineEdit = get_node(_author_overwrite_line_edit)

var showing_level_instance: LevelInstance

enum LevelPublishedState{
	Private = 0, 
	Public = 1, 
	Curated = 2, 
}

func _ready() -> void :
	
	curated_option_button.add_item("Private", LevelPublishedState.Private)
	curated_option_button.add_item("Public", LevelPublishedState.Public)
	curated_option_button.add_item("Curated", LevelPublishedState.Curated)
	
	for i in LevelUtils.LevelType.MAX:
		mode_options.add_item(LevelUtils.string_for_level_type(i), i)
	
	curated_parent.visible = false
	author_overwrite_container.visible = false
	
	save_button.connect("pressed", self, "on_save_button_pressed")
	fork_button.connect("pressed", self, "on_fork_button_pressed")
	share_button.connect("pressed", self, "on_share_button_pressed")
	download_button.connect("pressed", self, "on_download_button_pressed")
	mode_options.connect("item_selected", self, "_mode_item_selected")
	dialog.connect("animated_out", self, "on_dialog_animated_out")
	delete_button.connect("pressed", self, "on_delete_button_pressed")
	publish_button.connect("pressed", self, "on_publish_button_pressed")
	download_button.visible = not OS.has_feature("mobile")

func on_fork_button_pressed():
	emit_signal("fork_button_pressed")
	on_save_button_pressed()

func on_delete_button_pressed():
	if _should_show_delete_button(showing_level_instance):
		_confirm_delete_level(showing_level_instance.level_id, showing_level_instance.level_name)

func _confirm_delete_level(level_id: String, level_name: String):
	emit_signal("deleting_level", level_id)
		
	var confirmation_dialog_scene: PackedScene = GoodResourceLoader.load_resource("res://goodoh/ui/nodes/UIConfirmationDialog.tscn")
	var confirm_dialog: UIConfirmationDialog = confirmation_dialog_scene.instance()
	confirm_dialog.text = "Are you sure you\nwant to delete\n\'%s\'?" % [level_name]
	confirm_dialog.default_focus_to_yes_button = false
	get_tree().current_scene.add_child(confirm_dialog)
	confirm_dialog.dialog.background_override = true
	confirm_dialog.dialog.dialog_title_label.text = "DELETE LEVEL"
	var confirmed: bool = yield(confirm_dialog, "confirm_or_cancel")
	if not confirmed:
		return
		
	var spinner_dialog_scene: PackedScene = GoodResourceLoader.load_resource("res://goodoh/ui/nodes/UISpinnerDialog.tscn")
	var spinner_dialog: UISpinnerDialog = spinner_dialog_scene.instance()
	get_tree().current_scene.add_child(spinner_dialog)
	spinner_dialog.text = ""
	spinner_dialog.dialog.dialog_title_label.text = "DELETING LEVEL"
	spinner_dialog.dialog.background_override = true

	var response: Dictionary = yield(LevelCloudLoader.async_delete_level(level_id), "completed")
	if response.has("error"):
		spinner_dialog.error(response["error"])
		return
	showing_level_instance.level_id = ""
	show_level_data(showing_level_instance)
	spinner_dialog.dialog.animate_out()
	emit_signal("deleted_level", level_id)

func on_publish_button_pressed():
	if showing_level_instance.level_published == "Private":
		_on_publish_button_pressed()
	elif showing_level_instance.level_published == "Public":
		_on_unpublish_button_pressed()
	else:
		show_cannot_unpublish_dialog()

func _on_unpublish_button_pressed():
	var confirm_dialog_scene: PackedScene = GoodResourceLoader.load_resource("res://goodoh/ui/nodes/UIConfirmationDialog.tscn")
	var confirm_dialog: UIConfirmationDialog = confirm_dialog_scene.instance()
	confirm_dialog.text = "Unpublish your level?\n\nUnpublishing resets the level\'s leaderboard and ratings, and allow changes to your level.\nAre you sure you want to unpublish?"
	get_tree().current_scene.add_child(confirm_dialog)
	var sdf_label: SDFLabel = confirm_dialog.label
	sdf_label.font_size = SDFLabel.FontSize._64
	confirm_dialog.yes_button.label_text = "UNPUBLISH"
	confirm_dialog.no_button.label_text = "CANCEL"
	confirm_dialog.dialog.dialog_title = "UNPUBLISH"
	confirm_dialog.dialog.panel.rect_size.y = 900
	
	var confirmed: bool = yield(confirm_dialog, "confirm_or_cancel")
	if confirmed:
		_write_level_data()
		showing_level_instance.level_published = "Private"
		
		
		var save_result: Dictionary = yield(save_current_level(), "completed")
		if not save_result.has("error"):
			var notify_dialog_scene: PackedScene = GoodResourceLoader.load_resource("res://goodoh/ui/nodes/UINotifyDialog.tscn")
			var notify_dialog: UINotifyDialog = notify_dialog_scene.instance()
			notify_dialog.text = "Your level has been unpublished."
			get_tree().current_scene.add_child(notify_dialog)
			notify_dialog.dialog.dialog_title = "LEVEL UNPUBLISHED"
	else:
		pass

func _on_publish_button_pressed():
	_write_level_data()
	if Moonlight.auth.is_guest_account():
		var save_result: Dictionary = yield(save_current_level(), "completed")
		if save_result.has("error"):
			printerr("[LevelEditor_SaveDialog] failed to save level %s" % [save_result])
			return
		var notify_dialog_scene: PackedScene = GoodResourceLoader.load_resource("res://goodoh/ui/nodes/UINotifyDialog.tscn")
		var notify_dialog: UINotifyDialog = notify_dialog_scene.instance()
		notify_dialog.text = "You must SIGN UP to publish your Levels!\n\nGo to the Home scene and SIGN UP!"
		get_tree().current_scene.add_child(notify_dialog)
		notify_dialog.dialog.dialog_title = "SIGN UP"
		yield(notify_dialog, "confirmed")
		return
	
	var confirm_dialog_scene: PackedScene = GoodResourceLoader.load_resource("res://goodoh/ui/nodes/UIConfirmationDialog.tscn")
	var confirm_dialog: UIConfirmationDialog = confirm_dialog_scene.instance()
	if showing_level_instance.level_type == LevelUtils.LevelType.RACE:
		
		confirm_dialog.text = "FINISH your level ONCE to set the first leaderboard time and publish it!\n\nOnce published, your level will be LOCKED and added to the NEW list.\n\nAre you sure your level is ready to be PUBLISHED?"
	else:
		confirm_dialog.text = "Once published, your level will be LOCKED and added to the NEW list.\n\nAre you sure your level is ready to be PUBLISHED?"
	get_tree().current_scene.add_child(confirm_dialog)
	var sdf_label: SDFLabel = confirm_dialog.label
	sdf_label.font_size = SDFLabel.FontSize._64
	confirm_dialog.yes_button.label_text = "LETS DO IT"
	confirm_dialog.no_button.label_text = "CANCEL"
	confirm_dialog.dialog.dialog_title = "PUBLISH LEVEL"
	confirm_dialog.dialog.panel.rect_size.y = 1000
	
	var confirmed: bool = yield(confirm_dialog, "confirm_or_cancel")
	if not confirmed:
		return

	if showing_level_instance.level_type != LevelUtils.LevelType.RACE:
		
		showing_level_instance.level_published = "Public"
	var save_result: Dictionary = yield(save_current_level(), "completed")
	if save_result.has("error"):
		printerr("[LevelEditor_SaveDialog] failed to save level %s" % [save_result])
		return
	
	if showing_level_instance.level_type != LevelUtils.LevelType.RACE:
		
		var notify_dialog_scene: PackedScene = GoodResourceLoader.load_resource("res://goodoh/ui/nodes/UINotifyDialog.tscn")
		var notify_dialog: UINotifyDialog = notify_dialog_scene.instance()
		notify_dialog.text = "AWESOME!\nYour level has been published!\nNice work!"
		get_tree().current_scene.add_child(notify_dialog)
		notify_dialog.dialog.dialog_title = "LEVEL PUBLISHED"
	else:
		
		
		yield(ScreenTransitions.fade_in(), "completed")
		var level_data: = LevelJson.serialize_level(showing_level_instance)
		var time_trial_scene_parameters: = TimeTrialSceneParameters.new()
		time_trial_scene_parameters.level_id = showing_level_instance.level_id
		time_trial_scene_parameters.level_data = level_data
		time_trial_scene_parameters.level_data_string = to_json(level_data)
		time_trial_scene_parameters.mode = TimeTrialSceneParameters.TimeTrialSceneMode.PrepublishRun
		var time_trial_packed_scene: PackedScene = load("res://scenes/TimeTrialGameplayScene.tscn")
		var time_trial_scene: TimeTrialGameplayScene = time_trial_packed_scene.instance()
		time_trial_scene.parameters = time_trial_scene_parameters
		ScreenTransitions.swap_to_scene_node(time_trial_scene)



	
























func _mode_item_selected(index: int):
	_write_level_data()

func on_dialog_animated_out():
	showing_level_instance = null

func show_level_data(level_instance: LevelInstance):
	showing_level_instance = level_instance
	name_line_edit.text = level_instance.level_name
	player_count_line_edit.text = str(level_instance.max_players)
	mode_options.selected = mode_options.get_item_index(level_instance.level_type)
	
	if WinterpixelUser.is_winterpixel_user():
		
		
		curated_parent.visible = true
		var published_state_index: int = LevelPublishedState.Private
		match showing_level_instance.level_published:
			"Private":
				published_state_index = LevelPublishedState.Private
			"Public":
				published_state_index = LevelPublishedState.Public
			"Curated":
				published_state_index = LevelPublishedState.Curated
				
		curated_option_button.select(curated_option_button.get_item_index(published_state_index))
		author_overwrite_container.visible = true
		author_overwrite_line_edit.text = level_instance.author_id
	else:
		curated_parent.visible = false
		author_overwrite_container.visible = false
	
	
	delete_button.disabled = not _should_show_delete_button(showing_level_instance)
	if level_instance.level_published == "Public" or level_instance.level_published == "Curated":
		publish_button.label_text = "UNPUBLISH"
	else:
		publish_button.label_text = "PUBLISH"

func _should_show_delete_button(level_instance: LevelInstance) -> bool:
	if level_instance.level_id.empty():
		return false
	if Moonlight.local_account == null:
		return false
	if Moonlight.local_user_id() == WinterpixelUser.winterpixel_userid:
		return true
	if level_instance.author_id != Moonlight.local_account.user.id:
		return false
	if level_instance.level_published != "Private":
		return false
	return true

func _write_level_data():
	
	var is_already_curated: = showing_level_instance.level_published == "Curated"
	if WinterpixelUser.is_winterpixel_user():
		if not author_overwrite_line_edit.text.empty():
			showing_level_instance.author_id = author_overwrite_line_edit.text
		
		match curated_option_button.selected:
			LevelPublishedState.Private:
				showing_level_instance.level_published = "Private"
			LevelPublishedState.Public:
				showing_level_instance.level_published = "Public"
			LevelPublishedState.Curated:
				showing_level_instance.level_published = "Curated"
			_:
				pass
	
	
	showing_level_instance.level_type = mode_options.selected
	
	
	showing_level_instance.level_name = name_line_edit.text

func on_save_button_pressed():
	_write_level_data()
	emit_signal("save_button_pressed")
	save_current_level()

func on_share_button_pressed():
	
	share_current_level()
	emit_signal("share_button_pressed")

func share_current_level():
	var level_id: String = showing_level_instance.level_id
	if level_id.empty():
		_write_level_data()
		var save_result: Dictionary = yield(save_current_level(), "completed")
		if save_result.has("error"):
			return
	var share_dialog_scene: PackedScene = GoodResourceLoader.load_resource("res://project_specific/level_editor/ShareLevelDialog.tscn")
	var share_dialog: ShareLevelDialog = share_dialog_scene.instance()
	get_tree().current_scene.add_child(share_dialog)
	share_dialog.dialog.background_override = true
	share_dialog.share_url = ShareLevelDialog.share_url_play_level_id(showing_level_instance.level_id)

func save_current_level() -> Dictionary:
	var spinner_dialog_scene: PackedScene = GoodResourceLoader.load_resource("res://goodoh/ui/nodes/UISpinnerDialog.tscn")
	var spinner_dialog: UISpinnerDialog = spinner_dialog_scene.instance()
	get_tree().current_scene.add_child(spinner_dialog)
	spinner_dialog.text = ""
	spinner_dialog.dialog.dialog_title_label.text = "SAVING"
	spinner_dialog.dialog.background_override = true
	var save_result: Dictionary = yield(LevelLoader.async_save_level_to_cloud(showing_level_instance), "completed")
	if save_result.has("error"):
		var error_message: String = save_result["error"]
		if not WinterpixelUser.is_winterpixel_user():
			var is_already_curated: = showing_level_instance.level_published == "Curated"
			if is_already_curated:
				error_message = "This level has been CERTIFIED by WINTERPIXEL!\n\nIt can\'t be updated!nSubmit your level as a NEW LEVEL!"
		spinner_dialog.error(error_message)
		return save_result
	spinner_dialog.dialog.animate_out()
	show_level_data(showing_level_instance)
	return save_result

func on_download_button_pressed():
	_write_level_data()
	LevelLoader.save_local_level(showing_level_instance, LevelLoader.LevelLoadLocation.Local)
	if not OS.has_feature("web") and not OS.has_feature("Android") and not OS.has_feature("iOS"):
		
		var final_path: = ProjectSettings.globalize_path(LevelLoader.levels_local_save_path)
		OS.shell_open(final_path)

func show_cannot_unpublish_dialog():
	var notify_dialog_scene: PackedScene = GoodResourceLoader.load_resource("res://goodoh/ui/nodes/UINotifyDialog.tscn")
	var notify_dialog: UINotifyDialog = notify_dialog_scene.instance()
	notify_dialog.text = "This level has been CERTIFIED by WINTERPIXEL!\n\nIt can\'t be updated!"
	get_tree().current_scene.add_child(notify_dialog)
	notify_dialog.dialog.dialog_title = "LEVEL CERTIFIED"
