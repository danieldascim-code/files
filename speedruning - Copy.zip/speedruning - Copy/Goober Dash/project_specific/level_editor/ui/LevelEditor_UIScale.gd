extends Control
onready var parent_control: = get_parent_control()

export  var constant_update: = true
export  var enabled: = true


func _ready() -> void :
	get_viewport().connect("size_changed", self, "on_size_changed")
	_apply_scale()
	call_deferred("_apply_scale")
	


func on_size_changed():
	_apply_scale()

func _apply_scale():
	
	
	
	var scale_factor: = 1.0 / get_viewport().get_final_transform().get_scale().x
	var scale_factor2: = scale_factor
	





	scale_factor = scale_factor * 0.5
	
	if is_zero_approx(scale_factor):
		scale_factor = 1.0
	
	if not enabled:
		scale_factor = 1.0
	
	
	rect_scale = scale_factor * Vector2.ONE
	rect_size = parent_control.rect_size / scale_factor

func _process(delta: float) -> void :
	if constant_update:
		_apply_scale()
