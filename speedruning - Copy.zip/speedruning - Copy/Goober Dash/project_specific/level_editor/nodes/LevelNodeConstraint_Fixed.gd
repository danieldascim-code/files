tool 
extends LevelNodeConstraint
class_name LevelNodeConstraint_Fixed

export  var fixed_width: = 1
export  var fixed_height: = 1

func _compute_bounding_box(block_start: Int2, block_end: Int2, shape_rotation: int) -> void :
	var x_length: = abs(block_end.x - block_start.x)
	var y_length: = abs(block_end.y - block_start.y)
	var modded_block_start: = block_start.copy()
	if shape_rotation % 2 == 0:
		modded_block_start.x = block_end.x - fixed_width + 1
		modded_block_start.y = block_end.y - fixed_height + 1
	else:
		modded_block_start.x = block_end.x - fixed_height + 1
		modded_block_start.y = block_end.y - fixed_width + 1
	
	
	
	
	block_start.assign(block_end)
	block_end.maximum(modded_block_start).plus2(1, 1)
	block_start.minimum(modded_block_start)
