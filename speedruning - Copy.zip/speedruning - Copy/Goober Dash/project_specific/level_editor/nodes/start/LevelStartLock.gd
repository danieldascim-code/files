tool 
extends Node2D
class_name LevelStartLock

export  var _level_node: NodePath
onready var level_node: = get_node(_level_node) as LevelNode

var locked_in: = false

onready var top: = $LockYouIn / LevelFloorTop as LevelNode
onready var bottom: = $LockYouIn / LevelFloorBottom as LevelNode
onready var left: = $LockYouIn / LevelFloorLeft as LevelNode
onready var right: = $LockYouIn / LevelFloorRight as LevelNode
onready var top_out: = $LockYouOut / LevelFloorTop as LevelNode
onready var bottom_out: = $LockYouOut / LevelFloorBottom as LevelNode
onready var left_out: = $LockYouOut / LevelFloorLeft as LevelNode
onready var right_out: = $LockYouOut / LevelFloorRight as LevelNode

func _fetch_nodes():
	if not top:
		top = $LockYouIn / LevelFloorTop as LevelNode
	if not bottom:
		bottom = $LockYouIn / LevelFloorBottom as LevelNode
	if not left:
		left = $LockYouIn / LevelFloorLeft as LevelNode
	if not right:
		right = $LockYouIn / LevelFloorRight as LevelNode
	if not top_out:
		top_out = $LockYouOut / LevelFloorTop as LevelNode
	if not bottom_out:
		bottom_out = $LockYouOut / LevelFloorBottom as LevelNode
	if not left_out:
		left_out = $LockYouOut / LevelFloorLeft as LevelNode
	if not right_out:
		right_out = $LockYouOut / LevelFloorRight as LevelNode

func _ready():
	level_node.connect("apply_bounding_box", self, "apply_bounding_box")
	_set_locked_in(true, true)
	set_as_toplevel(true)

func set_locked_in(b: bool):
	
	_set_locked_in(b, true)

func _set_locked_in(b: bool, force: bool):
	if force or locked_in != b:
		locked_in = b
		
		top.body.enabled = b
		bottom.body.enabled = b
		left.body.enabled = b
		right.body.enabled = b
		top.visible = b
		bottom.visible = b
		left.visible = b
		right.visible = b
		
		var enable_lock_out: = false
		top_out.body.enabled = enable_lock_out
		bottom_out.body.enabled = enable_lock_out
		left_out.body.enabled = enable_lock_out
		right_out.body.enabled = enable_lock_out
		top_out.visible = enable_lock_out
		bottom_out.visible = enable_lock_out
		left_out.visible = enable_lock_out
		right_out.visible = enable_lock_out

func apply_bounding_box():
	
	setup_lock_you_in()
	setup_lock_you_out()

func setup_lock_you_in():
	top.shape_rotation = 2
	top.bounding_box_min.assign2(level_node.bounding_box_min.x, level_node.bounding_box_min.y - 1)
	top.bounding_box_max.assign2(level_node.bounding_box_max.x, level_node.bounding_box_min.y)
	top._update_bounding_box()
	
	left.shape_rotation = 1
	left.bounding_box_min.assign2(level_node.bounding_box_min.x - 1, level_node.bounding_box_min.y)
	left.bounding_box_max.assign2(level_node.bounding_box_min.x, level_node.bounding_box_max.y)
	left._update_bounding_box()
	
	right.shape_rotation = 3
	right.bounding_box_min.assign2(level_node.bounding_box_max.x, level_node.bounding_box_min.y)
	right.bounding_box_max.assign2(level_node.bounding_box_max.x + 1, level_node.bounding_box_max.y)
	right._update_bounding_box()
	
	bottom.shape_rotation = 0
	bottom.bounding_box_min.assign2(level_node.bounding_box_min.x, level_node.bounding_box_max.y)
	bottom.bounding_box_max.assign2(level_node.bounding_box_max.x, level_node.bounding_box_max.y + 1)
	bottom._update_bounding_box()

func setup_lock_you_out():
	top_out.shape_rotation = 0
	top_out.bounding_box_min.assign2(level_node.bounding_box_min.x, level_node.bounding_box_min.y)
	top_out.bounding_box_max.assign2(level_node.bounding_box_max.x, level_node.bounding_box_min.y)
	top_out._update_bounding_box()
	
	left_out.shape_rotation = 3
	left_out.bounding_box_min.assign2(level_node.bounding_box_min.x, level_node.bounding_box_min.y)
	left_out.bounding_box_max.assign2(level_node.bounding_box_min.x + 1, level_node.bounding_box_max.y)
	left_out._update_bounding_box()
	
	right_out.shape_rotation = 1
	right_out.bounding_box_min.assign2(level_node.bounding_box_max.x - 1, level_node.bounding_box_min.y)
	right_out.bounding_box_max.assign2(level_node.bounding_box_max.x, level_node.bounding_box_max.y)
	right_out._update_bounding_box()
	
	bottom_out.shape_rotation = 2
	bottom_out.bounding_box_min.assign2(level_node.bounding_box_min.x, level_node.bounding_box_max.y - 1)
	bottom_out.bounding_box_max.assign2(level_node.bounding_box_max.x, level_node.bounding_box_max.y)
	bottom_out._update_bounding_box()
