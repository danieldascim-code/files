extends Node

onready var parent: = get_parent() as Node2D

export  var _level_node: NodePath
onready var level_node: = get_node(_level_node) as LevelNode

export  var base_scale: = Vector2.ONE

export  var margin_left: = 0.0
export  var margin_right: = 0.0
export  var margin_top: = 0.0
export  var margin_bottom: = 0.0

func _init():
	if is_inside_tree():
		parent = get_parent()
		level_node = get_node(_level_node) as LevelNode

func _ready():
	level_node.connect("apply_bounding_box", self, "on_apply_bounding_box")
	on_apply_bounding_box()

func on_apply_bounding_box():
	var margin_scale: = Vector2(margin_left + margin_right, margin_top + margin_bottom)
	var s: = base_scale + margin_scale / level_node.scale
	parent.scale = s
	parent.position.x = 0.5 * (margin_left - margin_right)
	parent.position.y = 0.5 * (margin_top - margin_bottom)
