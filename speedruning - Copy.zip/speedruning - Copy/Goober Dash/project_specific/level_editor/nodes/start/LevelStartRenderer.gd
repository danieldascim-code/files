extends Node2D

onready var wp_game: = Utilities.find_game(self, false) as WPGame

onready var thicker_outline: Node2D = $Root / ThickerOutline
onready var root_node: Node2D = $Root

export  var _level_node: NodePath
onready var level_node: = get_node(_level_node) as LevelNode

export  var _level_editor_selected_renderer: NodePath
onready var level_editor_selected_renderer: = get_node(_level_editor_selected_renderer) as Control

export  var _level_editor_player_count_label: NodePath
onready var level_editor_player_count_label: = get_node(_level_editor_player_count_label) as SDFLabel

export  var _level_editor_player_spawn_location_template: NodePath
onready var level_editor_player_spawn_location_template: Control = get_node(_level_editor_player_spawn_location_template)

var player_spawn_locations: = []

var was_in_regular_pre_play: = false


func _ready() -> void :
	level_editor_selected_renderer.visible = false
	
	var scene = get_tree().current_scene
	var level_editor: LevelEditor = null
	if scene != null:
		if scene is LevelEditor:
			level_editor = scene as LevelEditor
		if not level_editor:
			level_editor = scene.get_node_or_null("LevelEditor")
	
	if level_editor != null:
		var select_tool: = level_editor.tool_select as LevelEditorToolSelect
		select_tool.connect("selected_nodes_changed", self, "on_selected_nodes_changed", [select_tool])
		level_node.connect("apply_bounding_box", self, "on_apply_bounding_box")
		root_node.visible = true
	else:
		root_node.visible = false
	level_editor_player_spawn_location_template.visible = false

func on_selected_nodes_changed(selected_nodes: Array, select_tool: LevelEditorToolSelect):
	var should_show: bool = level_node in selected_nodes
	level_editor_selected_renderer.visible = should_show
	on_apply_bounding_box()

func on_apply_bounding_box():
	if level_editor_selected_renderer and level_editor_selected_renderer.visible:
		var v: = LevelGrid.players_per_starting_block(level_node.world_rect.size)
		var n: = floor(v.x * v.y)
		if level_editor_player_count_label:
			level_editor_player_count_label.text = str(n)
		
		if level_editor_player_spawn_location_template:
			while player_spawn_locations.size() != n:
				if player_spawn_locations.size() > n:
					player_spawn_locations.pop_back().queue_free()
				if player_spawn_locations.size() < n:
					var new_node: Control = level_editor_player_spawn_location_template.duplicate()
					new_node.mouse_filter = Control.MOUSE_FILTER_IGNORE
					level_editor_player_spawn_location_template.get_parent().add_child(new_node)
					new_node.visible = true
					player_spawn_locations.append(new_node)
			
			for i in n:
				var spawn_location_indicator: Control = player_spawn_locations[i]
				spawn_location_indicator.rect_position = WPGame._compute_starting_point_position(level_node.world_rect.size, i)
