
extends Node2D
class_name LevelNodeShadow

onready var parent_renderer: Node2D = get_parent()

export  var offset: = Vector2(5.0, 5.0)





func _process(delta: float) -> void :
	if visible:
		var r: = parent_renderer.global_rotation
		var s: = parent_renderer.global_scale
		position = offset.rotated( - r) / s
