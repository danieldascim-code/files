shader_type canvas_item;

uniform vec2 world_size = vec2(50.0, 50.0);
uniform vec2 scale = vec2(1.0, 1.0);
uniform vec2 mask_scale_factor = vec2(1.0, 1.0);
uniform vec2 pattern_scale = vec2(1.0, 1.0);
uniform float speed = 1.0;
uniform sampler2D mask;

uniform int mask_margin_right;
uniform int mask_margin_top;
uniform int mask_margin_left;
uniform int mask_margin_bottom;

float map(float value, float originalMin, float originalMax, float newMin, float newMax) {
    return (value - originalMin) / (originalMax - originalMin) * (newMax - newMin) + newMin;
} 

float process_axis(float coord, float pixel, float texture_pixel, float start, float end) {
	if (coord > 1.0 - end * pixel) {
		return map(coord, 1.0 - end * pixel, 1.0, 1.0 - texture_pixel * end, 1.0);
	} else if (coord > start * pixel) {
		return map(coord, start * pixel, 1.0 - end * pixel, start * texture_pixel, 1.0 - end * texture_pixel);
	} else {
		return map(coord, 0.0, start * pixel, 0.0, start * texture_pixel);
	}
}

vec2 nineslice_mask_uv(vec2 uv) {
	ivec2 texture_size_i = textureSize(mask, 0);
	vec2 texture_size = vec2(float(texture_size_i.x), float(texture_size_i.y));
	vec2 pixel_size = 1.0 / texture_size;
	vec2 scaled_pixel_size = pixel_size / scale * mask_scale_factor;
	
	vec2 mapped_uv = vec2(
		process_axis(uv.x, scaled_pixel_size.x, pixel_size.x, float(mask_margin_left), float(mask_margin_right)),
		process_axis(uv.y, scaled_pixel_size.y, pixel_size.y, float(mask_margin_top), float(mask_margin_bottom))
	);
	return mapped_uv;
}

void fragment()
{
	ivec2 tex_size = textureSize(TEXTURE, 0);
	vec2 tex_size_f = vec2(float(tex_size.x), float(tex_size.y));
	vec2 uv = UV * pattern_scale * world_size / tex_size_f + vec2(0.0, speed * TIME);
	
	COLOR = texture(TEXTURE, uv);
	vec2 mask_uv = nineslice_mask_uv(UV);
	vec4 mask_sample = texture(mask, mask_uv);
	COLOR.a *= mask_sample.r;
	//COLOR = vec4(mask_uv.x, mask_uv.y, 1.0, 1.0);
}