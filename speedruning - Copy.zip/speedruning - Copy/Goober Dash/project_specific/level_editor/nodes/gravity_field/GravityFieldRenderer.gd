extends Node2D
onready var level_node: = get_parent() as GravityField

onready var shader_material: ShaderMaterial = $MeshInstance2D.material

const world_size_key: = "world_size"
const scale_key: = "scale"
const speed_key: = "speed"
const strength_key: = "strength"

func _ready() -> void :
	_update_shader()
	level_node.connect("apply_bounding_box", self, "_update_shader")
	level_node.connect("level_node_property_changed", self, "on_level_node_property_changed")

func on_level_node_property_changed(property_name: String, value):
	if property_name == strength_key:
		_update_shader()

func _update_shader():
	var absolute_rotated_size: = level_node.world_rect.size.rotated(level_node.shape_rotation * PI * 0.5)
	absolute_rotated_size.x = abs(absolute_rotated_size.x)
	absolute_rotated_size.y = abs(absolute_rotated_size.y)
	shader_material.set_shader_param(world_size_key, absolute_rotated_size)
	var scale2: = absolute_rotated_size / LevelGrid2.cell_size
	shader_material.set_shader_param(scale_key, scale2)
	shader_material.set_shader_param(speed_key, range_lerp(level_node.strength, 1.0, 5.0, 2.0, 4.0))
