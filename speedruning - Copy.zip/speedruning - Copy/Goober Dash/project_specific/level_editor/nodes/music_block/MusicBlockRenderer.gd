extends UpGuys_MusicBlockRenderer

onready var body: Box2DPhysicsBody = get_node("../Box2DPhysicsBody")
onready var game: WPGame = Utilities.find_game(self, false) as WPGame
onready var level_node: LevelNode = get_parent()
onready var audio_player: AudioStreamPlayer2D = $AudioStreamPlayer2D
onready var background: Node2D = $Node2D / Background
onready var foreground: Node2D = $Node2D / Foreground
onready var root: Node2D = $Node2D

const scale_s: = "scale"
const modulate_s: = "modulate"
const rotation_s: = "rotation"
const object_id_s: = "object_id"

var music_files: = [
	"res://project_specific/level_editor/nodes/music_block/sounds/28_C_131hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/29_Db_139hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/30_D_147hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/31_Eb_156hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/32_E_165hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/33_F_175hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/34_Gb_185hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/35_G_196hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/36_Ab_208hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/37_A_220hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/38_Bb_233hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/39_B_247hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/40_C_262hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/41_Db_277hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/42_D_294hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/43_Eb_311hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/44_E_330hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/45_F_349hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/46_Gb_370hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/47_G_392hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/48_Ab_415hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/49_A_440hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/50_Bb_466hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/51_B_494hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/52_C_523hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/53_Db_554hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/54_D_587hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/55_Eb_622hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/56_E_659hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/57_F_698hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/58_Gb_740hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/59_G_784hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/60_Ab_831hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/61_A_880hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/62_Bb_932hz.ogg", 
	"res://project_specific/level_editor/nodes/music_block/sounds/63_B_988hz.ogg", 
]

var tween: SceneTreeTween

var flash_color: = Color.white
var background_color: = Color.white

func _ready() -> void :
	
	level_node.connect("level_node_property_changed", self, "on_level_node_property_changed")
	
	_apply_music_note()

func _apply_music_note():
	var music_block: = (level_node as MusicBlock)
	var note: int = music_block.music_note
	var note_cycled: int = note % 12
	var note_octave: int = int(note / 12)
	var value: = float(note) / music_files.size()
	var hue: = range_lerp(float(note_cycled), 0, 11.0, 0.9, 0.0)
	flash_color = Color().from_hsv(hue, 0.5, 1.0)
	if flash_color.get_luminance() > 0.9:
		
		flash_color = flash_color.darkened(0.2)
	foreground.modulate = flash_color
	background.modulate = Color.white
	audio_player.stream = load(music_files[note])

func on_level_node_property_changed(k: String, v):
	if k == "note":
		_apply_music_note()

func music_play():
	audio_player.play()
	if tween and tween.is_valid():
		tween.kill()
	tween = create_tween()
	
	tween.set_parallel(true)
	tween.tween_property(root, scale_s, Vector2.ONE * 1.05, 0.2).from(Vector2.ONE).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_EXPO)
	tween.tween_property(root, scale_s, Vector2.ONE, 0.2).set_delay(0.2).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_EXPO)
	
	tween.tween_property(foreground, modulate_s, flash_color, 0.1).from(Color.white)
	
	tween.tween_property(background, modulate_s, background_color, 0.1).from(flash_color)
	shake_tween()


var _shake_tween: SceneTreeTween
func shake_tween():
	if _shake_tween != null and _shake_tween.is_valid():
		_shake_tween.kill()
	_shake_tween = create_tween()
	GoodTweens.shake_tween(_shake_tween, self, rotation_s, 0.0, deg2rad(7.5), 3, 0.5, randi() %2 == 0)
