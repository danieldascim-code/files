extends Node
class_name LevelCheckpoint_SensorPosition

onready var parent_fixture: = get_parent() as Box2DFixture
onready var parent_fixture_rect: = parent_fixture.shape as Box2DRectShape
export  var _level_node: NodePath
onready var level_node: = get_node(_level_node) as LevelNode
const closer_buffer: = 5.0
var wp_game_data: WPGameData

func _ready():
	var game: WPGame = Utilities.find_game(self, false)
	if game:
		level_node.connect("apply_bounding_box", self, "on_apply_bounding_box")
		wp_game_data = game.wp_game_data

func on_apply_bounding_box():
	var player_size_along_normal: = abs(wp_game_data.player_size.dot(Vector2.UP.rotated(level_node.shape_rotation * 0.5 * PI)))
	var sensor_offset: = - 0.5 * (LevelGrid.cell_size + parent_fixture_rect.size.y)
	var sensor_position: = sensor_offset - player_size_along_normal
	parent_fixture.position.y = sensor_position + closer_buffer
