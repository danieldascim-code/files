extends Node2D

onready var level_node: = get_parent() as LevelNode


onready var game: = Utilities.find_game(self, false) as WPGame
var world: UpguysBox2DWorld
onready var contact_point_animation: = $ContactPointAnimation as Node2D

export  var default_color: = Color.white
export  var active_color: = Color.green

export (Array, NodePath) var _tint_nodes: = []
var tint_nodes: = []
var last_active: = false
onready var terrain_color: = active_color
onready var hit_checkpoint_player: AudioStreamPlayer = $HitCheckpointPlayer
onready var hit_checker_animation_player: AnimationPlayer = $AnimationPlayer

const hit_checker_animation_name: = "player_hit"
const checker_modulate_track: = "Checker:self_modulate"
func _ready():
	if game:
		world = game.get_node("Box2DWorld")
	level_node.connect("apply_theme", self, "on_apply_theme")
	for t in _tint_nodes:
		var n: = get_node(t)
		if n is CanvasItem:
			tint_nodes.append(n)
	contact_point_animation.visible = false
	tint_those_nodes(default_color)

func on_apply_theme(t: BaseTheme):
	terrain_color = t.terrain_color_1

func _process(delta):
	if not visible:
		return
	var is_active: = false
	
	if not game or not world:
		return
	
	var local_player: = game.get_local_player() as WPPlayer
	if not local_player:
		return
	if local_player.last_checkpoint == level_node.level_node_index + 1:
		is_active = true
	
	if last_active != is_active:
		last_active = is_active
		var c: = default_color
		if is_active:
			c = active_color
		tint_those_nodes(c)
		
		if is_active:
			hit_checkpoint_player.play()
			
			
			
			var new_contact_point_animation: = contact_point_animation.duplicate() as Node2D
			get_parent().add_child(new_contact_point_animation)
			new_contact_point_animation.set_as_toplevel(true)
			new_contact_point_animation.visible = true
			new_contact_point_animation.position = world.get_checkpoint_position(local_player)
			
			
			var new_particles: = new_contact_point_animation.get_node("Particles2D") as Particles2D
			new_particles.emitting = true
			
			
			var player_color: = Color.white
			if game.client_renderer:
				var player_renderer: = game.client_renderer.get_renderer_for_object_id(local_player.object_id) as UpGuys_PlayerRenderer
				if player_renderer:
					player_color = player_renderer.spine.get_tint().lightened(0.2)
			
			var animation: = hit_checker_animation_player.get_animation(hit_checker_animation_name)
			var track_index: int = animation.find_track("Checker:self_modulate")
			animation.track_set_key_value(track_index, 0, player_color)
			hit_checker_animation_player.play(hit_checker_animation_name)
			
			new_contact_point_animation.modulate = active_color
			yield(get_tree().create_timer(2.0 * new_particles.lifetime), "timeout")
			new_particles.queue_free()

func tint_those_nodes(c: Color):
	for n in tint_nodes:
		n.modulate = c
	
