tool 
extends WPBox2DFixture
class_name LevelNodeBox2DCircleShapeMargin

export  var _level_node: NodePath
onready var level_node: = get_node(_level_node) as LevelNode
onready var circle_shape: = shape as Box2DCircleShape

export  var margin: = 0.0

func _ready() -> void :
	if level_node:
		level_node.connect("apply_bounding_box", self, "on_apply_bounding_box")
	
	var should_process: = Engine.editor_hint
	set_process(should_process)

func on_apply_bounding_box():
	var diameter: = LevelGrid.cell_size - margin / level_node.scale.x
	circle_shape.radius = 0.5 * diameter

func _process(delta: float) -> void :
	if level_node and owner == level_node:
		on_apply_bounding_box()
	
