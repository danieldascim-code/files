extends Node2D
class_name LevelSignRenderer

onready var level_node: LevelNode = get_parent()
onready var wp_game: WPGame = Utilities.find_game(self)
onready var message_anchor: Control = $MessageAnchor
onready var label: Label = $MessageAnchor / NinePatchRect / LevelSignMessageLabel

signal sign_shown()
signal sign_hidden()
signal sign_shown_or_hidden(shown)

func _ready() -> void :
	message_anchor.rect_scale = Vector2(1.0, 0.0)
	message_anchor.hide()
	if wp_game:
		pass
	level_node.connect("level_node_property_changed", self, "on_level_node_property_changed")
	
	var message_prop = level_node.get_level_node_property("message")
	if message_prop != null:
		label.text = message_prop

func on_level_node_property_changed(property_name: String, property_value):
	if property_name == "message":
		label.text = property_value

var tween: SceneTreeTween
var is_showing: = false

func _process(delta: float) -> void :
	if not visible:
		return
	if wp_game:
		var should_show: = false
		var l: WPPlayer = wp_game.get_local_player()
		if l:
			if l.alive:
				var radius: = 125.0
				if l.position.distance_squared_to(level_node.world_rect.get_center()) <= radius * radius:
					should_show = true
		
		if should_show != is_showing:
			if tween != null:
				if tween.is_valid():
					tween.kill()
					tween = null
			tween = create_tween()
			if should_show:
				tween.tween_callback(message_anchor, "show")
				tween.tween_property(message_anchor, "rect_scale", Vector2.ONE, 0.25).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_EXPO)
			else:
				tween.tween_property(message_anchor, "rect_scale", Vector2(0.0, 0.0), 0.25).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_EXPO)
				tween.tween_callback(message_anchor, "hide")
			
			is_showing = should_show
			emit_signal("sign_shown_or_hidden", is_showing)
			if is_showing:
				emit_signal("sign_shown")
			else:
				emit_signal("sign_hidden")
