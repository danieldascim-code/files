tool 
extends LevelNodeConstraint
class_name LevelNodeConstraint_Skinny

func _compute_bounding_box(block_start: Int2, block_end: Int2, shape_rotation: int) -> void :
	
	
	var x_length: = abs(block_end.x - block_start.x)
	var y_length: = abs(block_end.y - block_start.y)
	var modded_block_end: = block_end.copy()
	if x_length >= y_length:
		
		modded_block_end.y = block_start.y
	else:
		
		modded_block_end.x = block_start.x
	
	block_end.assign(block_start)
	block_start.minimum(modded_block_end)
	block_end.maximum(modded_block_end).plus2(1, 1)
