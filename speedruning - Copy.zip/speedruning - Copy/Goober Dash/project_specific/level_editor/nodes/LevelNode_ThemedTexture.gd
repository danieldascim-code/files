extends Node
class_name LevelNode_ThemedTexture

export  var _level_node: NodePath
onready var level_node: = get_node(_level_node) as LevelNode

export  var theme_property_name: = "some_themed_thing"
var default_texture: Texture

onready var target_node: = get_parent() as Node
export  var texture_property_name: = "texture"

func _ready():
	level_node.connect("apply_theme", self, "on_apply_theme")
	if not texture_property_name in target_node:
		printerr("[LevelNode_ThemedTexture] property_name %s is invalid on node %s" % [texture_property_name, get_path()])
		return

	var tex = target_node.get(texture_property_name)
	if not tex is Texture:
		printerr("[LevelNode_ThemedTexture] property_name %s is not a texture on node %s" % [texture_property_name, get_path()])

	default_texture = target_node.get(texture_property_name)

func on_apply_theme(level_theme: BaseTheme):
	var t: Texture = level_theme.get(theme_property_name)
	if t == null:
		t = default_texture
		
	
	target_node.set(texture_property_name, t)
