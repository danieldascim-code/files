tool 
extends LevelNodeConstraint
class_name LevelNodeConstraint_Square

func _compute_bounding_box(block_start: Int2, block_end: Int2, shape_rotation: int) -> void :
	
	var x_length: = block_end.x - block_start.x
	var y_length: = block_end.y - block_start.y

	var x_sign: = sign(x_length)
	if x_length == 0:
		x_sign = 1
	var y_sign: = sign(y_length)
	if y_length == 0:
		y_sign = 1
	var total_sign: = x_sign * y_sign
	
	var modded_block_end: = block_end.copy()
	var delta: = (x_length * total_sign)
	modded_block_end.y = block_start.y + delta
	
	block_end.assign(block_start)
	block_start.minimum(modded_block_end)
	block_end.maximum(modded_block_end).plus2(1, 1)
