tool 
extends LevelNodeConstraint
class_name LevelNodeConstraint_MinSize

export  var min_size_x: = 1
export  var min_size_y: = 1

func _compute_bounding_box(block_start: Int2, block_end: Int2, shape_rotation: int) -> void :

	var modded_block_start = block_start.copy().minimum(block_end)
	var modded_block_end = block_start.copy().maximum(block_end).plus2(1, 1)
	
	var x_length: = abs(modded_block_end.x - modded_block_start.x)
	var y_length: = abs(modded_block_end.y - modded_block_start.y)
	
	if (y_length < min_size_y):
		modded_block_end.plus2(0, min_size_y - y_length)
	if (x_length < min_size_x):
		modded_block_end.plus2(min_size_x - x_length, 0)

	
	block_start.assign(modded_block_start)
	block_end.assign(modded_block_end)
	
	
	
