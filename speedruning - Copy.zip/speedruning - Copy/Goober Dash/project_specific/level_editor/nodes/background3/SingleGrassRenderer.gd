extends Node2D
class_name SingleGrassRenderer

onready var rotation_pivot: Node2D = $RotationPivot
onready var nine_blade: NinePatchRect = $RotationPivot / NinePatchRect

onready var rotation_pivot2: Node2D = $RotationPivot2
onready var nine_blade2: NinePatchRect = $RotationPivot2 / NinePatchRect

var tween: SceneTreeTween
var tween2: SceneTreeTween
const _rotation_degrees_s: = "rotation_degrees"

func apply_colors(c: Color, c2: Color):
	nine_blade.self_modulate = c
	nine_blade2.self_modulate = c2

func make_blades(cell_delta: Vector2):
	var max_blade_size: = 100.0
	var inverse_scale: = 1.0
	
	var front_x_delta: = 0.125
	rotation_pivot2.position.x = inverse_scale * cell_delta.x * rand_range( - front_x_delta, front_x_delta)
	nine_blade2.rect_size.y = int(max_blade_size * rand_range(0.6, 1.0))
	
	var rear_x_delta: = 0.25
	var random_sign: = 1.0
	if randi() %2 == 1:
		random_sign = - 1.0
	rotation_pivot.position.x = rotation_pivot2.position.x + inverse_scale * cell_delta.x * random_sign * rand_range(rear_x_delta * 0.5, rear_x_delta)
	nine_blade.rect_size.y = int(max_blade_size * rand_range(0.5, 0.75))

func wiggle(direction: float):
	if tween != null and tween.is_valid():
		tween.kill()
	tween = create_tween()
	
	if tween2 != null and tween2.is_valid():
		tween2.kill()
	tween2 = create_tween()
	
	var bool_direction: = false
	if is_zero_approx(direction):
		bool_direction = randi() %2 == 0
	elif direction > 0.0:
		bool_direction = false
	else:
		bool_direction = true
	
	GoodTweens.shake_tween(tween, rotation_pivot, _rotation_degrees_s, 0.0, 10.0, 4, 1.0, bool_direction)
	GoodTweens.shake_tween(tween2, rotation_pivot2, _rotation_degrees_s, 0.0, 10.0, 4, 1.0, bool_direction)
