extends UpGuys_GrassRenderer
class_name GrassRenderer

export  var single_grass_scene: PackedScene
onready var level_node: LevelNode = get_parent()

var size_x: = - 1
var size_y: = - 1
var shape_rotation: = - 1

var grass_color1: = Color.white setget set_grass_color1
var grass_color2: = Color.white setget set_grass_color2

func _ready():
	if not Engine.editor_hint:
		level_node.connect("apply_bounding_box", self, "on_apply_bounding_box")

func _cell_delta() -> Vector2:
	return Vector2.RIGHT * LevelGrid2.cell_size / density

func _num_cells() -> int:
	if shape_rotation % 2 == 0:
		return int(size_x * density)
	return int(size_y * density)

func _cell_start() -> Vector2:
	var cell_delta: = _cell_delta()
	var world_size: = parent_level_node.world_rect.size
	if shape_rotation % 2 == 1:
		world_size = Vector2(world_size.y, world_size.x)
	var node_start: = - 0.5 * world_size
	return node_start + 0.5 * Vector2(cell_delta.x, world_size.y)

func on_apply_bounding_box():
	if size_x == parent_level_node.grid_rect.size.x and size_y == parent_level_node.grid_rect.size.y and shape_rotation == parent_level_node.shape_rotation:
		return
	shape_rotation = parent_level_node.shape_rotation
	size_x = parent_level_node.grid_rect.size.x
	size_y = parent_level_node.grid_rect.size.y
	
	var cell_delta: = _cell_delta()
	var num_cells: = _num_cells()
	
	
	while grass_blade_nodes.size() > num_cells:
		var n: Node = grass_blade_nodes.pop_back()
		n.queue_free()
	
	
	while grass_blade_nodes.size() < num_cells:
		var node: = single_grass_scene.instance()
		add_child(node)
		grass_blade_nodes.append(node)
	
	var inverse_scale: = Vector2.ONE / parent_level_node.scale
	var cell_start: = _cell_start()
	for i in num_cells:
		var j: = int(i)
		if shape_rotation > 1:
			j = num_cells - i - 1
		var node: SingleGrassRenderer = grass_blade_nodes[j]
		node.position = inverse_scale * (cell_start + cell_delta * i)
		node.scale = inverse_scale
		node.make_blades(cell_delta)
		node.apply_colors(grass_color1, grass_color2)

func set_grass_color1(c: Color):
	grass_color1 = c
	apply_colors()

func set_grass_color2(c: Color):
	grass_color2 = c
	apply_colors()

func apply_colors():
	for n in grass_blade_nodes:
		n.apply_colors(grass_color1, grass_color2)
