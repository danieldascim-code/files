tool 
extends WPBox2DFixture
class_name LevelNodeBox2DRectShapeMargins

export  var _level_node: NodePath
onready var level_node: = get_node(_level_node) as LevelNode
onready var rect_shape: = shape as Box2DRectShape

export  var margin_left: = 0.0
export  var margin_right: = 0.0
export  var margin_top: = 0.0
export  var margin_bottom: = 0.0

func _ready() -> void :
	if level_node:
		level_node.connect("apply_bounding_box", self, "on_apply_bounding_box")
	
	var should_process: = Engine.editor_hint
	set_process(should_process)

func on_apply_bounding_box():
	var w: = LevelGrid.cell_size - (margin_left + margin_right) / level_node.scale.x
	var h: = LevelGrid.cell_size - (margin_top + margin_bottom) / level_node.scale.y
	rect_shape.size = Vector2(w, h)
	position.x = 0.5 * (margin_left - margin_right)
	position.y = 0.5 * (margin_top - margin_bottom)

func _process(delta: float) -> void :
	if level_node and owner == level_node:
		on_apply_bounding_box()
	
