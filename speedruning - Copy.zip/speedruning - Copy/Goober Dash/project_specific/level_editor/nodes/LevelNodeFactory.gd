extends Reference
class_name LevelNodeFactory

const node_directory: = "res://project_specific/level_editor/nodes"
const icon_path_format: = "res://project_specific/level_editor/nodes/%s/icon.png"
const starting_point_key: = "start"
const finish_line_key: = "finish_line"
const gravity_field_key: = "gravity_field"
const checkpoint_key: = "checkpoint"
const disappearing_block_key: = "disappearing_block"
const physics_block_key: = "physics_block"

var scene_cache: = {}
var renderer_scene_cache: = {}
var icon_cache: = {}
var node_types: = []


const static_node_types: = [
	"block", 
	"floor", 
	"start", 
	"finish_line", 
	"checkpoint", 
	"pit", 
	"sawblade", 
	"ramp", 
	"gravity_field", 
]

func _load_nodes(disable_renderers: bool):
	_load_scene_cache(scene_cache, node_types, node_directory, disable_renderers)

func _load_icon_cache():
	for n in node_types:
		var node_type: String = n
		var icon_path: = icon_path_format % [node_type]
		if ResourceLoader.exists(icon_path, "Texture"):
			var icon: Texture = ResourceLoader.load(icon_path, "Texture")
			if icon:
				icon_cache[node_type] = icon

func create_node(node_type: String) -> LevelNode:
	if not scene_cache.has(node_type):
		printerr("[LevelNodeFactory] create_node() invalid node_type %s" % [node_type])
		
		return null
	
	var scene: = scene_cache[node_type] as PackedScene
	var node: = scene.instance() as LevelNode
	if node == null:
		printerr("[LevelNodeFactory] level_node was not of type LevelNode type: %s path: %s" % [node_type, scene.resource_path])
		assert (false)
		return null
	
	node.node_type = node_type
	
	
	if renderer_scene_cache.has(node_type):
		var renderer_scene: PackedScene = renderer_scene_cache[node_type]
		var renderer_node: Node = renderer_scene.instance()
		node.add_child(renderer_node)
	
	return node

func _load_scene_cache(scene_cache: Dictionary, node_types: Array, node_directory: String, disable_renderers: bool):
	scene_cache.clear()
	node_types.clear()
	renderer_scene_cache.clear()
	var directory: = Directory.new()
	var err: = directory.open(node_directory)
	if err != OK:
		printerr("[LevelNodeFactory] _parse_scene_cache(%s) open error: %d" % [node_directory, err])
		return
	err = directory.list_dir_begin(true, true)
	if err != OK:
		printerr("[LevelNodeFactory] _parse_scene_cache(%s) list_dir_begin error: %d" % [node_directory, err])
		return
	
	var file_name: = directory.get_next()
	while file_name != "":
		if directory.current_is_dir():
			var directory_path: = node_directory.plus_file(file_name)
			var scenes_in_directory: = _parse_scenes_from_directory(directory_path)
			if scenes_in_directory.size() != 1:
				printerr("[LevelNodeFactory] found invalid %d directory %s" % [scenes_in_directory.size(), directory_path])
			if scenes_in_directory.size() == 1:
				var scene_path: = scenes_in_directory[0] as String
				var scene: = ResourceLoader.load(scene_path, "PackedScene") as PackedScene
				if not scene:
					printerr("[LevelNodeFactory] _parse_scene_cache() error loading %s" % [scene_path])
				else:
					
					scene_cache[file_name] = scene
					node_types.append(file_name)
				if not disable_renderers:
					var renderer_scene_path: = scene_path.get_base_dir() + "/Renderer.tscn"
					var renderer_scene: = ResourceLoader.load(renderer_scene_path, "PackedScene") as PackedScene
					if not renderer_scene:
						printerr("[LevelNodeFactory] _parse_scene_cache() error loading renderer %s" % [renderer_scene_path])
					else:
						renderer_scene_cache[file_name] = renderer_scene
				
		file_name = directory.get_next()
	directory.list_dir_end()
	
	for s in static_node_types:
		if not node_types.has(s):
			printerr("[LevelNodeFactory] %s node type is missing!" % [s])
	
	node_types.sort_custom(self, "_sort_node_types")

static func _parse_scenes_from_directory(directory_path: String) -> Array:
	var directory: = Directory.new()
	var err: = directory.open(directory_path)
	if err != OK:
		printerr("[LevelNodeFactory] _parse_levels_from_directory(%s) open error: %d" % [directory_path, err])
		return []
	err = directory.list_dir_begin(true, true)
	if err != OK:
		printerr("[LevelNodeFactory] _parse_levels_from_directory(%s) list_dir_begin error: %d" % [directory_path, err])
		return []
		
	var paths: = []
	var file_name: = directory.get_next()
	while file_name != "":
		if not directory.current_is_dir():
			var file_path: = directory_path.plus_file(file_name)
			if _is_level_node_packed_scene(file_path):
				paths.append(file_path)
				
		file_name = directory.get_next()
	directory.list_dir_end()
	return paths

static func _is_level_node_packed_scene(file_path: String) -> bool:
	
	var ext: = file_path.get_extension()
	var file_name: = file_path.get_basename()
	return "LevelNode" in file_name and (ext == @"tscn" or ext == @"scn")

static func _sort_node_types(a: String, b: String) -> bool:
	
	
	
	var a_i: = static_node_types.find(a)
	var b_i: = static_node_types.find(b)
	if a_i == - 1 and b_i == - 1:
		
		return a.nocasecmp_to(b) < 0
	if a_i == - 1 or b_i == - 1:
		
		return a_i >= 0
	
	return a_i < b_i
