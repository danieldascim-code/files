shader_type canvas_item;

uniform vec2 global_scale = vec2(1.0, 1.0);
uniform vec2 global_position = vec2(1.0, 1.0);
uniform float global_rotation = 0.0;
uniform vec2 mesh_size = vec2(1.0, 1.0);
uniform float texture_scale = 1.0;
uniform vec2 offset = vec2(0.0, 0.0);

void fragment()
{
	vec2 texture_size = texture_scale * vec2(textureSize(TEXTURE, 0));
	
	vec2 uv = UV - vec2(0.5, 0.5);
	// Scale
	uv.x = uv.x * global_scale.x * mesh_size.x;
	uv.y = uv.y * global_scale.y * mesh_size.y;
	// Rotate
	float l = length(uv);
	float a = atan(uv.y, uv.x);
	uv = l * vec2(cos(a + global_rotation), sin(a + global_rotation));
	
	// Translate
	uv += global_position;
	
	// Repeat
	uv.x = mod(uv.x, texture_size.x) / texture_size.x;
	uv.y = mod(uv.y, texture_size.y) / texture_size.y;
	
	COLOR = texture(TEXTURE, uv);
}