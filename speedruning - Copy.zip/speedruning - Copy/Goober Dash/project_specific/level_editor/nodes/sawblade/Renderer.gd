extends Node2D

const sawblade_angular_vel: = 0.33 * TAU

onready var level_node: LevelNode = get_parent()
onready var saw_sizes: = [$Spin / Saw100, $Spin / Saw200, $Spin / Saw300]
onready var spin: = $Spin as Node2D
onready var shadow: MeshInstance2D = $Spin / UpGuys_LevelNodeShadow / Shadow
var last_sprite_size: = - 1

func _process(delta: float):
	if not visible:
		return
	
	
	spin.rotation += delta * sawblade_angular_vel
	
	
	var sprite_size: = 0
	var node_size: = level_node.grid_rect.size.x
	if node_size <= 2:
		sprite_size = 0
	elif node_size <= 4:
		sprite_size = 1
	else:
		sprite_size = 2
	
	
	if sprite_size != last_sprite_size:
		last_sprite_size = sprite_size
		for i in saw_sizes.size():
			saw_sizes[i].visible = sprite_size == i
		shadow.texture = saw_sizes[sprite_size].texture
