extends Object
class_name LevelNodeProperties

enum Type{
	REAPPEAR, 
	STRENGTH, 
	RECHARGE_TIME, 
	ONE_TIME_USE
}

