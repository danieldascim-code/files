extends Node2D

onready var level_node: LevelNode = get_parent()

onready var network_game: = Utilities.find_game(self, false)

onready var glow: = $Glow
onready var laser: = $Laser
onready var particles: = $Particles2D
onready var sight: = $Sight

onready var sound_origin: Node2D = $SoundOrigin
onready var charge_sound: AudioStreamPlayer2D = $SoundOrigin / ChargeAudio
onready var discharge_sound: AudioStreamPlayer2D = $SoundOrigin / DischargeAudio
onready var tase_sound: AudioStreamPlayer2D = $SoundOrigin / TaserAudio

onready var charge_sound_duration: = charge_sound.stream.get_length()

enum LaserState{
	OFF, CHARGING, LASING
}

var prev_state: int = LaserState.OFF

func _ready():
	laser.visible = false
	particles.emitting = false
	glow.modulate.a = 0.0
	glow.visible = true

func _process(delta: float):
	if not visible:
		return
	if not network_game:
		return
	
	var wp_game: WPGame = network_game
	
	var state: int = LaserState.OFF
	var raycast_length: = 1000.0
	
	var charging_ticks_left: = 999
	
	if not wp_game.is_game_over():
		var laser: = network_game.get_object_for_object_id(level_node.network_object_id) as Laser_NetworkObject
		if laser:
			var charge_ticks: int = network_game.wp_game_data.laser_charge_ticks
			var active_ticks: int = max(laser.lasing_duration_ticks, charge_ticks)
			var pause_ticks: int = laser.pause_duration_ticks
			var always_on: = laser.pause_duration_ticks == 0
			
			var tick: = network_game.time_to_ticks(wp_game.wp_game_data.play_time)
			var timer: int = (tick + laser.timing_offset) %(active_ticks + pause_ticks)
			if always_on or laser.is_active:
				if always_on or timer >= pause_ticks + charge_ticks:
					state = LaserState.LASING
				else:
					state = LaserState.CHARGING
					charging_ticks_left = (pause_ticks + charge_ticks) - timer
			else:
				state = LaserState.OFF
				
			raycast_length = laser.lasing_distance
	
	
	
	var total_len: = raycast_length + 15.0 - 10.0
	glow.scale.x = total_len + glow.scale.y * 2.0
	laser.scale.x = total_len + laser.scale.y * 2.0
	sight.scale.x = total_len + sight.scale.y * 2.0 + 4.0
	particles.position = Vector2(total_len + 20.0, 0.0)
	
	var target_glow_a: = 0.0
	var lambda: = 5.0
	var playing_charge_sound: = false
	var playing_tase_sound: = false

	match state:
		LaserState.CHARGING:
			
			laser.visible = false
			particles.emitting = false
			target_glow_a = 0.7
			lambda = 5.0
			var charging_seconds_left: = network_game.ticks_to_time(charging_ticks_left)
			if charging_seconds_left < charge_sound_duration:
				playing_charge_sound = true
		LaserState.LASING:
			
			laser.visible = true
			particles.emitting = true
			target_glow_a = 1.0
			lambda = 20.0
			playing_tase_sound = true
		LaserState.OFF, _:
			
			laser.visible = false
			particles.emitting = false
			glow.modulate.a = lerp(glow.modulate.a, 0.0, 0.02)
			target_glow_a = 0.0
			lambda = 8.0
	glow.modulate.a = lerp(glow.modulate.a, target_glow_a, 1.0 - exp( - lambda * delta)) as float
	
	if playing_charge_sound:
		if not charge_sound.is_playing():
			charge_sound.play()
	else:
		charge_sound.stop()
	if playing_tase_sound:
		if not tase_sound.is_playing():
			tase_sound.play()
	else:
		tase_sound.stop()
	
	if prev_state != LaserState.OFF and state == LaserState.OFF:
		discharge_sound.play()
	
	
	
	var vp: = get_viewport()
	var point: = get_global_transform().affine_inverse() * ViewportUtils._viewport_visible_rect(vp).get_center()
	var line: = Vector2(raycast_length, 0.0)
	var t: = 1.0
	if not is_zero_approx(raycast_length):
		t = clamp(line.dot(point) / line.dot(line), 0.0, 1.0)
	var closest: = line * t
	sound_origin.position = closest
	
	prev_state = state
