extends Node2D

onready var level_node: = get_parent() as LevelNode


onready var game: = Utilities.find_game(self, false) as WPGame
onready var checker: = $Checker as Node2D
onready var animation_player: = $AnimationPlayer as AnimationPlayer
onready var contact_point_animation: = $ContactPointAnimation as Node2D

func _ready():
	if game:
		game.connect("player_hit_finish_line", self, "on_player_hit_finish_line")

func on_player_hit_finish_line(player_id: int, rank: int, out_of: int, finish_line_index: int, contact_position: Vector2):
	if finish_line_index == level_node.level_node_index:
		
		animation_player.play("player_hit")
		
		var player_color: = Color.white
		if game.client_renderer:
			var player_renderer: = game.client_renderer.get_renderer_for_object_id(player_id) as UpGuys_PlayerRenderer
			if player_renderer:
				player_color = player_renderer.spine.get_tint().lightened(0.2)
		var animation: = animation_player.get_animation("player_hit")
		var track_index: = animation.find_track("Checker:self_modulate")
		animation.track_set_key_value(track_index, 1, player_color)
		var new_contact_point_animation: = contact_point_animation.duplicate() as Node2D
		get_parent().add_child(new_contact_point_animation)
		new_contact_point_animation.set_as_toplevel(true)
		new_contact_point_animation.position = contact_position
		var new_particles: = new_contact_point_animation.get_node("Particles2D") as Particles2D
		new_particles.emitting = true
		var new_particles2: = new_contact_point_animation.get_node("Particles2D2") as Particles2D
		new_particles2.emitting = true
		new_particles2.self_modulate = player_color
		
		yield(get_tree().create_timer(2.0 * new_particles.lifetime), "timeout")
		new_particles.queue_free()
