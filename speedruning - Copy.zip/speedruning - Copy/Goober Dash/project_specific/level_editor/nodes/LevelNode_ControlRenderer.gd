tool 
extends Control
class_name LevelNode_ControlRenderer
export  var _level_node: NodePath
onready var level_node: = get_node(_level_node) as LevelNode

func _ready():
	level_node.connect("apply_bounding_box", self, "on_apply_bounding_box")
	set_as_toplevel(true)

func on_apply_bounding_box():
	rect_size = level_node.world_rect.size
	rect_position = level_node.world_rect.position
