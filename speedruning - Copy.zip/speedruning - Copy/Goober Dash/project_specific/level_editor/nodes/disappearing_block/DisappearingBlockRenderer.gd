extends Node2D
class_name DisappearingBlockRenderer_Old

export  var _level_node: NodePath
onready var level_node: = get_node(_level_node) as LevelNode
onready var sound_start: AudioStreamPlayer2D = $StartDisapearingSound as AudioStreamPlayer2D
onready var solid_block_material_shader: ShaderMaterial = $MeshInstance2D.material as ShaderMaterial



onready var network_game: = Utilities.find_game(self, false)
var disappearing_tween: SceneTreeTween

const blink_rate: = 0.2
export  var blink_color: = Color.white
export  var normal_color: = Color.white
export  var not_there_color: = Color.white


var disappear_time: = 0.0
var reappear_time: = 0.0
var last_shown_dissapearing: = false

func _ready() -> void :
	if network_game:
		var wp_game_data: = (network_game as WPGame).wp_game_data
		disappear_time = wp_game_data.disappearing_block_seconds
		reappear_time = wp_game_data.disappearing_block_reappear_after
		disappearing_tween = _create_tween(disappear_time)
	self.modulate = normal_color

func _process(delta: float):
	if network_game:
		var disappearing_block: = network_game.get_object_for_object_id(level_node.network_object_id) as DisappearingBlock_NetworkObject
		if disappearing_block:
			if disappearing_block.is_disappearing and not disappearing_tween.is_running():
				var blink_time_left: = network_game.ticks_to_time(disappearing_block.disappearing_counter) - reappear_time
				blink_time_left = stepify(blink_time_left, 0.001)
				if blink_time_left > 0.0:
					var tween_seek_to: = disappear_time - blink_time_left
					
					seek_tween(disappearing_tween, tween_seek_to)
					disappearing_tween.play()
			
			if not disappearing_block.is_disappearing:
				if disappearing_tween.is_running():
					
					disappearing_tween.stop()
				
				self.modulate = normal_color
			
			if (disappearing_block.is_disappearing and not last_shown_dissapearing):
				sound_start.play()
				var t: = create_tween()
				solid_block_material_shader.set_shader_param("mix_value", 1.0)
				t.tween_property(solid_block_material_shader, "shader_param/mix_value", 0.0, 0.5).from(1.0)
				
				
			last_shown_dissapearing = disappearing_block.is_disappearing

func _create_tween(disappear_time: float):
	var t: = create_tween()
	var blink_time: = disappear_time - blink_rate * 0.5
	
	var num_blinks_ff: = stepify(blink_time / blink_rate, 0.01)
	
	var num_blinks_f: = floor(num_blinks_ff)
	var num_blinks: = int(num_blinks_f)
	var total_time: = num_blinks * blink_rate + blink_rate * 0.5
	var remainder_time: = disappear_time - total_time
	
	
	if remainder_time > 0.0:
		t.tween_interval(remainder_time)
	
	
	for i in num_blinks:
		t.tween_property(self, "modulate", blink_color, blink_rate * 0.5)
		t.tween_property(self, "modulate", normal_color, blink_rate * 0.5)
	
	t.tween_property(self, "modulate", not_there_color, blink_rate * 0.5)
	
	t.stop()
	t.connect("finished", t, "stop")
	return t

func seek_tween(t: SceneTreeTween, f: float):
	var d: = f - t.get_total_elapsed_time()
	t.custom_step(d)
