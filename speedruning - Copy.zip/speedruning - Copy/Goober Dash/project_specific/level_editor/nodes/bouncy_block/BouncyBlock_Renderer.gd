extends Node2D
onready var body: Box2DPhysicsBody = get_node("../Box2DPhysicsBody")
onready var game: WPGame = Utilities.find_game(self, false) as WPGame
onready var level_node: LevelNode = get_parent()
onready var mesh_instance: MeshInstance2D = $TweenRoot / MeshInstance2D
onready var tween_root: Node2D = $TweenRoot
onready var shader_material: ShaderMaterial = mesh_instance.material
onready var audio_player: AudioStreamPlayer2D = $AudioStreamPlayer2D

var colliding_bodies: = []
var colliding_player_ids: = []
var colliding_level_node_ids: = []
var tween: SceneTreeTween

func _ready() -> void :
	colliding_bodies.resize(8)

func _process(delta: float) -> void :
	var next_player_ids: = []
	var next_level_node_ids: = []
	var rect_size: = Vector2(200.0, 200.0)
	if ViewportRectCalculator.viewport_visible_rect.intersects(Rect2(global_position - 0.5 * rect_size, rect_size)):
		var b: = body.get_colliding_bodies(colliding_bodies)
		for i in b:
			var body: Box2DPhysicsBody = colliding_bodies[i]
			var body_parent: Node = body.get_parent()
			if "object_id" in body_parent:
				var object_id: int = body_parent.object_id
				_process_colliding_id(object_id, colliding_player_ids)
				next_player_ids.append(object_id)
			elif "level_node_index" in body_parent:
				var level_node_index: int = body_parent.level_node_index
				_process_colliding_id(level_node_index, colliding_level_node_ids)
				next_level_node_ids.append(level_node_index)
	colliding_player_ids = next_player_ids
	colliding_level_node_ids = next_level_node_ids

func _process_colliding_id(colliding_id: int, colliding_id_list: Array):
	if not colliding_id_list.has(colliding_id):
		colliding_id_list.append(colliding_id)
		_play_sound()

export  var flash_color: = Color.white

func _play_sound():

	if not audio_player.playing:
		audio_player.pitch_scale = rand_range(0.98, 1.02)
	audio_player.play(0)
	
	_play_color_tween()
	_play_scale_tween()

var _color_tween: SceneTreeTween
func _play_color_tween():
	if _color_tween and _color_tween.is_valid():
		_color_tween.kill()
	_color_tween = create_tween()
	_color_tween.tween_property(shader_material, "shader_param/color_override_mix", 0.0, 0.1).from(1.0).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_EXPO)

func _play_scale_tween():
	if tween and tween.is_valid():
		tween.kill()
	tween = create_tween()
	var hi_scale: = Vector2.ONE + (Vector2(0.5, 0.5) / level_node.grid_rect.size)
	tween.tween_property(tween_root, "scale", hi_scale, 0.1).from(Vector2.ONE).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	tween.tween_property(tween_root, "scale", Vector2.ONE, 0.5).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BOUNCE)
