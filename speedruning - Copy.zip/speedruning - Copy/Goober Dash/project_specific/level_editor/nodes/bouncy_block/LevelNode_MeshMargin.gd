extends MeshInstance2D

export  var margin: = Vector2(0.0, 0.0)
export  var default_scale: = Vector2(25.0, 25.0)

onready var level_node: LevelNode = get_parent().get_parent()

func _ready() -> void :
	level_node.connect("apply_bounding_box", self, "on_apply_bounding_box")

func on_apply_bounding_box():
	scale = default_scale + margin / level_node.scale
