
extends Polygon2D
class_name PolygonShadow

onready var parent_renderer: Node2D = get_parent()

export  var shadow_offset: = Vector2(5.0, 5.0)





func _process(delta: float) -> void :
	if visible:
		var r: = parent_renderer.global_rotation
		var s: = parent_renderer.global_scale
		position = shadow_offset.rotated( - r) / s
