extends Node
class_name LevelNode_ThemedColor

export  var _level_node: NodePath
onready var level_node: = get_node(_level_node) as LevelNode

export  var theme_property_name: = "some_themed_thing"
var default_color: Color

onready var target_node: = get_parent() as Node
export  var color_property_name: = "self_modulate"

func _ready():
	level_node.connect("apply_theme", self, "on_apply_theme")
	if not color_property_name in target_node:
		printerr("[LevelNode_ThemedColor] property_name %s is invalid on node %s" % [color_property_name, get_path()])
		return

	var tex = target_node.get(color_property_name)
	if not tex is Color:
		printerr("[LevelNode_ThemedColor] property_name %s is not a texture on node %s" % [color_property_name, get_path()])

	default_color = target_node.get(color_property_name)

func on_apply_theme(level_theme: BaseTheme):
	if not theme_property_name in level_theme:
		printerr("[LevelNode_ThemedColor] theme_property_name %s is invalid on node %s and theme %s" % [theme_property_name, get_path(), level_theme])
		
	var theme_property = level_theme.get(theme_property_name)
	var t: = default_color
	if theme_property != null and theme_property is Color:
		
		t = theme_property
	else:
		printerr("[LevelNode_ThemedColor] theme_property_name %s is not a color on theme %s on node %s" % [theme_property_name, level_theme, get_path()])
		t = default_color
	
	target_node.set(color_property_name, t)
