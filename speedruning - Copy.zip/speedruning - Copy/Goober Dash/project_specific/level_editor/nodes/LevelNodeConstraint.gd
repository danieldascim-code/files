tool 
extends Node
class_name LevelNodeConstraint

func _compute_bounding_box(block_start: Int2, block_end: Int2, shape_rotation: int) -> void :
	pass
