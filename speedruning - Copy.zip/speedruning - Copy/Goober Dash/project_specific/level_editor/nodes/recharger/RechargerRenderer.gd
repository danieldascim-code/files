extends Node2D

export  var _level_node: NodePath
onready var level_node: = get_parent() as Recharger

onready var network_game: = Utilities.find_game(self, false)

onready var active_nodes: = $Node2D / Active
onready var reload_nodes: = $Node2D / Reloading

func _ready() -> void :
	pass

func _process(_delta: float):
	if not network_game:
		return
	var recharger: Recharger_NetworkObject = network_game.get_object_for_object_id(level_node.network_object_id)
	if not recharger:
		return
	
	if recharger.recharge_counter > 0:
		if level_node.one_time_use == true:
			active_nodes.visible = false
			reload_nodes.visible = false
		else:
			active_nodes.visible = false
			reload_nodes.visible = true
	else:
		active_nodes.visible = true
		reload_nodes.visible = false
