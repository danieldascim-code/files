extends Node2D
onready var body: Box2DPhysicsBody = get_node("../Box2DPhysicsBody")
onready var game: WPGame = Utilities.find_game(self, false) as WPGame
onready var level_node: LevelNode = get_parent()




func _process(delta: float) -> void :
	var level_node_world_rect: = level_node.world_rect
	var max_width: = max(level_node_world_rect.size.x, level_node_world_rect.size.y)
	var world_rect: = Rect2(Vector2(body.position.x - (max_width * 0.5), body.position.y - (max_width * 0.5)), Vector2(max_width, max_width))
	var is_on_screen: = ViewportRectCalculator.viewport_visible_rect.intersects(world_rect)
	if not is_on_screen:
		visible = false
	else:
		visible = true
		if game and game.client_renderer and level_node.network_object_id > 0 and game.get_object_for_object_id(level_node.network_object_id) != null:
			var p: Vector2 = game.client_renderer.get_interpolated_property(level_node.network_object_id, "position", 0.0, false, 100.0)
			var r: float = game.client_renderer.get_interpolated_property(level_node.network_object_id, "rotation", 0.0, true, 10.0)
			var s: = body.get_transform().get_scale()
			global_transform = GoodMath.trs_transform2d(p, r, s)
		else:
			global_transform = body.get_transform()
