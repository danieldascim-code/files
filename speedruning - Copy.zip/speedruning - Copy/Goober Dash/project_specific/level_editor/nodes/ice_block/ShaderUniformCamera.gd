extends Node
class_name ShaderUniformCameraPosition

onready var parent: CanvasItem = get_parent()
onready var material: ShaderMaterial = parent.material
const shader_param: = "camera_position"

func _process(delta: float) -> void :
	var p: = ViewportRectCalculator.viewport_visible_rect.get_center()
	material.set_shader_param(shader_param, p)
