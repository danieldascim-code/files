tool 
extends Node2D
class_name LevelNodeRepeatingTemplate
onready var template: = $Template as Node2D
onready var parent_level_node: = get_parent() as LevelNode
var nodes: = []
var size_x: = - 1
var size_y: = - 1
var shape_rotation: = - 1

func _ready():
	if not Engine.editor_hint:
		parent_level_node.connect("apply_bounding_box", self, "on_apply_bounding_box")
		template.visible = false

func on_apply_bounding_box():
	if size_x == parent_level_node.grid_rect.size.x and size_y == parent_level_node.grid_rect.size.y and shape_rotation == parent_level_node.shape_rotation:
		return
	size_x = parent_level_node.grid_rect.size.x
	size_y = parent_level_node.grid_rect.size.y
	if template == null:
		template = $Template as Node2D
	template.visible = false
	
	var total_x: = parent_level_node.grid_rect.size.x
	var total_y: = parent_level_node.grid_rect.size.y
	var total: = total_x * total_y
	
	
	while nodes.size() > total:
		var n: Node = nodes.pop_back()
		n.queue_free()
	
	
	while nodes.size() < total:
		var node: = template.duplicate() as Node2D
		add_child(node)
		node.visible = true
		nodes.append(node)
	
	var inverse_scale: = Vector2.ONE / parent_level_node.scale
	for x in total_x:
		for y in total_y:
			var node: Node2D = nodes[y * total_x + x]
			node.position = inverse_scale * ( - 0.5 * parent_level_node.world_rect.size + LevelGrid.grid_to_world_xy(x, y) + LevelGrid.half_cell_2d)
			node.rotation = parent_level_node.shape_rotation * PI * 0.5
			node.scale = inverse_scale
	
