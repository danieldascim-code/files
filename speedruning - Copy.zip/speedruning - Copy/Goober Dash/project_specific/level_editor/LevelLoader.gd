tool 
extends Node

const levels_project_save_path: = "res://project_specific/levels"
const levels_special_save_path: = "res://project_specific/levels/special"
const levels_local_save_path: = "user://levels"
const force_level_path: = ""

const CURRENT_LEVEL_FORMAT_VERSION: = 2

enum LevelLoadLocation{
	Void = 0, 
	Local, 
	Cloud, 
	Project, 
	Special, 
	MAX
	MAX
}

const location_names = {
	LevelLoadLocation.Local: "local", 
	LevelLoadLocation.Cloud: "cloud", 
	LevelLoadLocation.Project: "project", 
	LevelLoadLocation.Special: "special", 
}

func _is_level_file(file_path: String) -> bool:
	return file_path.get_extension() == "json"

func async_load_level_from_cloud(level_id: String, node_factory: LevelNodeFactory) -> LevelInstance:
	var level_data: Dictionary = yield(LevelCloudLoader.async_download_level_data(level_id), "completed")
	if level_data.has("error"):
		printerr("[LevelLoader] async_load_level_from_cloud() failed to download level with id %s" % [level_id])
		return null
	
	return LevelJson.deserialize_level(level_data, node_factory)





func async_save_level_to_cloud(level_instance: LevelInstance) -> Dictionary:
	var level_data: = LevelJson.serialize_level(level_instance)
	var response: Dictionary = yield(LevelCloudLoader.async_save_level_data(level_data), "completed")
	if response.has("error"):
		printerr("[LevelLoader] async_save_level_to_cloud() failed to save level.")
		return {
			"error": response["error"]
		}
	var level_id: String = response["level_id"]
	level_instance.level_id = level_id
	
	return {
		"level_id": level_id
	}

func load_local_level(level_name: String, location: int, node_factory: LevelNodeFactory) -> LevelInstance:
	assert (location != LevelLoader.LevelLoadLocation.Cloud)
	var level_path: = path_for_location(level_name, location)
	return load_local_level_from_path(level_path, node_factory)

func load_local_level_from_path(level_path, node_factory: LevelNodeFactory) -> LevelInstance:
	var level_data: = _load_json_from_path(level_path)
	var level_node: = LevelJson.deserialize_level(level_data, node_factory)
	return level_node

func save_local_level(level_node: LevelInstance, location: int):
	if level_node.level_name.empty():
		level_node.level_name = "GooberLevel"
	var level_name: String = level_node.level_name
	var level_dictionary: = LevelJson.serialize_level(level_node)
	if OS.has_feature("web"):
		_download_level_js(level_dictionary, level_name)
	else:
		_save_level_json(level_dictionary, level_name, location)

func _download_level_js(level_dictionary: Dictionary, level_name: String):
	assert (OS.has_feature("web"))
	assert ( not level_name.empty())
	var file_json: = to_json(level_dictionary)
	var file_pool_byte_array: = file_json.to_utf8()
	JavaScript.download_buffer(file_pool_byte_array, level_name + ".json", "application/json")

func delete_local_level(level_name: String, location: int) -> bool:
	var folder: = location_directory(location)
	if folder.empty():
		printerr("[LevelLoader] file_exists_at_location() failed invalid location %d" % [location])
		return false
	var directory: = Directory.new()
	var err: = directory.open(folder)
	if err != OK:
		printerr("[LevelLoader] delete_file_at_location() dir open fail %s" % [err])
		return false
	
	var file_path: = path_for_location(level_name, location)
	print("remove %s from folder %s" % [file_path, folder])
	var remove_err: = directory.remove(file_path)
	if remove_err != OK:
		printerr("[LevelLoader] delete_file_at_location() remove fail %s" % [remove_err])
		return false
	return true

func _save_level_json(level_data: Dictionary, level_name: String, location: int):
	assert ( not level_name.empty())
	var folder: = location_directory(location)
	print("[LevelLoader] _save_level_json(%s, %s)" % [level_name, folder])
	
	
	var directory: = Directory.new()
	if not directory.dir_exists(folder):
		var dir_create_result: = directory.make_dir_recursive(folder)
		if dir_create_result != OK:
			printerr("[LevelLoader] _save_level_json(%s) error %d creating directory %s" % [level_name, dir_create_result, folder])
			return
	
	var path: = path_for_location(level_name, location)
	var level_json: = to_json(level_data)
	
	
	var f: = File.new()
	var file_error: = f.open(path, File.WRITE)
	if file_error != OK:
		printerr("[LevelLoader] _save_level_json() error %d opening file at path %s" % [file_error, path])
		return
	
	
	f.store_string(level_json)
	f.close()
	
	var globalized_path: = ProjectSettings.globalize_path(path)
	print("[LevelLoader] _save_level_json(%s) successfully saved %s" % [level_name, globalized_path])

func _load_json_from_path(level_path: String) -> Dictionary:
	print("[LevelLoader] _load_json_from_path(%s)" % [level_path])
	if not _is_level_file(level_path):
		printerr("[LevelLoader] _load_json_from_path(%s) is not a level path" % [level_path])
		return {}
	
	var f: = File.new()
	var file_error: = f.open(level_path, File.READ)
	if file_error != OK:
		printerr("[LevelLoader] _load_json_from_path() error %d opening file at path %s" % [file_error, level_path])
		return {}
	var file_text: = f.get_as_text()
	var parse_result: = JSON.parse(file_text)
	if parse_result.error != OK:
		printerr("[LevelLoader] _load_json_from_path(%s) json parse failure %s" % [level_path, parse_result])
		return {}
	if not parse_result.result is Dictionary:
		printerr("[LevelLoader] _load_json_from_path(%s) json parsed something thats not a dictionary %s" % [level_path, parse_result.result])
		return {}
	
	return parse_result.result

func _list_local_levels(directory_path: String) -> Array:
	var directory: = Directory.new()
	var err: = directory.open(directory_path)
	if err != OK:
		printerr("[LevelLoader] _list_local_levels(%s) open error: %d" % [directory_path, err])
		return []
	err = directory.list_dir_begin(true, true)
	if err != OK:
		printerr("[LevelLoader] _list_local_levels(%s) list_dir_begin error: %d" % [directory_path, err])
		return []
	
	var file_names: = []
	var file_name: = directory.get_next()
	while file_name != "":
		if not directory.current_is_dir():
			var file_path: = directory_path.plus_file(file_name)
			var should_add: = true
			if not directory.file_exists(file_path):
				printerr("[LevelLoader] _list_local_levels() file_path doesnt exist: %s" % [file_path])
				should_add = false
			if not _is_level_file(file_path):
				printerr("[LevelLoader] _list_local_levels() found not a level file: %s" % [file_path])
				should_add = false
			if should_add:
				file_names.append(file_name)
		file_name = directory.get_next()
	directory.list_dir_end()
	file_names.sort()
	
	var level_paths: = []
	for i in file_names.size():
		var f: String = file_names[i]
		var file_path: = directory_path.plus_file(f)
		level_paths.append(file_path)
	
	return level_paths

func location_directory(i: int) -> String:
	match i:
		LevelLoadLocation.Local:
			return levels_local_save_path
		LevelLoadLocation.Project:
			return levels_project_save_path
		LevelLoadLocation.Special:
			return levels_special_save_path
	
	return ""

func path_for_location(level_name: String, location: int) -> String:
	var folder: = location_directory(location)
	if folder.empty():
		printerr("[LevelLoader] path_for_location() invalid location %d" % [location])
		return ""
	var level_path: = folder.plus_file(level_name + ".json")
	return level_path

func file_exists_at_location(level_name: String, location: int) -> bool:
	var file_path: = path_for_location(level_name, location)
	var f: = File.new()
	return f.file_exists(file_path)
