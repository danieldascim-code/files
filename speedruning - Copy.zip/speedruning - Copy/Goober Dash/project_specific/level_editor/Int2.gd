extends Reference
class_name Int2

enum Face{
	Up, 
	Left, 
	Down, 
	Right, 
	MAX
}

var x: = 0
var y: = 0

func _to_string():
	return "(%s, %s)" % [x, y]

func copy() -> Int2:
	var i: = _int2_new()
	i.assign(self)
	return i

func assign(i: Int2) -> Int2:
	x = i.x
	y = i.y
	return self

func minimum(a: Int2) -> Int2:
	x = int(min(x, a.x))
	y = int(min(y, a.y))
	return self

func maximum(a: Int2) -> Int2:
	x = int(max(x, a.x))
	y = int(max(y, a.y))
	return self




func mul(f: float) -> Int2:
	x = x * f
	y = y * f
	return self

func signed() -> Int2:
	x = sign(x)
	y = sign(y)
	return self

func subtract(v: Int2) -> Int2:
	x -= v.x
	y -= v.y
	return self

func plus(v: Int2) -> Int2:
	x += v.x
	y += v.y
	return self

func plus_away_from_zero(v: Int2) -> Int2:
	return plus_away_from_zero2(v.x, v.y)

func insert(face: int, v: int) -> Int2:
	match face:
		Face.Left, Face.Right:
			x = v
		Face.Up, Face.Down:
			y = v
		_:
			printerr("[Int2] insert() unknown face: " + str(face))
	return self

func extract(face: int) -> int:
	match face:
		Face.Left, Face.Right:
			return x
		Face.Up, Face.Down:
			return y
	printerr("[Int2] extract() unknown face: " + str(face))
	return 0

func absolute() -> Int2:
	x = abs(x)
	y = abs(y)
	return self

func equals(v: Int2) -> bool:
	return (x == v.x) and (y == v.y)

func remove_other_components(face: int) -> Int2:
	match face:
		Face.Left, Face.Right:
			y = 0
		Face.Up, Face.Down:
			x = 0
	return self




func subtract2(x2: int, y2: int) -> Int2:
	x -= x2
	y -= y2
	return self

func plus2(x2: int, y2: int) -> Int2:
	x += x2
	y += y2
	return self

func equals2(x2: int, y2: int) -> bool:
	return x == x2 and y == y2

func assign2(x2: int, y2: int) -> Int2:
	x = x2
	y = y2
	return self

func clear():
	x = 0
	y = 0

func plus_away_from_zero2(_x: int, _y: int) -> Int2:
	if x >= 0:
		x += _x
	else:
		x -= _x
	if y >= 0:
		y += _y
	else:
		y -= _y
	return self

static func other_faces(face: int) -> Array:
	match face:
		Face.Left, Face.Right:
			return [Face.Up, Face.Back]
		Face.Up, Face.Down:
			return [Face.Right, Face.Back]
		_:
			printerr("[Int2] other_faces() unknown face: " + str(face))
	return []

static func normal_to_face(normal: Vector2) -> int:
	var e: = 0.1
	if normal.y < - e:
		return Face.Up
	elif normal.y > e:
		return Face.Down
	elif normal.x > e:
		return Face.Right
	elif normal.x < - e:
		return Face.Left
	else:
		printerr("[Int2] normal_to_face() unknown normal(" + str(normal) + ")")
		return Face.Up


func _int2_new() -> Int2:
	var s: = (get_script() as GDScript)
	var i: = s.new() as Int2
	return i
