extends PopupMenu

signal load_level_button_pressed(level_name, file_path)


func _ready():
	connect("about_to_show", self, "populate")

func populate():
	
	var project_paths: Array = LevelLoader._parse_level_paths_from_directory(LevelLoader.levels_project_save_path)
	var special_project_paths: Array = LevelLoader._parse_level_paths_from_directory(LevelLoader.levels_special_save_path)
	var local_paths: Array = LevelLoader._parse_level_paths_from_directory(LevelLoader.levels_local_save_path)
	
	clear()
	
	
	if project_paths.size() > 0:
		add_separator("project levels")
	for s in project_paths:
		var level_path: String = s
		_create_row_for_level(level_path)
	
	if local_paths.size() > 0:
		add_separator("local levels")
	for s in local_paths:
		var level_path: String = s
		_create_row_for_level(level_path)

	if special_project_paths.size() > 0:
		add_separator("special levels")
	for s in special_project_paths:
		var level_path: String = s
		_create_row_for_level(level_path)


func _create_row_for_level(file_path: String):
	var level_name: = file_path.get_file().get_basename()
	add_item(level_name)

func on_load_button_pressed(file_path: String):
	emit_signal("load_level_button_pressed", file_path)
