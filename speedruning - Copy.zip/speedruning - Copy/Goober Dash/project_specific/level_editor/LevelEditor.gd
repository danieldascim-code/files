extends Control
class_name LevelEditor

export  var _level: NodePath
onready var level: = get_node(_level) as Level

export  var _tool_select_button: NodePath
onready var tool_select_button: = get_node(_tool_select_button) as BaseButton

export  var _tool_select: NodePath
onready var tool_select: = get_node(_tool_select) as Control

export  var _tool_create: NodePath
onready var tool_create: = get_node(_tool_create) as Control

export  var _play_button: NodePath
onready var play_button: GoodButton = get_node(_play_button)

export  var _level_name_label: NodePath
onready var level_name_label: = get_node(_level_name_label) as Label

export  var _level_editor_camera: NodePath
onready var level_editor_camera: = get_node(_level_editor_camera) as LevelEditorCamera

export  var _ui_canvas_layer: NodePath
onready var ui_canvas_layer: = get_node(_ui_canvas_layer) as CanvasLayer

export  var _ui_root: NodePath
onready var ui_root: = get_node(_ui_root) as Control

export  var _edit_ui_root: NodePath
onready var edit_ui_root: = get_node(_edit_ui_root) as Control

export  var _game_edit_ui_root: NodePath
onready var game_edit_ui_root: = get_node(_game_edit_ui_root) as Control

export  var _grid_renderer: NodePath
onready var grid_renderer: Control = get_node(_grid_renderer)

export  var ui_layer: = 1

export  var _game: NodePath
onready var game: = get_node_or_null(_game) as WPGame

export  var _game_ui: NodePath
onready var game_ui: = get_node_or_null(_game_ui) as GameUI

export  var _game_hud: NodePath
onready var game_hud: GameHUD = get_node_or_null(_game_hud)

export  var _game_input_layer: NodePath
onready var game_input_layer: = get_node_or_null(_game_input_layer) as CanvasLayer

export  var _game_camera: NodePath
onready var game_camera: = get_node_or_null(_game_camera) as Camera2D

export  var _gesture_recognizer: NodePath
onready var gesture_recognizer: GestureRecognizer = get_node(_gesture_recognizer)

export  var _level_browser_dialog: NodePath
onready var level_browser_dialog: LevelEditor_LevelBrowser = get_node(_level_browser_dialog)

export  var _level_browser_button: NodePath
onready var level_browser_button: BaseButton = get_node(_level_browser_button)

export  var _reset_button: NodePath
onready var reset_button: BaseButton = get_node(_reset_button)

export  var _undo_button: NodePath
onready var undo_button: BaseButton = get_node(_undo_button)

export  var _redo_button: NodePath
onready var redo_button: BaseButton = get_node(_redo_button)

export  var _home_button: NodePath
onready var home_button: BaseButton = get_node(_home_button)

export  var _theme_button: NodePath
onready var theme_button: BaseButton = get_node(_theme_button)

export  var _level_save_button: NodePath
onready var level_save_button: BaseButton = get_node(_level_save_button)

export  var _level_save_dialog: NodePath
onready var level_save_dialog: LevelEditor_SaveDialog = get_node(_level_save_dialog)

export  var _theme_dialog: NodePath
onready var theme_dialog: LevelEditor_ThemesDialog = get_node(_theme_dialog)

var is_playing: = false
var is_mouse_present: = false
var undo: UndoRedo

enum Tool{
	Create, 
	Select, 
}
const tool_hotkeys: = {
	KEY_S: Tool.Select, 
	KEY_C: Tool.Create
}
onready var tools: = {
	Tool.Select: tool_select, 
	Tool.Create: tool_create
}

var active_tool: LevelEditorToolInterface
var node_factory: = LevelNodeFactory.new()

func _ready():
	undo = UndoRedo.new()
	get_tree().connect("files_dropped", self, "on_files_dropped")
	stop_tools()
	ui_canvas_layer.layer = ui_layer
	level_browser_dialog.dialog.background_override = true
	level_save_dialog.dialog.background_override = true
	node_factory._load_nodes(false)
	node_factory._load_icon_cache()
	play_button.connect("pressed", self, "on_play_pressed")
	level_save_button.connect("pressed", self, "on_level_save_button_pressed")
	level_browser_button.connect("pressed", self, "on_level_browser_button_pressed")
	reset_button.connect("pressed", self, "on_reset_players_pressed")
	home_button.connect("pressed", self, "on_home_button_pressed")
	theme_button.connect("pressed", self, "on_theme_button_pressed")
	ui_root.connect("gui_input", self, "on_ui_root_gui_input")
	ui_root.connect("mouse_entered", self, "on_mouse_entered")
	ui_root.connect("mouse_exited", self, "on_mouse_exited")
	redo_button.connect("pressed", self, "on_redo_button_pressed")
	undo_button.connect("pressed", self, "on_undo_button_pressed")
	
	level.connect("loaded_level", self, "on_level_loaded")
	level_save_dialog.connect("save_button_pressed", self, "on_save_dialog_save_button_pressed")
	level_save_dialog.connect("fork_button_pressed", self, "fork_current_level")
	level_browser_dialog.connect("play_level", self, "on_level_browser_play_level")
	level_browser_dialog.connect("new_level", self, "on_level_browser_new_level")
	theme_dialog.connect("select_theme", self, "on_theme_dialog_theme_selected")
	play_button.visible = is_playable()
	game_edit_ui_root.visible = false
	edit_ui_root.visible = true
	
	if is_playable():
		_on_play_changed()
		call_deferred("setup_initial_camera")
	
	ui_root.grab_focus()
	tool_select_button.connect("pressed", self, "select_tool", [Tool.Select])
	select_tool(Tool.Select, true)
	if game_hud:
		game_hud.connect("show_level_editor_button_pressed", self, "on_play_pressed")
	
	new_level()

func on_redo_button_pressed():
	var r: bool = undo.redo()
	print("[LevelEditor] redo: %s" % [undo.get_current_action_name()])

func on_undo_button_pressed():
	print("[LevelEditor] undo: %s" % [undo.get_current_action_name()])
	var r: bool = undo.undo()

func _exit_tree() -> void :
	if undo:
		undo.free()
		undo = null

func on_theme_button_pressed():
	theme_dialog.dialog.animate_in()

func on_theme_dialog_theme_selected(t: BaseTheme):
	level.set_level_theme(t)

func on_files_dropped(pool: PoolStringArray, screen: int):
	if pool.size() == 1:
		var first_file: String = pool[0]
		if LevelLoader._is_level_file(first_file):
			print("[LevelEditor] loading file from drag and drop: \'%s\'" % [first_file])
			var level_instance: LevelInstance = LevelLoader.load_local_level_from_path(first_file, node_factory)
			if level_instance != null:
				level.load_level(level_instance)

func on_level_browser_new_level():
	new_level()
	level_browser_dialog.dialog.animate_out()

func on_level_save_button_pressed():
	level.loaded_level.max_players = level.compute_player_count()
	level_save_dialog.show_level_data(level.loaded_level)
	level_save_dialog.dialog.animate_in()

func on_level_browser_button_pressed():
	level_browser_dialog.dialog.animate_in()

func on_level_browser_play_level(level_id: String, level_data: Dictionary):
	var level_instance: LevelInstance = yield(LevelLoader.async_load_level_from_cloud(level_id, node_factory), "completed")
	level_browser_dialog.dialog.animate_out()
	if level_instance != null:
		level.load_level(level_instance)

func on_save_dialog_save_button_pressed():
	set_level_name_label()

func select_tool(tool_key: int, silent: = false):
	active_tool = tools.get(tool_key)
	var active_select: = active_tool == tool_select
	if not active_select:
		tool_select_button.pressed = false
	elif not tool_select_button.pressed:
		tool_select_button.pressed = true
		if not silent:
			tool_select_button.emit_signal("pressed")

func on_ui_root_gui_input(event: InputEvent) -> void :
	if event is InputEventKey:
		if event.pressed:
			if tool_hotkeys.has(event.scancode) and not event.alt and not event.command and not event.control and not event.meta:
				select_tool(tool_hotkeys[event.scancode])
	
	if event is InputEventKey:
		if event.control:
			if event.scancode == KEY_Z:
				on_undo_button_pressed()
			elif event.scancode == KEY_Y:
				on_redo_button_pressed()
	
	if active_tool:
		active_tool._ui_root_gui_input(event)

func on_mouse_entered():
	is_mouse_present = true

func on_mouse_exited():
	is_mouse_present = false

func _process(delta: float) -> void :
	tool_create.visible = active_tool == tool_create and not is_playing
	tool_select.visible = active_tool == tool_select and not is_playing
	undo_button.disabled = not undo.has_undo()
	redo_button.disabled = not undo.has_redo()

func on_reset_players_pressed():
	reset_players()

func on_home_button_pressed():
	var confirmation_dialog_scene: PackedScene = GoodResourceLoader.load_resource("res://goodoh/ui/nodes/UIConfirmationDialog.tscn")
	var confirm_dialog: UIConfirmationDialog = confirmation_dialog_scene.instance()
	confirm_dialog.text = "Exit to home?"
	
	get_tree().current_scene.add_child(confirm_dialog)
	confirm_dialog.dialog.background_override = true
	confirm_dialog.dialog.dialog_title_label.text = "EXIT"
	var confirmed: bool = yield(confirm_dialog, "confirm_or_cancel")
	if confirmed:
		LoadHomeOnPress.go_home(get_tree())

func reset_players():
	if game != null:
		game._reset_players_with_reset_time(0.0)

func is_playable() -> bool:
	return game and game_camera and game_ui and game_input_layer

func on_play_pressed():
	if is_playable():
		is_playing = not is_playing
		_on_play_changed()

func _on_play_changed():
	game_camera.current = is_playing
	level_editor_camera.current = not is_playing
	game_input_layer.visible = is_playing
	game_ui.visible = is_playing
	edit_ui_root.visible = not is_playing
	
	grid_renderer.visible = not is_playing
	level_save_button.disabled = is_playing
	
	if not is_playing:
		level_editor_camera.global_position = game_camera.global_position
		level_editor_camera.target_position = level_editor_camera.global_position
		level_editor_camera.zoom = game_camera.zoom
		level_editor_camera.target_zoom = game_camera.zoom.x

func new_level():
	var default_level: LevelInstance = LevelLoader.load_local_level("default", LevelLoader.LevelLoadLocation.Special, node_factory)
	level.load_level(default_level)
	fork_current_level()

func fork_current_level():
	print("[LevelEditor] fork_current_level()")
	var my_author_id: = ""
	if Moonlight.local_account != null:
		my_author_id = Moonlight.local_account.user.id
	level.loaded_level.level_id = ""
	level.loaded_level.author_id = my_author_id
	level.loaded_level.level_published = "Private"

func check_auto_fork_level():
	var my_author_id: = ""
	if Moonlight.local_account != null:
		my_author_id = Moonlight.local_account.user.id
	
	if not WinterpixelUser.is_winterpixel_user():
		var is_someone_elses_level: = not level.loaded_level.author_id.empty() and level.loaded_level.author_id != my_author_id
		var is_noones_level: = level.loaded_level.level_id.empty()
		
		if is_noones_level or is_someone_elses_level:
			
			
			fork_current_level()

func on_level_loaded():
	undo.clear_history()
	check_auto_fork_level()
	if game:
		game.wp_game_data.play_time = - game.wp_game_data.transition_timer_preplay_time
	
	var starting_points: = level.get_starting_points()
	var starting_position: = Vector2.ZERO
	if starting_points.size() > 0:
		
		
		starting_position = starting_points[0].world_rect.get_center()
	level_editor_camera.global_position = starting_position
	level_editor_camera.target_position = starting_position
	reset_players()
	set_level_name_label()
	setup_initial_camera()

func set_level_name_label():
	if level_name_label:
		var level_name: String = "New Level"
		if level and level.loaded_level and not level.loaded_level.level_name.empty():
			level_name = level.loaded_level.level_name
		level_name_label.text = level_name

func stop_tools():
	for t in tools.values():
		var _tool: = t as LevelEditorToolInterface
		_tool._stop_tool()

func setup_initial_camera():
	
	if game_camera:
		level_editor_camera.target_zoom = game_camera._compute_distance_zoom()
		level_editor_camera.zoom = Vector2.ONE * level_editor_camera.target_zoom
	
	if game:
		var local_player: = game.get_local_player() as WPPlayer
		if local_player:
			level_editor_camera.global_position = local_player.position
			level_editor_camera.target_position = level_editor_camera.global_position
