extends Control
class_name LevelEditor_LevelRow

signal button_pressed()

export  var _button: NodePath
onready var button: BaseButton = get_node(_button)

export  var _name_label: NodePath
onready var name_label: Label = get_node(_name_label)

export  var _mode_label: NodePath
onready var mode_label: Label = get_node(_mode_label)

export  var _rating_parent: NodePath
onready var rating_parent: Control = get_node(_rating_parent)

export  var _rating_label: NodePath
onready var rating_label: SDFLabel = get_node(_rating_label)

export  var _rating_icon: NodePath
onready var rating_icon: TextureRect = get_node(_rating_icon)

export  var _rating_count: NodePath
onready var rating_count: Label = get_node(_rating_count)

export  var _author_label: NodePath
onready var author_label: Label = get_node(_author_label)

export  var _time_updated_label: NodePath
onready var time_updated_label: Label = get_node(_time_updated_label)

export  var _play_count_label: NodePath
onready var play_count_label: Label = get_node(_play_count_label)

export  var _certified_icon: NodePath
onready var certified_icon: Control = get_node(_certified_icon)

export  var _favorites_parent: NodePath
onready var favorites_parent: Control = get_node(_favorites_parent)

export  var _favorites_label: NodePath
onready var favorites_label: Label = get_node(_favorites_label)

export  var positive_rating_color: Color
export  var medium_rating_color: Color
export  var negative_rating_color: Color
export  var unknown_rating_color: Color

var level_id: String = ""

func show_level_data(_level_id: String, data: Dictionary):
	level_id = _level_id
	name_label.text = data.get("name", "-")
	mode_label.text = _mode_format(data)
	
	rating_label.text = _rating_format(data)
	rating_count.text = _rating_count_format(data)
	var rating_color: Color = _rating_color(data)
	rating_label.color = rating_color
	rating_icon.self_modulate = rating_color
	author_label.text = data.get("author_name", "")
	time_updated_label.text = _time_updated_format(data)
	time_updated_label.hint_tooltip = _time_updated_tooltip(data)
	play_count_label.text = _play_count_format(data)
	certified_icon.visible = data.get("published", "") == "Curated"
	button.connect("pressed", self, "emit_signal", ["button_pressed"])
	
	favorites_parent.visible = data.has("favorites_count")
	rating_parent.visible = not favorites_parent.visible
	if favorites_parent.visible:
		var favorites_count: String = str(data.get("favorites_count", "0"))
		print("rendering " + favorites_count)
		favorites_label.text = favorites_count
		print("from data: %s" % data)

func _rating_color(data: Dictionary) -> Color:
	if data.has("rating"):
		var r: float = data["rating"]
		if r > 4.0:
			return positive_rating_color
		elif r > 2.5:
			return medium_rating_color
		else:
			return negative_rating_color
	else:
		return unknown_rating_color

func _rating_format(data: Dictionary) -> String:
	if data.has("rating"):
		var r: = float(data["rating"])
		var rating_percent: = 25.0 * (r - 1.0)
		return "%d%%" % [rating_percent]
	return "-"

func _rating_count_format(data: Dictionary) -> String:
	if data.has("rating_count"):
		return "(%s)" % [data["rating_count"]]
	return "(-)"

func _mode_format(data: Dictionary) -> String:
	return "%s (%s)" % [data.get("game_mode", "-"), data.get("player_count", "-")]

func _play_count_format(data: Dictionary) -> String:
	
	return ""

func _time_updated_format(data: Dictionary) -> String:
	
	var update_time_string: String = data["update_time"]
	var update_time_unix: = Time.get_unix_time_from_datetime_string(update_time_string)
	var now: = Time.get_unix_time_from_system()
	return DateTimeUtils.format_time_past(now - update_time_unix)

func _time_updated_tooltip(data: Dictionary) -> String:
	
	var update_time_string: String = data["update_time"]
	var date_time_dict: = Time.get_datetime_dict_from_datetime_string(update_time_string, false)
	return "%s/%s/%s" % [date_time_dict["day"], date_time_dict["month"], date_time_dict["year"]]
