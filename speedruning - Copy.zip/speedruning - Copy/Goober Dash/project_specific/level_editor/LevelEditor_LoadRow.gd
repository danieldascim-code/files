extends HBoxContainer
class_name LevelEditorLoadRow






signal on_delete_pressed(name, location, uuid)
signal on_edit_pressed(name, location, uuid)
signal on_copy_pressed(name, location, uuid)

var level_uuid: = ""
var level_name: = ""
var level_type: = ""
var level_max_players: = 4
var level_published_state: = "Private"
var level_location: int = LevelLoader.LevelLoadLocation.Cloud
var level_modified_date: int = 0


export  var _name_label: NodePath
onready var name_label: = get_node(_name_label) as Label

export  var _mode_label: NodePath
onready var mode_label: = get_node(_mode_label) as Label

export  var _players_label: NodePath
onready var players_label: = get_node(_players_label) as Label

export  var _published_label: NodePath
onready var published_label: = get_node(_published_label) as Label

export  var _modified_label: NodePath
onready var modified_label: = get_node(_modified_label) as Label

export  var _delete_button: NodePath
onready var delete_button: = get_node(_delete_button) as Button

export  var _copy_button: NodePath
onready var copy_button: = get_node(_copy_button) as Button

export  var _play_button: NodePath
onready var play_button: = get_node(_play_button) as Button



func _ready():
	sync_ui()
	delete_button.connect("pressed", self, "on_delete_button_pressed")
	play_button.connect("pressed", self, "on_play_button_pressed")
	copy_button.connect("pressed", self, "on_copy_button_pressed")
	copy_button.visible = false
	
func hide_delete_button():
	play_button.visible = false
	delete_button.visible = false
	copy_button.visible = true
	
func on_delete_button_pressed():
	
	var confirm_dialog: UIConfirmationDialog = GoodResourceLoader.load_resource(GoodSceneRegistry.confirmation_dialog_scene).instance()
	confirm_dialog.text = "Are you sure you want to delete %s?" % [level_name]
	get_tree().current_scene.add_child(confirm_dialog)
	var result: bool = yield(confirm_dialog, "confirm_or_cancel")
	if result:
		emit_signal("on_delete_pressed", level_name, level_location, level_uuid)

func on_play_button_pressed():
	emit_signal("on_edit_pressed", level_name, level_location, level_uuid)
		
func on_copy_button_pressed():
	emit_signal("on_copy_pressed", level_name, level_location, level_uuid)

func set_data_dict(data: Dictionary):
	level_uuid = data["uuid"]
	level_name = data["level_name"]
	level_published_state = data["pub_state"]
	level_type = data["game_mode"]
	level_max_players = data["player_count"]
	level_location = data["location"]
	if data["update_time"]:
		level_modified_date = data["update_time"]
	
func sync_ui():
	name_label.text = level_name
	mode_label.text = level_type
	players_label.text = String(level_max_players)
	published_label.text = level_published_state
	if (level_modified_date > 0):
		modified_label.text = Time.get_date_string_from_unix_time(level_modified_date)
	else:
		modified_label.text = ""
	
	




