tool 
extends Node2D

onready var line: = $Line2D as Line2D
export  var width: = 10.0
export  var scale_factor: = Vector2.ONE





export  var anchor: = 0.5

const points: = PoolVector2Array([
	Vector2( - 1, - 1), 
	Vector2(1, - 1), 
	Vector2(1, 1), 
	Vector2( - 1, 1), 
	Vector2( - 1, - 1), 
])

func _init() -> void :
	if is_inside_tree():
		line = $Line2D as Line2D

func _ready() -> void :
	_update_line()

func _process(delta: float) -> void :
	_update_line()

func _update_line():
	line.width = width
	
	line.scale = Vector2.ONE / global_scale
	
	line.clear_points()
	
	var line_width_scaled: = Vector2.ZERO
	for p in points:
		var point: Vector2 = p
		var center_line_point: = point * scale_factor * global_scale
		
		
		
		var centering_x: = (0.5 - anchor) * sign(p.x) * width
		var centering_y: = (0.5 - anchor) * sign(p.y) * width
		var anchored: = center_line_point + Vector2(centering_x, centering_y)
		
		line.add_point(anchored)
