extends UpGuys_PolygonTerrain













export  var line_material_path: String = "res://project_specific/level_editor/terrain_stroke.material"
var line_material: Material
export  var shadow_material_path: String = "res://project_specific/level_editor/terrain_shadow.material"
var shadow_material: Material

var shadow_script: GDScript
export  var shadow_script_path: String = "res://project_specific/level_editor/nodes/LevelNodeShadow.gd"

export  var enable_shadows: = false

onready var level: Level = get_parent()
onready var level_node: = get_node_or_null("../..")

var enabled: = true

var dirty: = false

var thicknesses: = PoolRealArray()
var terrain_colors: = []
var line_materials: = []
var last_view_scale: = - 1.0
const line_material_view_scale_uniform: = "view_scale"
const enable_hide_nodes: = true
const relevant_types: = ["block", "ramp"]

func _ready():
	var game: NetworkGame = Utilities.find_game(self, false)
	enabled = not game or game.client_renderer != null
	
	if enabled:
		line_material = load(line_material_path)
		shadow_material = load(shadow_material_path)
		shadow_script = load(shadow_script_path)
		if level:
			level.connect("theme_changed", self, "on_theme_changed")
			level.connect("added_node", self, "on_added_node")
			level.connect("removed_node", self, "on_removed_node")
			level.connect("loaded_level", self, "on_loaded_level")
			level.connect("child_entered_tree", self, "on_added_node")
		elif level_node:
			level_node.connect("apply_bounding_box", self, "on_apply_bounding_box")
			level_node.connect("animation_created", self, "on_animation_created")
			level_node.connect("animation_deleted", self, "on_animation_deleted")
			level_node.connect("tree_exiting", self, "on_removed_node", [level_node])
		else:
			printerr("[PolygonTerrain] No level or level_node found!")

func on_theme_changed(_theme: BaseTheme):
	request_recalculate()

func on_added_node(node: LevelNode):
	if not node:
		return
	if node.node_type in relevant_types:
		request_recalculate()
		node.connect("apply_bounding_box", self, "on_apply_bounding_box")
		node.connect("animation_created", self, "on_animation_created")
		node.connect("animation_deleted", self, "on_animation_deleted")
		node.connect("tree_exiting", self, "on_removed_node", [node])
		node.connect("level_node_property_changed", self, "on_level_node_property_changed")

func on_level_node_property_changed(property_name: String, property_value):
	request_recalculate()

func on_removed_node(node: LevelNode):
	if dirty:
		return
	if not node:
		return
	if node.node_type in relevant_types:
		request_recalculate()

func on_loaded_level():
	for i in level.loaded_level.get_child_count():
		var node: = level.loaded_level.get_child(i)
		if node is LevelNode:
			on_added_node(node)
	request_recalculate()

func on_apply_bounding_box():
	request_recalculate()

func on_animation_created(_node: LevelNode):
	request_recalculate()

func on_animation_deleted(_node: LevelNode):
	request_recalculate()

func request_recalculate():
	dirty = true

func _process(_delta):
	if not enabled:
		return


	
	var view_scale: = get_viewport().get_canvas_transform().get_scale()
	var view_scale_avg: = (view_scale.x + view_scale.y) * 0.5
	if not is_equal_approx(view_scale_avg, last_view_scale):
		
		for mat in line_materials:
			mat.set_shader_param(line_material_view_scale_uniform, view_scale_avg)
		last_view_scale = view_scale_avg

	if dirty:
		recalculate_wrapper()
		dirty = false

func recalculate():
	if not dirty:
		return
	dirty = false
	

	
	var theme: = level.level_theme
	if theme:
		thicknesses = PoolRealArray([
			theme.terrain_color_1_thickness * 256.0, 
			theme.terrain_color_2_thickness * 256.0, 
			theme.terrain_color_3_thickness * 256.0, 
		])
		terrain_colors = [
			theme.terrain_color_1, 
			theme.terrain_color_2, 
			theme.terrain_color_3, 
		]
	else:
		thicknesses = PoolRealArray([
			1, 
			2, 
			3, 
		])
		terrain_colors = [
			Color.mediumseagreen, 
			Color.darksalmon, 
			Color.darkslategray, 
		]
	line_materials.clear()
	for i in thicknesses.size():
		var mat: = line_material.duplicate()
		mat.set_shader_param("color", terrain_colors[i])
		mat.set_shader_param("width", thicknesses[i])
		mat.set_shader_param(line_material_view_scale_uniform, last_view_scale)
		line_materials.push_back(mat)

	
	var all_polys: = []
	if level:
		if level.loaded_level:
			
			
			for i in level.loaded_level.get_child_count():
				var node: = level.loaded_level.get_child(i)
				if node is LevelNode:
					process_level_node(node, all_polys, theme)
		
		
		for i in level.get_child_count():
			var node: = level.get_child(i) as LevelNode
			if node:
				if not node.is_connected("apply_bounding_box", self, "on_apply_bounding_box"):
					on_added_node(node)
				process_level_node(node, all_polys, theme)
	elif level_node:
		process_level_node(level_node, all_polys, theme)
	
	process_polys(all_polys, self, theme)

func process_level_node(node: LevelNode, all_polys: Array, theme: BaseTheme):
	if not node.renderer:
		return
	var polygon2d: Polygon2D = node.renderer.get_node_or_null("Polygon2D")
	if polygon2d == null:
		return

	if node.animation != null:
		var parent: Node = node.renderer.get_node_or_null("PolyParent")
		if parent == null:
			return
		node.show()
		var renderer_global_transform: = node.renderer.global_transform
		var points: = polygon2d.polygon
		var xform: = Transform2D.IDENTITY.scaled(renderer_global_transform.get_scale())
		for i in points.size():
			points[i] = xform.xform(points[i])
		parent.transform = parent.transform.scaled(parent.transform.affine_inverse().get_scale() / xform.get_scale())
		process_polys([points], parent, theme)
	else:
		if enable_hide_nodes:
			
			node.hide()
		
		var points: = polygon2d.polygon
		for i in points.size():
			points[i] = node.renderer.global_transform.xform(points[i])
		all_polys.push_back(points)

func process_polys(all_polys: Array, parent: Node, theme: BaseTheme):
	var use_all_meshes: bool = true
	
	var clipper: = GDClipper2.new()
	var insets: = PoolRealArray()
	
	var r: = 0.0
	for i in thicknesses.size():
		r += thicknesses[i] * 0.5
		insets.push_back(r - 0.25)
		r += thicknesses[i] * 0.5

	var liness: = []
	var polys: = []
	var outer_corner_r: = 8.0
	var inner_corner_r: = 8.0
	if theme:
		outer_corner_r = clamp(theme.terrain_corner_radius, 0.0, 16.0)
		inner_corner_r = clamp(theme.terrain_corner_radius_inner, 0.0, 16.0)
	clipper.super_merge_upguys(all_polys, insets, outer_corner_r, inner_corner_r, liness, polys)

	while parent.get_child_count() > 0:
		var c: = parent.get_child(parent.get_child_count() - 1)
		parent.remove_child(c)
		c.free()
	var terrain_texture: Texture
	if theme:
		terrain_texture = theme.terrain_texture
	
	for i in polys.size():
		if not use_all_meshes:
			
			var poly2d: = Polygon2D.new()
			poly2d.texture = terrain_texture
			
			poly2d.set_polygon(polys[i])
			parent.add_child(poly2d)
		else:
			
			var mesh2d: = MeshInstance2D.new()
			mesh2d.texture = terrain_texture
			var points: PoolVector2Array = polys[i]
			var indicies: = Geometry.triangulate_polygon(points)
			var mesh: = ArrayMesh.new()
			var arrays = []
			arrays.resize(ArrayMesh.ARRAY_MAX)
			arrays[ArrayMesh.ARRAY_VERTEX] = points
			var uvs: = PoolVector2Array()
			uvs.resize(points.size())
			var tex_size: = terrain_texture.get_size()
			for uv_index in points.size():
				uvs[uv_index] = points[uv_index] / tex_size
			arrays[ArrayMesh.ARRAY_TEX_UV] = uvs
			arrays[ArrayMesh.ARRAY_INDEX] = indicies
			
			mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
			mesh2d.mesh = mesh
			parent.add_child(mesh2d)
		
		









	for i in liness.size():
		var lines: Array = liness[i]
		for j in lines.size():
			var points: PoolVector2Array = lines[j]
			var p_start: Vector2 = points[0]
			var p_end: Vector2 = points[points.size() - 1]
			var mid_edge: = (p_start + p_end) * 0.5
			points.insert(0, mid_edge)
			points.push_back(mid_edge)
			if not use_all_meshes:
				
				var line2d: = Line2D.new()
				if i == 0:
					line2d.joint_mode = Line2D.LINE_JOINT_ROUND
				else:
					line2d.joint_mode = Line2D.LINE_JOINT_SHARP
					line2d.sharp_limit = 100.0
				line2d.points = points
				line2d.width = thicknesses[i] + 1.0
				line2d.texture_mode = Line2D.LINE_TEXTURE_STRETCH
				line2d.material = line_materials[i]
				
				parent.add_child(line2d)
			else:
				
				var mesh_instance: = MeshInstance2D.new()
				var mesh: = ArrayMesh.new()
				var joint_mode: = Line2D.LINE_JOINT_SHARP
				var sharp_limit: = 100.0
				if i == 0:
					joint_mode = Line2D.LINE_JOINT_ROUND
					sharp_limit = 2.0
				var width: = thicknesses[i] + 1.0
				WPMath.build_line_mesh(mesh, points, Line2D.LINE_TEXTURE_STRETCH, joint_mode, Line2D.LINE_CAP_NONE, Line2D.LINE_CAP_NONE, 8, sharp_limit, width)
				mesh_instance.mesh = mesh
				mesh_instance.material = line_materials[i]
				parent.add_child(mesh_instance)
	
	
	if enable_shadows:
		for i in liness.size():
			var lines: Array = liness[i]
			for j in lines.size():
				var points: PoolVector2Array = lines[j]
				var p_start: Vector2 = points[0]
				var p_end: Vector2 = points[points.size() - 1]
				var mid_edge: = (p_start + p_end) * 0.5
				points.insert(0, mid_edge)
				points.push_back(mid_edge)

				var line2d: = Line2D.new()
				if i == 0:
					line2d.joint_mode = Line2D.LINE_JOINT_ROUND
				else:
					line2d.joint_mode = Line2D.LINE_JOINT_SHARP
					line2d.sharp_limit = 100.0
				line2d.points = points
				line2d.width = thicknesses[i] + 1.0
				line2d.texture_mode = Line2D.LINE_TEXTURE_STRETCH
				line2d.material = shadow_material
				line2d.set_script(shadow_script)
				line2d.offset = Vector2(3.0, 3.0)
				line2d.z_index = 20
				line2d.z_as_relative = false
				parent.add_child(line2d)
