extends Control
class_name LevelEditor_Inspector

signal rotate_pressed()
signal copy_pressed()
signal paste_pressed()
signal delete_pressed()

export  var _level_editor: NodePath
onready var level_editor: LevelEditor = get_node(_level_editor)

export  var _properties_panel: NodePath
onready var properties_panel: LevelEditor_PropertiesEditor = get_node(_properties_panel)

export  var _animation_editor: NodePath
onready var animation_editor: LevelEditor_AnimationEditor = get_node(_animation_editor)

export  var _properties_button: NodePath
onready var properties_button: BaseButton = get_node(_properties_button)

export  var _position_button: NodePath
onready var position_button: BaseButton = get_node(_position_button)

export  var _rotation_button: NodePath
onready var rotation_button: BaseButton = get_node(_rotation_button)

export  var _title_label: NodePath
onready var title_label: Label = get_node(_title_label)

export  var _title_icon: NodePath
onready var title_icon: TextureRect = get_node(_title_icon)

export  var _scroll_container: NodePath
onready var scroll_container: ScrollContainer = get_node(_scroll_container)

onready var panels: = [properties_panel, animation_editor]

export  var multi_node_texture: Texture

var is_in_landscape: = false

func _ready() -> void :
	properties_button.connect("pressed", self, "_show_panel", [properties_panel])
	position_button.connect("pressed", self, "_show_panel", [animation_editor])
	rotation_button.connect("pressed", self, "_show_panel", [animation_editor])
	_show_panel(properties_panel)
	call_deferred("_relayout_portrait_landscape", true)
	for p in panels:
		var inspector_panel: = p as LevelEditor_InspectorPanel
		inspector_panel.level_editor = level_editor

func _show_panel(panel: Control):
	for p in panels:
		p.visible = p == panel
	scroll_container.scroll_vertical = 0

func render_nodes(level_nodes: Array):
	if level_nodes == null or level_nodes.size() == 0:
		visible = false
	else:
		visible = true
	
	if level_nodes.size() == 0:
		title_label.text = "INSPECTOR"
		title_icon.texture = null
	elif level_nodes.size() == 1:
		var level_node: LevelNode = level_nodes[0]
		title_label.text = level_node.name.replace("_", " ").to_upper()
		title_icon.texture = level_editor.node_factory.icon_cache.get(level_node.node_type)
	elif level_nodes.size() > 1:
		title_label.text = "%d NODES" % [level_nodes.size()]
		title_icon.texture = multi_node_texture
	
	for p in panels:
		var inspector_panel: = p as LevelEditor_InspectorPanel
		inspector_panel.render_nodes(level_nodes)

func _process(delta: float) -> void :
	_relayout_portrait_landscape(false)

func _relayout_portrait_landscape(p_force: bool):
	var parent_size: = get_parent_control().rect_size
	if parent_size.y <= 0.0:
		return
	var new_is_in_landscape: = parent_size.x / parent_size.y > 0.75
	if is_in_landscape != new_is_in_landscape or p_force:
		is_in_landscape = new_is_in_landscape
		if is_in_landscape:
			anchor_left = 1.0
			anchor_right = 1.0
			anchor_top = 0.0
			anchor_bottom = 1.0
			margin_left = 0.0
			margin_right = - 50.0
			margin_top = 50.0
			margin_bottom = - 50.0
		else:
			anchor_left = 0.0
			anchor_right = 1.0
			anchor_top = 0.66
			anchor_bottom = 1.0
			margin_left = 50.0
			margin_right = - 50.0
			margin_top = 0.0
			margin_bottom = - 10.0
	
