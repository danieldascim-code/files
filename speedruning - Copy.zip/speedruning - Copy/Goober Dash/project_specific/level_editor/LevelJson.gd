extends Object
class_name LevelJson

static func serialize_level(level: LevelInstance) -> Dictionary:
	var metadata: = {}
	metadata["id"] = level.level_id
	metadata["name"] = level.level_name
	metadata["type"] = level.level_type
	metadata["game_mode"] = LevelUtils.string_for_level_type(level.level_type)
	metadata["theme"] = level.level_theme
	metadata["published"] = level.level_published
	metadata["player_count"] = level.max_players
	metadata["author_id"] = level.author_id
	metadata["author_name"] = level.author_name
	metadata["rating"] = level.rating
	metadata["rating_count"] = level.rating_count

	var nodes: = []
	for i in level.get_child_count():
		var c = level.get_child(i)
		var level_node: = c as LevelNode
		if level_node:
			var level_node_data: = level_node.serialize_level_node()
			nodes.append(level_node_data)
	
	var level_data: = {
		"metadata": metadata, 
		"nodes": nodes
	}
	return level_data

static func deserialize_level(input: Dictionary, node_factory: LevelNodeFactory) -> LevelInstance:
	var level_instance: = LevelInstance.new()
	var metadata: Dictionary = input["metadata"]
	level_instance.level_id = metadata.get("id", "")
	level_instance.author_id = metadata.get("author_id", "")
	level_instance.author_name = metadata.get("author_name", "")
	level_instance.rating = metadata.get("rating", 0.0)
	level_instance.rating_count = int(metadata.get("rating_count", 0))
	level_instance.level_name = metadata["name"]
	level_instance.name = level_instance.level_name
	level_instance.level_type = LevelUtils.level_type_for_string(metadata["game_mode"])
	level_instance.level_theme = metadata["theme"]
	level_instance.level_published = metadata["published"]
	level_instance.max_players = metadata["player_count"]
	
	var nodes: Array = input["nodes"]
	for i in nodes.size():
		var node_data: Dictionary = nodes[i]
		var level_node: = deserialize_level_node(node_data, node_factory)
		if level_node == null:
			continue
		level_node.level_node_index = i
		level_instance.add_child(level_node)
	return level_instance

static func deserialize_level_node(node_data: Dictionary, node_factory: LevelNodeFactory) -> LevelNode:
	var node_type: String = node_data["type"]
	var level_node: = node_factory.create_node(node_type)
	if level_node == null:
		return null
	level_node.fetch_sub_nodes()
	level_node.deserialize_level_node(node_data)
	return level_node
