extends Camera2D
class_name LevelEditorCamera

var target_position: = Vector2.ZERO
var target_zoom: = 1.0

const max_zoom: = 5.0
const min_zoom: = 0.1
const enable_position_smoothing: = false
const enabling_zoom_smoothing: = true
const position_smoothing: = 0.1
const zoom_smoothing: = 0.1

var smoothed_position: = Vector2.ZERO
var smoothed_zoom: = 0.0

func _ready() -> void :
	pass

func _process(delta: float) -> void :
	target_zoom = clamp(target_zoom, min_zoom, max_zoom)
	
	if enabling_zoom_smoothing:
		var zoom_smooth_result: = Smoothing.smooth_damp(zoom.x, target_zoom, smoothed_zoom, zoom_smoothing, delta)
		zoom = Vector2(zoom_smooth_result.x, zoom_smooth_result.x)
		smoothed_zoom = zoom_smooth_result.y
	else:
		zoom = Vector2(target_zoom, target_zoom)
	
	
	if enable_position_smoothing:
		var position_smooth_result: = Smoothing.smooth_damp_vec2(position, target_position, smoothed_position, position_smoothing, delta)
		position = position_smooth_result[0]
		smoothed_position = position_smooth_result[1]
	else:
		position = target_position
	
	force_update_scroll()
	if current:
		ViewportRectCalculator.calculate_viewport_visible_rect()
