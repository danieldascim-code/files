extends CanvasLayer
class_name LevelEditor_LevelBrowser

signal play_level(level_id, level_metadata)
signal new_level()

export  var levels_row_scene: PackedScene

export  var _create_new_parent: NodePath
onready var create_new_parent: Control = get_node(_create_new_parent)

export  var _create_new_button: NodePath
onready var create_new_button: BaseButton = get_node(_create_new_button)

export  var _levels_rows_parent: NodePath
onready var levels_rows_parent: Control = get_node(_levels_rows_parent)

export  var _button_grouper: NodePath
onready var button_grouper: ButtonGrouper = get_node(_button_grouper)

export  var _spinner_parent: NodePath
onready var spinner_parent: Control = get_node(_spinner_parent)

onready var dialog: UIDialog = $UIDialog

export  var _name_button: NodePath
onready var name_button: GoodButton = get_node(_name_button)

export  var _mode_button: NodePath
onready var mode_button: GoodButton = get_node(_mode_button)

export  var _sort_button_time: NodePath
onready var sort_button_time: GoodButton = get_node(_sort_button_time)

export  var _rating_button: NodePath
onready var rating_button: GoodButton = get_node(_rating_button)

export  var _search_tab_container: NodePath
onready var search_tab_container: Control = get_node(_search_tab_container)

export  var _search_row: NodePath
onready var search_row: Control = get_node(_search_row)

export  var _search_page_button: NodePath
onready var search_page_button: GoodButton = get_node(_search_page_button)

export  var _search_page_line_edit: NodePath
onready var search_page_line_edit: LineEdit = get_node(_search_page_line_edit)

export  var _levels_list_page: NodePath
onready var levels_list_page: Control = get_node(_levels_list_page)

export  var _filter_row_container: NodePath
onready var filter_row_container: Control = get_node(_filter_row_container)

export  var _time_range_row_container: NodePath
onready var time_range_row_container: Control = get_node(_time_range_row_container)

export  var _time_range_options: NodePath
onready var time_range_options: OptionButton = get_node(_time_range_options)

export  var _filter_line_edit: NodePath
onready var filter_line_edit: LineEdit = get_node(_filter_line_edit)

export  var _filter_line_edit_clear_button: NodePath
onready var filter_line_edit_clear_button: BaseButton = get_node(_filter_line_edit_clear_button)

export  var _empty_levels_row: NodePath
onready var empty_levels_row: Control = get_node(_empty_levels_row)

export  var _empty_levels_row_message: NodePath
onready var empty_levels_row_message: Label = get_node(_empty_levels_row_message)

const empty_levels_row_message_default: = "No levels found."
const empty_levels_row_message_editor_info: = "Create your own Levels\nin the Level Editor!"

enum SortIds{
	Name = 1, 
	Mode, 
	Players, 
	Rating, 
	TimeUpdated, 
}
onready var sort_buttons: = {
	SortIds.Name: name_button, 
	SortIds.Mode: mode_button, 
	SortIds.TimeUpdated: sort_button_time, 
	
	SortIds.Rating: rating_button
}

onready var sort_button_group: = ButtonGroup.new()
const initial_sort_id: = - SortIds.TimeUpdated

export  var disable_level_creation: = false setget set_disable_level_creation
export  var disable_level_search: = false setget set_disable_level_search
export  var allow_editor_info_message: = true

var level_rows: = {}
var level_rows_array: = []
var level_rows_filter_similarity: = {}

var all_level_data: = {}
var has_queried: = false
var query_counter: = 0

enum TabIds{
	MyLevels, 
	Favorites, 
	PublicTop, 
	PublicNew, 
	Curated, 
	Search, 
	Max
}
const TabNames: = {
	TabIds.MyLevels: "MY LEVELS", 
	TabIds.Favorites: "FAVORITES", 
	TabIds.PublicTop: "MOST FAV\'D", 
	TabIds.PublicNew: "NEW", 
	TabIds.Curated: "CERTIFIED", 
	TabIds.Search: "SEARCH", 
}

var sort_id: int = SortIds.Name setget set_sort_id
var game_mode_filter: Array = []

func _ready() -> void :
	set_disable_level_creation(disable_level_creation)
	set_disable_level_search(disable_level_search)
	for _sort_id in sort_buttons:
		var sort_button: GoodButton = sort_buttons[_sort_id]
		sort_button.toggle_mode = true
		sort_button.group = sort_button_group
		sort_button.pressed = _sort_id == abs(initial_sort_id)
		sort_button.connect("pressed", self, "on_sort_button_pressed", [_sort_id])
	
	set_sort_id(initial_sort_id)
	
	button_grouper.connect("changed", self, "on_button_grouper_changed")
	create_new_button.connect("pressed", self, "on_create_new_button_pressed")
	dialog.connect("animated_in", self, "on_animated_in")
	connect("visibility_changed", self, "on_visibility_changed")
	
	search_page_button.connect("pressed", self, "on_search_page_button_pressed")
	search_page_line_edit.connect("text_entered", self, "on_search_page_line_edit_enter")
	
	filter_line_edit.connect("text_changed", self, "on_filter_line_edit_text_changed")
	filter_line_edit.connect("text_entered", self, "on_filter_line_edit_text_entered")
	filter_line_edit_clear_button.connect("pressed", self, "on_filter_line_edit_clear_button_pressed")
	
	time_range_options.add_item("All Time", LevelCloudLoader.TopRatedTimeRange.AllTime)
	time_range_options.add_item("Today", LevelCloudLoader.TopRatedTimeRange.Day)
	time_range_options.add_item("This Week", LevelCloudLoader.TopRatedTimeRange.Week)
	time_range_options.add_item("This Month", LevelCloudLoader.TopRatedTimeRange.Month)
	time_range_options.connect("item_selected", self, "on_time_range_options_item_selected")
	time_range_options.selected = LevelCloudLoader.TopRatedTimeRange.AllTime
	
	FocusGlobal.connect("focus_lost", self, "on_focus_lost")

func on_time_range_options_item_selected(_time_range_item_index: int):
	query_levels()

func on_filter_line_edit_clear_button_pressed():
	filter_line_edit.text = ""
	sort_rows()

func on_filter_line_edit_text_changed(t: String):
	sort_rows()

func on_filter_line_edit_text_entered(t: String):
	sort_rows()

func _compute_filter_similarites():
	level_rows_filter_similarity.clear()
	if not filter_line_edit.is_visible_in_tree():
		return
	if filter_line_edit.text.empty():
		return
	var t: = filter_line_edit.text.to_lower()
	for level_id in all_level_data:
		var level_data: Dictionary = all_level_data[level_id]
		var similarity_name: = _compute_similarity(t, level_data, "name")
		var similarity_author: = _compute_similarity(t, level_data, "author_name")
		var similarity_mode: = _compute_similarity(t, level_data, "game_mode")
		var similarity_count: = _compute_similarity(t, level_data, "player_count")
		var similarity: = max(similarity_name, max(similarity_author, max(similarity_mode, similarity_count)))
		level_rows_filter_similarity[level_id] = similarity

func _compute_similarity(filter: String, level_data: Dictionary, level_data_key: String) -> float:
	var level_data_field: = str(level_data.get(level_data_key, ""))
	if level_data_field.empty():
		return 0.0
	return level_data_field.to_lower().similarity(filter)

func _apply_search_filter():
	if level_rows_filter_similarity.empty():
		
		
		for l in level_rows_array.size():
			var level_row: LevelEditor_LevelRow = level_rows_array[l]
			level_row.visible = true
		return
	
	var similarity_threshold: = 0.2
	for l in level_rows_array.size():
		var level_row: LevelEditor_LevelRow = level_rows_array[l]
		var similarity: float = level_rows_filter_similarity[level_row.level_id]
		level_row.visible = similarity > similarity_threshold

func show_sort_arrow():
	for _sort_id in sort_buttons:
		var sort_button: SortButton = sort_buttons[_sort_id]
		var sorting_this_button: bool = _sort_id == abs(sort_id)
		
		sort_button.sort_arrow.visible = sorting_this_button
		if sort_button.sort_arrow.visible:
			sort_button.sort_arrow.flip_v = sort_id > 0
		sort_button.sort_dash.visible = not sorting_this_button

func on_sort_button_pressed(_sort_id: int):
	if sort_id == _sort_id:
		
		
		_sort_id = - _sort_id
	elif abs(_sort_id) != abs(sort_id):
		
		if _sort_id == SortIds.Rating or _sort_id == SortIds.TimeUpdated:
			
			_sort_id = - _sort_id
	set_sort_id(_sort_id)

func set_sort_id(_sort_id: int):
	sort_id = _sort_id
	if is_inside_tree():
		sort_rows()
		show_sort_arrow()

func sort_rows():
	_compute_filter_similarites()
	_apply_search_filter()
	
	level_rows_array.sort_custom(self, "_sort_compare_level_rows")
	
	var end_index: = levels_rows_parent.get_child_count() - 1
	for _level_row in level_rows_array:
		var level_row: LevelEditor_LevelRow = _level_row
		levels_rows_parent.move_child(level_row, end_index)

func _sort_compare_level_rows(level_row_a: LevelEditor_LevelRow, level_row_b: LevelEditor_LevelRow) -> bool:
	if not all_level_data.has(level_row_a.level_id) or not all_level_data.has(level_row_b.level_id):
		printerr("[LevelEditor_LevelBrowser] _sort_compare_level_rows() cant sort rows because dont have data for level_ids %s, %s" % [level_row_a.level_id, level_row_b.level_id])
		return true
	
	var level_data_a: Dictionary = all_level_data[level_row_a.level_id]
	var level_data_b: Dictionary = all_level_data[level_row_b.level_id]
	
	if filter_row_container.visible and not filter_line_edit.text.empty():
		
		var similarity_a: float = level_rows_filter_similarity[level_row_a.level_id]
		var similarity_b: float = level_rows_filter_similarity[level_row_b.level_id]
		if not is_equal_approx(similarity_a, similarity_b):
			return similarity_a >= similarity_b
	
	var inverse_sort: = sort_id < 0
	if inverse_sort:
		
		var t: = level_data_a
		level_data_a = level_data_b
		level_data_b = t
	
	var abs_sort_id: = abs(sort_id)
	match abs_sort_id:
		SortIds.Name:
			pass
		SortIds.Players:
			var players_a: int = level_data_a["player_count"]
			var players_b: int = level_data_b["player_count"]
			if not players_a == players_b:
				return players_a < players_b
		SortIds.Mode:
			var mode_a: String = level_data_a["game_mode"]
			var mode_b: String = level_data_b["game_mode"]
			if not mode_a == mode_b:
				return mode_a.naturalnocasecmp_to(mode_b) < 0
		SortIds.Rating:
			if level_data_a.has("favorites_count") and level_data_b.has("favorites_count"):
				var favorites_a: float = level_data_a.get("favorites_count", 0.0)
				var favorites_b: float = level_data_b.get("favorites_count", 0.0)
				if not is_equal_approx(favorites_a, favorites_b):
					return favorites_a < favorites_b
			var rating_a: float = level_data_a.get("rating", 0.0)
			var rating_b: float = level_data_b.get("rating", 0.0)
			if not is_equal_approx(rating_a, rating_b):
				return rating_a < rating_b
		SortIds.TimeUpdated:
			var time_a_s: String = level_data_a.get("update_time", "")
			var time_b_s: String = level_data_b.get("update_time", "")
			if time_a_s.empty() != time_b_s.empty():
				return time_a_s.empty()
			var time_a: int = Time.get_unix_time_from_datetime_string(time_a_s)
			var time_b: int = Time.get_unix_time_from_datetime_string(time_b_s)
			if not time_a == time_b:
				return time_a < time_b
		_:
			pass
	
	var name_a: String = level_data_a["name"]
	var name_b: String = level_data_b["name"]
	return name_a.naturalnocasecmp_to(name_b) < 0

func on_create_new_button_pressed():
	emit_signal("new_level")

func give_default_focus_to_tab():
	var b = button_grouper.get_button(button_grouper.selected) as GoodButton
	if b:
		b.focusable.focus_me()

func on_animated_in():
	if not has_queried:
		on_button_grouper_changed()
	give_default_focus_to_tab()

func on_focus_lost(c: Control):
	if dialog.is_visible_in_tree() and dialog.is_showing:
		if is_a_parent_of(c):
			give_default_focus_to_tab()

func on_button_grouper_changed():
	var tab_id: = button_grouper.selected
	create_new_parent.visible = tab_id == TabIds.MyLevels
	var is_query: bool = tab_id in [TabIds.MyLevels, TabIds.Curated, TabIds.PublicNew, TabIds.PublicTop, TabIds.Favorites, TabIds.Search]
	levels_list_page.visible = is_query
	create_new_parent.visible = not disable_level_creation and tab_id == TabIds.MyLevels
	search_row.visible = tab_id == TabIds.Search
	filter_row_container.visible = tab_id == TabIds.MyLevels or tab_id == TabIds.Curated or tab_id == TabIds.Favorites
	time_range_row_container.visible = tab_id == TabIds.PublicTop
	dialog.dialog_title = TabNames.get(tab_id, "LEVELS")
	match tab_id:
		TabIds.PublicTop:
			rating_button.pressed = true
			set_sort_id( - SortIds.Rating)
		TabIds.PublicNew:
			sort_button_time.pressed = true
			set_sort_id( - SortIds.TimeUpdated)
		TabIds.Search:
			search_page_line_edit.text = ""
	
	if is_query:
		filter_line_edit.text = ""
		query_levels()

func on_search_page_line_edit_enter(t: String):
	on_search_page_button_pressed()

func on_search_page_button_pressed():
	query_levels()


















	pass

func query_levels():
	if not Moonlight.auth.is_logged_in():
		return
	var tab_id: = button_grouper.selected
	delete_rows()
	all_level_data.clear()
	spinner_parent.visible = true
	levels_rows_parent.visible = false
	
	query_counter += 1
	var local_query_counter: = query_counter
	var allow_empty_row: = true
	var levels_response: Dictionary = {}
	empty_levels_row_message.text = empty_levels_row_message_default
	match tab_id:
		TabIds.MyLevels:
			levels_response = yield(LevelCloudLoader.async_list_my_levels(), "completed")
			if allow_editor_info_message:
				empty_levels_row_message.text = empty_levels_row_message_editor_info
		TabIds.Favorites:
			
			levels_response = yield(LevelCloudLoader.async_list_favorite_levels(), "completed")
		TabIds.Curated:
			levels_response = yield(LevelCloudLoader.async_list_curated_levels(), "completed")
		TabIds.PublicNew:
			levels_response = yield(LevelCloudLoader.async_list_public_new_levels(), "completed")
		TabIds.PublicTop:
			var time_range: = time_range_options.get_selected_id()
			levels_response = yield(LevelCloudLoader.async_list_public_most_favorited_levels(time_range), "completed")
		TabIds.Search:
			var search_query: = search_page_line_edit.text
			if not search_query.empty():
				levels_response = yield(LevelCloudLoader.async_search_levels(search_query), "completed")
			else:
				levels_response = {"levels": []}
				allow_empty_row = false
	
	if local_query_counter != query_counter:
		
		
		
		
		return
	
	spinner_parent.visible = false
	levels_rows_parent.visible = true
	if levels_response.has("error"):
		printerr("[LevelBrowserDialog] failed to query levels")
	var levels_array: Array = levels_response.get("levels", [])
	for _level_data in levels_array:
		var level_data: Dictionary = _level_data
		var level_id: String = level_data["id"]
		all_level_data[level_id] = level_data
		if not game_mode_filter.empty():
			var game_mode: String = level_data.get("game_mode", "")
			if not game_mode in game_mode_filter:
				continue
		
		var level_row: = levels_row_scene.instance() as LevelEditor_LevelRow
		level_rows[level_id] = level_row
		level_rows_array.append(level_row)
		levels_rows_parent.add_child(level_row)
		level_row.show_level_data(level_id, level_data)
		level_row.connect("button_pressed", self, "on_play_pressed", [level_id, level_data])
	empty_levels_row.visible = levels_array.empty() and allow_empty_row
	sort_rows()

func on_play_pressed(level_id: String, level_data: Dictionary):
	emit_signal("play_level", level_id, level_data)

func delete_rows():
	for level_id in level_rows:
		var level_row: Node = level_rows[level_id]
		levels_rows_parent.remove_child(level_row)
		level_row.queue_free()
	level_rows.clear()
	level_rows_array.clear()
	level_rows_filter_similarity.clear()

func set_disable_level_creation(b: bool):
	disable_level_creation = b
	if create_new_parent:
		create_new_parent.visible = not b

func set_disable_level_search(b: bool):
	disable_level_search = b
	if is_inside_tree():
		search_tab_container.visible = not disable_level_search
		if button_grouper.selected == TabIds.Search:
			button_grouper.set_selected(TabIds.MyLevels)
