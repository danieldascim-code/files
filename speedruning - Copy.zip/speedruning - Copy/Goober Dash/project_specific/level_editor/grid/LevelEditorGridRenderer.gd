extends Control

onready var mesh_instance: = $MeshInstance2D as MeshInstance2D
var last_rect_size: = Vector2.ZERO

func _ready():
	_generate_mesh()

func _process(delta):
	
	_generate_mesh()

func _generate_mesh():
	last_rect_size = rect_size
	var mesh: = ArrayMesh.new()
	
	var vertices: = create_vertices()
	if vertices.size() > 0:
		
		var arrays = []
		arrays.resize(ArrayMesh.ARRAY_MAX)
		
		arrays[ArrayMesh.ARRAY_VERTEX] = vertices
		
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_LINES, arrays)
		
		mesh_instance.mesh = mesh
	
func create_vertices() -> PoolVector3Array:
	var canvas_transform: = get_viewport().canvas_transform
	var cell_size_2d: = LevelGrid.cell_size_2d
	var canvas_scale: = canvas_transform.get_scale()
	var scaled_cell_size_2d: = Vector2(canvas_scale.x * cell_size_2d.x, canvas_scale.y * cell_size_2d.y)
	
	
	var vertices = PoolVector3Array()
	var offset_x: = fmod(canvas_transform.get_origin().x, scaled_cell_size_2d.x)
	var offset_y: = fmod(canvas_transform.get_origin().y, scaled_cell_size_2d.y)
	
	var height: = ceil(rect_size.y / scaled_cell_size_2d.y) * scaled_cell_size_2d.y
	var width: = ceil(rect_size.x / scaled_cell_size_2d.x) * scaled_cell_size_2d.x
	
	var num_horizontal_lines: = floor(height / scaled_cell_size_2d.y)
	var num_vertical_lines: = floor(width / scaled_cell_size_2d.x)
	
	for i in num_horizontal_lines:
		var y: = int(i) * scaled_cell_size_2d.y + offset_y
		vertices.push_back(Vector3(0.0, y, 0.0))
		vertices.push_back(Vector3(width, y, 0.0))
	
	for i in num_vertical_lines:
		var x: = int(i) * scaled_cell_size_2d.x + offset_x
		vertices.push_back(Vector3(x, 0.0, 0.0))
		vertices.push_back(Vector3(x, height, 0.0))
	
	return vertices

func set_generate(b: bool):
	if is_inside_tree():
		if b:
			_generate_mesh()
