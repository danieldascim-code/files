extends Reference
class_name LevelGrid

const cell_size: = 50.0
const cell_size_2d: = Vector2(cell_size, cell_size)
const half_cell: = cell_size * 0.5
const half_cell_2d: = Vector2(half_cell, half_cell)
const grid_cells_per_goober: = Vector2(3, 3)

static func world_to_gridv(v: Vector2) -> Vector2:
	return Vector2(float_to_grid(v.x), float_to_grid(v.y))

static func world_to_grid(v: Vector2) -> Int2:
	return Int2.new().assign2(float_to_grid(v.x), float_to_grid(v.y))

static func world_rounded_to_grid(v: Vector2) -> Int2:
	return Int2.new().assign2(float_rounded_to_grid(v.x), float_rounded_to_grid(v.y))
	
static func grid_to_world(i: Int2) -> Vector2:
	return Vector2(grid_to_float(i.x), grid_to_float(i.y))

static func grid_to_world_xy(x: int, y: int) -> Vector2:
	return Vector2(grid_to_float(x), grid_to_float(y))

static func gridf_to_world_xy(x: float, y: float) -> Vector2:
	return Vector2(gridf_to_float(x), gridf_to_float(y))
	
static func float_to_grid(f: float) -> int:
	return int(floor(f / cell_size))

static func float_rounded_to_grid(f: float) -> int:
	return int(round(f / cell_size))

static func grid_to_float(i: int) -> float:
	return i * cell_size

static func gridf_to_float(f: float) -> float:
	return f * cell_size

static func grid_to_rect(min_grid: Int2, max_grid: Int2) -> Rect2:
	var world_min: = grid_to_world(min_grid)
	var world_max: = grid_to_world(max_grid)
	return Rect2(world_min, world_max - world_min)

static func center_of_grid_cell(i: Int2) -> Vector2:
	return grid_to_world(i) + (0.5 * cell_size_2d)

static func center_of_bounding_box(start: Int2, end: Int2) -> Vector2:
	return 0.5 * (grid_to_world(start) + grid_to_world(end))

static func distance_to_edge_of_grid_cell(i: Int2, face: int, point: Vector2) -> float:
	
	var edge: = extract_component_from_vector(grid_to_world(i), face)
	var vector_component: = extract_component_from_vector(point, face)
	return abs(edge - vector_component)

static func distance_to_edge_of_bounding_box(start: Int2, end: Int2, point: Vector2, face: int) -> float:
	if face == Int2.Face.Up or face == Int2.Face.Left:
		return distance_to_edge_of_grid_cell(start, face, point)
	return distance_to_edge_of_grid_cell(end, face, point)

static func first_point_of_edge_of_bounding_box(rect: Rect2, face: int) -> Vector2:
	if face == Int2.Face.Up or face == Int2.Face.Left:
		return rect.position
	return rect.end

static func second_point_of_edge_of_bounding_box(rect: Rect2, face: int) -> Vector2:
	if face == Int2.Face.Up or face == Int2.Face.Right:
		return Vector2(rect.end.x, rect.position.y)
	return Vector2(rect.position.x, rect.end.y)
	
static func edge_of_grid_cell(i: Int2, face: int) -> float:
	var cell_top_left: = grid_to_world(i)
	match face:
		Int2.Face.Down:
			return cell_top_left.y + cell_size
		Int2.Face.Right:
			return cell_top_left.x + cell_size
		Int2.Face.Up:
			return cell_top_left.y
		Int2.Face.Left:
			return cell_top_left.x
	
	printerr("[LevelGrid] grid_edge() invalid face: %d", face)
	assert (false)
	return 0.0

static func extract_component_from_vector(point: Vector2, face: int) -> float:
	match face:
		Int2.Face.Down, Int2.Face.Up:
			return point.y
		Int2.Face.Right, Int2.Face.Left:
			return point.x
	printerr("[LevelGrid] extract_component_from_vector()")
	return 0.0

static func players_per_starting_block(starting_block_size: Vector2) -> Vector2:
	var block_grid_size: = world_to_gridv(starting_block_size)
	return (block_grid_size / grid_cells_per_goober).floor()
