extends Object
class_name LevelCloudLoader

static func async_download_level_data(level_id: String) -> Dictionary:
	var payload: = {
		"id": level_id
	}
	var response_data: Dictionary = yield(Moonlight.call_rpc("levels_editor_get", payload, false, true, true), "completed")
	return _parse_level_data_response(level_id, response_data)

static func async_download_level_data_server_key(level_id: String) -> Dictionary:
	var payload: = {
		"id": level_id
	}
	var response_data: Dictionary = yield(Moonlight.call_rpc_with_server_key("levels_editor_get", payload), "completed")
	return _parse_level_data_response(level_id, response_data)

static func _parse_level_data_response(level_id: String, response_data: Dictionary) -> Dictionary:
	
	
	if response_data.has("error"):
		printerr("[LevelCloudLoader] levels_editor_get(%s) failed with error. %s" % [level_id, response_data["error"]])
		return response_data
	
	
	
	var data: String = response_data.get("data", "")
	if data.empty():
		data = response_data.get("level_data", "")
	if data.empty():
		printerr("[LevelCloudLoader] levels_editor_get(%s) invalid level data. %s" % [level_id, response_data])
		return {
			"error": "Invalid level data."
		}
	
	
	
	var pub_state: String = response_data.get("published", "")
	if pub_state.empty():
		pub_state = response_data.get("pub_state", "")
	if pub_state.empty():
		printerr("[LevelCloudLoader] levels_editor_get(%s) invalid pub_state. %s" % [level_id, response_data])
		return {
			"error": "Invalid level data."
		}
		
	var parsed_data = parse_json(data)
	if not parsed_data is Dictionary:
		return {
			"error": "Failed to parse level"
		}
	
	
	
	
	parsed_data["metadata"]["id"] = response_data.get("id", level_id)
	parsed_data["metadata"]["author_id"] = response_data["author_id"]
	parsed_data["metadata"]["author_name"] = response_data["author_name"]
	parsed_data["metadata"]["published"] = pub_state
	parsed_data["metadata"]["rating"] = response_data.get("rating", 0.0)
	parsed_data["metadata"]["rating_count"] = int(response_data.get("rating_count", 0))
	
	return parsed_data

static func async_save_level_data(level_data: Dictionary) -> Dictionary:
	var rpc_id: = "levels_editor_update"
	var level_metadata: Dictionary = level_data.get("metadata", {})
	var level_id: String = level_metadata.get("id", "")
	var is_create: = level_id.empty()
	if is_create:
		rpc_id = "levels_editor_create"
	
	var level_data_string: = to_json(level_data)
	var payload: = {
		"level_name": level_metadata["name"], 
		"level_theme": level_metadata["theme"], 
		"world_idx": 0, 
		"pub_state": level_metadata["published"], 
		"player_count": level_metadata["player_count"], 
		"game_mode": level_metadata["game_mode"], 
		"level_data": level_data_string, 
		"engine_version": 2
	}
	
	if not is_create:
		if not level_metadata["author_id"].empty():
			payload["author_id"] = level_metadata["author_id"]
		payload["id"] = level_id
	
	var response_data: Dictionary = yield(Moonlight.call_rpc(rpc_id, payload, false, true, true), "completed")
	if response_data.has("error"):
		var error_message: String = response_data["error"]
		if error_message.find("levels_player_count_check") != - 1:
			error_message = "Player count is invalid, make sure to have starting spots for players"
		elif error_message.find("levels_level_name_key") != - 1:
			error_message = "Level with that name already exists"
		printerr("[LevelCloudLoader] async_save_level_data() failed to save level to cloud. %s" % [error_message])
		return {
			"error": error_message
		}
	
	if not response_data.has("uuid"):
		printerr("[LevelCloudLoader] async_save_level_data unknown response: %s" % [response_data])
		return {
			"error": "Unknown error"
		}
	
	var response_level_id: String = response_data["uuid"]
	var response_author_id: String = response_data["author_id"]
	if is_create:
		print("[LevelCloudLoader] async_save_level_data() success. created new level with id: %s" % [response_level_id])
	else:
		print("[LevelCloudLoader] async_save_level_data() success. updated level with id: %s" % [response_level_id])
	return {
		"level_id": response_level_id, 
		"author_id": response_author_id, 
	}

static func async_delete_level(level_id: String) -> Dictionary:
	var response_data: Dictionary = yield(Moonlight.call_rpc("levels_editor_delete", {"id": level_id}, false, true), "completed")
	return response_data
	
static func async_list_my_levels() -> Dictionary:
	var response_data: Dictionary = yield(Moonlight.call_rpc("levels_query_my_levels", {}, false, true), "completed")
	return response_data

static func async_list_curated_levels() -> Dictionary:
	var response_data: Dictionary = yield(Moonlight.call_rpc("levels_query_curated", {}, false, true), "completed")
	return response_data

static func async_list_favorite_levels() -> Dictionary:
	var response_data: Dictionary = yield(Moonlight.call_rpc("levels_query_favorite", {}, false, true), "completed")
	return response_data

static func async_favorite_level(level_id: String) -> Dictionary:
	var response_data: Dictionary = yield(Moonlight.call_rpc("levels_favorite", {"level_id": level_id}, false, true), "completed")
	return response_data

static func async_unfavorite_level(level_id) -> Dictionary:
	var response_data: Dictionary = yield(Moonlight.call_rpc("levels_unfavorite", {"level_id": level_id}, false, true), "completed")
	return response_data

enum TopRatedTimeRange{
	AllTime, 
	Month, 
	Week, 
	Day
}
static func async_list_public_top_rated_levels(time_range: int) -> Dictionary:
	var time_range_param: = ""
	match time_range:
		TopRatedTimeRange.Day:
			time_range_param = "day"
		TopRatedTimeRange.Week:
			time_range_param = "week"
		TopRatedTimeRange.Month:
			time_range_param = "month"
		TopRatedTimeRange.AllTime, _:
			time_range_param = "all"
	var response_data: Dictionary = yield(Moonlight.call_rpc("levels_query_top_rated", {"time_range": time_range_param}, false, true), "completed")
	return response_data

static func async_list_public_most_favorited_levels(time_range: int) -> Dictionary:
	var time_range_param: = ""
	match time_range:
		TopRatedTimeRange.Day:
			time_range_param = "day"
		TopRatedTimeRange.Week:
			time_range_param = "week"
		TopRatedTimeRange.Month:
			time_range_param = "month"
		TopRatedTimeRange.AllTime, _:
			time_range_param = "all"
	var response_data: Dictionary = yield(Moonlight.call_rpc("levels_query_most_favorited", {"time_range": time_range_param}, false, true), "completed")
	return response_data

static func async_list_public_new_levels() -> Dictionary:
	var response_data: Dictionary = yield(Moonlight.call_rpc("levels_query_new", {}, false, true), "completed")
	return response_data

static func async_server_list_match_levels() -> Dictionary:
	var response_data: Dictionary = yield(Moonlight.call_rpc_with_server_key("levels_server_list_match_levels", {}), "completed")
	if response_data.has("error"):
		return response_data
	var parsed_response: Dictionary = {}
	for k in response_data:
		var level_data: Dictionary = response_data[k]
		parsed_response[k] = to_json(_parse_level_data_response("", level_data))
	return parsed_response

static func async_search_levels(query: String) -> Dictionary:
	var response_data: Dictionary = yield(Moonlight.call_rpc("levels_search", {"query": query}, false, true), "completed")
	return response_data
