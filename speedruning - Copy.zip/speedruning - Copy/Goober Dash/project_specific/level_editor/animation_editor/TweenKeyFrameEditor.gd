extends Control
class_name TweenKeyFrameEditor

signal delete_pressed()
signal up_pressed()
signal down_pressed()
signal duration_changed(duration)
signal value_changed(value)
signal transition_changed(transition)
signal easing_changed(easing)

export  var _property_option_button: NodePath
export  var _property_vector2_input: NodePath
export  var _property_vector2_input_x: NodePath
export  var _property_vector2_input_y: NodePath
export  var _property_single_input: NodePath
export  var _duration_input: NodePath
export  var _easing_input: NodePath
export  var _easing_parent: NodePath
export  var _transition_input: NodePath
export  var _expanded_row: NodePath
export  var _small_row: NodePath
export  var _small_row_button: NodePath
export  var _small_row_delete_button: NodePath
export  var _small_row_label_duration: NodePath
export  var _small_row_label_value: NodePath
export  var _small_row_label_value_container: NodePath
export  var _small_row_texture_rect: NodePath
export  var _up_button: NodePath
export  var _down_button: NodePath

onready var property_vector2_input: = get_node(_property_vector2_input) as Control
onready var property_vector2_input_x: = get_node(_property_vector2_input_x) as LineEdit
onready var property_vector2_input_y: = get_node(_property_vector2_input_y) as LineEdit
onready var property_single_input: = get_node(_property_single_input) as LineEdit
onready var duration_input: = get_node(_duration_input) as LineEdit
onready var easing_input: = get_node(_easing_input) as OptionButton
onready var easing_parent: = get_node(_easing_parent) as Control
onready var transition_input: = get_node(_transition_input) as OptionButton
onready var expanded_row: = get_node(_expanded_row) as Control
onready var small_row: = get_node(_small_row) as Control
onready var small_row_button: = get_node(_small_row_button) as BaseButton
onready var small_row_delete_button: = get_node(_small_row_delete_button) as BaseButton
onready var small_row_label_duration: = get_node(_small_row_label_duration) as Label
onready var small_row_label_value: = get_node(_small_row_label_value) as Label
onready var small_row_label_value_container: = get_node(_small_row_label_value_container) as Control
onready var small_row_texture_rect: = get_node(_small_row_texture_rect) as TextureRect
onready var up_button: = get_node(_up_button) as BaseButton
onready var down_button: = get_node(_down_button) as BaseButton

export  var vector2_icon: Texture
export  var float_icon: Texture
export  var delay_icon: Texture

onready var vector2_inputs: = [property_vector2_input_x, property_vector2_input_y]

var _expanded: = false setget set_expanded
var _disable_edit_button_on_frame: = 0

func _ready():
	up_button.connect("pressed", self, "on_up_button_pressed")
	down_button.connect("pressed", self, "on_down_button_pressed")
	
	for i in vector2_inputs.size():
		var line_edit: = vector2_inputs[i] as LineEdit
		line_edit.connect("text_changed", self, "on_vector2_input_changed", [i])
	
	
	property_single_input.connect("text_changed", self, "on_single_input_changed")
	
	
	duration_input.connect("text_changed", self, "on_duration_input_changed")
	
	
	for easing_name in TweenData.ET:
		easing_input.add_item(easing_name)
	easing_input.connect("item_selected", self, "on_easing_selected")
	
	
	for transition_name in TweenData.TT:
		transition_input.add_item(transition_name)
	transition_input.connect("item_selected", self, "on_transition_selected")
	
	
	small_row_delete_button.connect("pressed", self, "on_delete_button_pressed")
	small_row_button.connect("pressed", self, "on_edit_button_pressed")
	
	set_expanded(false)

func render_tween_data(tween_data: TweenKeyFrame):
	if not tween_data.is_connected("changed", self, "on_tween_data_changed"):
		tween_data.connect("changed", self, "on_tween_data_changed", [tween_data])
	
	
	_set_text_if_new(duration_input, str(tween_data.duration), true)
	
	
	if easing_input.selected != tween_data.ease_type:
		easing_input.select(tween_data.ease_type)
	if transition_input.selected != tween_data.transition:
		transition_input.select(tween_data.transition)
	
	update_line_edits(tween_data.value)
	update_small_row_duration(tween_data.duration)
	update_small_row_value(tween_data.value)

func on_tween_data_changed(tween_data: TweenKeyFrame):
	render_tween_data(tween_data)

func update_small_row_duration(duration: float):
	small_row_label_duration.text = "%ss" % [duration]

func update_small_row_value(value):
	if value == null:
		small_row_label_value_container.visible = false
	else:
		small_row_label_value_container.visible = true
		small_row_label_value.text = "%s" % [value]

func update_line_edits(final_value):
	var final_value_type = typeof(final_value)
	var is_supported_type: bool = final_value_type == TYPE_VECTOR2 or final_value_type == TYPE_INT or final_value_type == TYPE_REAL
	easing_parent.visible = is_supported_type
	
	property_vector2_input.visible = final_value_type == TYPE_VECTOR2
	property_single_input.visible = final_value_type == TYPE_INT or final_value_type == TYPE_REAL
	
	match final_value_type:
		TYPE_VECTOR2:
			small_row_texture_rect.texture = vector2_icon
			property_vector2_input.visible = true
			var v2: Vector2 = final_value
			_set_text_if_new(property_vector2_input_x, str(v2.x), true)
			_set_text_if_new(property_vector2_input_y, str(v2.y), true)
		TYPE_INT, TYPE_REAL:
			small_row_texture_rect.texture = float_icon
			property_single_input.visible = true
			_set_text_if_new(property_single_input, str(final_value), true)
		TYPE_NIL:
			small_row_texture_rect.texture = delay_icon

static func _set_text_if_new(line_edit: LineEdit, s: String, float_compare: bool):
	
	if line_edit.text != s:
		if not float_compare:
			line_edit.text = s
		elif not line_edit.text.is_valid_float():
			line_edit.text = s
		elif not is_equal_approx(float(line_edit.text), float(s)):
			line_edit.text = s

func on_vector2_input_changed(text: String, index: int):
	if not text.is_valid_float():
		return
	
	var value_x: = float(property_vector2_input_x.text)
	var value_y: = float(property_vector2_input_y.text)
	var value: = Vector2(value_x, value_y)
	print("[LevelEditorAnimationPanel] on_vector2_input_changed(%s, %s)" % [value, index])
	emit_signal("value_changed", value)
	update_small_row_value(value)

func on_single_input_changed(text: String):
	if not text.is_valid_float():
		return
	var value: = float(text)
	print("[LevelEditorAnimationPanel] on_single_input_changed(%s)" % [value])
	emit_signal("value_changed", value)
	update_small_row_value(value)

func on_duration_input_changed(text: String):
	if not text.is_valid_float():
		return
	var value: = float(text)
	print("[LevelEditorAnimationPanel] on_duration_input_changed(%s)" % [value])
	emit_signal("duration_changed", value)
	update_small_row_duration(value)

func on_easing_selected(easing: int):
	print("[LevelEditorAnimationPanel] on_easing_selected(%s)" % [easing])
	emit_signal("easing_changed", easing)

func on_transition_selected(transition: int):
	print("[LevelEditorAnimationPanel] on_transition_selected(%s)" % [transition])
	emit_signal("transition_changed", transition)

func set_expanded(e: bool):
	_expanded = e
	
	small_row.visible = true
	expanded_row.visible = _expanded

func _toggle_expand():
	set_expanded( not _expanded)

func on_delete_button_pressed():
	_disable_edit_button_on_frame = Engine.get_frames_drawn()
	emit_signal("delete_pressed")

func on_edit_button_pressed():
	if _disable_edit_button_on_frame == Engine.get_frames_drawn():
		return
	_toggle_expand()

func on_up_button_pressed():
	_disable_edit_button_on_frame = Engine.get_frames_drawn()
	emit_signal("up_pressed")

func on_down_button_pressed():
	_disable_edit_button_on_frame = Engine.get_frames_drawn()
	emit_signal("down_pressed")
