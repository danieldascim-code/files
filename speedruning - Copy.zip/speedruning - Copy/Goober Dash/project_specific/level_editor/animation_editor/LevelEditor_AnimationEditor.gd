extends LevelEditor_InspectorPanel
class_name LevelEditor_AnimationEditor

export  var _animation_sequence_editor: NodePath
export  var _play_button: NodePath
export  var _play_button_icon: NodePath
export  var _stop_button: NodePath
export  var _plus_button: NodePath
export  var _plus_delay_button: NodePath
export  var _position_button: NodePath
export  var _rotation_button: NodePath
export  var _repeat_button: NodePath
export  var _offset_input: NodePath
export  var _offset_parent: NodePath
export  var _plus_rotation_icon: NodePath
export  var _plus_position_icon: NodePath

export  var play_texture: Texture
export  var pause_texture: Texture
onready var sequence_editor: = get_node(_animation_sequence_editor) as TweenSequenceEditor
onready var play_button: = get_node(_play_button) as BaseButton
onready var play_button_icon: = get_node(_play_button_icon) as TextureRect
onready var stop_button: = get_node(_stop_button) as BaseButton
onready var position_button: = get_node(_position_button) as BaseButton
onready var rotation_button: = get_node(_rotation_button) as BaseButton
onready var plus_button: = get_node(_plus_button) as BaseButton
onready var plus_delay_button: = get_node(_plus_delay_button) as BaseButton
onready var repeat_button: = get_node(_repeat_button) as CheckButton
onready var offset_input: = get_node(_offset_input) as LineEdit
onready var offset_parent: = get_node(_offset_parent) as Control
onready var plus_rotation_icon: = get_node(_plus_rotation_icon) as TextureRect
onready var plus_position_icon: = get_node(_plus_position_icon) as TextureRect

var animation_rows: = []
var _selected_node_ids: = []
var selected_key: = "position"

func _ready():
	repeat_button.connect("pressed", self, "on_repeat_button_pressed")
	offset_input.connect("text_changed", self, "on_offset_input")
	play_button.connect("pressed", self, "on_play_button_pressed")
	stop_button.connect("pressed", self, "on_stop_button_pressed")
	position_button.connect("pressed", self, "on_position_button_pressed")
	rotation_button.connect("pressed", self, "on_rotation_button_pressed")
	plus_button.connect("pressed", self, "on_plus_button_pressed")
	plus_delay_button.connect("pressed", self, "on_plus_delay_button_pressed")
	sequence_editor.connect("delete_button_pressed", self, "on_delete_button_pressed")
	sequence_editor.connect("duration_changed", self, "on_duration_changed")
	sequence_editor.connect("value_changed", self, "on_value_changed")
	sequence_editor.connect("transition_changed", self, "on_transition_changed")
	sequence_editor.connect("easing_changed", self, "on_easing_changed")
	_update_plus_button()

func _process(delta: float):
	
	pass






func on_plus_delay_button_pressed():
	if _selected_node_ids.empty():
		return
	level_editor.undo.create_action("Create Animation Key")
	level_editor.undo.add_do_method(self, "create_key_frame", true, {}, _selected_node_ids.duplicate(), selected_key, - 1)
	level_editor.undo.add_undo_method(self, "delete_key_frame", _selected_node_ids.duplicate(), selected_key, - 1)
	level_editor.undo.commit_action()
	

func on_plus_button_pressed():
	if _selected_node_ids.empty():
		return
	level_editor.undo.create_action("Create Animation Key")
	level_editor.undo.add_do_method(self, "create_key_frame", false, {}, _selected_node_ids.duplicate(), selected_key, - 1)
	level_editor.undo.add_undo_method(self, "delete_key_frame", _selected_node_ids.duplicate(), selected_key, - 1)
	level_editor.undo.commit_action()
	

func on_delete_button_pressed(key_frame_index: int):
	if _selected_node_ids.empty():
		return
	
	
	var first_level_node_index: int = _selected_node_ids[0]
	var key_frame: TweenKeyFrame = get_key_frame(first_level_node_index, selected_key, key_frame_index)
	if not key_frame:
		printerr("[LevelEditor_AnimationEditor] on_delete_button_pressed() couldnt find key_frame for index %s" % [key_frame_index])
		return
	var serialized_key_frame: = key_frame.serialize_tween_key_frame()
	level_editor.undo.create_action("Delete Animation Key")
	level_editor.undo.add_do_method(self, "delete_key_frame", _selected_node_ids.duplicate(), selected_key, key_frame_index)
	level_editor.undo.add_undo_method(self, "create_key_frame", false, serialized_key_frame, _selected_node_ids.duplicate(), selected_key, key_frame_index)
	level_editor.undo.commit_action()
	

func on_repeat_button_pressed():
	level_editor.undo.create_action("Set Repeat")
	level_editor.undo.add_do_method(self, "set_repeat", _selected_node_ids.duplicate(), repeat_button.pressed)
	level_editor.undo.add_undo_method(self, "set_repeat", _selected_node_ids.duplicate(), get_repeat())
	level_editor.undo.commit_action()

func on_position_button_pressed():
	selected_key = "position"
	_update_plus_button()
	render_node_ids(_selected_node_ids)

func on_rotation_button_pressed():
	selected_key = "rotation_degrees"
	_update_plus_button()
	render_node_ids(_selected_node_ids)

func on_duration_changed(key_frame_index: int, duration: float):
	print("[LevelEditor_AnimationEditor] on_duration_changed() key_frame_index: %s duration: %s" % [key_frame_index, duration])
	assert ( not _selected_node_ids.empty())
	set_key_frame_value_with_undo("Set Duration", _selected_node_ids, key_frame_index, selected_key, "duration", duration)

func on_value_changed(key_frame_index: int, value):
	print("[LevelEditor_AnimationEditor] on_value_changed() key_frame_index: %s value: %s" % [key_frame_index, value])
	assert ( not _selected_node_ids.empty())
	set_key_frame_value_with_undo("Set Value", _selected_node_ids, key_frame_index, selected_key, "value", value)

func on_transition_changed(key_frame_index: int, transition: int):
	print("[LevelEditor_AnimationEditor] on_transition_changed() key_frame_index: %s transition: %s" % [key_frame_index, transition])
	assert ( not _selected_node_ids.empty())
	set_key_frame_value_with_undo("Set Transition", _selected_node_ids, key_frame_index, selected_key, "transition", transition)

func on_easing_changed(key_frame_index: int, easing: int):
	print("[LevelEditor_AnimationEditor] on_easing_changed() key_frame_index: %s easing: %s" % [key_frame_index, easing])
	assert ( not _selected_node_ids.empty())
	set_key_frame_value_with_undo("Set Easing", _selected_node_ids, key_frame_index, selected_key, "ease_type", easing)

func render_nodes(nodes: Array):
	_selected_node_ids.clear()
	for l in nodes:
		var level_node: LevelNode = l
		_selected_node_ids.push_back(level_node.level_node_index)
	render_node_ids(_selected_node_ids)

func render_node_ids(node_ids: Array):
	repeat_button.pressed = get_repeat()
	offset_parent.visible = repeat_button.pressed
	offset_input.text = str(get_offset())
	
	var all_match: = all_animations_match(node_ids)
	
	if not all_match:
		sequence_editor.render_tween_sequence(null)
		plus_button.disabled = true
		plus_delay_button.disabled = true
		return
	plus_button.disabled = false
	plus_delay_button.disabled = false
	var sequence: TweenSequence
	if _selected_node_ids.size() > 0:
		var first_node_id: int = _selected_node_ids[0]
		var first_node: LevelNode = level_editor.level.get_level_node(first_node_id)
		if first_node and first_node.animation:
			sequence = first_node.animation.animation_data.tween_sequences.get(selected_key)
	sequence_editor.render_tween_sequence(sequence)

func create_key_frame(is_delay: bool, serialized_data: Dictionary, level_node_indicies: Array, animation_key: String, key_frame_index: int):
	for level_node_index in level_node_indicies:
		var node: = level_editor.level.get_level_node(level_node_index)
		if not node:
			printerr("[LevelEditor_AnimationEditor] create_key_frame() couldnt find node for index %s" % [level_node_index])
			return
		var tween_sequence: TweenSequence
		
		if node.animation == null:
			node.create_animation_node()
		
		var initial_value = {"position": Vector2.ZERO, "rotation_degrees": 0.0}[animation_key]
		if not node.animation.animation_data.has_sequence(animation_key):
			tween_sequence = node.animation.animation_data.create_sequence(animation_key, initial_value)
		else:
			tween_sequence = node.animation.animation_data.get_sequence(animation_key)
		
		
		var key_frame_value = initial_value
		if is_delay:
			key_frame_value = null
		var tween_data: TweenKeyFrame = tween_sequence.insert_tween(key_frame_index, key_frame_value)
		if serialized_data and not serialized_data.empty():
			tween_data.deserialize_tween_key_frame(serialized_data)
		
	
	if _any_selected(level_node_indicies):
		render_node_ids(_selected_node_ids)

func delete_key_frame(level_node_indicies: Array, animation_key: String, key_frame_index: int):
	for level_node_index in level_node_indicies:
		var node: = level_editor.level.get_level_node(level_node_index)
		if not node:
			return
		if node.animation == null:
			printerr("[LevelEditor_AnimationEditor] cant delete index %d of nothing" % [key_frame_index])
			return
		if not node.animation.animation_data.has_sequence(animation_key):
			printerr("[LevelEditor_AnimationEditor] tween sequence with key %s doesnt exist" % [animation_key])
			return
		
		var tween_sequence: TweenSequence = node.animation.animation_data.get_sequence(animation_key)
		if key_frame_index < 0:
			key_frame_index = tween_sequence.number_of_tweens() - 1
		
		if key_frame_index < 0 or key_frame_index >= tween_sequence.number_of_tweens():
			printerr("[LevelEditor_AnimationEditor] invalid tween index %d on sequence with key %s" % [key_frame_index, animation_key])
			print_stack()
			return
		
		
		tween_sequence.remove_tween(key_frame_index)
		if tween_sequence.tweens.size() == 0:
			node.animation.animation_data.remove_sequence(tween_sequence.property)
		
		if node.animation.animation_data.tween_sequences.size() == 0:
			node.remove_animation()
	
	
	if _any_selected(level_node_indicies):
		render_node_ids(_selected_node_ids)

func set_key_frame_value_with_undo(action_name: String, level_node_indicies: Array, key_frame_index: int, sequence_key: String, property_name: String, value):
	if level_node_indicies.empty():
		return
	var new_values: = [value]
	var current_values: = []
	for level_node_index in level_node_indicies:
		var current_value = get_key_frame_value(level_node_index, key_frame_index, sequence_key, property_name)
		current_values.append(current_value)
	level_editor.undo.create_action(action_name, UndoRedo.MERGE_ENDS)
	level_editor.undo.add_do_method(self, "set_key_frame_values", level_node_indicies.duplicate(), key_frame_index, sequence_key, property_name, new_values)
	level_editor.undo.add_undo_method(self, "set_key_frame_values", level_node_indicies.duplicate(), key_frame_index, sequence_key, property_name, current_values)
	level_editor.undo.commit_action()

func set_key_frame_values(level_node_indicies: Array, key_frame_index: int, sequence_key: String, property_name: String, key_frame_values: Array):
	assert ( not key_frame_values.empty())
	for i in level_node_indicies.size():
		var level_node_index: int = level_node_indicies[i]
		var value = key_frame_values[min(i, key_frame_values.size() - 1)]
		var key_frame: = get_key_frame(level_node_index, sequence_key, key_frame_index)
		assert (property_name in key_frame)
		key_frame.set(property_name, value)
	
	if not level_editor.undo.is_commiting_action():
		if _any_selected(level_node_indicies):
			render_node_ids(_selected_node_ids)

func get_key_frame_value(level_node_index: int, key_frame_index: int, sequence_key: String, property_name: String):
	var key_frame: = get_key_frame(level_node_index, sequence_key, key_frame_index)
	assert (property_name in key_frame)
	return key_frame.get(property_name)

func get_key_frame(level_node_index: int, sequence_key: String, key_frame_index: int) -> TweenKeyFrame:
	var level_node: LevelNode = level_editor.level.get_level_node(level_node_index)
	if not level_node:
		return null
	if not level_node.animation:
		return null
	var sequence: = level_node.animation.animation_data.get_sequence(sequence_key)
	if not sequence:
		return null
	if key_frame_index < 0:
		return null
	if key_frame_index >= sequence.number_of_tweens():
		return null
	return sequence.get_tween(key_frame_index)

func _update_plus_button():
	plus_position_icon.visible = selected_key == "position"
	plus_rotation_icon.visible = selected_key == "rotation_degrees"

func on_play_button_pressed():
	pass
	






func on_stop_button_pressed():
	
	pass



func on_offset_input(t: String):
	if t.is_valid_float():
		level_editor.undo.create_action("Set Offset", UndoRedo.MERGE_ENDS)
		level_editor.undo.add_do_method(self, "set_offset", _selected_node_ids.duplicate(), float(t))
		level_editor.undo.add_undo_method(self, "set_offset", _selected_node_ids.duplicate(), get_offset())
		level_editor.undo.commit_action()

func get_repeat() -> bool:
	if _selected_node_ids.empty():
		return false
	var first_node_id: int = _selected_node_ids[0]
	var selected_node: LevelNode = level_editor.level.get_level_node(first_node_id)
	if selected_node and selected_node.animation:
		return selected_node.animation.animation_data.repeat
	return true

func set_repeat(level_node_indicies: Array, b: bool):
	for level_node_index in level_node_indicies:
		var node: LevelNode = level_editor.level.get_level_node(level_node_index)
		if not node:
			return
		if not node.animation:
			printerr("[LevelEditor_AniationEditor] cant set repeat without an animation")
			return
		node.animation.animation_data.repeat = b
	
	
	if _any_selected(level_node_indicies):
		render_node_ids(_selected_node_ids)

func get_offset() -> float:
	if _selected_node_ids.empty():
		return 0.0
	var first_node_id: int = _selected_node_ids[0]
	var selected_node: LevelNode = level_editor.level.get_level_node(first_node_id)
	if selected_node and selected_node.animation:
		return selected_node.animation.animation_data.offset
	return 0.0

func set_offset(level_node_indicies: Array, f: float):
	for level_node_index in level_node_indicies:
		var node: LevelNode = level_editor.level.get_level_node(level_node_index)
		if not node:
			return
		if not node.animation:
			printerr("[LevelEditor_AniationEditor] cant set repeat without an animation")
			return
		node.animation.animation_data.offset = f
	
	
	if _any_selected(level_node_indicies):
		render_node_ids(_selected_node_ids)

func all_animations_match(node_ids: Array) -> bool:
	if node_ids.empty():
		return true
	var first_node_index: int = node_ids[0]
	var first_node: LevelNode = level_editor.level.get_level_node(first_node_index)
	var has_animation: = first_node.animation != null
	var running_hash: = 0
	if has_animation:
		running_hash = first_node.animation.serialize_animation().hash()
	for level_node_index in node_ids:
		var level_node: LevelNode = level_editor.level.get_level_node(level_node_index)
		if level_node == null:
			printerr("[LevelEditor_AnimationEditor] all_animations_match() couldnt find level_node for index %s" % [level_node_index])
			return false
		if level_node == first_node:
			continue
		var i_has_animation: = level_node.animation != null
		var i_hash: = 0
		if level_node.animation != null:
			i_hash = level_node.animation.serialize_animation().hash()
		if i_has_animation != has_animation:
			return false
		if i_hash != running_hash:
			return false
	return true

func _any_selected(node_ids: Array) -> bool:
	for i in node_ids:
		if _selected_node_ids.has(i):
			return true
	return false
