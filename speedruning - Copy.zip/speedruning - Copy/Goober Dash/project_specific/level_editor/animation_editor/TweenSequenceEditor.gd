extends Control
class_name TweenSequenceEditor

signal delete_button_pressed(index)
signal duration_changed(index, duration)
signal value_changed(index, value)
signal transition_changed(index, transition)
signal easing_changed(index, easing)

export  var animation_row_scene: PackedScene
export  var _animation_row_parent: NodePath

onready var animation_row_parent: = get_node(_animation_row_parent) as Control

var animation_rows: = []
var tween_sequence: TweenSequence
var dragging_animation_row: TweenKeyFrameEditor

func on_delete_row_pressed(row: TweenKeyFrameEditor):
	var row_index: = animation_rows.find(row)
	assert (row_index >= 0 and row_index < animation_rows.size())
	emit_signal("delete_button_pressed", row_index)

func render_tween_sequence(_tween_sequence: TweenSequence):
	delete_rows()
	tween_sequence = _tween_sequence
	if tween_sequence != null:
		for i in tween_sequence.tweens.size():
			var row: = create_row()
			row.render_tween_data(tween_sequence.tweens[i])

func create_row() -> TweenKeyFrameEditor:
	return insert_row( - 1)

func insert_row(row_index: int) -> TweenKeyFrameEditor:
	assert (row_index <= animation_rows.size())
	var animation_row: = animation_row_scene.instance() as TweenKeyFrameEditor
	if row_index < 0 or row_index == animation_rows.size():
		row_index = animation_rows.size()
		animation_rows.append(animation_row)
		animation_row_parent.add_child(animation_row)
	else:
		var row_before: TweenKeyFrameEditor = animation_rows[row_index]
		animation_row_parent.add_child_below_node(row_before, animation_row)
	
	animation_row.connect("delete_pressed", self, "on_delete_row_pressed", [animation_row])
	animation_row.connect("up_pressed", self, "on_animation_row_up_pressed", [animation_row])
	animation_row.connect("down_pressed", self, "on_animation_row_down_pressed", [animation_row])
	animation_row.connect("value_changed", self, "emit_row_signal", ["value_changed", animation_row])
	animation_row.connect("duration_changed", self, "emit_row_signal", ["duration_changed", animation_row])
	animation_row.connect("transition_changed", self, "emit_row_signal", ["transition_changed", animation_row])
	animation_row.connect("easing_changed", self, "emit_row_signal", ["easing_changed", animation_row])
	animation_row.small_row_button.connect("button_down", self, "on_animation_row_button_down", [animation_row])
	animation_row.small_row_button.connect("button_up", self, "on_animation_row_button_up", [animation_row])
	return animation_row

func emit_row_signal(value, signal_name: String, row: TweenKeyFrameEditor):
	var row_index: = animation_rows.find(row)
	if row_index < 0:
		printerr("[TweenSequenceEditor] emit_row_signal(%s, %s, %s) couldnt find row" % [value, signal_name, row])
		
		return
	print("[TweenSequenceEditor] emit_row_signal(%s, %s, %s) did find row" % [value, signal_name, row])
	emit_signal(signal_name, row_index, value)

func delete_row(row_index: int):
	assert (row_index >= 0 and row_index < animation_rows.size())
	var row: TweenKeyFrameEditor = animation_rows[row_index]
	animation_rows.remove(row_index)
	row.queue_free()

func on_animation_row_up_pressed(animation_row: TweenKeyFrameEditor):
	var index: = animation_rows.find(animation_row)
	_move_tween(index, index - 1)

func on_animation_row_down_pressed(animation_row: TweenKeyFrameEditor):
	var index: = animation_rows.find(animation_row)
	_move_tween(index, index + 1)

func _move_tween(index: int, new_index: int):
	if index < 0 or index > animation_rows.size() - 1:
		return
	if new_index < 0 or new_index > animation_rows.size() - 1:
		return
	
	var animation_row: TweenKeyFrameEditor = animation_rows[index]
	var tween_data: TweenKeyFrame = tween_sequence.tweens[index]
	animation_rows.remove(index)
	animation_rows.insert(new_index, animation_row)
	
	
	var tweens: = tween_sequence.tweens
	tweens.remove(index)
	tweens.insert(new_index, tween_data)
	tween_sequence.tweens = tweens
	
	for r in animation_rows.size():
		var row: TweenKeyFrameEditor = animation_rows[ - r - 1]
		animation_row_parent.move_child(row, 0)

func on_animation_row_button_down(tween_key_frame_editor: TweenKeyFrameEditor):
	dragging_animation_row = tween_key_frame_editor

func on_animation_row_button_up(tween_key_frame_editor: TweenKeyFrameEditor):
	if dragging_animation_row == tween_key_frame_editor:
		dragging_animation_row = null

func delete_rows():
	for i in animation_rows.size():
		var row: TweenKeyFrameEditor = animation_rows[i]
		row.queue_free()
	animation_rows.clear()






