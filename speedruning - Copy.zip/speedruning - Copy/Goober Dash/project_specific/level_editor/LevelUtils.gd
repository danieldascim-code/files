extends Node2D
class_name LevelUtils


enum LevelType{
	RACE = 0, 
	LAST_ONE_STANDING, 
	LOBBY, 
	MAX
}

static func string_for_level_type(level_type: int) -> String:
	if level_type == LevelType.RACE:
		return "Race"
	elif level_type == LevelType.LAST_ONE_STANDING:
		return "Knockout"
	elif level_type == LevelType.LOBBY:
		return "Lobby"
		
	assert (false)
	printerr("unknown level level type %i" % [level_type])
	return "Race"
	

static func level_type_for_string(level_type_string: String) -> int:
	if level_type_string == "Race":
		return LevelType.RACE
	elif level_type_string == "Knockout":
		return LevelType.LAST_ONE_STANDING
	elif level_type_string == "Lobby":
		return LevelType.LOBBY
		
	assert (false)
	printerr("unknown level level type string %s" % [level_type_string])
	return LevelType.RACE
