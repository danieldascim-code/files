extends Reference
class_name LevelSerializer

static func serialize_level(level: Node2D) -> Dictionary:
	var d: = {}
	var num_children: = level.get_child_count()
	var serialized_nodes: = []
	for i in num_children:
		var child = level.get_child(i)
		if child is LevelNode:
			var level_node: = child as LevelNode
			var child_dictionary: = _serialize_level_node(level_node)
			serialized_nodes.append(child_dictionary)
	d["nodes"] = serialized_nodes
	return d

static func deserialize_level(d: Dictionary, node_factory: LevelNodeFactory) -> Node2D:
	var parent: = Node2D.new()
	var nodes: = d["nodes"] as Array
	for n in nodes:
		var child_dictionary: = n as Dictionary
		var level_node: = _deserialize_level_node(child_dictionary, node_factory)
		if level_node:
			parent.add_child(level_node)
			level_node.owner = parent
	return parent

static func _deserialize_level_node(d: Dictionary, node_factory: LevelNodeFactory) -> LevelNode:
	var level_node: = node_factory.create_node(d["type"])
	if level_node:
		level_node._deserialize(d)
	return level_node

static func _serialize_level_node(level_node: LevelNode) -> Dictionary:
	var d: = {}
	level_node._serialize(d)
	return d
