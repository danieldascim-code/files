extends Node
class_name LevelEditorCamera_MouseControls

onready var camera: = get_parent() as LevelEditorCamera

export  var _ui_root: NodePath
onready var ui_root: = get_node(_ui_root) as Control

var mouse_is_over_editor_ui: = false
var mouse_clicked_on_ui_root: = false
const middle_mouse_down_move_scalar: = 1.0
const mouse_wheel_zoom_scalar: = 0.05
const keyboard_move_scalar: = 1000.0
const keyboard_zoom_scalar: = 0.3

func _ready() -> void :
	ui_root.connect("gui_input", self, "on_ui_root_gui_input")
	ui_root.connect("mouse_entered", self, "on_ui_root_mouse_entered")
	ui_root.connect("mouse_exited", self, "on_ui_root_mouse_exited")

func on_ui_root_mouse_entered():
	mouse_is_over_editor_ui = true

func on_ui_root_mouse_exited():
	mouse_is_over_editor_ui = false

func _process(delta: float) -> void :
	
	var camera_down: = Input.get_axis("level_editor_camera_up", "level_editor_camera_down")
	var camera_right: = Input.get_axis("level_editor_camera_left", "level_editor_camera_right")
	camera.target_position += delta * keyboard_move_scalar * Vector2(camera_right, camera_down).normalized()
	
	if mouse_clicked_on_ui_root and Input.is_mouse_button_pressed(BUTTON_LEFT):
		var mouse_position: = ui_root.get_local_mouse_position()
		var mouse_edge_buffer: = 100.0
		var mouse_edge_speed: = 700.0
		var pan_vector: = Vector2.ZERO
		
		if mouse_position.x < mouse_edge_buffer:
			pan_vector.x -= 1.0 - mouse_position.x / mouse_edge_buffer
		elif mouse_position.x > ui_root.rect_size.x - mouse_edge_buffer:
			pan_vector.x += 1.0 - (ui_root.rect_size.x - mouse_position.x) / mouse_edge_buffer
		if mouse_position.y < mouse_edge_buffer:
			pan_vector.y -= 1.0 - mouse_position.y / mouse_edge_buffer
		elif mouse_position.y > ui_root.rect_size.y - mouse_edge_buffer:
			pan_vector.y += 1.0 - (ui_root.rect_size.y - mouse_position.y) / mouse_edge_buffer
		camera.target_position += delta * pan_vector * mouse_edge_speed

func _input(event: InputEvent) -> void :
	if mouse_clicked_on_ui_root:
		if event is InputEventMouseButton:
			if event.button_index == BUTTON_LEFT and not event.pressed:
				mouse_clicked_on_ui_root = false

func on_ui_root_gui_input(event: InputEvent) -> void :
	
	if event.is_action_pressed("level_editor_camera_zoom_in"):
		camera.target_zoom *= (1.0 + keyboard_zoom_scalar)
	if event.is_action_pressed("level_editor_camera_zoom_out"):
		camera.target_zoom *= (1.0 - keyboard_zoom_scalar)
	
	
	if event is InputEventMouseMotion:
		var mouse_motion_event: InputEventMouseMotion = event
		var is_holding_space: = Input.is_key_pressed(KEY_SPACE)
		if is_holding_space or mouse_motion_event.button_mask & BUTTON_MASK_MIDDLE != 0 or mouse_motion_event.button_mask & BUTTON_MASK_RIGHT != 0:
			var canvas_scalar: = get_viewport().canvas_transform.get_scale().x
			var mouse_delta: = mouse_motion_event.relative
			camera.target_position = camera.target_position - (middle_mouse_down_move_scalar * mouse_delta / canvas_scalar)
	
	
	if event is InputEventMouseButton:
		if event.button_index == BUTTON_LEFT and event.pressed:
			mouse_clicked_on_ui_root = true
		if mouse_is_over_editor_ui:
			if event.button_index == BUTTON_WHEEL_UP or event.button_index == BUTTON_WHEEL_DOWN:
				var sign_of_position_change: = 1.0
				if event.button_index == BUTTON_WHEEL_DOWN:
					sign_of_position_change = 0.0
				if event.button_index == BUTTON_WHEEL_UP:
					camera.target_zoom -= event.factor * mouse_wheel_zoom_scalar
				if event.button_index == BUTTON_WHEEL_DOWN:
					camera.target_zoom += event.factor * mouse_wheel_zoom_scalar
