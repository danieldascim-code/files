extends UpGuys_Level
class_name Level

signal unloading_level()
signal loaded_level()
signal added_node(level_node)
signal removed_node(level_node)
signal theme_changed(level_theme)
signal aabb_changed(aabb)


export  var listen_to_animation_creation: = false
export  var load_themes: = false

var level_load_location: int

onready var disappearing_block_network_type: = get_network_type("DisappearingBlock_NetworkObject")
onready var laser_network_type: = get_network_type("Laser_NetworkObject")
onready var recharger_network_type: = get_network_type("Recharger_NetworkObject")


var theme_loader: LevelThemeLoader
var level_theme: BaseTheme

func get_network_type(class_str: String) -> int:
	if network_game:
		return network_game.get_network_object_type_for_classname(class_str)
	return - 1

func _ready():
	if load_themes:
		theme_loader = LevelThemeLoader.new()
		set_level_theme(theme_loader.load_default_theme())
	
	loaded_level = LevelInstance.new()
	loaded_level.name = "StubLevel"
	add_child(loaded_level)

func tick_recharger(recharger: Recharger_NetworkObject):
	var level_node: Recharger = get_level_node(recharger.level_node_index)
	if not level_node:
		network_game.printerr_with_info("[Level] tick_recharger block %s has no level node with index %s" % [recharger.object_id, recharger.level_node_index])
		return
	
	if recharger.recharge_counter > 0:
		if not level_node.one_time_use:
			recharger.recharge_counter -= 1

	level_node.body.enabled = recharger.recharge_counter == 0

func load_level(level: LevelInstance, _load_location: = 0):
	unload_level()
	
	loaded_level = level
	if loaded_level == null:
		
		loaded_level = LevelInstance.new()
		loaded_level.name = "New Level"
	
	if theme_loader:
		level_theme = theme_loader.load_theme(loaded_level.level_theme)
	
	add_child(loaded_level)
	
	_parse_level_nodes()
	
	level_load_location = _load_location
	
	if level_theme:
		_apply_level_theme(level_theme)
	
	get_tree().flush_transform_notifications()
	
	emit_signal("loaded_level")

func unload_level():
	emit_signal("unloading_level")
	
	
	
	
	delete_network_objects()














	
	_clear_level_nodes()
	if loaded_level != null:
		remove_child(loaded_level)
		loaded_level.free()
	loaded_level = null
	aabb = Rect2()
	level_load_location = 0

func _parse_level_nodes() -> void :
	_clear_level_nodes()
	if loaded_level != null:
		for i in loaded_level.get_child_count():
			var level_node: = loaded_level.get_child(i) as LevelNode
			if level_node:
				_add_to_nodes_map(level_node)

func add_level_node(l: LevelNode):
	loaded_level.add_child(l)
	_add_to_nodes_map(l)
	l.owner = loaded_level
	emit_signal("added_node", l)

func remove_level_node(l: LevelNode):
	emit_signal("removed_node", l)
	print("[Level] remove_level_node() removing level node with level_node_index: %s" % [l.level_node_index])
	loaded_level.remove_child(l)
	_remove_from_nodes_map(l)
	l.free()






























static func _sort_overlap_nodes(a: LevelNode, b: LevelNode) -> bool:
	
	var size_a: = a.grid_rect.size.x * a.grid_rect.size.y
	var size_b: = b.grid_rect.size.x * b.grid_rect.size.y
	if size_a != size_b:
		return size_a < size_b
	
	
	return a.level_node_index > b.level_node_index

func get_disappearing_blocks() -> Array:
	return get_nodes_of_type(LevelNodeFactory.disappearing_block_key)

func get_starting_points() -> Array:
	return get_nodes_of_type(LevelNodeFactory.starting_point_key)

func get_finish_lines() -> Array:
	return get_nodes_of_type(LevelNodeFactory.finish_line_key)

func get_gravity_fields() -> Array:
	return get_nodes_of_type(LevelNodeFactory.gravity_field_key)

func get_nodes_of_type(s: String) -> Array:
	if type_to_nodes_map.has(s):
		return type_to_nodes_map[s]
	return []

func compute_player_count() -> int:
	var player_count: = 0
	var starting_points: = get_starting_points()
	for s in starting_points:
		var starting_point: LevelNode = s
		var num_players_v: = LevelGrid.players_per_starting_block(starting_point.world_rect.size)
		player_count += num_players_v.x * num_players_v.y
	return player_count

func next_level_node_index() -> int:
	return ids_given_out

func _add_to_nodes_map(level_node: LevelNode):
	if level_node.level_node_index < 0:
		
		level_node.level_node_index = ids_given_out
		ids_given_out += 1
	else:
		
		
		
		
		
		
		ids_given_out = max(ids_given_out, level_node.level_node_index + 1)
	
	if id_to_nodes.has(level_node.level_node_index):
		printerr("[Level] _add_to_nodes_map(%s) id already taken" % [level_node])
	id_to_nodes[level_node.level_node_index] = level_node
	
	level_node.name = "%s_%d" % [level_node.node_type, level_node.level_node_index]
	
	aabb = grow_abb(aabb, level_node)
	emit_signal("aabb_changed", aabb)
	
	if not type_to_nodes_map.has(level_node.node_type):
		type_to_nodes_map[level_node.node_type] = []
	type_to_nodes_map[level_node.node_type].append(level_node)
	
	if listen_to_animation_creation:
		level_node.connect("animation_created", self, "on_animation_created")
		level_node.connect("animation_deleted", self, "on_animation_deleted")
	if level_node.animation != null:
		_add_animation_node(level_node)
	
	if network_game != null:
		var network_object: NetworkObject = level_node.internal_network_object()
		if network_object != null:
			if network_game.type == NetworkGame.SERVER:
				
				
				
				var level_node_index: = level_node.level_node_index
				network_object.level_node_index = level_node_index
				level_node.remove_child(network_object)
				network_game.add_child(network_object)
				var network_object_id: = network_object.object_id
				level_node.network_object_id = network_object_id
				
			else:
				
				
				
				
				var id_hash: = _id_hash_level_node_index(level_node.level_node_index)
				level_node.network_object_id = id_hash
				
				var existing_network_object: = network_game.get_object_for_object_id(id_hash)
				if null == existing_network_object:
					network_object.level_node_index = level_node.level_node_index
					level_node.remove_child(network_object)
					network_game.add_child(network_object)
					var network_object_id: = network_object.object_id
					level_node.network_object_id = network_object_id
					assert (network_object_id == id_hash)
				else:
					assert (existing_network_object is LevelNodeBaseNetworkObject)
					assert (existing_network_object.level_node_index == level_node.level_node_index)
					level_node.remove_child(network_object)
					network_object.free()
				
	
	
	if level_theme:
		level_node.apply_theme(level_theme)

func on_animation_created(level_node: LevelNode):
	_add_animation_node(level_node)

func on_animation_deleted(level_node: LevelNode):
	
	if level_node.renderer:
		level_node.renderer.transform = Transform2D.IDENTITY
	_remove_animation_node(level_node)

func _remove_from_nodes_map(level_node: LevelNode):
	if not id_to_nodes.has(level_node.level_node_index):
		
		printerr("[Level] _remove_from_nodes_map() no level_node with id %d" % [level_node.level_node_index])
	else:
		id_to_nodes.erase(level_node.level_node_index)

	if not type_to_nodes_map.has(level_node.node_type):
		
		printerr("[Level] _remove_from_nodes_map() no level_node_list for level_node of type %s" % [level_node.node_type])
	else:
		var level_node_list: Array = type_to_nodes_map[level_node.node_type]
		level_node_list.erase(level_node)

	if level_node.animation != null:
		_remove_animation_node(level_node)

	if level_node.network_object_id >= 0:
		var network_object: = network_game.get_object_for_object_id(level_node.network_object_id)
		if network_object:
			
			network_game.remove_child(network_object)
			network_object.free()
		else:
			
			pass
	else:
		
		pass
	
	level_node.level_node_index = - 1
	aabb = calculate_aabb()
	emit_signal("aabb_changed", aabb)

func has_level_node(index: int) -> bool:
	return id_to_nodes.has(index)







func _clear_level_nodes() -> void :
	ids_given_out = 0
	type_to_nodes_map.clear()
	id_to_nodes.clear()
	animated_nodes.clear()

func _add_animation_node(animation_node: LevelNode):
	animated_nodes.append(animation_node)

func _remove_animation_node(animation_node: LevelNode):
	animated_nodes.erase(animation_node)

func set_level_theme(r: Resource):
	if theme_loader:
		level_theme = r as BaseTheme
		if level_theme == null:
			level_theme = theme_loader.default_theme
		_apply_level_theme(level_theme)
		if loaded_level != null:
			loaded_level.level_theme = theme_loader.theme_key(level_theme)

func _apply_level_theme(level_theme: BaseTheme):
	for level_id in id_to_nodes:
		var level_node: = id_to_nodes[level_id] as LevelNode
		level_node.apply_theme(level_theme)
	emit_signal("theme_changed", level_theme)

func recalculate_aabb():
	var new_aabb: = calculate_aabb()
	if new_aabb != aabb:
		aabb = new_aabb
		emit_signal("aabb_changed", aabb)

func calculate_aabb() -> Rect2:
	var r: = Rect2()
	for level_id in id_to_nodes:
		var level_node: = id_to_nodes[level_id] as LevelNode
		r = r.expand(level_node.world_rect.position)
		r = r.expand(level_node.world_rect.end)
	return r

func grow_abb(r: Rect2, level_node: LevelNode) -> Rect2:
	r = r.expand(level_node.world_rect.position)
	r = r.expand(level_node.world_rect.end)
	return r
