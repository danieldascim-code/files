extends Camera2D
class_name GameCamera

export  var _game: NodePath
onready var game: = get_node(_game) as WPGame

export  var _game_data: NodePath
onready var game_data: = get_node(_game_data) as WPGameData

const default_zoom: = 1.0
const winner_zoom: = 0.3



const max_viewable_distance: = 1.0 * Vector2(2000.0, 2000.0)
const min_viewable_distance: = 1.0 * Vector2(1000.0, 1200.0)

onready var enable_zoom: = OS.has_feature("editor") and true
export  var z_factor: = 1.0

var z: = default_zoom
var zoom_target: = default_zoom
var zoom_smooth_velocity: = 0.0

var position_smoothed_velocity: = Vector2.ZERO

const mouse_wheel_zoom_tweak: = 0.025

var is_running_preplay_tween: = false
var first_frame: = true
var intro_pan_enabled: = true

func _ready():
	zoom = Vector2(z, z)
	current = true
	game.connect("level_loaded", self, "on_level_loaded")
	

func _input(event):
	if enable_zoom:
		if event is InputEventMouseButton:
			if event.is_pressed():
				var zoom_change: = 0.0
				if event.button_index == BUTTON_WHEEL_DOWN or event.button_index == BUTTON_WHEEL_UP:
					if event.button_index == BUTTON_WHEEL_DOWN:
						zoom_change -= event.factor
					elif event.button_index == BUTTON_WHEEL_UP:
						zoom_change += event.factor
					
					z_factor = clamp(z_factor + zoom_change * mouse_wheel_zoom_tweak, 0.01, 50.0)

func on_level_loaded():
	intro_camera_pan_tween()

func intro_camera_pan_tween():
	var focussed_player: = _find_focussed_player()
	if not focussed_player:
		return
	if game.wp_game_data.is_level_editor:
		return
	if not intro_pan_enabled:
		return
	var seconds_to_look_at_goober: = 3.0
	if game.wp_game_data.is_time_trial:
		seconds_to_look_at_goober = 2.0
	var total_animation_time: = abs(game.wp_game_data.state_time) - seconds_to_look_at_goober
	total_animation_time = min(4.5, total_animation_time)
	
	if game.is_in_regular_pre_play() and total_animation_time >= 2.0:
		var target_position = focussed_player.position
		var delay_time: = min(1.0, total_animation_time * 0.33)
		var anim_time: = total_animation_time - delay_time
		var finish_lines: = game.level.get_finish_lines()
		if finish_lines.size() > 0:
			var finish_line: LevelNode = finish_lines[0]
			position = finish_line.world_rect.get_center()
			
			is_running_preplay_tween = true
			var t: = create_tween()
			t.tween_property(self, "position", target_position, anim_time).set_ease(Tween.EASE_IN_OUT).set_trans(Tween.TRANS_QUAD).set_delay(delay_time)
			t.tween_callback(self, "_end_preplay_tween")

func _end_preplay_tween():
	is_running_preplay_tween = false

func _process(delta):
	if not game.is_game_started():
		return
	
	
	var focussed_player: = _find_focussed_player()
	if not focussed_player:
		return
	
	
	var focussed_renderer: = game.client_renderer.get_renderer_for_object_id(focussed_player.object_id) as UpGuys_PlayerRenderer
	if not focussed_renderer:
		return
	var target_position: = focussed_renderer.position_node.position
	
	
	if game.wp_game_data.is_time_trial or game.wp_game_data.is_replay:
		if game.is_game_over():
			target_position = target_position + Vector2(0, 100.0)
	
	
	var position_smoothing_enabled: = false
	var p_smooth_time: = 0.0
	if game.is_game_over():
		
		position_smoothing_enabled = true
		p_smooth_time = 0.2
		if game.wp_game_data.is_time_trial:
			p_smooth_time = 0.2
	elif is_running_preplay_tween:
		
		
		position_smoothing_enabled = false
		target_position = position
	elif focussed_player.alive:
		
		position_smoothing_enabled = false
	else:
		
		position_smoothing_enabled = true
		p_smooth_time = 0.1












	
	if position_smoothing_enabled:
		var p: = Smoothing.smooth_damp_vec2(position, target_position, position_smoothed_velocity, p_smooth_time, delta, INF)
		position_smoothed_velocity = p[1]
		target_position = p[0]
	else:
		position_smoothed_velocity = target_position - position
		position_smoothed_velocity = Vector2.ZERO
	
	position = target_position
		
	
	if game.is_game_over():
		if game.wp_game_data.state_time > 1.0 or game.wp_game_data.is_time_trial:
			var target_zoom = winner_zoom
			var zoom_speed: = 1.0
			if game.wp_game_data.is_time_trial:
				zoom_speed = 0.5
			var smooth_result: = Smoothing.smooth_damp(z, 0.2, zoom_smooth_velocity, zoom_speed, delta)
			z = smooth_result.x
			zoom_smooth_velocity = smooth_result.y
	else:
		z = _compute_distance_zoom()
		zoom_smooth_velocity = 0.0
	
	zoom = Vector2(z, z) * z_factor
	force_update_scroll()
	ViewportRectCalculator.calculate_viewport_visible_rect()

func _compute_distance_zoom() -> float:
	
	var viewport: = get_viewport()
	var viewport_rect: = viewport.get_visible_rect()
	var visible_rect: = ViewportUtils._viewport_visible_rect(viewport)
	var min_distance_zoom_x: = min_viewable_distance.x / viewport_rect.size.x
	var min_distance_zoom_y: = min_viewable_distance.y / viewport_rect.size.y
	
	
	
	
	
	
	var min_distance_zoom: = max(min_distance_zoom_x, min_distance_zoom_y)
	
	var max_distance_zoom_x: = max_viewable_distance.x / viewport_rect.size.x
	var max_distance_zoom_y: = max_viewable_distance.y / viewport_rect.size.y
	
	
	var max_distance_zoom: = min(max_distance_zoom_x, max_distance_zoom_y)
	
	
	var distance_zoom: = min(max_distance_zoom, min_distance_zoom)
	
	
	return distance_zoom

func _find_focussed_player() -> WPPlayer:
	var local_player: = game.get_local_player() as WPPlayer
	if local_player == null:
		return null
	if local_player.spectator_object_id > 0:
		return game.get_player_for_object_id(local_player.spectator_object_id) as WPPlayer
	return local_player
