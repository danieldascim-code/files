extends CanvasLayer
class_name TimeTrialLeaderboardRecordCard

onready var dialog: UIDialog = $UIDialog

export  var _spinner: NodePath
onready var spinner: Control = get_node(_spinner)

export  var _player_profile_container: NodePath
onready var player_profile_container: Control = get_node(_player_profile_container)

export  var _player_name_label: NodePath
onready var player_name_label: Label = get_node(_player_name_label)

export  var _player_level_label: NodePath
onready var player_level_label: Label = get_node(_player_level_label)

export  var _goober: NodePath
onready var goober: Goober = get_node(_goober)

export  var _player_profile_container_anchor: NodePath
onready var player_profile_container_anchor: GoodAnchorPoint = get_node(_player_profile_container_anchor)

export  var _player_profile_container_tween: NodePath
onready var player_profile_container_tween: Tween = get_node(_player_profile_container_tween)

export  var _rank_label: NodePath
onready var rank_label: Label = get_node(_rank_label)

export  var _time_label: NodePath
onready var time_label: Label = get_node(_time_label)

export  var _level_name_label: NodePath
onready var level_name_label: Label = get_node(_level_name_label)

export  var _level_author_label: NodePath
onready var level_author_label: Label = get_node(_level_author_label)

export  var _race_ghost_button: NodePath
onready var race_ghost_button: BaseButton = get_node(_race_ghost_button)

export  var _watch_replay_button: NodePath
onready var watch_replay_button: BaseButton = get_node(_watch_replay_button)

signal race_ghost_button_pressed()
signal watch_replay_button_pressed()

func _ready() -> void :
	spinner.visible = true
	player_profile_container.visible = false
	race_ghost_button.connect("pressed", self, "emit_signal", ["race_ghost_button_pressed"])
	watch_replay_button.connect("pressed", self, "emit_signal", ["watch_replay_button_pressed"])

func show_leaderboard_record_card(user_id: String, leaderboard_record: Dictionary, level_metadata: Dictionary):
	var response: Dictionary = yield(Moonlight.call_rpc("query_player_profile", {
		"user_id": user_id
	}, false), "completed")
	if response == null or response.has("error"):
		printerr("[PlayerProfileDialog] query_player_profile failed")
		dialog.animate_out()
		return
	
	spinner.visible = false
	player_name_label.text = response.get("display_name", "")
	player_level_label.text = str(response.get("level", "1"))
	var skin: Dictionary = response.get("skin", {})
	goober.set_goober_skin_data(skin)

	player_profile_container_tween.interpolate_callback(player_profile_container, 0.0, "show")
	player_profile_container_tween.interpolate_property(player_profile_container_anchor, "offset", Vector2(0.0, - dialog.rect_size.y), Vector2.ZERO, 0.25, Tween.TRANS_QUINT, Tween.EASE_OUT)
	player_profile_container_tween.start()

	var record_rank: int = int(leaderboard_record.get("rank", 0))
	var record_score: float = float(leaderboard_record.get("score", 0.0)) / 100000.0
	var score_formatted: = "%.3f seconds" % [record_score]

	rank_label.text = "%s place" % [DateTimeUtils.number_to_ordinal_string(record_rank)]
	time_label.text = score_formatted
	level_name_label.text = level_metadata.get("name", "")
	level_author_label.text = "by " + level_metadata.get("author_name", "")
