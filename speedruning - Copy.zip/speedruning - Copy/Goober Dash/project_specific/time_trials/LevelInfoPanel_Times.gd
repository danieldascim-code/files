extends Node
class_name LevelInfoPanel_Times

signal world_record_button_pressed()
signal personal_best_button_pressed()
signal ghost_button_pressed()

export  var _this_time_container: NodePath
onready var this_time_container: Control = get_node(_this_time_container)

export  var _this_time_time_pill: NodePath
onready var this_time_time_pill: TimePill = get_node(_this_time_time_pill)

export  var _this_time_world_record_icon: NodePath
onready var this_time_world_record_icon: TimeTrial_RecordIcon = get_node(_this_time_world_record_icon)

export  var _this_time_personal_best_icon: NodePath
onready var this_time_personal_best_icon: TimeTrial_RecordIcon = get_node(_this_time_personal_best_icon)

export  var _world_record_time_pill: NodePath
onready var world_record_time_pill: TimePill = get_node(_world_record_time_pill)

export  var _world_record_holder_name: NodePath
onready var world_record_holder_name: Label = get_node(_world_record_holder_name)

export  var _world_record_icon_rays: NodePath
onready var world_record_icon_rays: TimeTrial_RecordIcon = get_node(_world_record_icon_rays)

export  var _world_record_button: NodePath
onready var world_record_button: BaseButton = get_node(_world_record_button)

export  var _world_record_container: NodePath
onready var world_record_container: Control = get_node(_world_record_container)

export  var _personal_best_time_pill: NodePath
onready var personal_best_time_pill: TimePill = get_node(_personal_best_time_pill)

export  var _personal_best_icon_rays: NodePath
onready var personal_best_icon_rays: TimeTrial_RecordIcon = get_node(_personal_best_icon_rays)

export  var _personal_best_container: NodePath
onready var personal_best_container: Control = get_node(_personal_best_container)

export  var _personal_best_button: NodePath
onready var personal_best_button: BaseButton = get_node(_personal_best_button)

export  var _ghost_container: NodePath
onready var ghost_container: Control = get_node(_ghost_container)

export  var _ghost_name: NodePath
onready var ghost_name: Label = get_node(_ghost_name)

export  var _ghost_time_pill: NodePath
onready var ghost_time_pill: TimePill = get_node(_ghost_time_pill)

export  var _ghost_button: NodePath
onready var ghost_button: BaseButton = get_node(_ghost_button)

onready var enable_test_show_animations: = OS.has_feature("editor") and false

func _ready() -> void :
	personal_best_time_pill.set_no_time()
	this_time_time_pill.set_no_time()
	this_time_container.hide()
	world_record_time_pill.set_no_time()
	world_record_holder_name.text = ""
	personal_best_container.visible = not Moonlight.auth.is_guest_account()
	world_record_container.hide()
	ghost_container.hide()
	personal_best_button.connect("pressed", self, "emit_signal", ["personal_best_button_pressed"])
	world_record_button.connect("pressed", self, "emit_signal", ["world_record_button_pressed"])
	ghost_button.connect("pressed", self, "emit_signal", ["ghost_button_pressed"])

func show_this_time(this_time: float):
	this_time_container.show()
	this_time_time_pill.set_time(this_time)

func show_personal_best(this_time: float, leaderboard_data: Dictionary):
	personal_best_time_pill.set_no_time()
	if leaderboard_data.has("owner_records"):
		var owner_records: Array = leaderboard_data["owner_records"]
		if owner_records.size() > 0:
			var self_record: Dictionary = owner_records[0]
			var record_rank: int = int(self_record.get("rank", 0))
			var record_score: float = float(self_record.get("score", 0.0)) / 100000.0
			personal_best_time_pill.set_time(record_score)
			
			if not is_zero_approx(this_time):
				if enable_test_show_animations or is_equal_approx(record_score, this_time):
					this_time_personal_best_icon.animate_in(0.0)
					personal_best_icon_rays.animate_in(0.0)
					if enable_test_show_animations or record_rank == 1:
						this_time_world_record_icon.animate_in(0.25)
						world_record_icon_rays.animate_in(0.25)

func show_world_record(leaderboard_data: Dictionary):
	world_record_container.show()
	world_record_time_pill.set_no_time()
	world_record_holder_name.text = ""
	if leaderboard_data.has("records"):
		var records: Array = leaderboard_data["records"]
		if records.size() > 0:
			var top_record: Dictionary = records[0]
			var record_score: float = float(top_record.get("score", 0.0)) / 100000.0
			world_record_time_pill.set_time(record_score)
			
			
			var record_name: String = top_record.get("username", {}).get("value", "")
			world_record_holder_name.text = record_name

func show_ghost_time(ghost_time: float, ghost_username: String):
	ghost_container.show()
	ghost_name.text = ghost_username
	ghost_time_pill.set_time(ghost_time)
