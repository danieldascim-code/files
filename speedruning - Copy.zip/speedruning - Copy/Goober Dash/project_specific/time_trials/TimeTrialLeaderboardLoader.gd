extends Reference
class_name TimeTrialLeaderboardLoader














































static func async_query_time_trial_leaderboard(level_id: String, limit = 25) -> Dictionary:
	print("[TimeTrialLeaderboardLoader] async_query_time_trial_leaderboard(%s, %s)" % [level_id, limit])
	var local_user_id: = Moonlight.local_user_id()
	var payload: = {
		"level_id": level_id, 
		"owner_ids": [local_user_id], 
		"limit": limit, 
	}
	var result: Dictionary = yield(Moonlight.call_rpc("time_trial_query_leaderboard", payload, false), "completed")
	if result.has("error"):
		printerr("[TimeTrialLeaderboards] async_query_time_trial_leaderboard() failed to query leaderboard. error: %s" % [result])
	return result

static func async_query_time_trial_leaderboard_specific_record(level_id: String, user_id: String) -> Dictionary:
	print("[TimeTrialLeaderboardLoader] async_query_time_trial_leaderboard_specific_record(%s, %s)" % [level_id, user_id])
	var local_user_id: = Moonlight.local_user_id()
	var payload: = {
		"level_id": level_id, 
		"owner_ids": [user_id], 
		"limit": 0, 
	}
	var result: Dictionary = yield(Moonlight.call_rpc("time_trial_query_leaderboard", payload, false, true), "completed")
	if result.has("error"):
		printerr("[TimeTrialLeaderboards] async_query_time_trial_leaderboard() failed to query leaderboard. error: %s" % [result])
		return {}
	var owner_records: Array = result.get("owner_records", [])
	if owner_records.empty():
		printerr("[TimeTrialLeaderboards] async_query_time_trial_leaderboard() no owner record %s" % [result])
		return {}
	return owner_records[0]
	
static func async_query_time_trial_leaderboard_self_record(level_id: String) -> Dictionary:
	print("[TimeTrialLeaderboardLoader] async_query_time_trial_leaderboard_self_record(%s)" % [level_id])
	var local_user_id: = Moonlight.local_user_id()
	var payload: = {
		"level_id": level_id, 
		"owner_ids": [local_user_id], 
		"limit": 0, 
	}
	var result: Dictionary = yield(Moonlight.call_rpc("time_trial_query_leaderboard", payload, false, true), "completed")
	if result.has("error"):
		printerr("[TimeTrialLeaderboards] async_query_time_trial_leaderboard() failed to query leaderboard. error: %s" % [result])
		return {}
	var owner_records: Array = result.get("owner_records", [])
	if owner_records.empty():
		printerr("[TimeTrialLeaderboards] async_query_time_trial_leaderboard() no owner record %s" % [result])
		return {}
	return owner_records[0]
