extends Reference
class_name TimeTrialSceneParameters

enum TimeTrialSceneMode{
	TimeTrial, 
	ReplayGhost, 
	Replay, 
	PrepublishRun
}


var mode: int = TimeTrialSceneMode.TimeTrial
var level_id: = ""
var replay_user_id: = ""


var local_user_id: = ""
var loaded_level_id: = ""
var leaderboard_data: = {}
var leaderboard_data_timestamp: = 0
var level_data: = {}
var level_data_string: = ""
var loaded_replay_user_id: = ""
var replay_metadata: = {}
var replay_bytes: = PoolByteArray()
var replay_player_name: = ""
var replay_time: = 0.0
