extends CanvasLayer
class_name TimeTrialLeaderboardDialog

signal leaderboard_queried(level_id, leaderboard_data)
signal leaderboard_row_pressed(level_id, user_id, leaderboard_record)

export  var _leaderboard: NodePath
onready var leaderboard: TimeTrialLeaderboard = get_node(_leaderboard)

export  var _level_name_label: NodePath
onready var level_name_label: Label = get_node(_level_name_label)

export  var _level_author_label: NodePath
onready var level_author_label: Label = get_node(_level_author_label)

export  var _my_best_rank_time_pill: NodePath
onready var my_best_rank_time_pill: TimePill = get_node(_my_best_rank_time_pill)

export  var _my_best_rank_label: NodePath
onready var my_best_rank_label: Label = get_node(_my_best_rank_label)

export  var _my_username_label: NodePath
onready var my_username_label: Label = get_node(_my_username_label)

export  var _my_best_button: NodePath
onready var my_best_button: BaseButton = get_node(_my_best_button)

export  var _personal_best_icon: NodePath
onready var personal_best_icon: TimeTrial_RecordIcon = get_node(_personal_best_icon)

export  var _world_record_icon: NodePath
onready var world_record_icon: TimeTrial_RecordIcon = get_node(_world_record_icon)

export  var _spinner: NodePath
onready var spinner: Control = get_node(_spinner)

onready var dialog: UIDialog = $UIDialog

func _ready() -> void :
	leaderboard.connect("leaderboard_row_pressed", self, "on_leaderboard_row_pressed")
	my_username_label.text = Moonlight.storage.storage_get("account.user.display_name", "")
	my_best_rank_time_pill.hide()
	my_best_rank_label.text = ""
	spinner.hide()

func show_leaderboard(level_id: String, level_data: Dictionary):
	spinner.show()
	var leaderboard_data: Dictionary = yield(TimeTrialLeaderboardLoader.async_query_time_trial_leaderboard(level_id), "completed")
	spinner.hide()
	emit_signal("leaderboard_queried", level_id, leaderboard_data)
	var level_metadata: Dictionary = level_data.get("metadata", {})
	level_name_label.text = level_metadata.get("name", "")
	level_author_label.text = "Designer: " + level_metadata.get("author_name", "")
	var my_best_time: = 0.0
	var my_best_rank: int = 0
	var found_self: bool = false
	var self_leaderboard_record: = {}
	if not leaderboard_data.has("error"):
		if leaderboard_data.has("owner_records"):
			var owner_records: Array = leaderboard_data["owner_records"]
			if owner_records.size() > 0:
				found_self = true
				var self_record: Dictionary = owner_records[0]
				var record_rank: int = int(self_record.get("rank", 0))
				my_best_time = float(self_record.get("score", 0.0)) / 100000.0
				my_best_rank = record_rank
				self_leaderboard_record = self_record.duplicate(true)
	if found_self:
		my_best_rank_time_pill.show()
		my_best_rank_time_pill.set_time(my_best_time)
		personal_best_icon.animate_in(0.0)
		my_best_rank_label.text = DateTimeUtils.number_to_ordinal_string(my_best_rank)
		if my_best_rank == 1:
			world_record_icon.animate_in(0.0)
	else:
		my_best_rank_time_pill.hide()
		my_best_rank_label.text = ""
	
	if found_self:
		if my_best_button.is_connected("pressed", self, "on_leaderboard_row_pressed"):
			my_best_button.disconnect("pressed", self, "on_leaderboard_row_pressed")
		my_best_button.connect("pressed", self, "on_leaderboard_row_pressed", [level_id, Moonlight.local_user_id(), self_leaderboard_record])
	leaderboard.show_time_trial_leaderboard(level_id, leaderboard_data, Moonlight.local_user_id())

func on_leaderboard_row_pressed(level_id, user_id, leaderboard_record):
	emit_signal("leaderboard_row_pressed", level_id, user_id, leaderboard_record)
