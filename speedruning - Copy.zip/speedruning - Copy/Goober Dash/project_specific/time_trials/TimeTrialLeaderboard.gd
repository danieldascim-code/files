extends VBoxContainer
class_name TimeTrialLeaderboard

var rows: = []
signal leaderboard_row_pressed(level_id, user_id, leaderboard_record)

export  var row_scene: PackedScene

export  var _row_parent: NodePath
onready var row_parent: = get_node(_row_parent)

export  var _empty_row: NodePath
onready var empty_row: Control = get_node(_empty_row)

export  var local_user_row_color: Color

func _ready() -> void :
	empty_row.hide()

func delete_rows():
	for r in rows:
		r.queue_free()
	rows.clear()

func show_time_trial_leaderboard(level_id: String, leaderboard_data: Dictionary, local_user_id: String):
	delete_rows()
	
	var records: Array = leaderboard_data.get("records", [])
	for i in records.size():
		var record: Dictionary = records[i]
		var leaderboard_row: LeaderboardRow = row_scene.instance()

		rows.append(leaderboard_row)
		row_parent.add_child(leaderboard_row)

		
		
		var record_name: String = record.get("username", {}).get("value", "")
		var record_rank: int = int(record.get("rank", 0))
		var record_score: float = float(record.get("score", 0.0)) / 100000.0
		var score_formatted: = "%.3fs" % [record_score]
		var record_owner: String = record.get("owner_id", "")
		var record_metadata_str: String = record.get("metadata", "")
		var record_metadata: Dictionary = {}
		if not record_metadata_str.empty():
			var d = parse_json(record_metadata_str)
			if d is Dictionary:
				record_metadata = d
		
		var is_self: = record_owner == local_user_id
		leaderboard_row.show_data(record_name, str(record_rank), score_formatted, record_metadata, i % 2 == 0 or is_self)
		if is_self:
			leaderboard_row.background.self_modulate = local_user_row_color
		leaderboard_row.connect("pressed", self, "on_leaderboard_row_pressed", [level_id, record_owner, record])
	
	empty_row.visible = rows.size() == 0

func on_leaderboard_row_pressed(level_id: String, user_id: String, record: Dictionary):
	emit_signal("leaderboard_row_pressed", level_id, user_id, record)
