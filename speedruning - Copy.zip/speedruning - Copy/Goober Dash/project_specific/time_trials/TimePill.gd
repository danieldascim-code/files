extends Control
class_name TimePill

export  var _time_label: NodePath
onready var time_label: Label = get_node(_time_label)

export  var _time_label_frac: NodePath
onready var time_label_frac: Label = get_node(_time_label_frac)

export  var _time_label_s: NodePath
onready var time_label_s: Label = get_node_or_null(_time_label_s)

func set_no_time():
	time_label.text = "-"
	time_label_frac.text = ""
	time_label_s.text = ""

func set_time(t: float):
	var stringified: = "%.3f" % t
	var splat: = stringified.split_floats(".")
	var number: = 0
	var decimal: = 0
	if splat.size() > 0:
		number = int(splat[0])
	if splat.size() > 1:
		decimal = int(splat[1])
	time_label.text = "%d" % number
	time_label_frac.text = ".%03d" % decimal
	time_label_s.text = "s"

