tool 
extends Node

onready var leveup_dialog_scene: = get_parent() as UILevelUpDialog


func _ready():
	if OS.has_feature("editor") and get_tree().current_scene == get_parent():
		yield(get_tree().create_timer(0.5), "timeout")
		
		
		
		
		

		leveup_dialog_scene.show()
