tool 
extends Node

onready var reward_dialog_scene: = get_parent() as UIRewardDialog


func _ready():
	if OS.has_feature("editor") and get_tree().current_scene == get_parent():
		yield(get_tree().create_timer(0.05), "timeout")
		
		
		var match_data: = {
			"is_winner": true, 
			"match_rank": 1, 
			"coins": 40, 
			"stars": 2, 
			"trophies": 8, 
			"trophies_multiplier": 2.0, 
			"awards": [{"award": "finisher", "count": 1}, {"award": "betatester", "count": 1}], 
			"coins_multiplier": 2.0, 
			"qualified_rounds": 3, 
			"first_place_rounds": 1, 
			"spin_results": {
				"spins": [
					{
						"type": "cosmetic", 
						"cosmetic_id": "hat_chicken", 
						"cosmetic_value": 46, 
						"cosmetic_quantity": 5, 
						"is_gold": false
					}, 
					{
						"type": "cosmetic", 
						"cosmetic_id": "hat_chicken", 
						"cosmetic_value": 46, 
						"cosmetic_quantity": 5, 
						"is_gold": false
					}, 
					{
						"type": "cosmetic", 
						"cosmetic_id": "hat_chicken", 
						"cosmetic_value": 46, 
						"cosmetic_quantity": 5, 
						"is_gold": true
					}, 
					{
						"type": "coins", 
						"coins": 13, 
						"is_gold": false
					}
				]
			}
		}
		reward_dialog_scene.generate_rewards_list_from_match_data(match_data)
		reward_dialog_scene.show_reward_data()
		
