extends ViewportSDF
class_name GDViewportSDF

export (NodePath) var _camera
onready var camera: = get_node_or_null(_camera) as Camera2D

func _process(delta):
	var base_viewport: Viewport
	if camera:
		base_viewport = camera.get_viewport()
		
		camera.force_update_scroll()
	else:
		base_viewport = get_tree().root
	
	size = base_viewport.size
	
	
	canvas_transform = base_viewport.get_final_transform() * base_viewport.canvas_transform



