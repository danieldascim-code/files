extends Control

export  var _game_input: NodePath
onready var game_input: GameInput = get_node(_game_input)

func _ready() -> void :
	game_input.connect("aim_start", self, "on_aim_start")
	game_input.connect("aim_stop", self, "on_aim_stop")
	game_input.connect("aim_moved", self, "on_aim_moved")
	hide()

func on_aim_start(p: Vector2):
	visible = true
	set_rotation(p.angle() + PI * 0.5)

func on_aim_stop(p: Vector2):
	visible = false
	set_rotation(p.angle() + PI * 0.5)

func on_aim_moved(p: Vector2):
	set_rotation(p.angle() + PI * 0.5)
