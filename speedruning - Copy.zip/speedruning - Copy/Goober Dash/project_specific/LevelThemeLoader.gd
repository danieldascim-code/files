extends Reference
class_name LevelThemeLoader

var themes: = {}
var default_theme: BaseTheme
const default_theme_path: = "res://project_specific/level_themes/green/theme.tres"
const default_theme_key: = "green"
const themes_directory: = "res://project_specific/level_themes/"

func _init():
	_parse_themes()

func theme_key(r: BaseTheme) -> String:
	for k in themes:
		if r == themes[k]:
			return k
	return default_theme_key

func load_theme(theme_id: String) -> BaseTheme:
	if themes.has(theme_id):
		return themes[theme_id] as BaseTheme
	return default_theme

func load_default_theme() -> BaseTheme:
	return default_theme

func _parse_themes():
	default_theme = ResourceLoader.load(default_theme_path, "Resource")
	assert (default_theme)
	themes.clear()
	var directory: = Directory.new()
	var err: = directory.open(themes_directory)
	if err != OK:
		printerr("[LevelThemeLoader] _parse_scene_cache(%s) open error: %d" % [themes_directory, err])
		return
	err = directory.list_dir_begin(true, true)
	if err != OK:
		printerr("[LevelThemeLoader] _parse_scene_cache(%s) list_dir_begin error: %d" % [themes_directory, err])
		return
	
	var file_name: = directory.get_next()
	while file_name != "":
		if directory.current_is_dir():
			var directory_path: = themes_directory.plus_file(file_name)
			var theme_path: = directory_path.plus_file("theme.tres")
			if ResourceLoader.exists(theme_path, "Resource"):
				var theme_resource: = ResourceLoader.load(theme_path, "Resource") as BaseTheme
				if theme_resource:
					themes[file_name] = theme_resource

		file_name = directory.get_next()
	directory.list_dir_end()
