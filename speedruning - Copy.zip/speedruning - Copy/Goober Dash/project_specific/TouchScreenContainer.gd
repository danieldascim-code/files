extends Control
onready var parent_control: = get_parent_control()

func _ready() -> void :
	SavedSettings.connect("on_value_changed", self, "on_saved_settings_value_changed")
	get_viewport().connect("size_changed", self, "on_size_changed")
	_apply_scale()
	call_deferred("_apply_scale")

func on_saved_settings_value_changed(k: String, value):
	if k == "touchscreen_control_scale":
		_apply_scale()

func on_size_changed():
	_apply_scale()

func _apply_scale():
	
	
	
	var scale_factor: = 1.0 / get_viewport().get_final_transform().get_scale().x
	
	var saved_ui_scale: float = SavedSettings.get_value("touchscreen_control_scale", 1.0)
	
	var max_size: = Vector2(1080.0, 1080.0)
	scale_factor *= saved_ui_scale
	
	scale_factor = min(scale_factor, parent_control.rect_size.x / max_size.x)
	scale_factor = min(scale_factor, parent_control.rect_size.y / max_size.y)
	
	if is_zero_approx(scale_factor):
		scale_factor = 1.0
	
	rect_scale = scale_factor * Vector2.ONE
	rect_size = parent_control.rect_size / scale_factor










