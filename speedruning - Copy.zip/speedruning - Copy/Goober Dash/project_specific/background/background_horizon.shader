shader_type canvas_item;

uniform vec2 uv_offset;
uniform vec2 uv_scale = vec2(1.0, 1.0);

void fragment() {
	vec2 uv = uv_scale * (UV + uv_offset);
	uv.y = clamp(uv.y, TEXTURE_PIXEL_SIZE.y, 1.0 - TEXTURE_PIXEL_SIZE.y);
	COLOR = texture(TEXTURE, uv);
}