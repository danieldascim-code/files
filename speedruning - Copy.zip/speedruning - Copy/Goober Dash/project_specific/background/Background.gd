extends CanvasLayer

export  var _level: NodePath
onready var level: = get_node(_level) as Level

export  var _game: NodePath
onready var game: = get_node_or_null(_game) as WPGame

export  var parallax_speed: = Vector2(0.5, 0.1)

onready var gradient_texture_rect: TextureRect = $Background / Gradient
onready var gradient_texture: GradientTexture2D = gradient_texture_rect.texture
onready var gradient: Gradient = gradient_texture.gradient
onready var background_horizon_layer: = $Background / BackgroundHorizon as TextureRect
onready var background_top_layer: = $Background / AnchorTop as TextureRect
onready var base_background: = $Background as Control
onready var tiling_background: = $Background / TilingTexture as TextureRect

onready var gradient_doesnt_scroll_texture_rect: = $Background / GradientFullScreen as TextureRect
onready var gradient_doesnt_scroll_texture: GradientTexture2D = gradient_doesnt_scroll_texture_rect.texture
onready var gradient_doesnt_scroll: Gradient = gradient_doesnt_scroll_texture.gradient

export  var test_bottom: = 0.0
export  var test_top: = 0.0
export  var test_theme: Resource

export  var horizon_texture_scale: = 1.0
export  var horizon_parallax_speed: = Vector2.ONE

export  var anchor_top_texture_scale: = 1.0
export  var anchor_top_parallax_speed: = Vector2.ONE
export  var anchor_top_horizontal_scroll: = 1.0
var anchor_top_horizontal_scroll_timer: = 0.0

export  var tiling_texture_scale: = 1.0
export  var tiling_parallax_speed: = Vector2.ONE
export  var tiling_texture_tint: = Color.white

func _ready():
	if level:
		level.connect("theme_changed", self, "on_theme_changed")
		apply_theme(level.level_theme)
	if game:
		game.connect("game_over", self, "on_game_over")

func on_game_over(winner_id: int):
	if not game.wp_game_data.is_time_trial:
		var tween: = create_tween()
		tween.tween_interval(1.0)
		tween.tween_property(tiling_background, "modulate", Color.transparent, 1.0)
		tween.play()

func on_theme_changed(t: BaseTheme):
	apply_theme(t)

func apply_theme(t: BaseTheme):
	
	
	if t == null:
		return
	if t.background_gradient_texture:
		gradient_texture_rect.texture = t.background_gradient_texture
	else:
		gradient_texture.gradient = t.background_gradient
		gradient_texture_rect.texture = gradient_texture
	
	if t.background_gradient_texture:
		gradient_doesnt_scroll_texture_rect.texture = t.background_gradient_texture
	else:
		gradient_doesnt_scroll_texture.gradient = t.background_gradient
		gradient_doesnt_scroll_texture_rect.texture = gradient_texture
		
	if t.horizon_texture:
		background_horizon_layer.texture = t.horizon_texture
	if t.tiling_bg_texture:
		tiling_background.texture = t.tiling_bg_texture
	if t.clouds_texture:
		background_top_layer.texture = t.clouds_texture

func _process(delta):
	var aabb_bottom: = 0.0
	var aabb_top: = 0.0
	var gradient_top: = 0.0
	var gradient_bottom: = 0.0
	
	if Engine.editor_hint:
		aabb_bottom = test_bottom
		aabb_top = test_top
		apply_theme(test_theme)
	else:
		var canvas_xform: = get_viewport().canvas_transform
		var inverse_xform: = canvas_xform.affine_inverse()
		var canvas_position: Vector2 = inverse_xform.origin
		var canvas_scale: = canvas_xform.get_scale()
		
		var viewport_rect: = base_background.get_viewport_rect()
		var visible_rect_global: Rect2 = inverse_xform.xform(viewport_rect)
	
		
		aabb_bottom = level.aabb.end.y
		aabb_top = min(aabb_bottom - 1500.0, level.aabb.position.y)
		gradient_top = min(aabb_top, visible_rect_global.position.y)
		
		gradient_bottom = max(aabb_bottom, visible_rect_global.position.y)
	
	_process_horizon(delta, aabb_bottom, aabb_top, delta)
	_process_gradient(delta, gradient_bottom, gradient_top)

func _process_horizon(_delta: float, bottom: float, top: float, delta: float):
	var viewport: = get_viewport()
	var visible_rect: = viewport.get_visible_rect()
	var canvas_xform: = viewport.canvas_transform
	var inverse_xform: = canvas_xform.affine_inverse()
	var canvas_position: Vector2 = inverse_xform.origin
	var canvas_scale: = canvas_xform.get_scale()
	var inverse_canvas_scale: = inverse_xform.get_scale()
	
	var visible_rect_world: Rect2 = inverse_xform.xform(visible_rect)
	
	
	
	var uv_offset: = Vector2(1.0, 0.0) * horizon_parallax_speed * canvas_position * canvas_scale / background_horizon_layer.texture.get_size()
	
	background_horizon_layer.material.set_shader_param("uv_offset", uv_offset)
	
	var uv_scale: = inverse_canvas_scale / horizon_texture_scale
	background_horizon_layer.material.set_shader_param("uv_scale", uv_scale)
	
	
	var horizon_height: = background_horizon_layer.texture.get_height() / uv_scale.y
	background_horizon_layer.rect_scale = Vector2.ONE
	var bottom_viewport_space: Vector2 = viewport.canvas_transform.xform(Vector2(0.0, bottom))
	
	var rect_y: = bottom_viewport_space.y - horizon_height * 0.75
	background_horizon_layer.rect_position = Vector2(0.0, rect_y)
	
	var rect_size_y: = max(0.0, visible_rect.size.y - rect_y)
	background_horizon_layer.rect_size = Vector2(visible_rect.size.x, rect_size_y)
	
	
	
	
	
	var top_uv_scale: = inverse_canvas_scale / anchor_top_texture_scale
	background_top_layer.material.set_shader_param("uv_scale", top_uv_scale)
	
	var background_top_height: = background_top_layer.texture.get_height() / top_uv_scale.y
	background_top_layer.rect_scale = Vector2.ONE
	
	
	
	var top_viewport_space: Vector2 = viewport.canvas_transform.xform(Vector2(0.0, top))
	background_top_layer.rect_size = Vector2(visible_rect.size.x, max(background_top_height, top_viewport_space.y))
	background_top_layer.rect_position = Vector2(0.0, top_viewport_space.y - background_top_layer.rect_size.y)
	
	
	
	var top_uv_offset: = Vector2(1.0, 0.0) * anchor_top_parallax_speed * canvas_position * canvas_scale / background_top_layer.texture.get_size()
	
	var top_texture_offset: = max(0.0, background_top_layer.rect_size.y - background_top_height)
	top_uv_offset.y = - top_texture_offset / background_top_layer.texture.get_size().y
	
	anchor_top_horizontal_scroll_timer += delta
	top_uv_offset.x += (anchor_top_horizontal_scroll * anchor_top_horizontal_scroll_timer) / background_top_layer.texture.get_width()
	background_top_layer.material.set_shader_param("uv_offset", top_uv_offset)
	
	
	
	tiling_background.rect_scale = Vector2.ONE
	tiling_background.rect_size = visible_rect.size
	tiling_background.rect_position = Vector2.ZERO

	tiling_background.material.set_shader_param("uv_offset", tiling_parallax_speed * canvas_position * canvas_scale / tiling_background.texture.get_size())
	tiling_background.material.set_shader_param("uv_scale", inverse_canvas_scale / tiling_texture_scale)
	tiling_background.self_modulate = tiling_texture_tint

func _process_gradient(delta: float, bottom: float, top: float):
	var canvas_xform: = get_viewport().canvas_transform
	var bottom_canvas_space: Vector2 = canvas_xform.xform(Vector2(0.0, bottom))
	var top_canvas_space: Vector2 = canvas_xform.xform(Vector2(0.0, top))
	
	gradient_texture_rect.rect_position = Vector2(0.0, top_canvas_space.y)
	gradient_texture_rect.rect_size.y = abs(bottom_canvas_space.y - top_canvas_space.y)
