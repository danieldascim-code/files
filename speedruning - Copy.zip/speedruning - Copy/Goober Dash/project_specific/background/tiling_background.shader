shader_type canvas_item;
render_mode blend_add;

uniform vec2 uv_offset;
uniform vec2 uv_scale = vec2(1.0, 1.0);

void fragment() {
	vec2 uv = uv_scale * (UV + uv_offset);
	COLOR = texture(TEXTURE, uv);
}