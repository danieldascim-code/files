extends CanvasLayer
class_name UICosmeticCardDialog

signal card_unlocked()

export  var _coin_cost_label: NodePath
onready var coin_cost_label: Label = get_node(_coin_cost_label)

export  var _coin_cost_label2: NodePath
onready var coin_cost_label2: Label = get_node(_coin_cost_label2)

export  var _coin_cost_label2_container: NodePath
onready var coin_cost_label2_container: Control = get_node(_coin_cost_label2_container)

export  var _xp_gain_label: NodePath
onready var xp_gain_label: Label = get_node(_xp_gain_label)

export  var _cosmetic_card: NodePath
onready var cosmetic_card: CosmeticCard = get_node(_cosmetic_card)

export  var _equip_button: NodePath
onready var equip_button: BaseButton = get_node(_equip_button)

export  var _unlock_container: NodePath
onready var unlock_container: Control = get_node(_unlock_container)

export  var _unlock_button: NodePath
onready var unlock_button: GoodButton = get_node(_unlock_button)

export  var _unlock_label: NodePath
onready var unlock_label: Label = get_node(_unlock_label)

export  var _emote_holder_parent: NodePath
onready var emote_holder_parent: Control = get_node(_emote_holder_parent)

export  var _emote_container: NodePath
onready var emote_container: Control = get_node(_emote_container)

export  var _emote_equip_show: NodePath
onready var emote_equip_show: GoodTweener = get_node(_emote_equip_show)

export  var _emote_equip_hide: NodePath
onready var emote_equip_hide: GoodTweener = get_node(_emote_equip_hide)

export  var _equip_show: NodePath
onready var equip_show: GoodTweener = get_node(_equip_show)

export  var _equip_hide: NodePath
onready var equip_hide: GoodTweener = get_node(_equip_hide)

export  var _description: NodePath
onready var description: CosmeticCard_Description = get_node(_description)

export  var _back_button: NodePath
onready var back_button: GoodButton = get_node(_back_button)

onready var dialog: UIDialog = $UIDialog

var showing_cosmetic_id: String = ""
var emote_slots: = []
var is_showing_emote_slots: = false
var is_showing: = false

func _ready() -> void :
	emote_container.visible = false
	Moonlight.storage.observe("player.profile.emotes", self, "on_emotes_changed")

func on_player_card_data_changed(diff: Moonlight_StorageDiff):
	_render_data()

func show_cosmetic(cosmetic_id: String):
	showing_cosmetic_id = cosmetic_id
	var player_card_key: = "player.profile.cards." + showing_cosmetic_id
	Moonlight.storage.observe(player_card_key, self, "on_player_card_data_changed")
	_render_data()

func _render_data():
	var cosmetic_id: = showing_cosmetic_id
	var player_card_key: = "player.profile.cards." + cosmetic_id
	var cosmetic_data: = CosmeticsCollection.lookup_cosmetic_id(cosmetic_id)
	if not cosmetic_data.empty():
		var player_card_data: Dictionary = Moonlight.storage.storage_get("player.profile.cards." + cosmetic_id, {})
		cosmetic_card.show_cosmetic(cosmetic_id, player_card_data)
		description.show_cosmetic_data(cosmetic_data)
		var cosmetic_name: String = cosmetic_data.get("name", "")
		var rarity: String = cosmetic_data.get("rarity", "common")
		var type: String = cosmetic_data.get("type", "")
		var unlocked: bool = player_card_data.get("unlocked", false)
		var cosmetic_level = int(cosmetic_data.get("level", 0))
		var player_level: int = Moonlight.storage.storage_get("player.profile.level", 0)
		var coin_cost: = CosmeticsCollection.coin_cost_for_item_level(cosmetic_level)
		var xp_gain: = CosmeticsCollection.xp_gain_for_item_level(cosmetic_level)
		var quantity: int = int(player_card_data.get("quantity", 0))
		var denominator: int = CosmeticsCollection.card_cost_for_item_level(cosmetic_level, rarity)
		var can_unlock: bool = quantity >= denominator
		var can_collect: bool = player_level >= cosmetic_level
		
		if not is_showing:
			if type == "emote":
				pass
			else:
				equip_button.connect("pressed", self, "equip_cosmetic", [cosmetic_id])
		if not is_showing:
			unlock_button.connect("pressed", self, "unlock_cosmetic", [cosmetic_id, coin_cost])
		equip_button.disabled = not unlocked
		equip_button.visible = can_unlock or unlocked
		unlock_container.visible = not unlocked
		coin_cost_label.text = str(coin_cost)
		coin_cost_label2.text = "Cost: " + str(coin_cost)
		coin_cost_label2_container.visible = not can_unlock
		xp_gain_label.text = "Earn: +" + str(xp_gain)
		unlock_button.visible = can_unlock
		
		if unlock_button.visible:
			unlock_button.focusable.grab_focus_on_visible = true
		elif equip_button.visible:
			equip_button.focusable.grab_focus_on_visible = true
		else:
			back_button.focusable.grab_focus_on_visible = true
		
		if can_unlock:
			unlock_label.text = "UNLOCK NOW!"
		elif not can_collect:
			unlock_label.text = "REACH LEVEL %d to COLLECT!" % [cosmetic_level]
		elif quantity < denominator:
			unlock_label.text = "COLLECT %d MORE TO UNLOCK" % [denominator - quantity]
		else:
			unlock_label.text = "UNLOCK NOW!"
		
		if type == "emote" and unlocked:
			if not is_showing:
				instant_show_emote_slots()
				render_emote_slots(cosmetic_id)
			else:
				animate_in_emote_slots()
				render_emote_slots(cosmetic_id)
	
		is_showing = true

func instant_show_emote_slots():
	equip_hide.set_to_first_final_value()
	emote_equip_show.set_to_first_final_value()
	emote_container.visible = true
	

func animate_in_emote_slots():
	equip_hide.play()
	emote_equip_show.play()
	emote_container.visible = true

func render_emote_slots(cosmetic_id: String):
	if emote_slots.empty():
		var emote_holder_index: = 0
		for i in emote_holder_parent.get_child_count():
			var child = emote_holder_parent.get_child(i)
			var emote_holder: CosmeticCardDialog_EmoteHolder = child as CosmeticCardDialog_EmoteHolder
			if emote_holder:
				emote_holder.plus_label.visible = true
				emote_slots.append(emote_holder)
				emote_holder.connect("pressed", self, "on_emote_holder_pressed", [emote_holder_index, cosmetic_id])
				emote_holder_index += 1
	var emotes: Array = Moonlight.storage.storage_get("player.profile.emotes", [])
	update_emote_slots(emotes)

func on_emote_holder_pressed(emote_holder_index: int, cosmetic_id: String):
	var emotes: Array = Moonlight.storage.storage_get("player.profile.emotes", []).duplicate()
	assert (emote_holder_index >= 0)
	assert (emote_holder_index < 4)
	if emotes.size() <= emote_holder_index:
		emotes.resize(emote_holder_index + 1)
		for i in emotes.size():
			if emotes[i] == null:
				emotes[i] = ""
	
	var current_emote: String = emotes[emote_holder_index]
	if current_emote == cosmetic_id:
		
		emotes[emote_holder_index] = ""
	else:
		var already_equipped_at_index: = emotes.find(showing_cosmetic_id)
		if already_equipped_at_index >= 0:
			
			emotes[already_equipped_at_index] = current_emote
			emotes[emote_holder_index] = cosmetic_id
		else:
			emotes[emote_holder_index] = cosmetic_id
	yield(Moonlight.call_rpc("equip_emote", {"emote_ids": emotes}), "completed")
	
	

func on_emotes_changed(diff: Moonlight_StorageDiff):
	var emotes: Array = diff.value
	update_emote_slots(emotes)

func update_emote_slots(emotes: Array):
	if not emote_slots.empty():
		assert (emote_slots.size() >= emotes.size())
		var should_show_empty: = true
		for emote_id in emotes:
			if emote_id == showing_cosmetic_id:
				
				should_show_empty = false
		
		for i in emote_slots.size():
			var emote_slot: CosmeticCardDialog_EmoteHolder = emote_slots[i]
			var emote_id: String = ""
			if i < emotes.size():
				emote_id = emotes[i]
			
			if not emote_id.empty():
				emote_slot.show_emote(emote_id)
				emote_slot.visible = true
			elif should_show_empty:
				should_show_empty = false
				emote_slot.show_emote("")
				emote_slot.visible = true
			else:
				emote_slot.visible = false

func equip_cosmetic(cosmetic_id: String):
	var cosmetic_data: Dictionary = CosmeticsCollection.lookup_cosmetic_id(cosmetic_id)
	var cosmetic_ids: Dictionary = Moonlight.storage.storage_get("player.profile.skin", {}).duplicate(true)
	var cosmetic_type: String = cosmetic_data["type"]
	cosmetic_ids[cosmetic_type] = cosmetic_id
	var payload: = {
		"cosmetic_ids": cosmetic_ids.values()
	}
	var result: = yield(Moonlight.call_rpc("set_skin", payload), "completed") as Dictionary
	dialog.animate_out()
	return result

func unlock_cosmetic(cosmetic_id: String, coin_cost: int):
	var current_coin_balance: int = Moonlight.storage.storage_get("wallet.coins", 0)
	if current_coin_balance >= coin_cost:
		var result: Dictionary = yield(Moonlight.call_rpc("unlock_cosmetic", {"cosmetic_id": cosmetic_id}), "completed")
		if not result.has("error"):
			emit_signal("card_unlocked")
	else:
		var popup: = GoodResourceLoader.load_resource(GoodSceneRegistry.notification_dialog_scene).instance() as UINotifyDialog
		popup.text = "Play more rounds or head to the shop to collect more coins!"
		get_tree().current_scene.add_child(popup)
		popup.dialog.dialog_title_label.text = "NOT ENOUGH COINS"
		popup.dialog.animate_in()

		
