extends Reference
class_name CosmeticsCollection


const color_default_id: = "color_default"
const color_yellow_id: = "color_yellow"

const prebaked_cosmetic_data: = {
	"color_default": {
		"type": "color", 
		"level": 1, 
		"name": "Blue", 
		"spine": "body/Normal", 
		"color": "blue"
	}, 
	"color_yellow": {
		"type": "color", 
		"level": 1, 
		"name": "Yellow", 
		"spine": "body/Normal", 
		"color": "yellow"
	}
}

static func lookup_cosmetic_id(cosmetic_id: String) -> Dictionary:
	if cosmetic_id.empty():
		printerr("[CosmeticsCollection] lookup_cosmetic_id() cannot query empty cosmetic_id")
		return {}
	var cosmetic_data = Moonlight.storage.storage_get("cosmetics." + cosmetic_id, {}) as Dictionary
	if cosmetic_data.empty():
		if prebaked_cosmetic_data.has(cosmetic_id):
			cosmetic_data = prebaked_cosmetic_data[cosmetic_id] as Dictionary
	
	if cosmetic_data.empty():
		printerr("[CosmeticsCollection] lookup_cosmetic_id() %s not found" % [cosmetic_id])
		return {}
	return cosmetic_data

static func filter_cosmetics_type(cosmetic_type: String) -> Dictionary:
	var filtered_cosmetics: = {}
	if Moonlight.storage.data.has("cosmetics"):
		var cosmetics: Dictionary = Moonlight.storage.data["cosmetics"]
		for cosmetic_id in cosmetics:
			var cosmetic_data: = cosmetics[cosmetic_id] as Dictionary
			if cosmetic_data["type"] == cosmetic_type:
				filtered_cosmetics[cosmetic_id] = cosmetic_data
	
	return filtered_cosmetics

static func count_unlockable_cards_of_type(p_cosmetic_type: String) -> int:
	var unlockable_cards: int = 0
	var player_cards: Dictionary = Moonlight.storage.storage_get("player.profile.cards", {})
	for cosmetic_id in player_cards:
		var player_card_data: Dictionary = player_cards[cosmetic_id]
		var is_unlocked: bool = player_card_data.get("unlocked", false)
		if is_unlocked:
			continue
		var cosmetic_data: Dictionary = lookup_cosmetic_id(cosmetic_id)
		if cosmetic_data.empty():
			continue
		var cosmetic_type: String = cosmetic_data.get("type", "")
		if cosmetic_type != p_cosmetic_type:
			continue
		var cosmetic_level: int = cosmetic_data.get("level", 0)
		var cosmetic_rarity: String = cosmetic_data.get("rarity", "")
		var cards_needed: int = card_cost_for_item_level(cosmetic_level, cosmetic_rarity)
		var cards_held: int = player_card_data.get("quantity", 0)
		if cards_held >= cards_needed:
			unlockable_cards += 1
	
	return unlockable_cards

static func count_unlockable_cards() -> int:
	var unlockable_cards: int = 0
	var player_cards: Dictionary = Moonlight.storage.storage_get("player.profile.cards", {})
	for cosmetic_id in player_cards:
		var player_card_data: Dictionary = player_cards[cosmetic_id]
		var is_unlocked: bool = player_card_data.get("unlocked", false)
		if is_unlocked:
			continue
		var cosmetic_data: Dictionary = lookup_cosmetic_id(cosmetic_id)
		if cosmetic_data.empty():
			continue
		var cosmetic_level: int = cosmetic_data.get("level", 0)
		var cosmetic_rarity: String = cosmetic_data.get("rarity", "")
		var cards_needed: int = card_cost_for_item_level(cosmetic_level, cosmetic_rarity)
		var cards_held: int = player_card_data.get("quantity", 0)
		if cards_held >= cards_needed:
			unlockable_cards += 1
	
	return unlockable_cards

static func card_cost_for_item_level(item_level: int, rarity: String) -> int:
	if item_level > 12:
		item_level = 12
	var progression_data: Dictionary = Moonlight.storage.storage_get("metadata.progression", {})
	var l: = int(progression_data.get("card_cost_per_item_level", 1))
	var b: = int(progression_data.get("card_cost_per_item_level_base", 1))
	if rarity == "rare":
		b = int(progression_data.get("card_cost_per_item_level_rare", 1))
	elif rarity == "epic":
		b = int(progression_data.get("card_cost_per_item_level_epic", 1))
	return b + ((item_level - 1) * l)

static func coin_cost_for_item_level(item_level: int) -> int:
	var progression_data: Dictionary = Moonlight.storage.storage_get("metadata.progression", {})
	var b: float = progression_data.get("coin_cost_per_item_level_base", 1.0)
	var e: float = progression_data.get("coin_cost_per_item_level_exponent", 1.0)
	var m: int = int(progression_data.get("coin_cost_per_item_level_max", 9999999999.0))
	return int(min(_exponential(item_level - 1, b, e), m))

static func xp_gain_for_item_level(item_level: int) -> int:
	var progression_data: Dictionary = Moonlight.storage.storage_get("metadata.progression", {})
	var m: int = int(progression_data.get("xp_gain_per_item_level_13", 9999999999.0))
	if item_level >= 13:
		return m
	var b: float = progression_data.get("xp_gain_per_item_level_base", 1.0)
	var e: float = progression_data.get("xp_gain_per_item_level_exponent", 1.0)
	
	return int(_exponential(item_level - 1, b, e))

static func xp_cost_for_level(level: int) -> int:
	if level <= 1:
		return 0
	var progression_data: Dictionary = Moonlight.storage.storage_get("metadata.progression", {})
	if level == 12:
		var twelve: int = int(progression_data.get("xp_cost_per_level_12", 9999999999.0))
		return twelve
	
	var b: float = progression_data.get("xp_cost_per_level_base", 1.0)
	var e: float = progression_data.get("xp_cost_per_level_exponent", 1.0)
	var m: int = int(progression_data.get("xp_cost_per_level_max", 9999999999.0))
	return int(min(_exponential(level - 2, b, e), m))

static func _exponential(level: int, base: float, exponent: float) -> int:
	var l: = float(level)
	var b: = float(base)
	var result: = b * pow(exponent, l)
	return int(round(result))


static func level_for_total_xp(total_xp: int) -> int:
	if total_xp <= 0:
		return 1
	var level: = 0
	var next_level_xp_sum: = xp_cost_for_level(level + 1)
	while total_xp >= next_level_xp_sum:
		level += 1
		next_level_xp_sum += xp_cost_for_level(level + 1)
	return level

static func compute_xp_total_cost(level: int) -> int:
	var xp_sum: = 0
	for i in level + 1:
		xp_sum += xp_cost_for_level(i)
	return xp_sum

static func gems_cost_to_speed_up_wheel(seconds: int) -> int:
	if seconds > 0:
		var seconds_to_gems: float = Moonlight.storage.storage_get("metadata.progression.star_wheel_timer_seconds_to_gems", 1.0)
		return int(ceil(seconds / seconds_to_gems))
	else:
		return 0
