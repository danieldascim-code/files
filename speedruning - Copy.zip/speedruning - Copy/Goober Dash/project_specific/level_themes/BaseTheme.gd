extends Resource
class_name BaseTheme

export  var ui_accent_color: = Color.white
export  var ui_accent_color_dark: = Color.white
export  var terrain_color_1: = Color.white
export  var terrain_color_1_thickness: = 0.025
export  var terrain_color_2: = Color.white
export  var terrain_color_2_thickness: = 0.025
export  var terrain_color_3: = Color.white
export  var terrain_color_3_thickness: = 0.025
export  var rear_grass_color: = Color("00aa49")
export  var front_grass_color: = Color("80ec72")
export  var jump_zone_tint: = Color.white
export  var jump_zone_outline_tint: = Color.white
export (float, 0.0, 16.0, 1.0) var terrain_corner_radius: = 10.0
export (float, 0.0, 16.0, 1.0) var terrain_corner_radius_inner: = 8.0

export  var background_gradient: Gradient
export  var background_gradient_texture: Texture

export  var terrain_texture: Texture
export  var horizon_texture: Texture
export  var clouds_texture: Texture
export  var tiling_bg_texture: Texture
export  var doodad_texture_1: Texture
export  var doodad_texture_2: Texture
export  var doodad_texture_3: Texture
export  var doodad_texture_4: Texture
export  var doodad_texture_5: Texture
export  var ornament_texture_arrow: Texture
export  var ornament_texture_alert: Texture

export  var background_block: Texture
export  var background_block2: Texture
export  var background_block3: Texture

export  var checkpoint_texture: Texture
export  var floor_texture: Texture
export  var finish_line_texture: Texture
export  var fullscreen_particles: PackedScene


export  var saw_100: Texture
export  var saw_200: Texture
export  var saw_300: Texture

export  var gravity_field: Texture
export  var gravity_field_tint: = Color.white
export  var gravity_field_outline_tint: = Color.white

export  var disappearing_block: Texture
export  var disappearing_block_tint: = Color.white
export  var disappearing_outline_tint: = Color.white

export  var pit_texture: Texture

export  var laser_color: = Color.red
export  var start_pattern_tint: = Color(1.0, 1.0, 1.0, 67.0 / 255.0)
export  var start_outline_tint: = Color.white


