shader_type canvas_item;
uniform sampler2D gradient;
/*
void vertex() {
	VERTEX = (EXTRA_MATRIX * (WORLD_MATRIX * vec4(VERTEX, 0.0, 1.0))).xy;
	//vec4 c = COLOR;
	//COLOR = vec4(1.0, 1.0, 1.0, 1.0);
}
*/
void fragment() {
	
	vec4 vertex_color = COLOR;
	
	// COLOR = vertex_color;
	
	vec4 sample = texture(TEXTURE, UV);
	vec2 grad_uv = vec2(sample.r, vertex_color.y);
	vec3 grad = texture(gradient, grad_uv).rgb;
	

	COLOR.rgb = mix(sample.rgb, grad.rgb, 1.0 - vertex_color.r);
	COLOR.a = sample.a;
}