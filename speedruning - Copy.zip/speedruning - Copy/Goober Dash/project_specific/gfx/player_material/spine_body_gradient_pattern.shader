shader_type canvas_item;

uniform float pattern_color;
uniform sampler2D pattern;
uniform sampler2D gradient;

void fragment() {
	vec4 sample = texture(TEXTURE, UV);
	float bw = sample.r;
	vec2 pat_uv = vec2(2.0 * UV.x, 2.0 * UV.y);
	vec3 pat_rgb = texture(pattern, pat_uv).rgb;
	float pat = max(pattern_color, 1.0 - pat_rgb.r);
	float grad_x = bw;
	// does go into border when pattern color is > 0
	grad_x = bw * pat;
	// doesnt go into border when pattern color is > 0
	grad_x = min(bw,  pat);
	
	
	vec3 grad = texture(gradient, vec2(grad_x, 0.5)).rgb;
	COLOR.rgb = grad;
	COLOR.a = sample.a;
}