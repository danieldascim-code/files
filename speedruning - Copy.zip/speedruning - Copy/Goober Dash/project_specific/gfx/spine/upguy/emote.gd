extends SpineSprite
class_name EmoteSpineSprite

var _hide_after_complete: = false
var _popout_entry: SpineTrackEntry = null

func _enter_tree() -> void :
	pass


func show_loop_animation(anim: String) -> void :
	_reset_everything()
	var state: = get_animation_state()
	state.set_animation(anim, true)
	
func show_static_frame(anim: String) -> void :
	_reset_everything()
	var state: = get_animation_state()
	state.set_animation("preview/" + anim, false)
	state.apply(get_skeleton())

func show_single_animation_and_hide(anim: String) -> void :
	_hide_after_complete = true
	self.visible = true
	_reset_everything()
	var state: = get_animation_state()
	state.set_animation("popin", 0.0, false)
	state.add_animation(anim, 0.0, false)
	_popout_entry = state.add_animation("popout", 0.0, false)


func _ready():
	self.connect("animation_event", self, "on_spine_animation_event")
	self.connect("animation_completed", self, "_on_animation_completed")
	self.preview_skin = ""
	self.preview_animation = ""
	_reset_everything()

func _on_animation_completed(spine_sprite: Object, animation_state: SpineAnimationState, track_entry: Object):
	if _hide_after_complete and _popout_entry == track_entry:
		self.visible = false
	_hide_after_complete = false

func on_spine_animation_event(spine_sprite: SpineSprite, animation_state: SpineAnimationState, track_entry: SpineTrackEntry, event: SpineEvent):
	pass

func _reset_everything():
	get_skeleton().set_skin_by_name("normal")
	get_skeleton().set_to_setup_pose()
	var state: = get_animation_state()
	state.clear_tracks()
