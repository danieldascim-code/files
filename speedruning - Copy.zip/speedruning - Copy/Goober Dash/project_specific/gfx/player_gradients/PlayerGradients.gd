extends Node
class_name PlayerGradients

const gradients: = [
	"res://project_specific/gfx/player_gradients/beige.tres", 
	"res://project_specific/gfx/player_gradients/blue-pink.tres", 
	"res://project_specific/gfx/player_gradients/blue.tres", 
	"res://project_specific/gfx/player_gradients/blue_dark.tres", 
	"res://project_specific/gfx/player_gradients/brown.tres", 
	"res://project_specific/gfx/player_gradients/cyan-pink.tres", 
	"res://project_specific/gfx/player_gradients/cyan-yellow.tres", 
	"res://project_specific/gfx/player_gradients/green.tres", 
	"res://project_specific/gfx/player_gradients/indigo-green.tres", 
	"res://project_specific/gfx/player_gradients/lemon-lime.tres", 
	"res://project_specific/gfx/player_gradients/lime-lemon.tres", 
	"res://project_specific/gfx/player_gradients/navy-peach.tres", 
	"res://project_specific/gfx/player_gradients/notint.tres", 
	"res://project_specific/gfx/player_gradients/orange.tres", 
	"res://project_specific/gfx/player_gradients/pink-cyan.tres", 
	"res://project_specific/gfx/player_gradients/pink.tres", 
	"res://project_specific/gfx/player_gradients/purple-gold.tres", 
	"res://project_specific/gfx/player_gradients/purple-teal.tres", 
	"res://project_specific/gfx/player_gradients/purple.tres", 
	"res://project_specific/gfx/player_gradients/red-yellow.tres", 
	"res://project_specific/gfx/player_gradients/red.tres", 
	"res://project_specific/gfx/player_gradients/rose.tres", 
	"res://project_specific/gfx/player_gradients/white.tres", 
	"res://project_specific/gfx/player_gradients/yellow-pink.tres", 
	"res://project_specific/gfx/player_gradients/yellow.tres", 
]

static func index_of_gradient_name(gradient_name: String) -> int:
	var full_path: = "res://project_specific/gfx/player_gradients/" + gradient_name + ".tres"
	return gradients.find(full_path)

static func uv_index_of_gradient_name(gradient_name: String) -> float:
	var index: = index_of_gradient_name(gradient_name)
	var half_pixel: = 0.5 / gradients.size()
	return (float(index) / gradients.size()) + half_pixel

static func load_gradient(gradient_name: String) -> Gradient:
	var full_path: = "res://project_specific/gfx/player_gradients/" + gradient_name + ".tres"
	return load(full_path) as Gradient
