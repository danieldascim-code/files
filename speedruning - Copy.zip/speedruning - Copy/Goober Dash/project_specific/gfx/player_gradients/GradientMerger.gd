tool 
extends EditorScript
const output_file: = "res://project_specific/gfx/player_gradients/player_gradients.png"


func _run() -> void :
	var merged_image: = Image.new()
	var texture_width: = 32
	var texture_height: = PlayerGradients.gradients.size()
	merged_image.create(texture_width, texture_height, false, Image.FORMAT_RGBA8)
	
	for i in PlayerGradients.gradients.size():
		var gradient: Gradient = load(PlayerGradients.gradients[i])
		var gradient_texture: = GradientTexture.new()
		gradient_texture.width = 32
		
		gradient_texture.gradient = gradient
		var gradient_data: = gradient_texture.get_data()
		merged_image.blit_rect(gradient_data, Rect2(Vector2.ZERO, gradient_data.get_size()), Vector2(0.0, i))
	merged_image.save_png(output_file)
	get_editor_interface().get_resource_filesystem().scan()
