extends Node

func _ready():
	randomize()
\
func get_game_node(this: Node, path: String) -> Node:
	var game: = find_game(this)
	if game:
		var n: = game.get_node(path) as Node
		if not n:
			printerr("[Utilities] get_game_node() couldn\'t find node from with path: " + path + " from: " + str(this))
		return n
	printerr("[Utilities] get_game_node() couldn\'t find game")
	return null

func find_game(this: Node, assert_if_not_found = true) -> NetworkGame:
	var game: NetworkGame = null
	var node: Node = this
	while node and not game:
		if node is NetworkGame:
			game = node
		elif node is NetworkRenderer:
			var renderer: = node as NetworkRenderer
			game = renderer.get_network_game()
		elif node is GameUI:
			var game_ui: = node as GameUI
			game = game_ui.game
			if not game:
				game = game_ui.get_node(game_ui._game)
		
		node = node.get_parent()
	
	if not game and assert_if_not_found:
		printerr("[Utilities] find_game() couldn\'t find game from node: " + str(this))
		assert (false)
	return game



static func format_int_nice(v: int) -> String:
	var s: = String(abs(v))
	var o: = ""
	if v < 0:
		o += "-"
	var i: = - ((len(s) + 2) %3 - 2)
	for c in s:
		if i > 0 and i % 3 == 0:
			o += ","
		o += c
		i += 1
	return o


static func fill(v, count: int) -> Array:
	var arr: = []
	arr.resize(count)
	for i in count:
		arr[i] = v
	return arr



func enum_reverse(dict, value):
	for k in dict.keys():
		if dict[k] == value:
			return k
	return null

static func int_to_rank(i: int) -> String:
	return DateTimeUtils.number_to_ordinal_string(i)
