extends BaseScreenTransitions

onready var transition_1: ScreenTransition1 = $ScreenTransition1

func _ready():
	transition_1.visible = false
	transition_1.connect("animation_finished", self, "emit_signal", ["transition_completed"])

func fade_in():
	yield(transition_1._animate_in(), "completed")
	
func fade_out():
	yield(transition_1._animate_out(), "completed")
