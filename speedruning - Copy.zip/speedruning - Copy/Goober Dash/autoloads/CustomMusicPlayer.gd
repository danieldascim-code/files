extends Node

enum MusicType{Intro, Menu, Lobby, Game, None}

onready var intro_stream: = $IntroClip as AudioStreamPlayer
onready var main_stream: = $MainMenuMusic as AudioStreamPlayer
onready var lobby_stream: = $LobbyMusic as AudioStreamPlayer
onready var game_stream: = $GameMusic as AudioStreamPlayer

onready var playing_music_type: int = MusicType.Intro

func get_current_playing_music() -> int:
	if intro_stream.playing:
		return MusicType.Intro
	if main_stream.playing:
		return MusicType.Menu
	if lobby_stream.playing:
		return MusicType.Lobby
	if game_stream.playing:
		return MusicType.Game
	
	return MusicType.None

func get_stream_for_type(i: int) -> AudioStreamPlayer:
	match i:
		MusicType.Intro:
			return main_stream
		MusicType.Menu:
			return main_stream
		MusicType.Lobby:
			return game_stream
		MusicType.Game:
			return game_stream
	
	return main_stream

func _ready() -> void :
	intro_stream.connect("finished", self, "on_intro_finished")

func play_music_type(i: int):
	
	var p: = get_stream_for_type(i)
	if p.playing:
		return
	stop_music();
	p.play()
	
	if (p == game_stream):
		AudioServer.set_bus_effect_enabled(AudioServer.get_bus_index("music"), 0, false)
	elif (p == main_stream):
		AudioServer.set_bus_effect_enabled(AudioServer.get_bus_index("music"), 0, true)

func play_music():
	play_music_type(MusicType.Intro)

func stop_music():
	if intro_stream.playing:
		intro_stream.stop()
	if main_stream.playing:
		main_stream.stop()
	if lobby_stream.playing:
		lobby_stream.stop()
	if game_stream.playing:
		game_stream.stop()

func on_intro_finished():
	play_music_type(MusicType.Menu)
	
func is_playing():
	return intro_stream.playing or main_stream.playing or lobby_stream.playing or game_stream.is_playing
