extends Node

export (Texture) var crosshair_texture: Texture
export (int) var crosshair_size: int
var cached_crosshair_texture: Texture = null

export (Texture) var dot_texture: Texture
export (int) var dot_size: int
var cached_dot_texture: Texture = null

export (Texture) var pointer_texture: Texture
export (int) var pointer_size: int
var cached_pointer_texture: Texture = null
export (Vector2) var pointer_hotspot: Vector2

export (Texture) var text_texture: Texture
export (int) var text_cursor_size: int
var cached_text_texture: Texture = null

var cached_empty_texture: Texture = null

enum CursorType{Default, Pointer, Crosshair, Dot, None}
var cursor_type: = - 1 setget set_cursor_type

var hide_cursor: = false setget set_hide_cursor

const verbose: = true
onready var disabled: = true

func set_hide_cursor(b: bool):
	if hide_cursor != b:
		hide_cursor = b
		_refresh_cursor()

func set_cursor_type(c: int):
	if cursor_type != c:
		cursor_type = c
		_refresh_cursor()

func _refresh_cursor():
	if OS.has_feature("server"):
		return
	if disabled:
		return
	
	if hide_cursor:
		_apply_cursor(cached_empty_texture, - 1, cached_empty_texture)
		if verbose:
			print("[CustomCursor] hide cursor")
	else:
		match cursor_type:
			CursorType.Crosshair:
				if verbose:
					print("[CustomCursor] apply crosshair")
				cached_crosshair_texture = _apply_cursor(crosshair_texture, crosshair_size, cached_crosshair_texture)
			CursorType.Dot:
				if verbose:
					print("[CustomCursor] apply dot")
				cached_dot_texture = _apply_cursor(dot_texture, dot_size, cached_dot_texture)
			CursorType.Pointer:
				if verbose:
					print("[CustomCursor] apply pointer")
				cached_pointer_texture = _apply_cursor(pointer_texture, pointer_size, cached_pointer_texture, Input.CURSOR_ARROW, pointer_hotspot)
			CursorType.Default:
				Input.set_custom_mouse_cursor(null, Input.CURSOR_ARROW, Vector2.ZERO)
			CursorType.None:
				if verbose:
					print("[CustomCursor] apply none")
				_apply_cursor(cached_empty_texture, - 1, cached_empty_texture)
			_:
				printerr("[CustomCursor] unknown cursor type: ", cursor_type)

func _ready():
	if OS.has_feature("server"):
		return
	if disabled:
		return
	
	var empty_image: = Image.new()
	empty_image.create(2, 2, false, Image.FORMAT_RGBA8)
	cached_empty_texture = ImageTexture.new()
	cached_empty_texture.create_from_image(empty_image)
	
	cached_text_texture = _apply_cursor(text_texture, text_cursor_size, self.cached_text_texture, Input.CURSOR_IBEAM)
	
	
	self.cursor_type = CursorType.Default

func _apply_cursor(t: Texture, max_size: int, cached_tex: Texture, cursor_shape: int = Input.CURSOR_ARROW, hotspot: = Vector2(0.5, 0.5)) -> Texture:
	if OS.has_feature("server"):
		return null
	if disabled:
		return null
	if cached_tex == null:
		if max_size > 0:
			var cursor_image: = t.get_data()
			scale_image(cursor_image, max_size)
			cached_tex = ImageTexture.new()
			cached_tex.create_from_image(cursor_image)
		else:
			cached_tex = t
	var hotspot_size: = hotspot * cached_tex.get_size()
	hotspot_size.x = round(hotspot_size.x)
	hotspot_size.y = round(hotspot_size.y)
	Input.set_custom_mouse_cursor(cached_tex, cursor_shape, hotspot_size)
	return cached_tex

func scale_image(image: Image, max_size: int):
	var s: = float(max_size) / max(image.get_width(), image.get_height())
	image.resize(image.get_width() * s, image.get_height() * s, Image.INTERPOLATE_LANCZOS)

func _input(event: InputEvent) -> void :
	if OS.has_feature("server"):
		return
	if not JoypadInputBlocker.should_block_input():
		if event is InputEventJoypadButton:
			self.hide_cursor = true
		elif event is InputEventMouse or event is InputEventKey:
			self.hide_cursor = false
