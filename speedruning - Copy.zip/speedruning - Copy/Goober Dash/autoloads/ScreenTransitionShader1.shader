shader_type canvas_item;
render_mode unshaded;

varying vec2 world_position;

uniform vec4 color : hint_color = vec4(1.0);
uniform float circle_radius = 1000.0; 
uniform float angle = -0.0;

uniform float target_in = 0.8;
uniform float target_out = 0.2;
uniform float spread = 0.08;


void vertex(){
	world_position = (vec4(VERTEX, 0.0, 1.0)).xy;
}

void fragment() {
	
	float M_PI = 3.14159265f;
	mat2 rotation = mat2( vec2(cos(M_PI/4.0), sin(M_PI/4.0)), vec2(-sin(M_PI/4.0), cos(M_PI/4.0)));
	
	// Spacing
	vec2 pos = mod(rotation * (world_position.xy + vec2(0.0, TIME*200.0)), vec2(100.0)) - vec2(50.0);
	float dist_squared = dot(pos, pos);
	float delta = fwidth(dist_squared);
	
	

	float sep_target_in = target_in - (0.2f*UV.x);
	float sep_target_out = target_out - (0.2f*UV.x);
	float sep_spread = spread;
	
	float sep_mult = smoothstep(sep_target_in+sep_spread, sep_target_in-sep_spread, UV.y);
	float sep_circle_radius = circle_radius*sep_mult;
	
	float sep_mult_out = smoothstep(sep_target_out-sep_spread, sep_target_out+sep_spread, UV.y);
	sep_circle_radius = sep_circle_radius*sep_mult_out*8.0;
	
	COLOR = mix(vec4(color.rgb, 1.0), vec4(color.rgb, 0.0), smoothstep(sep_circle_radius-delta, sep_circle_radius, dist_squared));
	
	
	
    
	
	
	
}