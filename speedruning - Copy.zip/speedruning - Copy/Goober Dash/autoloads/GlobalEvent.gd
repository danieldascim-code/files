extends Node

signal UI_GAMEPLAY_PLAYER_DIED(position, velocity, color, spineSprite, wearing_hat)
signal UI_GAMEPLAY_PLAYER_CHEER(position, velocity, color)

signal UI_EMOTE_BUTTON_PRESSED(emote)
signal UI_POST_EMOTE_FOR_PLAYER_OBJECTID(emote, player_object_id)
signal UI_POST_CHEERS_FOR_PLAYER_OBJECTID(player_object_id, sent_player_name)

signal UI_TIMETRIAL_NEXT_REQUESTED()

signal UI_REWARDED_AD_AVAILABLE()
signal UI_REWARDED_AD_UNAVAILABLE()
