extends VBoxContainer
class_name DiscordParticipantList

export  var participant_row_scene: PackedScene
var rows: Array

export  var _hsep: NodePath
onready var hsep: Control = get_node(_hsep)

export  var _more_panel: NodePath
onready var more_panel: Control = get_node(_more_panel)

export  var _rows_parent: NodePath
onready var rows_parent: Control = get_node(_rows_parent)

var discord_user_id: String
const show_self: = false

const max_members_to_show: = 8
const fake_members_to_show: = 0

func _ready() -> void :
	if not Moonlight.discord_api.is_in_discord():
		hide()
		return
	discord_user_id = Moonlight.session.vars.get("DiscordUserId", "")
	if discord_user_id.empty():
		printerr("[DiscordParticipantList] couldnt find discord_user_id")
		return
	
	DiscordAuth.connect("discord_participants_changed", self, "on_discord_participants_changed")
	DiscordAuth.get_discord_participants()

func on_discord_participants_changed(participants: Array):
	render_participants(participants)
	pass

func render_participants(participants: Array):
	
	delete_rows()
	for p in participants:
		var participant_data: Dictionary = p
		var participant_user_id: String = participant_data.get("id", "")
		if participant_user_id == discord_user_id and not show_self:
			continue
		var participant_name: String = participant_data.get("nickname", "")
		if participant_name.empty():
			participant_name = participant_data.get("global_name", "")
		var participant_avatar_id: String = participant_data.get("avatar", "")
		var participant_avatar_url: String = "https://cdn.discordapp.com/embed/avatars/0.png"
		
		
		if not participant_avatar_id.empty():
			participant_avatar_url = "https://cdn.discordapp.com/avatars/%s/%s.png?size=256" % [participant_user_id, participant_avatar_id]
		
		var participant_row: PlayerNameRow = participant_row_scene.instance()
		rows_parent.add_child(participant_row)
		rows.append(participant_row)
		participant_row.render_player_name(participant_name)
		participant_row.render_discord_avatar(participant_avatar_url)
		if rows.size() >= max_members_to_show:
			break
	
	for i in fake_members_to_show:
		var participant_row: PlayerNameRow = participant_row_scene.instance()
		rows_parent.add_child(participant_row)
		rows.append(participant_row)
		participant_row.render_player_name("Other Player %s" % [i])
		participant_row.render_discord_avatar("https://cdn.discordapp.com/embed/avatars/0.png")
		if rows.size() >= max_members_to_show:
			break
	
	more_panel.visible = (participants.size() - 1 + fake_members_to_show) > max_members_to_show
	if more_panel.visible:
		rows_parent.move_child(more_panel, rows_parent.get_child_count() - 1)
	hsep.visible = rows.size() > 0 and false

func delete_rows():
	for r in rows:
		r.queue_free()
	rows.clear()
