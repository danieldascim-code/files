tool 
extends Control
class_name UIDialog

signal animated_out
signal animated_in
signal closed
signal background_button_pressed
signal close_button_pressed

onready var tween: = $Tween as Tween
onready var background: = $BackgroundButton / Background as Control
onready var background_button: = $BackgroundButton as BaseButton
onready var panel_anchor_point: = $Panel / GoodAnchorPoint as GoodAnchorPoint
onready var close_button: = $Panel / CloseButton as GoodButton
onready var panel: = $Panel as Control
onready var dialog_root: = $Panel / DialogRoot as Control
onready var scene_root: = get_parent() as CanvasLayer
export  var dialog_title: String = "" setget set_dialog_title
export  var _dialog_title_label: NodePath
onready var dialog_title_label: Label = get_node(_dialog_title_label)
onready var background_override_color: ColorRect = $BackgroundButton / Background / BackgroundOverride
onready var background_default: Control = $BackgroundButton / Background / BackgroundDefault

var is_showing: = false
export  var background_override: = false setget set_background_override
const animation_duration: = 0.25
const animate_out_duration: = 0.4
export  var show_on_ready: = true
export  var free_after_animate_out: = true
export  var enable_background_button: = true
export  var animate_in_offset: = Vector2(0, 0)
export  var close_button_grabs_focus_on_visible: = true
export  var enable_back_button_close: = true

enum AnimateDirection{
	Top, Bottom, Left, Right
}
export (AnimateDirection) var animate_in: = AnimateDirection.Top
export (AnimateDirection) var animate_out: = AnimateDirection.Top

var original_focus: Control
onready var focus_global = get_node_or_null("/root/FocusGlobal")

func set_background_override(b: bool):
	background_override = b
	if is_inside_tree():
		background_default.visible = not b
		background_override_color.visible = b

func _ready() -> void :
	set_dialog_title(dialog_title)
	if Engine.editor_hint:
		return
	
	if close_button_grabs_focus_on_visible:
		close_button.focusable.grab_focus_on_visible = true
	
	close_button.connect("pressed", self, "on_close_button_pressed")
	background_button.connect("pressed", self, "on_background_button_pressed")
	panel_anchor_point.offset = offscreen_position(animate_in)
	self.visible = false
	background.modulate = Color.transparent
	background.visible = true
	background_button.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if show_on_ready:
		animate_in()
	set_background_override(background_override)

func set_dialog_title(s: String):
	dialog_title = s
	if dialog_title_label:
		dialog_title_label.text = dialog_title

func _input(event: InputEvent) -> void :
	if is_showing:
		if event.is_action_pressed("ui_cancel"):
			
			accept_event()
			
			if enable_back_button_close:
				emit_signal("closed")
				animate_out()
		if event.is_action_pressed("ui_start"):
			accept_event()

func _unhandled_input(event):
	if is_showing:
		accept_event()

func run_do_tween(b: bool):
	if is_inside_tree() and b:
		animate_in()
		yield(get_tree().create_timer(3.0), "timeout")
		animate_out()

func offscreen_position(animation_direction: int) -> Vector2:
	var v: = Vector2.ZERO
	match animation_direction:
		AnimateDirection.Top:
			return Vector2(0.0, - rect_size.y)
		AnimateDirection.Bottom:
			return Vector2(0.0, rect_size.y)
		AnimateDirection.Left:
			return Vector2( - rect_size.x, 0.0)
		AnimateDirection.Right:
			return Vector2(rect_size.x, 0.0)
	return v

func animate_toggle():
	if is_showing:
		animate_out()
	else:
		animate_in()

func animate_in():
	if not is_showing:
		if focus_global != null:
			original_focus = focus_global.focused_control
		propagate_call("__focusable_dialog_opening")
		
		if not visible:
			panel_anchor_point.offset = offscreen_position(animate_in)
		visible = false
		is_showing = true
		tween.remove_all()
		tween.interpolate_callback(self, 0.0, "set_visible", true)
		tween.interpolate_property(background, "modulate", Color.transparent, Color.white, animation_duration, Tween.TRANS_EXPO, Tween.EASE_OUT)
		tween.interpolate_property(panel_anchor_point, "offset", null, animate_in_offset, animation_duration, Tween.TRANS_QUINT, Tween.EASE_OUT)
		tween.start()
		
		background_button.mouse_filter = Control.MOUSE_FILTER_STOP
		emit_signal("animated_in")

func animate_out():
	if is_showing:
		is_showing = false
		if focus_global != null:
			focus_global.focus_on_control(original_focus)
		propagate_call("__focusable_dialog_closing")
		tween.remove_all()
		background_button.mouse_filter = MOUSE_FILTER_IGNORE
		tween.interpolate_property(background, "modulate", null, Color.transparent, animation_duration, Tween.TRANS_EXPO, Tween.EASE_OUT)
		tween.interpolate_property(panel_anchor_point, "offset", null, offscreen_position(animate_out), animation_duration, Tween.TRANS_QUINT, Tween.EASE_OUT)
		if free_after_animate_out:
			tween.interpolate_callback(scene_root, animate_out_duration, "queue_free")
		else:
			tween.interpolate_callback(self, animate_out_duration, "set_visible", false)
		background_button.mouse_filter = Control.MOUSE_FILTER_IGNORE
		tween.start()
		emit_signal("animated_out")

func on_close_button_pressed():
	animate_out()
	emit_signal("close_button_pressed")
	emit_signal("closed")

func on_background_button_pressed():
	if enable_background_button:
		animate_out()
		emit_signal("background_button_pressed")
		emit_signal("closed")
