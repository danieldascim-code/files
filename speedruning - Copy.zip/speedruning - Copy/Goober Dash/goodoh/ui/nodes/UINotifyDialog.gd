extends CanvasLayer
class_name UINotifyDialog

signal confirmed

export (String) var text = "" setget set_label_text
export (NodePath) var _label
export (NodePath) var _ok_button

onready var label: = get_node(_label) as Label
onready var ok_button: = get_node(_ok_button) as Button

onready var dialog: = get_node("UIDialog") as UIDialog

func _ready():
	ok_button.connect("pressed", self, "ok_clicked")
	dialog.connect("closed", self, "dialog_closed")
	label.text = text
	
	
	
	
func set_label_text(label_text: String):
	text = label_text
	if (label):
		label.text = label_text

func ok_clicked():
	emit_signal("confirmed")
	dialog.animate_out()

func dialog_closed():
	emit_signal("confirmed")
