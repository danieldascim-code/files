extends CanvasLayer
class_name UISpinnerDialog

export  var text: = "" setget set_label_text

export  var _label: NodePath
onready var label: Label = get_node(_label)

export  var _button: NodePath
onready var button: Button = get_node(_button)

export  var _spinner: NodePath
onready var spinner: Control = get_node(_spinner)

onready var dialog: UIDialog = $UIDialog



func _ready():
	button.connect("pressed", self, "on_button_pressed")
	dialog.enable_background_button = false
	button.visible = false
	spinner.visible = true
	set_label_text(text)

func set_label_text(label_text: String):
	text = label_text
	if label:
		label.text = label_text
		label.visible = not text.empty()




func error(err_msg: String):
	dialog.enable_background_button = true
	button.visible = true
	spinner.visible = false
	set_label_text(err_msg)

func finished():
	spinner.visible = false

func on_button_pressed():
	dialog.animate_out()
