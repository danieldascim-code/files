extends CanvasLayer







export (NodePath) var _crazygames_button
onready var crazygames_button: = get_node(_crazygames_button) as Button

func _ready():
	$UIDialog / Panel / DialogRoot / LoginDialogForm / VBoxContainer / AppleSigninCustom / MoonlightAppleSigninScript.connect("error", self, "apple_signin_error")
	crazygames_button.visible = false
	
	if get_tree() != null and get_tree().root.has_node("CrazyAuth"):
		var crazyAuth = get_tree().root.get_node("CrazyAuth")
		var onCrazy = crazyAuth.is_user_accounts_available()
		if (onCrazy):
			crazygames_button.visible = true
	

func apple_signin_success():
	$UIDialog.animate_out()
	Moonlight.socket.close()
	get_tree().change_scene(GoodSceneRegistry.connecting_scene)

func apple_signin_error(text: String):
	$UIDialog.animate_out()
	
	var confirm_dialog_scene: = GoodResourceLoader.load_resource(GoodSceneRegistry.notification_dialog_scene) as PackedScene
	var popup: = confirm_dialog_scene.instance() as UINotifyDialog
	popup.text = text
	get_tree().current_scene.add_child(popup)
	popup.dialog.animate_in()





