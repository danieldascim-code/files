extends CanvasLayer
class_name UISigninCrazygamesDialog


export (NodePath) var _spinner
onready var spinner: = get_node(_spinner) as Control

export (NodePath) var _text_label
onready var text_label: = get_node(_text_label) as SDFLabel


func _test():
	pass


func _ready():
	spinner.visible = true
	text_label.visible = false
	
	
	var result: Dictionary = yield(CrazyAuth.async_get_user(), "get_user_response")
	if (result.has("error")):
		_get_user_response_no_user()
	else:
		_get_user_response_success(result)


func _get_user_response_no_user():
	spinner.visible = true
	text_label.visible = false
	
	
	var result: Dictionary = yield(CrazyAuth.async_show_auth_prompt(), "show_auth_prompt_response")
	if (result.has("error")):
		_auth_prompt_error(result["error"])
	else:
		_auth_prompt_success(result)
	
func _auth_prompt_error(errString: String):
	spinner.visible = false
	text_label.visible = true
	text_label.text = errString
	
func _auth_prompt_success(result: Dictionary):
	var user_dict: Dictionary = result["user"]
	spinner.visible = false
	text_label.visible = false
	_get_user_token(user_dict)
	
func _get_user_response_success(result: Dictionary):
	var user_dict: Dictionary = result["user"]
	spinner.visible = false
	text_label.visible = false
	_get_user_token(user_dict)

func _get_user_token(user_dict: Dictionary):
	spinner.visible = true
	
	
	var result: Dictionary = yield(CrazyAuth.async_get_user_token(), "get_user_token_response")
	if (result.has("error")):
		_user_token_error(result["error"])
	else:
		_user_token_success(result)

func _user_token_error(errString: String):
	spinner.visible = false
	text_label.visible = true
	text_label.text = errString
	
func _user_token_success(result: Dictionary):
	print("crazy _user_token_success")
	var token: String = result["token"]
	spinner.visible = true
	
	var payload: = {"token": token}
	var rpc_result: Dictionary = yield(Moonlight.call_rpc("crazygames_auth", payload), "completed")
	spinner.visible = false
	if rpc_result.has("error"):
		printerr("rpc err")
	else:
		var customcrazyid: String = rpc_result.get("customcrazyid", "")
		print(customcrazyid)
		Moonlight.auth.log_out()
		Moonlight.saved_data.set_crazygames_device_id_credentials(customcrazyid)
		get_tree().change_scene(GoodSceneRegistry.connecting_scene)

