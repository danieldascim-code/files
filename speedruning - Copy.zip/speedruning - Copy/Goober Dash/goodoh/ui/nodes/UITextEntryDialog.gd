extends CanvasLayer
class_name UITextEntryDialog

signal text_entered(text)

export (NodePath) var _line_edit
onready var line_edit: = get_node(_line_edit) as LineEdit

export (NodePath) var _title_label
onready var title_label: = get_node(_title_label) as Label

export (NodePath) var _ok_button
onready var ok_button: = get_node(_ok_button) as BaseButton

export  var close_on_submission: = false

onready var dialog: = $UIDialog as UIDialog

var title_text: = ""
var placeholder_text: = ""

func _ready():
	if not title_text.empty():
		title_label.text = title_text
	if not placeholder_text.empty():
		line_edit.placeholder_text = placeholder_text
	line_edit.connect("text_entered", self, "on_line_edit_text_entered")
	ok_button.connect("pressed", self, "on_button_pressed")

func _finish():
	emit_signal("text_entered", line_edit.text)
	if close_on_submission:
		dialog.animate_out()

func on_line_edit_text_entered(t: String):
	_finish()

func on_button_pressed():
	_finish()
