extends CanvasLayer
class_name UIConfirmationDialog

signal confirmed
signal cancelled
signal confirm_or_cancel(b)

export (String) var text = ""
export (NodePath) var _label
export (NodePath) var _yes_button
export (NodePath) var _no_button

onready var label: = get_node(_label) as Label
onready var yes_button: = get_node(_yes_button) as GoodButton
onready var no_button: = get_node(_no_button) as GoodButton

onready var dialog: UIDialog = get_node("UIDialog")

export  var default_focus_to_yes_button: = true

func _ready():
	yes_button.connect("pressed", self, "yes_clicked")
	no_button.connect("pressed", self, "no_clicked")
	dialog.connect("closed", self, "dialog_closed")
	label.text = text
	if default_focus_to_yes_button:
		yes_button.focusable.grab_focus_on_visible = true
	else:
		no_button.focusable.grab_focus_on_visible = true

func set_label_text(label_text: String):
	text = label_text
	if (label):
		label.text = label_text

func yes_clicked():
	emit_signal("confirmed")
	emit_signal("confirm_or_cancel", true)
	dialog.animate_out()

func dialog_closed():
	emit_signal("cancelled")
	emit_signal("confirm_or_cancel", false)
	
func no_clicked():
	emit_signal("cancelled")
	emit_signal("confirm_or_cancel", false)
	dialog.animate_out()
