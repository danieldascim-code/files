extends Node
class_name OpenConfiguredStoreURLOnPress

onready var parent_button: = get_parent() as BaseButton

func _ready():
	parent_button.connect("pressed", self, "on_button_pressed")

func on_button_pressed():
	var url: = ""
	if OS.has_feature("Android"):
		url = "market://details?id=" + GoodConfig.get_config_value("android_package_id")
	elif OS.has_feature("iOS"):
		url = GoodConfig.get_config_value("apple_appstore_url")
	elif OS.has_feature("steam"):
		url = GoodConfig.get_config_value("steam_app_url")
	if not url.empty():
		print("[OpenConfiguredStoreURLOnPress] on_button_pressed() opening url " + url)
		OS.shell_open(url)
	else:
		printerr("[OpenConfiguredStoreURLOnPress] on_button_pressed() couldnt find url for updater")
