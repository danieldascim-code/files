extends Node
class_name SavedSlider

onready var parent_slider: = get_parent() as Slider
export  var default_value: = 1.0
export  var setting_key: = ""

func _ready():
	if not setting_key.empty():
		var initial_value: = SavedSettings.get_value(setting_key, default_value) as float
		parent_slider.value = initial_value
	parent_slider.connect("value_changed", self, "on_slider_value_changed")
	call_deferred("on_slider_value_changed", parent_slider.value)

func on_slider_value_changed(slider_value: float):
	if not setting_key.empty():
		SavedSettings.set_value(setting_key, slider_value)
