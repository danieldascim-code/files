extends Node
class_name PlaySoundOnSignal

onready var parent_node: = get_parent() as Node
export (AudioStream) var audio_stream: AudioStream
export (String) var signal_name: = ""
export  var volume_db: float = 0.0
export  var pitch_scale: float = 1.0
export  var bus: String = "Master"
export  var restart_if_playing: = false
export  var delay: = 0.0

var sound_stream: AudioStreamPlayer

func _ready():
	sound_stream = AudioStreamPlayer.new()
	if (parent_node.has_signal(signal_name)):
		parent_node.connect(signal_name, self, "on_button_pressed")
	
	sound_stream.stream = audio_stream
	add_child(sound_stream)

func on_button_pressed():
	if not sound_stream.is_playing() or restart_if_playing:
		if delay > 0.0:
			yield(get_tree().create_timer(delay), "timeout")
		sound_stream.volume_db = volume_db
		sound_stream.pitch_scale = pitch_scale
		sound_stream.bus = bus
		sound_stream.play(0.0)

