tool 
extends Node
class_name GoodAnchorPoint

export  var offset: = Vector2.ZERO setget set_offset
export  var anchor_to_parent: = Vector2.ZERO setget set_anchor_to_parent
export  var pivot: = Vector2.ZERO setget set_pivot
onready var target: = get_parent() as Control
onready var grandparent: = target.get_parent_control() as Control

const do_stop_recursion: = false
var stop_recursion: = false
const epsilon_sq: = 1e-05

var will_deferred: = false
var is_deferred: = false

func set_offset(v: Vector2):
	offset = v
	if is_inside_tree():
		apply_anchor_point()

func set_anchor_to_parent(v: Vector2):
	anchor_to_parent = v
	if is_inside_tree():
		apply_anchor_point()

func set_pivot(v: Vector2):
	pivot = v
	if is_inside_tree():
		apply_anchor_point()

func apply_anchor_point():
	if will_deferred and not is_deferred:
		is_deferred = true
		call_deferred("_apply_anchor_point")
	else:
		_apply_anchor_point()

func _apply_anchor_point():
	is_deferred = false
	if target:
		var position_in_parent: = Vector2.ZERO
		if grandparent:
			position_in_parent = Vector2(grandparent.rect_size.x * anchor_to_parent.x, grandparent.rect_size.y * anchor_to_parent.y)
		
		var new_pivot_offset: = target.rect_size * pivot
		var new_rect_position: = position_in_parent + offset - new_pivot_offset
		
		var pivot_changed: = target.rect_pivot_offset.distance_squared_to(new_pivot_offset) > epsilon_sq
		var position_changed: = target.rect_position.distance_squared_to(new_rect_position) > epsilon_sq
		
		if pivot_changed or position_changed:
			target.rect_pivot_offset = new_pivot_offset
			target.rect_position = new_rect_position

func _process(delta):
	if Engine.editor_hint:
		target = get_parent() as Control
		will_deferred = false
		if target != null:
			grandparent = target.get_parent_control()
		else:
			grandparent = null
		apply_anchor_point()

func _ready():
	set_process(Engine.editor_hint)
	if not Engine.editor_hint:
		will_deferred = should_defer()
		if will_deferred:
			call_deferred("_setup")
		else:
			_setup()
		
		apply_anchor_point()

func _setup():
	if grandparent:
		grandparent.connect("resized", self, "apply_anchor_point")
	if target:
		target.connect("resized", self, "apply_anchor_point")

func should_defer() -> bool:
	
	
	if not target:
		return false
	return target.anchor_left != 0.0 or target.anchor_right != 0.0 or target.anchor_bottom != 0.0 or target.anchor_top != 0.0
