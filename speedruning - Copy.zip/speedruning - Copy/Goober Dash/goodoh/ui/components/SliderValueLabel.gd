extends Node

class_name SliderValueLabel

export (NodePath) var _slider
onready var slider: = get_node(_slider) as Range

export  var label_format: = "%s"
onready var parent_label: = get_parent() as Label

func _ready() -> void :
	slider.connect("value_changed", self, "on_slider_changed")
	on_slider_changed(slider.value)

func on_slider_changed(value: float):
	parent_label.text = label_format % [slider.value]
