extends Node
class_name AnimatedEllipsisLabel

onready var parent_label: = get_parent() as Label

const rate: = 0.5
var timer: = 0.0

export  var format: = "%s"
var last_number: = - 1

func _process(delta: float):
	timer += delta
	if timer >= rate:
		timer = 0.0
		var num_ellipsis: = (last_number + 1) %6
		parent_label.text = format % [ellipses_string(num_ellipsis)]
		last_number = num_ellipsis

func ellipses_string(num_ellipsis: int) -> String:
	var ellipsis_string: = ""
	if num_ellipsis > 3:
		num_ellipsis = 2 - (num_ellipsis - 4)
		
	for i in num_ellipsis:
		ellipsis_string += "."
	return ellipsis_string
