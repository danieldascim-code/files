extends Node
class_name RevealPasswordButton

onready var parent_button: = get_parent()

export  var _line_edit: NodePath
onready var line_edit: LineEdit = get_node(_line_edit)

export  var _icon: NodePath
onready var icon: TextureRect = get_node(_icon)

export  var password_hidden_icon: Texture
export  var password_revealed_icon: Texture

func _ready() -> void :
	parent_button.connect("pressed", self, "on_button_pressed")
	_refresh_icon()

func on_button_pressed():
	line_edit.secret = not line_edit.secret
	_refresh_icon()

func _refresh_icon():
	icon.texture = password_hidden_icon if line_edit.secret else password_revealed_icon
