extends Node
class_name CallMethodOnVisible
onready var parent_control: = get_parent() as Control

export (NodePath) var _target
onready var target: = get_node(_target)

export  var visible: = false
export  var method_name: = ""

func _ready():
	parent_control.connect("visibility_changed", self, "on_visibility_changed")

func on_visibility_changed():
	if visible == parent_control.is_visible_in_tree():
		target.call(method_name)
