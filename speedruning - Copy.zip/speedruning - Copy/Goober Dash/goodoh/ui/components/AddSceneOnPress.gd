extends Node

class_name AddSceneOnPress

export (PackedScene) var scene: PackedScene
onready var parent_button: = get_parent() as Button

export (NodePath) var _add_node_to: NodePath
onready var add_node_to: = get_node_or_null(_add_node_to)

func _ready():
	parent_button.connect("pressed", self, "on_button_pressed")

func on_button_pressed():
	var new_scene: = scene.instance()
	if add_node_to != null:
		add_node_to.add_child(new_scene)
	else:
		get_tree().current_scene.add_child(new_scene)
