tool 
extends Node
class_name ControlZIndex

onready var parent_control: = get_parent() as Control
export  var z_index: = 0 setget set_zindex

func _ready():
	set_zindex(z_index)

func set_zindex(z: int):
	z_index = z
	if is_inside_tree():
		var rid: = parent_control.get_canvas_item()
		VisualServer.canvas_item_set_z_index(rid, z_index)
