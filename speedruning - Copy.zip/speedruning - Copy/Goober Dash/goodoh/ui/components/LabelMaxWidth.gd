tool 
extends Node
class_name LabelMaxWidth

func scale_label_to_max_width():
	var parent_label: = get_parent() as Label
	if parent_label:
		
		var label_width: = max(parent_label.get_minimum_size().x, 1.0)
		var max_width: = parent_label.get_parent_control().rect_size.x
		var label_scale: float = clamp(max_width / label_width, 0.0, 1.0)
		
		parent_label.rect_scale = Vector2(label_scale, label_scale)
		

func _process(delta):
	scale_label_to_max_width()
