extends BaseListener
class_name AddSceneOnSignal

export (PackedScene) var scene: PackedScene
onready var parent_button: = get_parent() as Button

export (NodePath) var _add_node_to: NodePath
onready var add_node_to: = get_node_or_null(_add_node_to)

func do():
	var new_scene: = scene.instance()
	if add_node_to != null:
		add_node_to.add_child(new_scene)
	else:
		get_tree().current_scene.add_child(new_scene)
