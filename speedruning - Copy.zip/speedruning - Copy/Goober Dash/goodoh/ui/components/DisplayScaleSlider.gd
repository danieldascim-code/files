extends SavedSlider

class_name DisplayScaleSlider

var default_display_width
var default_display_height
var default_stretch_mode
var default_strech_aspect

func _ready() -> void :
	default_display_width = ProjectSettings.get_setting("display/window/size/width")
	default_display_height = ProjectSettings.get_setting("display/window/size/height")
	var project_settings_stretch_mode: = ProjectSettings.get_setting("display/window/stretch/mode") as String
	match project_settings_stretch_mode:
		"2d":
			default_stretch_mode = SceneTree.STRETCH_MODE_2D
		"viewport":
			default_stretch_mode = SceneTree.STRETCH_MODE_VIEWPORT
		"disabled":
			default_stretch_mode = SceneTree.STRETCH_MODE_DISABLED
		_:
			printerr("[DisplayScaleSlider] unknown stretch mode in project settings: " + project_settings_stretch_mode)
			
	var project_settings_stretch_aspect: = ProjectSettings.get_setting("display/window/stretch/aspect") as String
	match project_settings_stretch_aspect:
		"expand":
			default_strech_aspect = SceneTree.STRETCH_ASPECT_EXPAND
		"ignore":
			default_strech_aspect = SceneTree.STRETCH_ASPECT_IGNORE
		"keep":
			default_strech_aspect = SceneTree.STRETCH_ASPECT_KEEP
		"keep_height":
			default_strech_aspect = SceneTree.STRETCH_ASPECT_KEEP_HEIGHT
		"keep_width":
			default_strech_aspect = SceneTree.STRETCH_ASPECT_KEEP_WIDTH
		_:
			printerr("[DisplayScaleSlider] unknown stretch mode in project settings: " + project_settings_stretch_mode)
			
func on_slider_value_changed(slider_value: float):
	.on_slider_value_changed(slider_value)
	var ratio: = parent_slider.value
	var display_width: = int(default_display_width * ratio)
	var display_height: = int(default_display_height * ratio)
	get_tree().set_screen_stretch(default_stretch_mode, default_strech_aspect, Vector2(display_width, display_height))
