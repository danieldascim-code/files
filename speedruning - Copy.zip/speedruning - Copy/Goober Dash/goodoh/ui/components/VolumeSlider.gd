extends SavedSlider
class_name VolumeSlider

export  var bus: = "Master"
export  var min_value: = - 40.0
export  var max_value: = 0.0

func on_slider_value_changed(slider_value: float):
	set_volume(slider_value)
	.on_slider_value_changed(slider_value)

func set_volume(slider_value: float):
	var bus_index: = AudioServer.get_bus_index(bus)
	if bus_index != null:
		var volume_value = lerp(min_value, max_value, slider_value)
		
		var mute_it: = slider_value < 0.05
		
		AudioServer.set_bus_mute(bus_index, mute_it)
		AudioServer.set_bus_volume_db(bus_index, volume_value)
