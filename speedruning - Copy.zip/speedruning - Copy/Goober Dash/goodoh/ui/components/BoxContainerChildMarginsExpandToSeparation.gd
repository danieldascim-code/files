tool 
extends Node
class_name BoxContainerChildMarginsExpandToSeparation

export (NodePath) var _box_container
onready var box_container: = get_node(_box_container) as BoxContainer

onready var parent_control: = get_parent() as Control

var last_separation: = 0

func _process(delta):
	if Engine.editor_hint:
		box_container = get_node_or_null(_box_container)
		parent_control = get_parent()
	
	var separation: = box_container.get_constant("separation")
	if separation != last_separation:
		last_separation = separation
		parent_control.margin_left = int(separation * - 0.5)
		parent_control.margin_right = int(separation * 0.5)
