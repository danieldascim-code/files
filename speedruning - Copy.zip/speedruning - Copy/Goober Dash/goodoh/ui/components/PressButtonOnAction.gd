extends Node
class_name PressButtonOnAction

export  var action: = ""
onready var parent_button: = get_parent() as BaseButton

export  var use_unhandled_input: = true
export  var only_when_visible: = true
export  var exact_match: = true
export  var allow_echo: = false

func _unhandled_input(event: InputEvent) -> void :
	if use_unhandled_input:
		handle_event(event)

func _input(event: InputEvent) -> void :
	if not use_unhandled_input:
		handle_event(event)

func handle_event(event: InputEvent):
	if event.is_action_pressed(action, allow_echo, exact_match):
		if not only_when_visible or parent_button.is_visible_in_tree():
			get_tree().set_input_as_handled()
			parent_button.call_deferred("emit_signal", "pressed")
