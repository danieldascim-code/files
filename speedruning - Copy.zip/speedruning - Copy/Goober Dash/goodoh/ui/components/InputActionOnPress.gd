extends Node
class_name InputActionOnPress

onready var parent_button: = get_parent() as BaseButton
export  var action_name: = ""

func _ready():
	parent_button.connect("pressed", self, "on_button_pressed")
	parent_button.connect("button_down", self, "on_button_down")
	parent_button.connect("button_up", self, "on_button_up")

func on_button_pressed():
	pass

func on_button_down():
	var event: = InputEventAction.new()
	event.pressed = true
	event.action = action_name
	Input.parse_input_event(event)

func on_button_up():
	var event: = InputEventAction.new()
	event.pressed = false
	event.action = action_name
	Input.parse_input_event(event)
