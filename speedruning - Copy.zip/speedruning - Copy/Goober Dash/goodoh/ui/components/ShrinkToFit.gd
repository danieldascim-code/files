tool 
extends Node
class_name ShrinkToFit

onready var parent_container: = get_parent() as Container

func _process(delta: float) -> void :
	parent_container = get_parent() as Container
	if parent_container.rect_size.x > parent_container.rect_min_size.x or parent_container.rect_size.y > parent_container.rect_min_size.y:
		parent_container.rect_size = Vector2.ZERO
