extends Node
class_name PlaySoundOnFocus

onready var parent_control: = get_parent() as Control
export (AudioStream) var audio_stream: AudioStream
export  var volume_db: float = 0.0
export  var pitch_scale: float = 1.0
export  var bus: String = "Master"

var sound_stream: AudioStreamPlayer

func _ready():
	sound_stream = AudioStreamPlayer.new()
	parent_control.connect("focus_entered", self, "on_focus_entered")
	if (parent_control.has_signal("item_focused")):
		parent_control.connect("item_focused", self, "on_item_focused")
	sound_stream.stream = audio_stream
	add_child(sound_stream)

func on_item_focused(i: int):
	on_focus_entered()

func on_focus_entered():
	if not sound_stream.is_playing():
		sound_stream.volume_db = volume_db
		sound_stream.pitch_scale = pitch_scale
		sound_stream.bus = bus
		sound_stream.play()

