extends Node
class_name Focusable

onready var focus_global_autoload: = get_node("/root/FocusGlobal")
onready var parent_control: = get_parent() as Control
export  var grab_focus_on_ready: = false
export  var grab_focus_on_visible: = false
export  var restore_focus_on_delete: = false
export  var restore_focus_on_hide: = false
export  var grab_focus_on_click: = false
export  var always_enable_focus: = false



var focus_group: FocusGroup

export (NodePath) var _focus_dump: NodePath
onready var focus_dump: = get_node_or_null(_focus_dump) as Control

var has_been_focused: = false
var original_focus: Control
export  var force_disable_focus: = false setget set_force_disable_focus
const verbose: = false
const dump_focus_fallback: = false
var disabled_via_dialog_close: = false

func _exit_tree() -> void :
	if focus_group:
		focus_group.focusable_controls.erase(parent_control)
		
	if restore_focus_on_delete:
		restore_focus()
	else:
		if parent_control == FocusGlobal.focused_control:
			dump_focus()

func _ready() -> void :
	assert (parent_control)
	if parent_control is OptionButton:
		var parent_option_button: = parent_control as OptionButton
		var popup: = parent_option_button.get_popup()
		var popup_focusable = get_script().new()
		popup_focusable.restore_focus_on_hide = true
		popup_focusable.grab_focus_on_visible = true
		popup.add_child(popup_focusable)
	
	parent_control.connect("visibility_changed", self, "on_visibility_changed")
	focus_global_autoload.connect("focus_changed", self, "on_focus_changed")
	
	if grab_focus_on_click:
		if parent_control is BaseButton:
			parent_control.connect("pressed", self, "focus_me")
	
	var parent_focus_group: = find_parent("*FocusGroup")
	if parent_focus_group is FocusGroup:
		focus_group = parent_focus_group
	
	if focus_group:
		focus_group.focusable_controls.append(parent_control)
	
	if parent_control is LineEdit or parent_control is PopupMenu:
		always_enable_focus = true
	
	on_focus_changed()
	
	if grab_focus_on_ready:
		focus_me()

func on_focus_changed():
	if always_enable_focus or focus_global_autoload.is_focus_enabled():
		enable_focus()
	else:
		disable_focus()

func focus_group_check() -> bool:
	if focus_group == null:
		return true
	if focus_global_autoload.focused_control == null:
		return true
	return focus_group.focusable_controls.has(focus_global_autoload.focused_control)

func on_visibility_changed():
	if parent_control.is_visible_in_tree():
		if grab_focus_on_visible:
			if focus_group != null:
				focus_group.focused_control = parent_control
			if focus_group_check():
				if verbose:
					print("[Focusable] focus group pass %s from %s" % [parent_control.get_path(), focus_global_autoload.focused_control])
				focus_me()
			else:
				if verbose:
					print("[Focusable] focus group fail %s from %s" % [parent_control.get_path(), focus_global_autoload.focused_control])
					
	else:
		if restore_focus_on_hide:
			restore_focus()
		else:
			if parent_control == FocusGlobal.focused_control:
				dump_focus()

func restore_focus():
	var next_focus: = original_focus
	if focus_dump != null:
		next_focus = focus_dump
		
	if has_been_focused:
		if verbose:
			if parent_control:
				if is_instance_valid(next_focus):
					print("[Focusable] restore_focus() %s original %s" % [parent_control.get_path(), next_focus.name])
				else:
					printerr("[Focusable] restore_focus() %s original %s" % [parent_control.get_path(), "null"])
		focus_global_autoload.focus_on_control(next_focus)

func focus_me():
	set_original_focus(focus_global_autoload.focused_control)
	if verbose:
		if original_focus != null:
			print("[Focusable] focus_me() %s original %s" % [parent_control.get_path(), original_focus.name])
		else:
			print("[Focusable] focus_me() %s original %s" % [parent_control.get_path(), "null"])
	has_been_focused = true
	focus_global_autoload.focus_on_control(parent_control, always_enable_focus)

func enable_focus():
	
	
	
	if not force_disable_focus and not focus_enabled():
		parent_control.focus_mode = Control.FOCUS_ALL

func disable_focus():
	
	
	
	if always_enable_focus:
		return
	
	if focus_enabled():
		parent_control.focus_mode = Control.FOCUS_NONE

func focus_enabled():
	return parent_control.focus_mode == Control.FOCUS_ALL

func force_disable():
	self.force_disable_focus = true
	
func remove_force_disable():
	self.force_disable_focus = false

func set_force_disable_focus(f: bool):
	force_disable_focus = f
	if is_inside_tree():
		_refresh_focus_enabled()

func _refresh_focus_enabled():
	if force_disable_focus or disabled_via_dialog_close:
		if parent_control == FocusGlobal.focused_control:
			dump_focus()
		disable_focus()
	else:
		if focus_global_autoload.is_focus_enabled():
			enable_focus()


func dump_focus():
	var next_focus: Control
	next_focus = focus_dump
	if focus_dump is FocusGroup:
		next_focus = focus_dump.focused_control
		if verbose:
			print("[Focusable] dump_focus() to focus_group %s focused_control %s" % [focus_dump.get_path(), next_focus.get_path()])
	if dump_focus_fallback:
		if next_focus == null:
			next_focus = parent_control.find_next_valid_focus()
		if next_focus == null:
			next_focus = parent_control.find_prev_valid_focus()
	
	if verbose:
		if next_focus == null:
			printerr("[Focusable] dump_focus() %s -> to null" % [parent_control.get_path()])
		else:
			print("[Focusable] dump_focus() %s -> %s" % [parent_control.get_path(), next_focus])
	
	FocusGlobal.focus_on_control(next_focus)

func connect_to_delete_signal(c: Control):
	c.connect("tree_exited", self, "release_original_focus")

func disconnect_from_delete_signal(c: Control):
	c.disconnect("tree_exited", self, "release_original_focus")

func release_original_focus():
	set_original_focus(null)
	
func set_original_focus(c: Control):
	if original_focus != null:
		disconnect_from_delete_signal(original_focus)
	original_focus = c
	if original_focus != null:
		connect_to_delete_signal(original_focus)

func __focusable_dialog_closing():
	
	
	
	disabled_via_dialog_close = true
	_refresh_focus_enabled()

func __focusable_dialog_opening():
	disabled_via_dialog_close = false
	_refresh_focus_enabled()
