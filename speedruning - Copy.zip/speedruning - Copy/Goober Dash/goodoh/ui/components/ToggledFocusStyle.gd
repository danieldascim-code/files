extends Node

class_name ToggledFocusStyle

export (StyleBox) var selected_stylebox: StyleBox

onready var parent_button: = get_parent() as BaseButton

func _ready() -> void :
	parent_button.connect("toggled", self, "on_button_toggled")
	

func on_button_toggled(toggled: bool):
	if toggled:
		parent_button.add_stylebox_override("focus", selected_stylebox)
	else:
		parent_button.add_stylebox_override("focus", null)
