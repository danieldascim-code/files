extends Node
class_name WebReloadOnPress

onready var parent_button: = get_parent() as BaseButton

func _ready():
	parent_button.connect("pressed", self, "reload_webpage")

func reload_webpage():
	if OS.has_feature("web"):
		JavaScript.eval(\
\
		"\n\t\t\twindow.location.reload()\n\t\t")
