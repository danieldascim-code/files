tool 
extends Node
class_name MatchRectPosition

export  var _target: NodePath
onready var target: = get_node(_target) as Control
export  var offset: = Vector2.ZERO

onready var parent_control: = get_parent() as Control

func _ready():
	pass

func _process(delta):
	if target and parent_control:
		parent_control.rect_global_position = target.rect_global_position + offset
