extends Node

class_name HoverTint

export  var normal_color: = Color.white
export  var hover_color: = Color.white
export  var focus_color: = Color.white
export  var pressed_color: = Color.white
export  var disabled_color: = Color.white
export (NodePath) var _tint_target: NodePath
onready var tint_target: = get_node_or_null(_tint_target) as Control
export  var tint_children: = false

var is_hovered: = false
var is_focused: = false

onready var parent_control: = get_parent() as Control
onready var parent_button: = parent_control as BaseButton

export  var verbose: = false

func _ready():
	
	if _tint_target.is_empty():
		tint_target = get_parent() as Control
	assert (tint_target)
	assert (parent_control)
	parent_control.connect("mouse_entered", self, "on_mouse_entered")
	parent_control.connect("mouse_exited", self, "on_mouse_exited")
	parent_control.connect("focus_entered", self, "on_focus_entered")
	parent_control.connect("focus_exited", self, "on_focus_exited")
	if parent_button:
		parent_button.connect("button_down", self, "on_button_down")
		parent_button.connect("button_up", self, "on_button_up")
		parent_button.connect("pressed", self, "on_pressed")
		parent_button.connect("toggled", self, "on_toggled")
		parent_button.connect("disabled_changed", self, "on_disabled_changed")
	set_color()


func on_mouse_entered():
	if verbose:
		print("[HoverTint] on mouse enter")
	is_hovered = true
	set_color()
func on_mouse_exited():
	if verbose:
		print("[HoverTint] on mouse exit")
	is_hovered = false
	set_color()


func on_toggled(t: bool):
	if verbose:
		print("[HoverTint] on toggled ", parent_button.pressed)
	set_color()
func on_pressed():
	if verbose:
		print("[HoverTint] on pressed ", parent_button.pressed)
	set_color()
func on_button_down():
	if verbose:
		print("[HoverTint] on button down ", parent_button.pressed)
	set_color()
func on_button_up():
	
	yield(get_tree(), "idle_frame")
	if verbose:
		print("[HoverTint] on button up pressed ", parent_button.pressed)
	set_color()
	


func on_focus_entered():
	if verbose:
		print("[HoverTint] on focus enter")
	is_focused = true
	set_color()
func on_focus_exited():
	if verbose:
		print("[HoverTint] on focus exit")
	is_focused = false
	set_color()


func on_disabled_changed(disabled: bool):
	set_color()


func set_color():
	if parent_button and parent_button.disabled:
		if verbose:
			print("[HoverTint] using disabled color")
		set_color_(disabled_color)
	elif parent_button and parent_button.pressed:
		if verbose:
			print("[HoverTint] using pressed color")
		set_color_(pressed_color)
	elif is_hovered:
		if verbose:
			print("[HoverTint] using hover color")
		set_color_(hover_color)
	elif is_focused:
		if verbose:
			print("[HoverTint] using focus color")
		set_color_(focus_color)
	else:
		if verbose:
			print("[HoverTint] using normal color")
		set_color_(normal_color)

func set_color_(color: Color):
	if tint_children:
		tint_target.modulate = color
	else:
		tint_target.self_modulate = color
