extends Node

class_name ControllerSlider

onready var parent_slider: = get_parent() as Slider
const default_step_size: = 10.0

func _ready():
	parent_slider.connect("gui_input", self, "on_slider_gui_input")

func get_step_size():
	if parent_slider.step > 0:
		return parent_slider.step
	else:
		return (parent_slider.max_value - parent_slider.min_value) / default_step_size

func on_slider_gui_input(event: InputEvent):
	if event is InputEventAction:
		print("is action")
	if parent_slider is HSlider:
		if Input.is_action_pressed("player_left"):
			slide_down()
		elif Input.is_action_pressed("player_right"):
			slide_up()
	elif parent_slider is VSlider:
		if Input.is_action_pressed("player_down"):
			slide_down()
		elif Input.is_action_pressed("player_up"):
			slide_up()

func slide_down():
	parent_slider.value = parent_slider.value - get_step_size()

func slide_up():
	parent_slider.value = parent_slider.value + get_step_size()
