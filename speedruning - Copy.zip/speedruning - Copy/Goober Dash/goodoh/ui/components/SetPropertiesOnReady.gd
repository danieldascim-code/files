extends Node
class_name SetPropertiesOnReady

export  var property_overrides: = {}
export  var disable: = false

func _ready():
	if not disable:
		var parent: = get_parent() as Node
		for property_name in property_overrides:
			parent.set(property_name, property_overrides[property_name])
