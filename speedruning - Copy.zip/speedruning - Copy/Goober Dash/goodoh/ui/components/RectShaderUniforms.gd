tool 
extends Control
class_name RectShaderUniforms
onready var parent_rect: = get_parent() as Control

const test_signals: = true
export  var _rect_position: = false
export  var _rect_size: = false
export  var _rect_rotation: = false
export  var _rect_scale: = false
export  var _rect_pivot: = false

export  var _rect_global_position: = false
export  var _rect_global_rotation: = false
export  var _rect_global_scale: = false

func _ready():
	mouse_filter = MOUSE_FILTER_IGNORE
	rect_size = Vector2.ZERO
	visible = false
	set_notify_transform(true)
	_apply_shader_uniforms()

func _notification(what):
	match what:
		NOTIFICATION_TRANSFORM_CHANGED:
			get_global_transform()
			_apply_shader_uniforms()

func _apply_shader_uniforms():
	if parent_rect:
		var m: ShaderMaterial = parent_rect.material
		if _rect_position:
			m.set_shader_param("rect_position", parent_rect.rect_position)
		if _rect_size:
			m.set_shader_param("rect_size", parent_rect.rect_size)
		if _rect_rotation:
			m.set_shader_param("rect_rotation", deg2rad(parent_rect.rect_rotation))
		if _rect_pivot:
			m.set_shader_param("rect_pivot", parent_rect.rect_pivot_offset / parent_rect.rect_size)
		if _rect_scale:
			m.set_shader_param("rect_scale", parent_rect.rect_scale)
		
		if _rect_global_position or _rect_global_rotation or _rect_global_scale:
			var global_transform: = parent_rect.get_global_transform()
			if _rect_global_position:
				m.set_shader_param("rect_global_position", global_transform.get_origin())
			if _rect_global_rotation:
				m.set_shader_param("rect_global_rotation", global_transform.get_rotation())
			if _rect_global_scale:
				m.set_shader_param("rect_global_scale", global_transform.get_scale())
