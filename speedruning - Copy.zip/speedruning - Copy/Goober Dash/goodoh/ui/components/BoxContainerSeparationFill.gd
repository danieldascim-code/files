tool 
extends Node
class_name BoxContainerSeparationFill

onready var parent: = get_parent() as Control
const constant_key: = "separation"

var last_size: = Vector2.ZERO

export  var hard_refresh: = false setget set_hard_refresh

func _ready():
	refresh()
	hard_refresh()

func _init():
	parent = get_parent() as Control

func set_hard_refresh(b: bool):
	if is_inside_tree():
		if b:
			hard_refresh()

func _process(delta: float):
	refresh()

func refresh():
	if parent is HBoxContainer or parent is VBoxContainer:
		var count_child_controls: = 0
		var child_size_sum: = Vector2.ZERO
		for i in parent.get_child_count():
			var c = parent.get_child(i)
			if c is Control:
				if c.visible:
					count_child_controls += 1
					child_size_sum += c.rect_size
		
		var size_diff: = parent.rect_size - child_size_sum
		var relevant_component: = size_diff.x if parent is HBoxContainer else size_diff.y
		var seperation_to_fill: = int(round(float(relevant_component) / (count_child_controls - 1)))
		var current_separation: = 0
		
		if parent.has_constant_override(constant_key):
			current_separation = parent.get_constant(constant_key)
		if current_separation != seperation_to_fill:
			parent.add_constant_override(constant_key, seperation_to_fill)
			if Engine.editor_hint:
				parent.property_list_changed_notify()

func hard_refresh():
	
	parent.add_constant_override(constant_key, 0)
	call_deferred("refresh")
