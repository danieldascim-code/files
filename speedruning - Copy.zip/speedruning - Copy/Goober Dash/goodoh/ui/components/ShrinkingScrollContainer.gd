tool 
extends Node
class_name ShrinkingScrollContainer

onready var scroll_container: = get_parent() as ScrollContainer

export  var _scroll_container_contents: NodePath setget _set_scroll_container_contents_path
onready var scroll_container_contents: = get_node_or_null(_scroll_container_contents) as Control

export  var start_scrolling_at: = Vector2.ZERO setget _set_start_scrolling_at
export  var shrink_horizontal: = false
export  var shrink_vertical: = false

func _ready():
	_connect()
	_refresh()

func _refresh():
	if scroll_container_contents:
		var contents_minimum_size: = scroll_container_contents.get_minimum_size()
		if shrink_horizontal:
			scroll_container.rect_min_size.x = min(contents_minimum_size.x, start_scrolling_at.x)
			scroll_container.rect_size.x = scroll_container.rect_min_size.x
		if shrink_vertical:
			scroll_container.rect_min_size.y = min(contents_minimum_size.y, start_scrolling_at.y)
			scroll_container.rect_size.y = scroll_container.rect_min_size.y


func _init():
	scroll_container = get_parent() as ScrollContainer
	_connect()

func _set_scroll_container_contents_path(n: NodePath):
	_scroll_container_contents = n
	_connect()

func _set_start_scrolling_at(v: Vector2):
	start_scrolling_at = v
	_refresh()

func _connect():
	var new_scroll_container_contents = get_node_or_null(_scroll_container_contents)
	if scroll_container_contents and scroll_container_contents.is_connected("item_rect_changed", self, "_refresh"):
		scroll_container_contents.disconnect("item_rect_changed", self, "_refresh")
	scroll_container_contents = new_scroll_container_contents
	if scroll_container_contents:
		if not scroll_container_contents.is_connected("item_rect_changed", self, "_refresh"):
			scroll_container_contents.connect("item_rect_changed", self, "_refresh")
