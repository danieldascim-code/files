extends Node
class_name ButtonGrouper

signal changed
export  var allow_unselect: = false
export  var unselect_index: = 0
export  var initial_selected: = - 1

onready var parent_control: = get_parent() as Control
onready var button_group: = ButtonGroup.new()
onready var buttons: = []
var selected: = - 1 setget set_selected

func _ready():
	for i in parent_control.get_children():
		if i is BaseButton:
			var b: = i as BaseButton
			if b.visible:
				b.group = button_group
				b.toggle_mode = true
				b.connect("pressed", self, "button_pressed", [b])
				buttons.append(b)
	call_deferred("_set_initial_selected")

func _set_initial_selected():
	set_selected(initial_selected)

func button_pressed(b: BaseButton):
	var new_selection: = buttons.find(button_group.get_pressed_button())
	if self.selected != new_selection:
		self.selected = new_selection
	elif allow_unselect:
		self.selected = unselect_index

func set_selected(i):
	if selected != i:
		if i >= 0 and i < buttons.size():
			
			
			buttons[i].pressed = true
		else:
			
			
			if selected >= 0 and selected < buttons.size():
				buttons[selected].pressed = false
		selected = i
		self.emit_signal("changed")

func get_button(i: int) -> BaseButton:
	if i < buttons.size() and i >= 0:
		return buttons[i]
	else:
		return null
