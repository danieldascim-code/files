extends Node
class_name TouchableButton

onready var parent_button: = get_parent() as BaseButton

export  var action_name: = ""

const verbose: = false
enum State{
	None, 
	Mouse, 
	Touch
}
var touch_index: = 0
var touch_state: int = State.None

func _ready() -> void :
	parent_button.button_mask = 0
	parent_button.connect("gui_input", self, "on_parent_gui_input")

func _input(event):
	
	var should_release: = false
	match touch_state:
		State.Touch:
			if event is InputEventScreenTouch and not event.pressed and touch_index == event.index:
				_release_button(parent_button)
				touch_state = State.None
				touch_index = 0
		State.Mouse:
			if event is InputEventMouseButton and not event.pressed:
				_release_button(parent_button)
				touch_state = State.None

func on_parent_gui_input(event: InputEvent):
	if parent_button.disabled:
		return
	
	
	if touch_state == State.None:
		var should_press: = false
		if event is InputEventScreenTouch and event.pressed:
			touch_state = State.Touch
			touch_index = event.index
			_press_button(parent_button)
			
		if event is InputEventMouseButton and event.pressed:
			touch_state = State.Mouse
			_press_button(parent_button)

func _press_button(button: BaseButton):
	if verbose:
		print("[TouchableButton] _press_button() button %s button is pressed %s touch_state %s touch index %s" % [parent_button.name, parent_button.pressed, touch_state, touch_index])
	action_press()
	button.pressed = true
	button.emit_signal("button_down")
	button.emit_signal("pressed")

func _release_button(button: BaseButton):
	if verbose:
		print("[TouchableButton] _release_button() button %s touch_state %s touch index %s" % [parent_button.name, touch_state, touch_index])
	action_release()
	button.pressed = false
	button.emit_signal("button_up")

func is_pressed() -> bool:
	return touch_state != State.None

func action_press():
	if not action_name.empty():
		var event: = InputEventAction.new()
		event.pressed = true
		event.action = action_name
		Input.parse_input_event(event)

func action_release():
	if not action_name.empty():
		var event: = InputEventAction.new()
		event.pressed = false
		event.action = action_name
		Input.parse_input_event(event)
