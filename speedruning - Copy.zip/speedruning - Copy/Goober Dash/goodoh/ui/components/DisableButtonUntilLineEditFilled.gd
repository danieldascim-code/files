extends Node
class_name DisableButtonUntilLineEditFilled

onready var parent_button: = get_parent() as Button

export (NodePath) var line_edit_path
onready var line_edit: = get_node(line_edit_path) as LineEdit

export  var minimum_characters: = 1

func _ready():
	assert (line_edit)
	assert (parent_button)
	line_edit.connect("text_changed", self, "on_text_changed")
	on_text_changed(line_edit.text)

func on_text_changed(line_edit_text: String):
	parent_button.disabled = line_edit_text.length() < minimum_characters
