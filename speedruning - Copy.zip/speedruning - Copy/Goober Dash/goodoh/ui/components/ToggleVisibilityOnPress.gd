extends Node
class_name ToggleVisibilityOnPress

export (NodePath) var target_path
onready var target: = get_node(target_path) as Control

onready var parent_button: = get_parent() as BaseButton

func _ready():
	assert (parent_button)
	parent_button.connect("pressed", self, "on_button_pressed")

func on_button_pressed():
	target.visible = not target.visible
