extends Node

class_name AddScenePathOnPress

export  var scene_path: String
onready var parent_button: = get_parent() as Button

export (NodePath) var _add_node_to: NodePath
onready var add_node_to: = get_node_or_null(_add_node_to)

func _ready():
	parent_button.connect("pressed", self, "on_button_pressed")

func on_button_pressed():
	var new_scene: PackedScene = load(scene_path) as PackedScene
	if new_scene != null:
		var new_node: = new_scene.instance()
		if add_node_to != null:
			add_node_to.add_child(new_node)
		else:
			get_tree().current_scene.add_child(new_node)
