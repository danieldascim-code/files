extends Node
class_name SavedAudioBusVolume


export  var setting_name: = ""
export  var bus_name: = ""
export  var min_value: = - 40.0
export  var max_value: = 0.0
export  var default_normalized_value: = 1.0

func set_saved_volume():
	var bus_index: = AudioServer.get_bus_index(bus_name)
	var volume_slider_level: = default_normalized_value
	if SavedSettings.has_value(setting_name):
		volume_slider_level = SavedSettings.get_value(setting_name) as float
	else:
		SavedSettings.set_value(setting_name, default_normalized_value)
	
	if bus_index != null:
		
		var volume_value = lerp(min_value, max_value, volume_slider_level)
		var mute_it: = volume_slider_level < 0.05
		AudioServer.set_bus_mute(bus_index, mute_it)
		AudioServer.set_bus_volume_db(bus_index, volume_value)

func _ready() -> void :
	call_deferred("set_saved_volume")
