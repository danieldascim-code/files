extends Node
class_name OpenURLOnPress

onready var parent_button: = get_parent() as BaseButton
export  var url: = ""

onready var moonlight: Node = get_node("/root/Moonlight")

func _ready():
	parent_button.connect("pressed", self, "on_button_pressed")

func on_button_pressed():
	if moonlight and moonlight.discord_api and moonlight.discord_api.is_in_discord():
		moonlight.discord_api.open_url(url)
	else:
		OS.shell_open(url)
