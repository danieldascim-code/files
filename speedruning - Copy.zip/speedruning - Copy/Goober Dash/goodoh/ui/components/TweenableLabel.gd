extends Node
class_name TweenableLabel

signal int_changed
signal float_changed
signal int_changed_up
signal float_changed_up








onready var parent_label: = get_parent() as Label



export  var float_format: = "%.1f"
export  var int_format: = "%s"

var first_int: = true
var first_float: = true
var last_int: = 0
var last_float: = 0.0

func set_float(f: float, emit_changed: bool):
	parent_label.text = float_format % [f]
	var _last_float = last_float
	last_float = f
	if emit_changed:
		emit_signal("float_changed")
		if f > _last_float and not first_float:
			emit_signal("float_changed_up")
	first_float = false

func set_int(i: int, emit_changed: bool):
	parent_label.text = int_format % [i]
	var _last_int = last_int
	last_int = i
	if emit_changed:
		emit_signal("int_changed")
		if i > _last_int and not first_int:
			emit_signal("int_changed_up")
	first_int = false

func interpolate_int(i: int):
	if i != last_int or first_int:
		set_int(i, true)

func interpolate_float(f: float):
	if f != last_float or first_float:
		set_float(f, true)

func tween_int(tween: Tween, final_value: int, animation_duration: = 0.5, animation_delay: = 0.0):
	if final_value == last_int + 1:
		set_int(final_value, true)
		return
	tween.interpolate_method(self, "interpolate_int", last_int, final_value, animation_duration, Tween.TRANS_SINE, Tween.EASE_OUT, animation_delay)

func tween_float(tween: Tween, final_value: float, animation_duration: = 0.5, animation_delay: = 0.0):
	tween.interpolate_method(self, "interpolate_float", last_float, final_value, animation_duration, Tween.TRANS_SINE, Tween.EASE_OUT, animation_delay)
