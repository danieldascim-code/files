extends Node
class_name SavedLineEdit

export  var setting_name: = ""
onready var parent_line_edit: = get_parent() as LineEdit

func _ready():
	assert (parent_line_edit)
	if not setting_name.empty():
		if SavedSettings.has_value(setting_name):
			parent_line_edit.text = SavedSettings.get_value(setting_name, "")
			parent_line_edit.emit_signal("text_changed", parent_line_edit.text)
	
	parent_line_edit.connect("text_changed", self, "on_text_changed")

func on_text_changed(t: String):
	SavedSettings.set_value(setting_name, t)
