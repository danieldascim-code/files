tool 
extends Node
class_name MultiMargin



export  var margin: = 0.0 setget set_margin

export  var left: = false
export  var right: = false
export  var top: = false
export  var bottom: = false

onready var parent_control: = get_parent() as Control

func _ready():
	pass

func set_margin(m: float):
	margin = m
	if parent_control:
		if left:
			parent_control.margin_left = margin
		if right:
			parent_control.margin_right = - margin
		if top:
			parent_control.margin_top = margin
		if bottom:
			parent_control.margin_bottom = - margin
