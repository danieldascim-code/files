extends Node
class_name PlaySoundOnPress

onready var parent_button: = get_parent() as BaseButton
export (AudioStream) var audio_stream: AudioStream
export  var volume_db: float = 0.0
export  var pitch_scale: float = 1.0
export  var bus: String = "Master"

var sound_stream: AudioStreamPlayer

func _ready():
	sound_stream = AudioStreamPlayer.new()
	parent_button.connect("pressed", self, "on_button_pressed")
	if (parent_button.has_signal("item_selected")):
		parent_button.connect("item_selected", self, "on_item_selected")
	sound_stream.stream = audio_stream
	add_child(sound_stream)

func on_item_selected(i: int):
	
	on_button_pressed()

func on_button_pressed():
	if not sound_stream.is_playing() or true:
		sound_stream.volume_db = volume_db
		sound_stream.pitch_scale = pitch_scale
		sound_stream.bus = bus
		sound_stream.play()

