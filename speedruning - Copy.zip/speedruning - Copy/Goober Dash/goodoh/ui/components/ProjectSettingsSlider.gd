extends SavedSlider

class_name ProjectSettingsSlider

export  var project_settings_key: = ""

func on_slider_value_changed(slider_value: float):
	.on_slider_value_changed(slider_value)
	print("[ProjectSettingsSlider] setting " + project_settings_key + " to " + str(slider_value))
	ProjectSettings.set_setting(project_settings_key, slider_value)
	var error = ProjectSettings.save()
	assert ( not error)
