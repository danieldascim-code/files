extends Node
class_name SetVisibilityOnReady

onready var parent_canvas_item: = get_parent() as CanvasItem
export  var visibility: = false

func _ready():
	assert (parent_canvas_item)
	parent_canvas_item.visible = visibility
