extends Node
class_name CallMethodOnLineEditEnter

export (NodePath) var target_path
export  var method_name: = ""
export  var arguments: = []

onready var target_node: = get_node(target_path) as Node
onready var parent_line_edit: = get_parent() as LineEdit

func _ready():
	assert (parent_line_edit)
	assert (target_node)
	parent_line_edit.connect("text_entered", self, "on_text_entered")

func on_text_entered(t: String):
	if (arguments and arguments.size() > 0):
		target_node.callv(method_name, arguments)
	else:
		target_node.call(method_name)
