tool 
extends Node
class_name ButtonFontColorForwarder
export  var _button: NodePath
onready var parent_button: = get_node(_button) as Button
onready var parent: = get_parent() as Control

export  var color_property_name: = "self_modulate"


onready var normal_color: = parent_button.get_color("font_color")
onready var hover_color: = parent_button.get_color("font_color_hover")
onready var focus_color: = parent_button.get_color("font_color_focus")
onready var pressed_color: = parent_button.get_color("font_color_pressed")
onready var disabled_color: = parent_button.get_color("font_color_disabled")



var is_hovered: = false
var is_focused: = false

export  var verbose: = false

func _ready():
	parent_button.connect("mouse_entered", self, "on_mouse_entered")
	parent_button.connect("mouse_exited", self, "on_mouse_exited")
	parent_button.connect("focus_entered", self, "on_focus_entered")
	parent_button.connect("focus_exited", self, "on_focus_exited")
	parent_button.connect("button_down", self, "on_button_down")
	parent_button.connect("button_up", self, "on_button_up")
	parent_button.connect("pressed", self, "on_pressed")
	parent_button.connect("toggled", self, "on_toggled")
	set_color()
	set_process(Engine.editor_hint)

func _process(delta: float) -> void :
	if Engine.editor_hint:
		parent_button = get_node(_button)
		normal_color = parent_button.get_color("font_color")
		hover_color = parent_button.get_color("font_color_hover")
		focus_color = parent_button.get_color("font_color_focus")
		pressed_color = parent_button.get_color("font_color_pressed")
		disabled_color = parent_button.get_color("font_color_disabled")
		set_color()


func on_mouse_entered():
	if verbose:
		print("[HoverTint] on mouse enter")
	is_hovered = true
	set_color()
func on_mouse_exited():
	if verbose:
		print("[HoverTint] on mouse exit")
	is_hovered = false
	set_color()


func on_toggled(t: bool):
	if verbose:
		print("[HoverTint] on toggled ", parent_button.pressed)
	set_color()
func on_pressed():
	if verbose:
		print("[HoverTint] on pressed ", parent_button.pressed)
	set_color()
func on_button_down():
	if verbose:
		print("[HoverTint] on button down ", parent_button.pressed)
	set_color()
func on_button_up():
	
	yield(get_tree(), "idle_frame")
	if verbose:
		print("[HoverTint] on button up pressed ", parent_button.pressed)
	set_color()
	


func on_focus_entered():
	if verbose:
		print("[HoverTint] on focus enter")
	is_focused = true
	set_color()
func on_focus_exited():
	if verbose:
		print("[HoverTint] on focus exit")
	is_focused = false
	set_color()


func set_color():
	if parent_button and parent_button.pressed:
		if verbose:
			print("[HoverTint] using pressed color %s" % get_path())
		set_color_(pressed_color)
	elif is_hovered:
		if verbose:
			print("[HoverTint] using hover color %s" % get_path())
		set_color_(hover_color)
	elif is_focused:
		if verbose:
			print("[HoverTint] using focus color %s" % get_path())
		set_color_(focus_color)
	else:
		if verbose:
			print("[HoverTint] using normal color %s" % get_path())
		set_color_(normal_color)

func set_color_(color: Color):
	parent.set(color_property_name, color)
