extends Control
class_name GoodVirtualAnalogStick

signal knob_grabbed(normalized_position)
signal knob_released(normalized_position)
signal knob_moved(normalized_position)

onready var knob: = $Knob as Control
onready var knob_anchor: = $Knob / GoodAnchorPoint as GoodAnchorPoint
onready var anchor: = $Anchor as Control
onready var anchor_anchor: = $Anchor / GoodAnchorPoint as GoodAnchorPoint
export  var override_radius: = 0.0
export  var only_accept_tap_within_radius: = false


export  var action_left: = ""
export  var action_right: = ""
export  var action_up: = ""
export  var action_down: = ""
export  var dead_zone: = 0.1
export  var drag_anchor: = false

var disabled: = false

const verbose: = true
enum State{
	None, 
	Mouse, 
	Touch
}
var touch_index: = 0
var touch_state: int = State.None
var touch_position: = Vector2.ZERO

func _radius() -> float:
	if override_radius > 0.0:
		return override_radius
	
	return 0.5 * min(rect_size.x, rect_size.y)

func _within_radius(local_point: Vector2) -> bool:
	if drag_anchor:
		return true
	return ( not only_accept_tap_within_radius) or local_point.length() <= _radius()

func _gui_input(event: InputEvent):
	if disabled:
		return
	
	if touch_state == State.None:
		var should_press: = false
		if event is InputEventScreenTouch or event is InputEventMouseButton:
			if event.pressed:
				var local_point: Vector2 = event.position - rect_size * 0.5
				if _within_radius(local_point):
					if drag_anchor:
						anchor_anchor.offset = local_point
					if event is InputEventScreenTouch:
						touch_state = State.Touch
						touch_index = event.index
						touch_position = local_point
						_move_knob()
						emit_signal("knob_grabbed", normalized_touch_position())
						
					if event is InputEventMouseButton:
						touch_state = State.Mouse
						touch_position = local_point
						_move_knob()
						emit_signal("knob_grabbed", normalized_touch_position())

func _input(event):
	
	match touch_state:
		State.Touch:
			if event is InputEventScreenDrag and touch_index == event.index:
				var p: Vector2 = make_input_local(event).position
				var local_point: Vector2 = p - rect_size * 0.5
				
				if _within_radius(local_point):
					touch_position = local_point
					_move_knob()
					emit_signal("knob_moved", normalized_touch_position())
		State.Mouse:
			if event is InputEventMouseMotion:
				var p: Vector2 = make_input_local(event).position
				var local_point: Vector2 = p - rect_size * 0.5
				
				if _within_radius(local_point):
					touch_position = local_point
					_move_knob()
					emit_signal("knob_moved", normalized_touch_position())
	
	
	match touch_state:
		State.Touch:
			if event is InputEventScreenTouch and not event.pressed and touch_index == event.index:
				_move_knob()
				emit_signal("knob_released", normalized_touch_position())
				touch_state = State.None
				touch_index = 0
				touch_position = Vector2.ZERO
		State.Mouse:
			if event is InputEventMouseButton and not event.pressed:
				_move_knob()
				emit_signal("knob_released", normalized_touch_position())
				touch_state = State.None
				touch_position = Vector2.ZERO

func _move_knob():
	var r: = _radius()
	if drag_anchor:
		if is_being_touched():
			if touch_position().length_squared() > r * r:
				anchor_anchor.offset = touch_position - r * touch_position().normalized()
		else:
			anchor_anchor.offset = Vector2.ZERO
		knob_anchor.offset = touch_position
	else:
		var clamped_position: = touch_position().limit_length(_radius())
		knob_anchor.offset = clamped_position
	
	var normalized_position: Vector2 = normalized_touch_position()
	
	_send_action(action_left, normalized_position.x, false)
	_send_action(action_right, normalized_position.x, true)
	_send_action(action_up, normalized_position.y, false)
	_send_action(action_down, normalized_position.y, true)


func is_being_touched() -> bool:
	return touch_state != State.None

func touch_position() -> Vector2:
	return touch_position - anchor_anchor.offset

func normalized_touch_position() -> Vector2:
	var radius: float = _radius()
	if is_zero_approx(radius):
		return Vector2.ZERO
	return touch_position().limit_length(radius) / radius

func _send_action(action_name: String, f: float, positive: bool):
	if not action_name.empty():
		if positive and f > dead_zone:
			var event: = InputEventAction.new()
			event.action = action_name
			event.pressed = true
			event.strength = f
			Input.parse_input_event(event)
		elif not positive and f < - dead_zone:
			var event: = InputEventAction.new()
			event.action = action_name
			event.pressed = true
			event.strength = abs(f)
			Input.parse_input_event(event)
		else:
			var event: = InputEventAction.new()
			event.action = action_name
			event.pressed = false
			Input.parse_input_event(event)
