extends Node
class_name ControlMatchViewport

onready var parent_control: = get_parent() as Control
export  var scale: = 1.0

func _process(delta: float) -> void :
	do()

func do():
	var size: = parent_control.get_viewport_rect().size
	parent_control.rect_size = size * scale
