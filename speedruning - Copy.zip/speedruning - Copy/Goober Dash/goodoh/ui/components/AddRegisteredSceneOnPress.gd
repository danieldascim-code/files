extends Node
class_name AddRegisteredSceneOnPress

onready var parent_button: = get_parent() as BaseButton
export  var scene_name: = ""

export (NodePath) var _add_node_to: NodePath
onready var add_node_to: = get_node_or_null(_add_node_to)

func _ready():
	parent_button.connect("pressed", self, "on_parent_button_pressed")

func on_parent_button_pressed():
	var v = GoodSceneRegistry.get(scene_name)
	if not v is PackedScene:
		printerr("[AddRegisteredSceneOnPress] on_parent_button_pressed() scene_name %s is invalid" % [scene_name])
		return
	
	var p: = v as PackedScene
	var new_node: = p.instance()
	if add_node_to != null:
		add_node_to.add_child(new_node)
	else:
		get_tree().current_scene.add_child(new_node)
