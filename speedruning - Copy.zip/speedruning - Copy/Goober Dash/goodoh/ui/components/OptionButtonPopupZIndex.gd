extends Node
class_name OptionButtonPopupZIndex

onready var parent_options_button: = get_parent() as OptionButton
export  var z_index: = 0

func _ready():
	call_deferred("set_popup_z_index")

func set_popup_z_index():
	var rid: = parent_options_button.get_popup().get_canvas_item()
	VisualServer.canvas_item_set_z_index(rid, z_index)
