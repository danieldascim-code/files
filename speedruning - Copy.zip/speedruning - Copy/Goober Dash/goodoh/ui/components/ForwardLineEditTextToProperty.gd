extends Node
class_name ForwardLineEditTextToProperty

onready var line_edit_parent: = get_parent() as LineEdit

export (NodePath) var target_path
onready var target: = get_node(target_path) as Node

export  var target_property: = ""

func _ready():
	assert (line_edit_parent)
	assert (target)
	assert (target_property_is_string())
	line_edit_parent.connect("text_changed", self, "on_text_changed")
	on_text_changed(line_edit_parent.text)

func on_text_changed(line_edit_text: String):
	target.set(target_property, line_edit_text)
	
func target_property_is_string() -> bool:
	var target_properties: = target.get_property_list()
	for property in target_properties:
		if property["name"] == target_property:
			return property["type"] == TYPE_STRING
	
	return false
