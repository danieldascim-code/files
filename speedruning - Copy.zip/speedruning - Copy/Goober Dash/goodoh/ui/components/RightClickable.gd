extends Node
class_name RightClickable

signal right_clicked()

onready var parent_control: Control = get_parent()

var touch_timer: = 0.0
const long_touch_duration: = 2.0
const void_touch_index: = - 1
var touch_index: = - 1
var touch_down_position: = Vector2.ZERO
const verbose: = false
const drag_release_delta: = 20.0

func _ready() -> void :
	parent_control.connect("gui_input", self, "on_parent_gui_input")

func _input(event: InputEvent) -> void :
	if touch_index != void_touch_index:
		if event is InputEventScreenTouch:
			if touch_index == event.index:
				if not event.pressed:
					touch_index = void_touch_index
					touch_timer = 0.0
					if verbose:
						print("[RightClickable] touch release")
		if event is InputEventScreenDrag:
			if touch_index == event.index:
				
				if not parent_control.get_rect().has_point(event.position):
					touch_index = void_touch_index
					touch_timer = 0.0
					if verbose:
						print("[RightClickable] releasing due to drag off")
				if event.position.distance_to(touch_down_position) > drag_release_delta:
					touch_index = void_touch_index
					touch_timer = 0.0
					if verbose:
						print("[RightClickable] releasing due to drag")

func on_parent_gui_input(event: InputEvent):
	if event is InputEventMouseButton:
		if event.pressed:
			if event.button_index == BUTTON_RIGHT:
				emit_signal("right_clicked")
				if verbose:
					print("[RightClickable] right clicked")
	
	if touch_index == void_touch_index:
		if event is InputEventScreenTouch:
			if event.pressed:
				touch_index = event.index
				touch_timer = 0.0
				touch_down_position = event.position + parent_control.rect_global_position
				if verbose:
					print("[RightClickable] start touch")

func _process(delta: float) -> void :
	if touch_index != void_touch_index and touch_timer < long_touch_duration:
		touch_timer += delta
		if touch_timer >= long_touch_duration:
			emit_signal("right_clicked")
			if verbose:
				print("[RightClickable] long touch")
