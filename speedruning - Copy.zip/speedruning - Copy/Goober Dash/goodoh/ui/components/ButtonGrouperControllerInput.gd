extends Node
class_name ButtonGrouperControllerInput

onready var parent_button_grouper: = get_parent() as ButtonGrouper

export (NodePath) var up_audio_stream_player
export (NodePath) var down_audio_stream_player

onready var up_sound_stream: = get_node_or_null(up_audio_stream_player) as AudioStreamPlayer
onready var down_sound_stream: = get_node_or_null(down_audio_stream_player) as AudioStreamPlayer

func _unhandled_input(event: InputEvent):
	if JoypadInputBlocker.should_block_input():
		return
	
	if not parent_button_grouper.parent_control.is_visible_in_tree():
		return
	
	if event.is_action_pressed("ui_page_down"):
		if parent_button_grouper.parent_control.is_visible_in_tree():
			if parent_button_grouper.selected + 1 < parent_button_grouper.buttons.size():
				parent_button_grouper.selected = parent_button_grouper.selected + 1
				play_up_sound()
	
	if event.is_action_pressed("ui_page_up"):
		if parent_button_grouper.parent_control.is_visible_in_tree():
			if parent_button_grouper.selected > 0:
				parent_button_grouper.selected = parent_button_grouper.selected - 1
				play_down_sound()

func play_up_sound():
	if up_sound_stream:
		up_sound_stream.play()

func play_down_sound():
	if down_sound_stream:
		down_sound_stream.play()
