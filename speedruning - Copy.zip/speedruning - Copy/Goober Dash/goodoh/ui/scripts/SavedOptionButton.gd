extends OptionButtonOptions

class_name SavedOptionButton

export (String) var setting_key

onready var saved_settings = get_node("/root/SavedSettings")

func _ready() -> void :
	assert (saved_settings != null)
	
	
	var initial_value = saved_settings.set_default_value(setting_key, default_value)
	if setting_key and setting_key.length() > 0:
		initial_value = saved_settings.get_value(setting_key, default_value)
	else:
		print("[SavedOptionButton] " + name + " has no setting key.")
	
	select(initial_value)


func on_option_selected(item_index):
	
	saved_settings.set_value(setting_key, item_index)

