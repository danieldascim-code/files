tool 
extends Node
class_name Editor_MarkMouseInput

export  var _run: bool setget _do_run
onready var parent_control: Control = get_parent()

export  var mark_buttons_as_pass: = true
const mark_as_pass: = ["BaseButton", "TextEdit", "LineEdit", "ScrollBar", "Slider"]
func _do_run(b: bool):
	if b:
		run()

func run():
	parent_control = get_parent()
	if parent_control != null:
		_recursively_mark_input(parent_control)
		print("[MarkMouseInput] done")

func _recursively_mark_input(c: Node):
	var marked_as_pass: = false
	if mark_buttons_as_pass:
		for i in mark_as_pass:
			if c.is_class(i):
				c.mouse_filter = Control.MOUSE_FILTER_PASS
				print("[MarkMouseInput] Marking %s as pass" % [parent_control.get_path_to(c)])
				marked_as_pass = true
				break
	
	if not marked_as_pass:
		var control = c as Control
		if control:
			if control.mouse_filter != Control.MOUSE_FILTER_IGNORE:
				print("[MarkMouseInput] Marking %s as ignore from %s" % [parent_control.get_path_to(control), control.mouse_filter])
				control.mouse_filter = Control.MOUSE_FILTER_IGNORE
			
	
	for i in c.get_child_count():
		var child = c.get_child(i)
		_recursively_mark_input(child)
