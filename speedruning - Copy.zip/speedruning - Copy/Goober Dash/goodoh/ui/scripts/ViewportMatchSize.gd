extends Node
class_name ViewportMatchSize

onready var parent_viewport: Viewport = get_parent()

func _process(delta: float) -> void :
	parent_viewport.size = get_tree().root.size
