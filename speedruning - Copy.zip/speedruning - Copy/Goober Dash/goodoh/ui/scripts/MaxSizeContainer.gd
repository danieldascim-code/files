tool 
class_name MaxSizeContainer
extends Container

enum HAlign{LEFT, CENTER, RIGHT}
enum VAlign{TOP, CENTER, BOTTOM}

export  var rect_max_size: Vector2 = Vector2( - 1, - 1) setget set_rect_max_size
export (HAlign) var align_h: int = HAlign.CENTER setget set_align_h
export (VAlign) var align_v: int = VAlign.CENTER setget set_align_v

func set_rect_max_size(to: Vector2):
	rect_max_size = to
	if rect_max_size.x < 0:
		rect_max_size.x = - 1
	if rect_max_size.y < 0:
		rect_max_size.y = - 1
	fit_child()

func set_align_h(to: int):
	align_h = to
	fit_child()

func set_align_v(to: int):
	align_v = to
	fit_child()

func _notification(what: int):
	match what:
		NOTIFICATION_SORT_CHILDREN, \
		NOTIFICATION_RESIZED:
			fit_child()

func fit_child():
	if get_child_count() == 0:
		return
	
	var position: = Vector2.ZERO
	var size: = rect_size
	var max_size: = get_maximum_size()
	match align_h:
		HAlign.CENTER:
			position.x = max(0, (rect_size.x - max_size.x) / 2)
		HAlign.RIGHT:
			position.x = max(0, rect_size.x - max_size.x)
	
	match align_v:
		VAlign.CENTER:
			position.y = max(0, (rect_size.y - max_size.y) / 2)
		VAlign.BOTTOM:
			position.y = max(0, rect_size.y - max_size.y)
	
	size.x = min(rect_size.x, max_size.x)
	size.y = min(rect_size.y, max_size.y)
	
	for i in get_child_count():
		var c: = get_child(i) as Control
		if c:
			fit_child_in_rect(c, Rect2(position, size))

func get_maximum_size() -> Vector2:
	var size: = rect_max_size
	if size.x < 0:
		size.x = 10000000
	if size.y < 0:
		size.y = 10000000
	return size

func _get_minimum_size() -> Vector2:
	var min_size: = rect_min_size
	for i in get_child_count():
		var c: = get_child(i) as Control
		if c:
			min_size.x = max(min_size.x, c.rect_min_size.x)
			min_size.y = max(min_size.y, c.rect_min_size.y)
	return min_size
