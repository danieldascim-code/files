extends Control
class_name CloseVirtualKeyboard
onready var focus_global_autoload: = get_node("/root/FocusGlobal")
var is_focussing_text_box: = false

func _ready() -> void :
	self.visible = false
	
	if is_mobile_device():
		focus_global_autoload.connect("focused_control_changed", self, "on_focused_control_changed")

func on_focused_control_changed(c: Control):
	if c is LineEdit or c is TextEdit:
		is_focussing_text_box = true
	else:
		is_focussing_text_box = false

func _input(event: InputEvent) -> void :
	if is_focussing_text_box:
		if OS.is_showing_virtual_keyboard():
			if event is InputEventMouseButton or event is InputEventScreenTouch:
				if focus_global_autoload.focused_control != null:
					if not focus_global_autoload.focused_control.get_global_rect().has_point(event.position):
						print("[CloseVirtualKeyboard] Accepting touch event and closing keyboard")
						accept_event()
						OS.hide_virtual_keyboard()
					else:
						print("[CloseVirtualKeyboard] Ignoring touch event")

func is_mobile_device() -> bool:
	var os_name: = OS.get_name()
	return os_name == "Android" or os_name == "iOS"
