extends Node

class_name TextureButtonHover

export  var normal_color: = Color.white
export  var hover_color: = Color.white
export  var pressed_color: = Color.white
export  var tint_children: = false

var is_hovered: = false
onready var parent_texture_button: = get_parent() as TextureButton

func _ready():
	assert (parent_texture_button)
	parent_texture_button.connect("mouse_entered", self, "on_mouse_entered")
	parent_texture_button.connect("mouse_exited", self, "on_mouse_exited")
	parent_texture_button.connect("button_down", self, "on_button_down")
	parent_texture_button.connect("button_up", self, "on_button_up")
	parent_texture_button.connect("pressed", self, "on_pressed")
	parent_texture_button.connect("toggled", self, "on_toggled")
	set_color()


func on_mouse_entered():
	is_hovered = true
	set_color()
func on_mouse_exited():
	is_hovered = false
	set_color()


func on_toggled(t: bool):
	set_color()
func on_pressed():
	set_color()
func on_button_down():
	set_color()
func on_button_up():
	set_color()

func set_color():
	if parent_texture_button.pressed:
		set_color_(pressed_color)
	elif is_hovered:
		set_color_(hover_color)
	else:
		set_color_(normal_color)

func set_color_(color: Color):
	if tint_children:
		parent_texture_button.modulate = color
	else:
		parent_texture_button.self_modulate = color
