extends Node

signal focus_changed
signal focused_control_changed(c)
signal focus_lost(c)

var is_focus_really_enabled: = Input.get_connected_joypads().size() > 0
var focused_control: Control

const verbose: = false

var is_using_keyboard: = false

func _ready() -> void :
	if OS.has_feature("server"):
		return
	
	get_tree().root.connect("gui_focus_changed", self, "on_gui_focus_changed")

func on_gui_focus_changed(c: Control):
	set_focused_control(c)
	if verbose:
		var a: = "null"
		if focused_control != null:
			a = focused_control.get_path()
		print("[FocusGlobal] on_gui_focus_changed() %s" % [a])

func focus_on_control(c: Control, force: = false):
	if verbose:
		var a: = "null"
		if focused_control != null:
			a = focused_control.get_path()
		
		var b: = "null"
		if c != null:
			b = c.get_path()
		print("[FocusGlobal] focus_on_control() %s -> %s" % [a, b])

	if c != null:
		if focused_control != null and focused_control != c and focused_control.is_inside_tree():
			focused_control.release_focus()
		set_focused_control(c)
		if force or is_focus_enabled():
			c.call_deferred("grab_focus")
		
		
	else:
		var og_focus: = focused_control
		if focused_control != null:
			focused_control.release_focus()
		
		set_focused_control(null)
		emit_signal("focus_lost", og_focus)

func connect_to_delete_signal(c: Control):
	c.connect("tree_exited", self, "release_focused_control")

func disconnect_from_delete_signal(c: Control):
	c.disconnect("tree_exited", self, "release_focused_control")

func release_focused_control():
	set_focused_control(null)

func set_focused_control(c: Control):
	if focused_control != null:
		disconnect_from_delete_signal(focused_control)
	focused_control = c
	
	if focused_control != null:
		connect_to_delete_signal(focused_control)
	
	emit_signal("focused_control_changed", focused_control)

func is_focus_enabled() -> bool:
	return is_focus_really_enabled

func _input(event: InputEvent) -> void :
	if event is InputEventJoypadButton or event is InputEventKey:
		var was_focus_enabled: = is_focus_enabled()
		is_using_keyboard = event is InputEventKey
		is_focus_really_enabled = true
		if not was_focus_enabled:
			emit_signal("focus_changed")
			if focused_control:
				focus_on_control(focused_control)


	
	if event is InputEventMouseButton:
		var was_focus_enabled: = is_focus_enabled()
		is_focus_really_enabled = false
		if was_focus_enabled:
			emit_signal("focus_changed")
