extends Node2D
class_name VirtualAnalogStick















signal analog_force_change(vector2, analog)

const INACTIVE_IDX = - 1

export  var isDynamicallyShowing = false
export  var analogName = ""

var ball
var bg
var animationPlayer
var parent

var centerPoint = Vector2(0, 0)
var currentForce = Vector2(0, 0)
var halfSize = Vector2()
var ballPos = Vector2()
var squaredHalfSizeLength = 0
var currentPointerIDX = INACTIVE_IDX;

func _ready():
	set_process_input(true)
	get_nodes()
	calculate_node_sizes()
	
	if isDynamicallyShowing:
		
		self.modulate.a = 0

func get_nodes():
	bg = get_node("Background")
	ball = get_node("Ball")
	animationPlayer = get_node("AnimationPlayer")
	parent = get_parent()

func calculate_node_sizes():
	halfSize = bg.get_rect().size / 2
	squaredHalfSizeLength = halfSize.x * halfSize.y
	
func _input(event):
	var incomingPointer = extract_pointer_index(event)
	if incomingPointer == INACTIVE_IDX:
		
		return
	
	if check_change_active_pointer(event):
		if (currentPointerIDX != incomingPointer) and event.is_pressed():
			currentPointerIDX = incomingPointer;
			show_at_position(Vector2(event.position.x, event.position.y))

	var theSamePointer = currentPointerIDX == incomingPointer
	if is_active() and theSamePointer:
		
		process_input(event)

func check_change_active_pointer(event):
	var mouseButton = event is InputEventMouseButton
	var touch = event is InputEventScreenTouch
	
	if mouseButton or touch:
		if isDynamicallyShowing:
			
			assert (false)
			return get_parent().get_global_rect().has_point(Vector2(event.global_position.x, event.global_position.y))
		else:
			
			var length = (self.global_position - Vector2(event.position.x, event.position.y)).length_squared();
			return length < squaredHalfSizeLength
	else:
		
		return false

func is_active():
	return currentPointerIDX != INACTIVE_IDX

func extract_pointer_index(event):
	var touch = event is InputEventScreenTouch
	var drag = event is InputEventScreenDrag
	var mouseButton = event is InputEventMouseButton
	var mouseMove = event is InputEventMouseMotion
	
	if touch or drag:
		
		return event.index
	elif mouseButton or mouseMove:
		
		return 0
	else:
		
		return INACTIVE_IDX
		
func process_input(event):
	calculate_force(event.position.x - self.global_position.x, event.position.y - self.global_position.y)
	updateBallPos()
	
	var isReleased = isReleased(event)
	if isReleased:
		reset()


func reset():
	currentPointerIDX = INACTIVE_IDX
	calculate_force(0, 0)

	if isDynamicallyShowing:
		updateBallPos()
		hide()
	else:
		updateBallPos()

func show_at_position(pos):
	
	if isDynamicallyShowing:
		animationPlayer.play("alpha_in")
		self.global_position = pos
	
func hide():
	animationPlayer.play("alpha_out")

func updateBallPos():
	ballPos.x = halfSize.x * currentForce.x
	ballPos.y = halfSize.y * - currentForce.y
	ball.position = ballPos

func calculate_force( var x,  var y):
	
	currentForce.x = (x - centerPoint.x) / halfSize.x
	currentForce.y = - (y - centerPoint.y) / halfSize.y
	
	
	if currentForce.length_squared() > 1:
		currentForce = currentForce / currentForce.length()
	
	emit_signal("analog_force_change", currentForce, self)

func isPressed(event):
	if event.type == InputEvent.MOUSE_MOTION:
		return (event.button_mask == 1)
	elif event.type == InputEvent.SCREEN_TOUCH:
		return event.pressed

func isReleased(event):
	if event is InputEventScreenTouch:
		return not event.pressed
	elif event is InputEventMouseButton:
		return not event.pressed
