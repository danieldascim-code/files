extends Node
class_name FPSLabel

onready var parent_label: Label = get_parent()

func _process(_delta):
	if parent_label.is_visible_in_tree():
		parent_label.text = str(Engine.get_frames_per_second()) + "fps"
