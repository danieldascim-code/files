extends Control
class_name Paginator

signal page_changed(page)

export (NodePath) var _button_grouper: NodePath
onready var button_grouper: = get_node(_button_grouper) as ButtonGrouper

var current_page: = 0
var pages: = []
var tweens: = []
const animation_time: = 0.5

func _ready():
	button_grouper.connect("changed", self, "on_button_grouper_changed")
	for i in get_child_count():
		var child_control: = get_child(i) as Control
		if child_control:
			pages.append(child_control)
			child_control.visible = false
			var new_tween: = Tween.new()
			add_child(new_tween)
			tweens.append(new_tween)

func on_button_grouper_changed():
	var selected_page: = button_grouper.selected
	var left_to_right: = selected_page < current_page
	animate_out(pages[current_page], left_to_right, tweens[current_page])
	animate_in(pages[selected_page], left_to_right, tweens[selected_page])
	current_page = selected_page
	emit_signal("page_changed", pages[current_page])
	
func animate_out(node: Control, to_right: bool, tween: Tween):
	var destination_position: = rect_size.x
	if not to_right:
		destination_position = - rect_size.x
	
	tween.remove_all()
	tween.interpolate_property(node, "rect_position", Vector2.ZERO, Vector2(destination_position, 0.0), animation_time, Tween.TRANS_EXPO, Tween.EASE_OUT)
	tween.interpolate_callback(node, animation_time, "set_visible", false)
	tween.start()

func animate_in(node: Control, from_left: bool, tween: Tween):
	var initial_position: = - rect_size.x
	if not from_left:
		initial_position = rect_size.x
	
	tween.remove_all()
	if node.visible:
		node.visible = false
	node.visible = true
	node.rect_position = Vector2(initial_position, 0.0)
	tween.interpolate_property(node, "rect_position", node.rect_position, Vector2.ZERO, animation_time + 0.05, Tween.TRANS_EXPO, Tween.EASE_OUT)
	tween.start()
