extends Node

class_name GrabFocusOnVisible

export  var only_once: = false
var has_grabbed: = false

var parent: Control

func _ready():
	assert (get_parent() is Control)
	parent = get_parent()
	
	if parent.has_node("Focusable"):
		var f: Focusable = parent.get_node_or_null("Focusable")
		if f != null:
			f.grab_focus_on_visible = true
	else:
		var e = parent.connect("visibility_changed", self, "do")
		assert (e == 0)
	
func do():
	if only_once and has_grabbed:
		return
	
	if parent.is_visible_in_tree():
		has_grabbed = true
		parent.grab_focus()
