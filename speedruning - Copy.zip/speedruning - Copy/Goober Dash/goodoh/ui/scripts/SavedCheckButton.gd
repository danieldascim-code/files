extends CheckButton

class_name SavedCheckButton

export (String) var setting_key
export (bool) var default_value

onready var saved_settings = get_node("/root/SavedSettings")

func _ready() -> void :
	assert (saved_settings != null)
	
	
	if saved_settings != null:
		var initial_value = saved_settings.set_default_value(setting_key, default_value)
		if setting_key and setting_key.length() > 0:
			
			initial_value = saved_settings.get_value(setting_key, default_value)
			
			
			var error = connect("toggled", self, "on_toggle")
			assert ( not error)
		else:
			print("[SavedCheckButton] " + name + " has no setting key.")

		
		pressed = initial_value
		
func on_toggle(item_index):
	
	if saved_settings != null:
		saved_settings.set_value(setting_key, item_index)
