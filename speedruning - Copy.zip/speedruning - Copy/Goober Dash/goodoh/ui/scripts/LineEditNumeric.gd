extends LineEdit
class_name LineEditNumeric

signal number_changed(number)

export  var do_minimum: = false
export  var minimum: = 0
export  var do_maximum: = false
export  var maximum: = 0
export  var step: = 0.1
export  var initial_value: = 0.0

var number: = 0.0 setget set_number

func _ready():
	set_number(initial_value)
	connect("text_changed", self, "on_text_changed")
	connect("text_entered", self, "on_text_entered")
	connect("focus_exited", self, "on_focus_exit")

func on_focus_exit():
	process_text(self.text, true, true)

func on_text_changed(new_text: String):
	process_text(new_text, false, true)

func on_text_entered(t: String):
	process_text(t, true, true)

func process_text(new_text: String, override_text: bool, _emit_signal: bool):
	var cursor: = caret_position
	var old_number: = number
	
	number = float(new_text)
	if step > 0.0:
		number = stepify(number, step)
	if do_minimum:
		number = max(number, minimum)
	if do_maximum:
		number = min(number, maximum)
	
	if override_text:
		text = str(number)
		caret_position = clamp(cursor, 0, text.length())
	
	if number != old_number and _emit_signal:
		emit_signal("number_changed", number)

func set_number(n: float):
	process_text(str(n), true, true)

func set_number_no_signal(n: float):
	process_text(str(n), true, false)
