extends Control
class_name FocusGroup

onready var focus_global: = get_node("/root/FocusGlobal")





var focusable_controls: = []
var focused_control: Control

func _ready() -> void :
	focus_global.connect("focused_control_changed", self, "on_focused_control_changed")
	
func on_focused_control_changed(f: Control):
	if focusable_controls.has(f):
		focused_control = f
