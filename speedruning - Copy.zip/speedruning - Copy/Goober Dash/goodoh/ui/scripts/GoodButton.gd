tool 
extends Button
class_name GoodButton


export (String, MULTILINE) var label_text: = "" setget set_label_text

export  var _sdf_label: NodePath = NodePath("SDFLabel")
onready var sdf_label: = get_node_or_null(_sdf_label) as Label

export (SDFLabel.FontSize) var font_size: = SDFLabel.default_font_size_index setget set_label_font_size

export  var _icon_node: = NodePath("GoodIcon")
onready var icon_node: = get_node_or_null(_icon_node) as TextureRect
export (Texture) var icon_tex setget set_icon_tex


export (Resource) var swatch setget set_swatch
onready var swatcher: = get_node_or_null("SwatchdApplier") as SwatchdButton

onready var focusable: = get_node_or_null("Focusable") as Focusable
onready var play_sound_on_press: = get_node_or_null("PlaySoundOnPress") as PlaySoundOnPress

export (Array, NodePath) var swatchd_tint_paths: Array
export (SwatchdButton.ButtonDrawState) var swatchd_preview_state: = 0 setget set_preview_state

func _ready():
	if sdf_label:
		sdf_label.text = label_text
		sdf_label.font_size = font_size
	if icon_node:
		set_icon_tex(icon_tex)
	if swatcher:
		for t in swatchd_tint_paths:
			var c = get_node(t) as Control
			if c:
				swatcher.tint_paths.append(c)
			else:
				printerr("invalid node path \'%s\' on goodbutton at path \'%s\'" % [c, get_path()])
		swatcher.swatch = swatch
		swatcher.apply_color_index()

func set_preview_state(i: int):
	swatchd_preview_state = i
	if swatcher:
		swatcher.preview_state = i

func set_label_text(t: String):
	label_text = t
	if sdf_label:
		sdf_label.text = t

func set_icon_tex(t: Texture):
	icon_tex = t
	if icon_node:
		icon_node.texture = t
		if not icon_node.expand:
			icon_node.rect_size = Vector2.ZERO

func set_label_font_size(i: int):
	font_size = i
	if sdf_label:
		sdf_label.font_size = font_size

func set_swatch(s: Resource):
	if s == null:
		swatch = null
	elif s is Swatchd:
		swatch = s
		if swatcher:
			swatcher.swatch = swatch
			swatcher.set_color()
	elif s != null:
		printerr("[GoodButton] set_swatch() called with not a swatch.")
