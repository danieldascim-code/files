extends Node
class_name ExplodingIconAnimation

const explosion_duration: = 0.5
const animation_duration: = 1.0
const time_per_100_icons: = 0.5

export (PackedScene) var icon
onready var tween: = $Tween as Tween
export  var audio_bus: = ""

export  var time_between_burst_sounds: = 0.1
export (AudioStream) var burst_sound
var burst_sound_player: RapidSoundPlayer
export  var burst_db: = 0.0
export  var burst_sound_delay: = 0.2

export  var burst_pitch: = 1.0

export (AudioStream) var start_sound
onready var start_sound_player: = $StartSoundPlayer
export  var start_db: = 0.0

func _ready():
	if burst_sound != null:
		burst_sound_player = RapidSoundPlayer.new()
		burst_sound_player.time_between_sounds = time_between_burst_sounds
		burst_sound_player.audio_stream = burst_sound
		burst_sound_player.audio_bus = audio_bus
		burst_sound_player.pitch = burst_pitch
		burst_sound_player.volume_db = burst_db
		add_child(burst_sound_player)
	
	start_sound_player.stream = start_sound
	start_sound_player.volume_db = start_db
	start_sound_player.bus = audio_bus


static func animation_duration_for_icon(index: int) -> float:
	var icon_delay: = float(index) * time_per_100_icons / 100.0
	return animation_duration + explosion_duration + icon_delay - 0.1

func spawn_exploding_icon(number: int, starting_point: Vector2, destination: Control, node_parent: Node = null, delay: = 0.0, play_start_sound: = true, min_circle: = 120.0, max_circle: = 200.0, pitch_min: = 1.0, pitch_max: = 1.0):
	if number <= 0:
		return
	var single_pitch: = - 1.0
	if abs(pitch_min - pitch_max) < 0.0001:
		single_pitch = pitch_min
	
	if play_start_sound:
		tween.interpolate_callback(start_sound_player, delay, "play")
	var checked_node2D: = false
	var is_node2D: = false
	for i in number:
		var exploding_coin: = icon.instance() as CanvasItem
		if not checked_node2D:
			is_node2D = exploding_coin is Node2D
			checked_node2D = true
		
		var position_key: String
		var scale_key: String
		if is_node2D:
			position_key = "global_position"
			scale_key = "scale"
		else:
			position_key = "rect_global_position"
			scale_key = "rect_scale"
		
		if node_parent != null:
			node_parent.add_child(exploding_coin)
		else:
			add_child(exploding_coin)
		
		var random_delta: = rand_range(min_circle, max_circle) * Vector2.UP.rotated(rand_range(0.0, TAU))
		var icon_delay: = float(i) * time_per_100_icons / 100.0 + delay
		
		var start_point: = starting_point + 0.0 * random_delta
		var random_position_on_circle: = starting_point + random_delta
		exploding_coin.visible = false
		
		
		
		
		
		
		if burst_sound_player != null:
			tween.interpolate_callback(burst_sound_player, icon_delay + burst_sound_delay, "play_sound", burst_pitch)
		
		tween.interpolate_callback(exploding_coin, icon_delay, "set_visible", true)
		tween.interpolate_property(exploding_coin, position_key, start_point, random_position_on_circle, explosion_duration, Tween.TRANS_CUBIC, Tween.EASE_OUT, icon_delay)
		
		tween.follow_property(exploding_coin, position_key, random_position_on_circle, destination, "rect_global_position", animation_duration, Tween.TRANS_CUBIC, Tween.EASE_IN_OUT, explosion_duration + icon_delay - 0.1)
		tween.interpolate_property(exploding_coin, scale_key, Vector2(1.0, 1.0), Vector2(2.0, 2.0), explosion_duration, Tween.TRANS_CUBIC, Tween.EASE_OUT, icon_delay)
		tween.interpolate_property(exploding_coin, scale_key, Vector2(2.0, 2.0), Vector2(1.0, 1.0), animation_duration, Tween.TRANS_CUBIC, Tween.EASE_IN_OUT, explosion_duration + icon_delay - 0.1)
		
		var total_time: = icon_delay + animation_duration + explosion_duration - 0.1
		tween.interpolate_callback(exploding_coin, total_time, "queue_free")
	
	tween.start()
	
