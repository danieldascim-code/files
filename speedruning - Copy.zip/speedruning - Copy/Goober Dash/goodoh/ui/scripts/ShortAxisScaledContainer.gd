tool 
extends Container
class_name ShortAxisScaledContainer

export  var short_axis_min: = 1080
export  var short_axis_max: = 1080

func _notification(what: int):
	match what:
		NOTIFICATION_VISIBILITY_CHANGED, \
		NOTIFICATION_SORT_CHILDREN, \
		NOTIFICATION_RESIZED:
			rescale_children()

func rescale_children():
	var size: = self.rect_size
	var short_axis: = Vector2.AXIS_X
	if size.y < size.x:
		short_axis = Vector2.AXIS_Y
	
	var adjust_ratio: = 1.0
	if size[short_axis] != 0:
		if size[short_axis] < short_axis_min:
			adjust_ratio = short_axis_min / size[short_axis]
		elif size[short_axis] > short_axis_max:
			adjust_ratio = short_axis_max / size[short_axis]
	adjust_ratio = 1.0 / adjust_ratio
	var adjust_scale: = Vector2.ONE * adjust_ratio
	var adjusted_size: = size / adjust_ratio
	
	for i in get_child_count():
		var c: = get_child(i) as Control
		if c:
			fit_child_in_rect(c, Rect2(Vector2.ZERO, adjusted_size))
			c.rect_pivot_offset = Vector2.ZERO
			c.rect_scale = adjust_scale
