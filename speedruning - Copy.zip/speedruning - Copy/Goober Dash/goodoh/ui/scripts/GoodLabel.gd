tool 
extends Label
class_name GoodLabel

export  var offset: = Vector2.ZERO setget set_offset
export  var anchor_to_parent: = Vector2(0.5, 0.5) setget set_anchor_to_parent
export  var pivot: = Vector2(0.5, 0.5) setget set_pivot
export  var left_margin: = 0.0 setget set_left_margin
export  var right_margin: = 0.0 setget set_right_margin
export  var fit_inside_parent: = true
export  var override_max_width: = - 1.0 setget set_override_max_width

export  var enable_constant_update: = false

export  var disable_anchor_point: = false
export  var smart_wrap: = - 1

func _ready():
	
	var _error: = self.connect("minimum_size_changed", self, "on_minimum_size_changed")
	_error = self.connect("item_rect_changed", self, "on_item_rect_changed")
	var parent_control: = self.get_parent_control()
	if parent_control:
		parent_control.connect("resized", self, "on_parent_resized")
	update_label()

func on_item_rect_changed():
	pass
	
	
	

func _process(delta: float) -> void :
	if enable_constant_update and is_visible_in_tree():
		update_label()

func on_parent_resized():
	update_label()

func on_minimum_size_changed():
	update_label()
	
func set_right_margin(f: float):
	right_margin = f
	if is_inside_tree():
		update_label()
	
func set_left_margin(f: float):
	left_margin = f
	if is_inside_tree():
		update_label()

func set_pivot(v: Vector2):
	pivot = v
	if is_inside_tree():
		apply_anchor_point()

func set_override_max_width(m: float):
	override_max_width = m
	if is_inside_tree():
		update_label()

func set_offset(p: Vector2):
	offset = p
	if is_inside_tree():
		apply_anchor_point()

func set_anchor_to_parent(a: Vector2):
	anchor_to_parent = a
	if is_inside_tree():
		apply_anchor_point()


func update_label():
	
	do_smart_wrap()
	fit_rect_to_text()
	scale_label_to_max_width()
	apply_anchor_point()

func do_smart_wrap():
	if smart_wrap > 0:
		var first_whitespace: = text.find(" ")
		var should_autowrap: = first_whitespace > 0 and first_whitespace <= smart_wrap
		var is_change: = should_autowrap != autowrap
		autowrap = should_autowrap
		if is_change and Engine.editor_hint:
			call_deferred("property_list_changed_notify")

func fit_rect_to_text():
	var max_width = get_max_width()
	if not self.autowrap:
		self.rect_min_size = Vector2.ZERO
	else:
		self.rect_min_size = Vector2(max_width, 0.0)
	
	self.rect_size = get_minimum_size()

func scale_label_to_max_width():
	var max_width = get_max_width()
	if max_width > 0.001:
		var label_width: = max(self.rect_size.x, 1.0)
		var label_scale: float = clamp(max_width / label_width, 0.0, 1.0)
		self.rect_scale = Vector2(label_scale, label_scale)

func apply_anchor_point():
	if disable_anchor_point:
		return
	var position_in_parent: = Vector2.ZERO
	var parent_control: = get_parent() as Control
	if parent_control:
		position_in_parent = parent_control.rect_size * self.anchor_to_parent
	var margin_delta = Vector2(lerp(left_margin, - right_margin, self.pivot.x), 0.0)
	var pivot_point: = self.rect_scale * self.rect_size * self.pivot
	self.rect_position = margin_delta + position_in_parent + offset - pivot_point

func get_max_width():
	var max_width: = - 1.0
	
	if fit_inside_parent:
		var t: = get_parent_control()
		if t:
			max_width = t.rect_size.x - left_margin - right_margin
	
	if override_max_width > 0.001:
		max_width = override_max_width
	
	return max_width
