tool 
extends Control
class_name GoodohSpinner

export  var run_now: = false setget setter

var timer: = 0.0
var spinner_nodes: = []

func setter(value):
	if (value):
		place_buttons()

func _fetch_spinner_nodes():
	spinner_nodes.clear()
	var child_count = get_child_count()
	for i in child_count:
		var child: = get_child(i)
		if child is TextureRect:
			spinner_nodes.append(child)

func _ready():
	_fetch_spinner_nodes()

func _process(delta):
	timer += delta * 1.0
	var child_count = spinner_nodes.size()
	for i in child_count:
		var t: float = fmod(i, child_count) / float(child_count)
		var child: TextureRect = spinner_nodes[i]
		child.modulate.a = (sin((t * PI * 2.0) + timer * 10.0) + 1.0) / 2.0


func place_buttons():
	_fetch_spinner_nodes()
	if spinner_nodes.empty():
		return
	var angle_increment: = (2.0 * PI) / spinner_nodes.size()
	var my_size = get_size()
	var center = get_size() / 2.0
	center.y *= - 1
	
	var rect = min(my_size.x, my_size.y) / 2.0

	var max_size = rect * 0.6
	var min_size = rect * 1.0

	var width = max_size - min_size
	var half_size = min_size + width / 2

	var angle = - PI + PI / 4
	for spinner_node in spinner_nodes:
		var size = spinner_node.get_size() / 3 * spinner_node.rect_scale

		
		

		
		if width < size.x: size.x = 0
		if width < size.y: size.y = 0

		
		var x = center.x + cos(angle) * (half_size + size.x)
		var y = center.y + sin(angle) * (half_size + size.y)

		var corner_pos = Vector2(x, - y) - (spinner_node.get_size() * spinner_node.rect_scale / 2)
		spinner_node.set_position(corner_pos)

		
		angle += angle_increment

