tool 
extends Node
class_name GoodTweener

export (NodePath) var target_path
onready var target: = get_node_or_null(target_path) as Node

export (NodePath) var tween_path
onready var tween: = get_node_or_null(tween_path) as Tween

export (Array, Resource) var tween_list: = []
export  var append_tween: = false setget set_append_tween

export  var repeat: = false
export  var parallel: = false
export  var cancel_current_tweens_on_play: = true
export  var set_property_to_first_value_on_ready: = false
export  var set_property_to_second_value_on_ready: = false
export  var editor_play: = false setget do_editor_play
export  var editor_stop: = false setget do_editor_stop
export  var play_on_ready: = false

func _init() -> void :
	tween_list = []

func _ready():
	if not Engine.editor_hint:
		assert (tween)
		assert (target)
		if set_property_to_first_value_on_ready:
			set_to_first_value()
		if set_property_to_second_value_on_ready:
			set_to_first_final_value()
		if play_on_ready:
			call_deferred("play")

func set_to_first_value():
	if tween_list.size() > 0:
		var first_tween: = tween_list[0] as TweenData
		var initial_value = first_tween.initial_value()
		if initial_value != null:
			target.set_indexed(first_tween.property, initial_value)

func set_to_first_final_value():
	if tween_list.size() > 0:
		var first_tween: = tween_list[0] as TweenData
		var final_value = first_tween.final_value()
		if final_value != null:
			target.set_indexed(first_tween.property, final_value)

func do_editor_play(b: bool):
	if is_inside_tree() and b:
		target = get_node_or_null(target_path) as Node
		tween = get_node_or_null(tween_path) as Tween
		play()

func do_editor_stop(b: bool):
	if is_inside_tree() and b:
		target = get_node_or_null(target_path) as Node
		tween = get_node_or_null(tween_path) as Tween
		tween.remove_all()
		set_to_first_value()

func set_append_tween(b: bool):
	if b and is_inside_tree():
		tween_list.append(TweenData.new())
		property_list_changed_notify()

func play():
	if cancel_current_tweens_on_play:
		tween.remove_all()
	
	var duration_thus_far: = 0.0
	var previous_final_value = null
	
	for data in tween_list:
		var t: = data as TweenData
		assert (t)
		if t:
			var i = null
			if t.initial_value_type == TweenData.InitialValueType.Explicit:
				i = t.initial_value()
			elif t.initial_value_type == TweenData.InitialValueType.PreviousFinal:
				i = previous_final_value
			tween.interpolate_property(target, t.property, i, t.final_value(), t.duration, t.transition, t.ease_type, duration_thus_far + t.delay)
			if not parallel:
				duration_thus_far += t.delay + t.duration
			previous_final_value = t.final_value()
	
	if repeat:
		tween.repeat = true
	
	tween.start()
