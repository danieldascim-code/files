extends Reference
class_name GoodTweens

static func shake_tween(tween: SceneTreeTween, node: Node, property: String, initial_rotation: float, amplitude: float, num_shakes: int, duration: float, direction: bool):
	var direction_factor: = - 1.0
	if direction:
		direction_factor = 1.0
	var first_slerpitude: = initial_rotation + - direction_factor * amplitude
	var duration_per_shake: = duration / (num_shakes + 0.5)
	tween.tween_property(node, property, first_slerpitude, duration_per_shake * 0.25).from(initial_rotation)
	for i in num_shakes:
		
		var slerpitude: float = direction_factor * lerp(amplitude, 0.0, float(i) / float(num_shakes))
		var a: = initial_rotation + slerpitude
		var b: = initial_rotation - slerpitude
		tween.tween_property(node, property, a, duration_per_shake * 0.5)
		tween.tween_property(node, property, b, duration_per_shake * 0.5)
	tween.tween_property(node, property, initial_rotation, duration_per_shake * 0.25)
