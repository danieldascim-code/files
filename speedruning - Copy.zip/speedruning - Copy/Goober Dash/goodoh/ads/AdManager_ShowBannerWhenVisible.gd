extends Node2D
class_name AdManager_ShowBannerWhenVisible

func _ready() -> void :
	connect("visibility_changed", self, "on_visibility_changed")
	call_deferred("_refresh")

func _refresh():
	if is_visible_in_tree():
		AdManager.show_banner()
	else:
		AdManager.hide_banner()

func on_visibility_changed():
	_refresh()

func _exit_tree():
	AdManager.hide_banner()

func _process(delta):
	if is_visible_in_tree():
		AdManager.request_banner()
