extends Node


func _enter_tree():
	AdManager.show_banner()
	
func _exit_tree():
	AdManager.hide_banner()

func _process(delta):
	AdManager.request_banner()
