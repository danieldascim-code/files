extends Node
class_name OutliveParent

export  var delay: = 0.0

onready var node: = get_parent() as Node
onready var parent: = node.get_parent() as Node
onready var grandparent: = parent.get_parent() as Node
var has_reparented: = false

func _ready():
	call_deferred("reparent")

func reparent():
	parent.remove_child(node)
	grandparent.add_child(node)
	parent.connect("tree_exiting", self, "on_parent_exit")
	has_reparented = true

func on_parent_exit():
	parent.disconnect("tree_exiting", self, "on_parent_exit")
	if is_inside_tree():
		if delay > 0.0:
			yield(get_tree().create_timer(delay), "timeout")
		node.queue_free()
