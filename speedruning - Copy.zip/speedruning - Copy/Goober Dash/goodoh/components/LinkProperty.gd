tool 
extends Node
class_name LinkProperty

export  var update_continuously: = true
export  var other_node: NodePath setget set_other_node
var other_property_name: = "" setget set_other_property_name
var property_name: = "" setget set_property_name
var flip_bool: = false

var parent: Node
var other: Node

func _ready():
	if Engine.is_editor_hint():
		set_process(false)
		return
	
	parent = get_parent()
	other = get_node(other_node)
	
	_copy_property()
	set_process(update_continuously)

func _process(_delta: float):
	_copy_property()

func _copy_property():
	var other_data = other.get(other_property_name)
	if other_data is bool and flip_bool:
		other_data = not other_data
	
	parent.set(property_name, other_data)

func _get_configuration_warning():
	var warn: = ""
	
	var other_node_instance: = get_node_or_null(other_node)
	
	if other_node_instance == null:
		warn += "\nOther node does not exist."
	
	if other_property_name.empty():
		warn += "\nNeed to set other property name."
	elif other_node_instance and not other_property_name in other_node_instance:
		warn += "\nOther property does not exist in other node."
	
	if property_name.empty():
		warn += "\nNeed to set parent property name."
	elif get_parent() and not property_name in get_parent():
		warn += "\nProperty does not exist in parent."
	
	var linked_value = other_node_instance.get(other_property_name) if other_node_instance else null
	var self_value = get_parent().get(property_name)
	if other_node_instance and typeof(linked_value) != typeof(self_value):
		warn += "\nLinked value is a different type than the parent\'s value."
	
	if other_node_instance and typeof(linked_value) != TYPE_BOOL and flip_bool:
		warn += "\nFlip bool is enabled for a non-bool property, so it will have no effect."
	
	return warn




func set_other_node(value: NodePath):
	other_node = value
	_update_list()

func set_other_property_name(value: String):
	other_property_name = value
	_update_list()

func set_property_name(value: String):
	property_name = value
	_update_list()

func property_can_revert(property: String):
	if property == "other_property_name":
		return true
	if property == "property_name":
		return true
	if property == "flip_bool":
		return true
	return false

func property_get_revert(property: String):
	if property == "other_property_name":
		return ""
	if property == "property_name":
		return ""
	if property == "flip_bool":
		return false
	return null

func _update_list():
	property_list_changed_notify()
	if is_inside_tree():
		get_tree().emit_signal("node_configuration_warning_changed", self)

const PROPERTY_HINT_PROPERTY_OF_INSTANCE: = 32

func _get_property_list():
	var properties: = []
	
	if not is_inside_tree():
		
		properties = [
			{
				name = "other_property_name", 
				type = TYPE_STRING, 
				usage = PROPERTY_USAGE_DEFAULT
			}, 
			{
				name = "property_name", 
				type = TYPE_STRING, 
				usage = PROPERTY_USAGE_DEFAULT
			}, 
			{
				name = "flip_bool", 
				type = TYPE_BOOL, 
				usage = PROPERTY_USAGE_DEFAULT
			}
		] + properties
		return properties
	
	var other_node_instance: = get_node_or_null(other_node)
	
	if flip_bool or (other_node_instance and typeof(other_node_instance.get(other_property_name)) == TYPE_BOOL):
		properties = [
			{
				name = "flip_bool", 
				type = TYPE_BOOL, 
				usage = PROPERTY_USAGE_DEFAULT
			}
		] + properties
	
	properties = [
		{
			name = "other_property_name", 
			type = TYPE_STRING, 
			usage = PROPERTY_USAGE_DEFAULT, 
			hint = PROPERTY_HINT_PROPERTY_OF_INSTANCE, 
			hint_string = str(other_node_instance.get_instance_id()) if other_node_instance else ""
		}, 
		{
			name = "property_name", 
			type = TYPE_STRING, 
			usage = PROPERTY_USAGE_DEFAULT, 
			hint = PROPERTY_HINT_PROPERTY_OF_INSTANCE, 
			hint_string = str(get_parent().get_instance_id())
		}
	] + properties
	return properties
