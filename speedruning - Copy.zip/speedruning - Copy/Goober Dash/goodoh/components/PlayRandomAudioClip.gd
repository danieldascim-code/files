extends Node

class_name PlayRandomAudioClip

onready var parent: = get_parent()

export (Array, AudioStream) var audio_clips: = []

func _ready():
	assert (parent.get_class() in ["AudioStreamPlayer", "AudioStreamPlayer2D", "AudioStreamPlayer3D"])

func play():
	var random_index: = randi() %audio_clips.size()
	var audio_clip: = audio_clips[random_index] as AudioStream
	assert (audio_clip != null)
	parent.stream = audio_clip
	parent.play()
