tool 
extends Node
class_name MatchRectSize

onready var parent: = get_parent() as Control
export (NodePath) var target_control
onready var target: = get_node(target_control) as Control

export  var match_x: = true
export  var match_y: = true

export  var margin_x: = 0.0
export  var margin_y: = 0.0
export  var constant_update: = false

export  var respect_min_size_x: = false
export  var respect_min_size_y: = false

func _ready():
	if not Engine.editor_hint:
		assert (target != null)
		assert (parent != null)
	target.connect("resized", self, "on_target_resized")
	call_deferred("on_target_resized")

func on_target_resized():
	var target_size: = parent.rect_min_size
	
	if match_x:
		target_size.x = (abs(target.rect_scale.x) * target.rect_size.x) + margin_x
	if match_y:
		target_size.y = (abs(target.rect_scale.y) * target.rect_size.y) + margin_y
	
	if respect_min_size_x:
		target_size.x = max(parent.rect_min_size.x, target_size.x)
	if respect_min_size_y:
		target_size.y = max(parent.rect_min_size.y, target_size.y)
	
	if not (respect_min_size_x or respect_min_size_y):
		parent.rect_min_size = target_size
	
	parent.rect_size = target_size

func _process(delta):
	if Engine.editor_hint:
		target = get_node_or_null(target_control) as Control
		if target:
			parent = get_parent() as Control
			on_target_resized()
	else:
		if constant_update:
			on_target_resized()












