extends Node

class_name LoadSceneOnPress

export (PackedScene) var scene
onready var parent_button: = get_parent() as Button

var is_loading: = false

export  var delay: = 0.0

func _ready():
	parent_button.connect("pressed", self, "on_button_pressed")

func on_button_pressed():
	if not is_loading:
		is_loading = true
		if delay > 0.0:
			yield(get_tree().create_timer(delay), "timeout")
		
		ScreenTransitions.fade_to_scene(scene)
