extends Node
class_name PlayParticlesOnce

export  var play_on_ready: = false

onready var parent_particles: = get_parent() as Particles2D

var timer: = 0.0
var has_played: = false
var total_lifetime: = 0.0

func _enter_tree() -> void :
	parent_particles = get_parent() as Particles2D
	parent_particles.emitting = false

func _ready() -> void :
	if play_on_ready:
		play()

func play():
	if not parent_particles.emitting:
		has_played = true
		total_lifetime = parent_particles.lifetime * 2.0
		parent_particles.emitting = true
		parent_particles.one_shot = true

func _process(delta: float) -> void :
	if has_played:
		timer += delta
		if timer >= total_lifetime:
			queue_free()
