extends Node
class_name SetVisibilityOnInputMode

export  var visible_on_kbm: = false
export  var visible_on_joypad: = false
export  var visible_on_touchscreen: = false


export  var keyboard_steals_touchscreen: = false

enum InputMode{
	INPUT_KEYBOARD_MOUSE, 
	INPUT_JOYPAD, 
	INPUT_TOUCHSCREEN, 
	UNDEFINED
}

const global_current_mode: = {"mode": InputMode.UNDEFINED}
var current_mode: int = InputMode.INPUT_KEYBOARD_MOUSE

func _ready():
	if global_current_mode["mode"] == InputMode.UNDEFINED:
		if Input.get_connected_joypads().size() > 0:
			current_mode = InputMode.INPUT_JOYPAD
		elif OS.has_feature("mobile"):
			current_mode = InputMode.INPUT_TOUCHSCREEN
		global_current_mode["mode"] = current_mode
	else:
		current_mode = global_current_mode["mode"]
	update_visibility()

func _input(event):
	var touchscreen_mode: = SavedSettings.get_value("touchscreen_mode", false) as bool
	var mobile: = OS.has_feature("mobile") or touchscreen_mode
	
	if event is InputEventKey:
		if current_mode != InputMode.INPUT_TOUCHSCREEN or keyboard_steals_touchscreen:
			current_mode = InputMode.INPUT_KEYBOARD_MOUSE
		
	elif event is InputEventMouse or event is InputEventGesture or event is InputEventScreenTouch:
		if mobile:
			current_mode = InputMode.INPUT_TOUCHSCREEN
		else:
			current_mode = InputMode.INPUT_KEYBOARD_MOUSE
		
	elif event is InputEventJoypadButton or event is InputEventJoypadMotion:
		current_mode = InputMode.INPUT_JOYPAD
	
	global_current_mode["mode"] = current_mode
	
	update_visibility()

func update_visibility():
	var show: bool
	match current_mode:
		InputMode.INPUT_KEYBOARD_MOUSE:
			show = visible_on_kbm
		InputMode.INPUT_JOYPAD:
			show = visible_on_joypad
		InputMode.INPUT_TOUCHSCREEN:
			show = visible_on_touchscreen
		_:
			show = false
			printerr("[SetVisibilityOnInputMode] current_mode (%s) is invalid." % current_mode)
	get_parent().visible = show
