extends Node
class_name PlayChildParticlesOnce

var timer: = 0.0
var has_played: = false
var total_lifetime: = 0.0

export  var play_on_ready = true

export (Array, NodePath) var _particles
var particles: = []

func _ready() -> void :
	for n in _particles:
		var p = get_node(n)
		assert (p is Particles2D)
		particles.append(p)
		p.one_shot = true
		p.emitting = false
		total_lifetime = max(total_lifetime, p.lifetime * 2.0)
	
	if play_on_ready:
		play()

func play():
	has_played = true
	for p in particles:
		p.emitting = true

func _process(delta: float) -> void :
	if has_played:
		timer += delta
		if timer >= total_lifetime:
			queue_free()
