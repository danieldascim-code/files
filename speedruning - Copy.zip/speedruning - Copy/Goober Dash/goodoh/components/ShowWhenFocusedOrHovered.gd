extends Node
class_name ShowWhenFocusedOrHovered

export (NodePath) var _target
onready var target: = get_node(_target) as Control

onready var parent_control: = get_parent() as Control

func _ready():
	target.connect("mouse_entered", self, "refresh_defer")
	target.connect("mouse_exited", self, "refresh_defer")
	target.connect("focus_entered", self, "refresh_defer")
	target.connect("focus_exited", self, "refresh_defer")
	
	refresh_defer()

func refresh_defer():
	call_deferred("refresh")

func refresh():
	parent_control.visible = target.is_hovered() or target.has_focus()
