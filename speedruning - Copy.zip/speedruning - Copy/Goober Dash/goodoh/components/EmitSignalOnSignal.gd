extends Node
class_name EmitSignalOnSignal

onready var parent_node: = get_parent() as Node
export  var _signal: = ""

export  var _target: NodePath
onready var target: = get_node(_target) as Node
export  var target_signal: = ""

func _ready():
	parent_node.connect(_signal, target, "emit_signal", [target_signal])
