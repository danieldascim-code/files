extends Node

class_name SetAsTopLevel

func _ready():
	assert (get_parent() is Spatial or get_parent() is CanvasItem)
	get_parent().set_as_toplevel(true)
