tool 
extends Node
class_name UseSteamVirtualKeyboard

export  var big_picture_input_description: = ""

var _Steam: Object = null
onready var lineedit: = get_parent() as LineEdit
onready var disabled: = not OS.has_feature("steam")

var is_using_joypad: bool = false

var lineedit_is_focused: = false

func _ready():
	if Engine.is_editor_hint() or disabled:
		return

	_Steam = Engine.get_singleton("Steam")
	
	if _Steam == null:
		disabled = true
		printerr("[UseSteamVirtualKeyboard] Steam singleton is missing.")
		return

	if not _Steam.isSteamRunning():
		printerr("[UseSteamVirtualKeyboard] Steam is not running.")
	
	if lineedit == null:
		if Engine.is_editor_hint():
			update_configuration_warning()
		return
	
	if Input.get_connected_joypads().size() > 0:
		is_using_joypad = true
	elif OS.has_feature("mobile"):
		is_using_joypad = false
	
	lineedit.connect("focus_entered", self, "set", ["lineedit_is_focused", true])
	lineedit.connect("focus_entered", self, "_open_keyboard")
	lineedit.connect("focus_exited", self, "set", ["lineedit_is_focused", false])
	
	_Steam.connect("gamepad_text_input_dismissed", self, "_on_gamepad_text_input_dismissed")

func _input(event):
	if event is InputEventKey:
		is_using_joypad = false
	elif event is InputEventMouse or event is InputEventGesture or event is InputEventScreenTouch:
		is_using_joypad = false
	elif event is InputEventJoypadButton or event is InputEventJoypadMotion:
		is_using_joypad = true
		
		if event is InputEventJoypadButton and event.pressed and lineedit_is_focused:
			if event.button_index == JOY_BUTTON_0:
				_open_keyboard()

func _open_keyboard():
	if disabled:
		return
	
	
	
	if _Steam.isSteamRunningOnSteamDeck():
		var floating_input_mode: = _Steam.FLOATING_GAMEPAD_TEXT_INPUT_MODE_SINGLE_LINE as int
		match lineedit.virtual_keyboard_type:
			LineEdit.KEYBOARD_TYPE_EMAIL_ADDRESS:
				floating_input_mode = _Steam.FLOATING_GAMEPAD_TEXT_INPUT_MODE_EMAIL
			LineEdit.KEYBOARD_TYPE_NUMBER, LineEdit.KEYBOARD_TYPE_NUMBER_DECIMAL:
				floating_input_mode = _Steam.FLOATING_GAMEPAD_TEXT_INPUT_MODE_NUMERIC
		
		
		
		var size: = OS.window_size
		var success: = _Steam.showFloatingGamepadTextInput(floating_input_mode, 0, size.y * 0.5, size.x, size.y * 0.5) as bool
		
		if success:
			return
	
	if not is_using_joypad:
		return
	
	
	if _Steam.isSteamInBigPictureMode():
		var input_mode: = _Steam.GAMEPAD_TEXT_INPUT_MODE_NORMAL as int
		match lineedit.virtual_keyboard_type:
			LineEdit.KEYBOARD_TYPE_PASSWORD:
				input_mode = _Steam.GAMEPAD_TEXT_INPUT_MODE_PASSWORD
		
		var line_input_mode: = _Steam.GAMEPAD_TEXT_INPUT_LINE_MODE_SINGLE_LINE as int
		
		var success: = _Steam.showGamepadTextInput(input_mode, line_input_mode, big_picture_input_description, lineedit.max_length, lineedit.text) as bool
		
		if success:
			return
	
	printerr("[UseSteamVirtualKeyboard] failed to show gamepad keyboard. need to enable big picture mode or play on steam deck.")

func _close_keyboard():
	
	
	pass

func _on_gamepad_text_input_dismissed(submitted: bool, submitted_text: String):
	print("submitted: " + str(submitted))
	print("submitted_text: " + str(submitted_text))
	if submitted:
		lineedit.text = submitted_text

func _get_configuration_warning() -> String:
	var warn: = ""
	
	if lineedit == null and is_inside_tree():
		warn += "\nUseSteamVirtualKeyboard only works as a child of LineEdit."
	
	return warn
