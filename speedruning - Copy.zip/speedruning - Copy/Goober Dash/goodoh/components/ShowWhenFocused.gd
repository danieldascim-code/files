extends Node
class_name ShowWhenFocused

export (NodePath) var _control

onready var control: = get_node(_control) as Control
onready var parent_control: = get_parent() as Control

func _ready():
	control.connect("focus_entered", self, "refresh")
	control.connect("focus_exited", self, "refresh")
	
	refresh()

func refresh():
	parent_control.visible = control.has_focus()
