tool 
extends Node
class_name GradientTint

export (Gradient) var gradient: Gradient
export  var apply_to_children: = false

func apply_gradient_tint(g: float):
	var parent_canvas_item: = get_parent() as CanvasItem
	if parent_canvas_item:
		if apply_to_children:
			parent_canvas_item.modulate = gradient.interpolate(g)
		else:
			parent_canvas_item.self_modulate = gradient.interpolate(g)
