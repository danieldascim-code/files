tool 
extends Node2D
class_name Node2DShaderUniforms

onready var mesh_instance: = get_parent() as MeshInstance2D

export  var _position: = false
export  var _rotation: = false
export  var _scale: = false

export  var _global_position: = false
export  var _global_rotation: = false
export  var _global_scale: = false

func _ready():
	set_notify_transform(true)
	set_notify_local_transform(true)
	_apply_shader_uniforms()

func _notification(what):
	match what:
		NOTIFICATION_TRANSFORM_CHANGED:
			get_global_transform()
			_apply_shader_uniforms()
		NOTIFICATION_LOCAL_TRANSFORM_CHANGED:
			_apply_shader_uniforms()

func _apply_shader_uniforms():
	if mesh_instance:
		var m: ShaderMaterial = mesh_instance.material
		if m:
			if _position:
				m.set_shader_param("position", mesh_instance.position)
			if _rotation:
				m.set_shader_param("rotation", mesh_instance.rotation)
			if _scale:
				m.set_shader_param("scale", mesh_instance.scale)
			
			if _global_position or _global_rotation or _global_scale:
				var g: = mesh_instance.get_global_transform()
				if _global_position:
					m.set_shader_param("global_position", g.get_origin())
				if _global_rotation:
					m.set_shader_param("global_rotation", g.get_rotation())
				if _global_scale:
					m.set_shader_param("global_scale", g.get_scale())
