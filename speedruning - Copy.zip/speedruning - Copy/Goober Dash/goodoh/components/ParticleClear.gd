extends Node2D
class_name ParticleClear









onready var particles: Particles2D = get_parent()
var has_emitted_on_screen: = false

func _process(delta: float) -> void :
	var particles_rect: = particles.visibility_rect
	particles_rect.position += particles.global_position
	var is_on_screen: = ViewportRectCalculator.viewport_visible_rect.intersects(particles_rect, true)
	
	if not has_emitted_on_screen and is_on_screen and particles.emitting:
		has_emitted_on_screen = true
	if has_emitted_on_screen and not is_on_screen:
		has_emitted_on_screen = false
		
		
		particles.amount = particles.amount
		
