extends Node
class_name ShowWhenToggled

export (NodePath) var _button
onready var button: = get_node(_button) as BaseButton

onready var parent_control: = get_parent() as Control
export  var negate: = false

func _ready():
	button.connect("toggled", self, "on_button_toggled")
	on_button_toggled(button.pressed)

func on_button_toggled(toggled: bool):
	if negate:
		toggled = not toggled
	parent_control.visible = toggled
