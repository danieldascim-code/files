tool 
extends Node

class_name ForceMinSize
onready var parent_control: = get_parent() as Control

func _ready():
	pass

func _process(delta: float) -> void :
	force_min_size()

func force_min_size():
	parent_control.rect_size = Vector2.ZERO
