




extends Node

class_name MatchVisibility

export (NodePath) var target
export  var invert: = false

func _ready():
	
	var parent = get_parent()
	assert (parent is Control)
	var target_node = get_node(target)
	
	if target_node is Control:
		target_node.connect("visibility_changed", self, "on_visibility_changed", [target_node])
	else:
		printerr("[MatchVisibility] target is not control.")
		print_tree_pretty()
		assert (false)
	
	
	on_visibility_changed(target_node)
	
func on_visibility_changed(t):
	var parent = get_parent()
	assert (parent is Control)
	
	
	var v: bool = t.visible
	if invert:
		v = not v
	
	
	parent.visible = v
	
func _exit_tree():
	
	var target_node = get_node(target)
	if target_node is Control:
		target_node.disconnect("visibility_changed", self, "on_visibility_changed")
