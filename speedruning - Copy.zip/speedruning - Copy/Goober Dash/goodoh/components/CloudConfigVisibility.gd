extends Node
class_name CloudConfigVisibility

onready var parent_control: = get_parent() as Control

export  var cloud_config_key: = ""
export  var default_value: = false


func _ready() -> void :
	Moonlight.connect("on_cloud_config_fetched", self, "_refresh")
	_refresh()

func _refresh():
	parent_control.visible = cloud_config_bool_value()

func cloud_config_bool_value() -> bool:
	var visibility_value = DictionaryUtils.nested_dictionary_lookup(cloud_config_key, Moonlight.cloud_config)
	if visibility_value is bool:
		return visibility_value
	return default_value
