extends Node
class_name EmitSignalOnPress

onready var parent_button: = get_parent() as BaseButton

export  var _target: NodePath
onready var target: = get_node(_target) as Node
export  var _signal: = ""

func _ready():
	parent_button.connect("pressed", target, "emit_signal", [_signal])
