extends Node
class_name ShowWhenPressed

export (NodePath) var _button
onready var button: = get_node(_button) as BaseButton

onready var parent_control: = get_parent() as Control
export  var negate: = false

func _ready():
	button.connect("button_down", self, "on_button_down")
	button.connect("button_up", self, "on_button_up")
	_refresh()

func on_button_down():
	_refresh()

func on_button_up():
	_refresh()
	
func _refresh():
	var should_show: = button.pressed
	if negate:
		should_show = not should_show
	parent_control.visible = should_show
