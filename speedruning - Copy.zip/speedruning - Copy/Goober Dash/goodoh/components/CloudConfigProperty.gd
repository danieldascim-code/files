tool 
extends Node
class_name CloudConfigProperty

export  var cloud_config_key: = ""
export  var property_name: = "" setget set_property_name
var property_type: = 0
onready var parent: = get_parent()
onready var default_value = parent.get(property_name)

func _ready() -> void :
	compute_property_type()
	if not Engine.editor_hint:
		Moonlight.connect("on_cloud_config_fetched", self, "_refresh")
		_refresh()

func _refresh():
	var value = DictionaryUtils.nested_typed_dictionary_lookup(cloud_config_key, Moonlight.cloud_config, property_type)
	if value == null:
		value = default_value
	parent.set(property_name, value)

func set_property_name(s: String):
	property_name = s
	if is_inside_tree():
		compute_property_type()
		update_configuration_warning()
	
func compute_property_type():
	property_type = typeof(parent.get(property_name))

func _get_configuration_warning():
	if parent and not property_name in parent:
		return "Property name is invalid"
		
	return ""
