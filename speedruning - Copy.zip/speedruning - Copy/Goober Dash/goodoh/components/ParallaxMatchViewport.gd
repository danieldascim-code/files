extends Node
class_name ParallaxMatchViewport

export (Array, NodePath) var _parallax_layers: Array
onready var parent_parallax: = get_parent() as ParallaxBackground

var parallax_layers: = []

func _ready() -> void :
	_fetch_nodes()

func _process(delta: float) -> void :
	do()

func do():
	var viewport: = parent_parallax.get_viewport()
	
	var size: = viewport.get_visible_rect().size
	for p in parallax_layers:
		var parallax_layer: = p as ParallaxLayer
		parallax_layer.motion_mirroring = size

func _fetch_nodes():
	for p in _parallax_layers:
		var parallax_layer: = get_node(p) as ParallaxLayer
		assert (parallax_layer)
		parallax_layers.append(parallax_layer)
