tool 
extends Node
class_name PlayChildParticles

export  var play_child_particles: = false setget set_editor_play
export  var always_restart: = false

func play():
	play_or_stop(true)

func stop():
	play_or_stop(false)

func play_or_stop(play: bool):
	for i in get_parent().get_child_count():
		var child: = get_parent().get_child(i)
		var child_particles: = child as Particles2D
		if child_particles:
			if play:
				if ( not child_particles.emitting) or always_restart:
					child_particles.restart()
				else:
					child_particles.emitting = true
			else:
				child_particles.emitting = false

func set_editor_play(b: bool):
	play_child_particles = b
	if is_inside_tree():
		play_or_stop(b)
