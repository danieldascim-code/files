extends Node
class_name SetVisibilityOnSignal





export  var signal_name: = ""
export  var visible: = false
export (NodePath) var target_path: NodePath

onready var target: = get_node(target_path) as CanvasItem
onready var parent_node: = get_parent() as Node

func _ready():
	assert (target)
	parent_node.connect(signal_name, self, "on_signal")

func on_signal():
	target.visible = visible
