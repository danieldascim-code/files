extends Node
class_name CallMethodAfterDelay

onready var parent: = get_parent() as Node

var running: = false
var timer: = 0.0
var delay: = 0.0
var method_name: = ""

func _ready():
	if not running:
		set_process(false)

func call_method_after_delay(_method_name: String, _delay: float):
	running = true
	delay = _delay
	method_name = _method_name
	timer = 0.0
	self.set_process(true)

func _process(delta):
	if running:
		timer += delta
		if timer > delay:
			parent.call_deferred(method_name)
			running = false
			timer = 0.0
			self.set_process(false)
