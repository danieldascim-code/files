extends Node

class_name PressButtonOnPress

export (NodePath) var _target
onready var target_button: = get_node(_target) as BaseButton
onready var target_control: = get_node(_target) as Control
onready var parent_button: = get_parent() as BaseButton

export  var push_style: = false

func _ready():
	parent_button.connect("pressed", self, "on_button_pressed")
	parent_button.connect("button_down", self, "on_button_down")
	parent_button.connect("button_up", self, "on_button_up")
	parent_button.connect("mouse_entered", self, "on_mouse_entered")
	parent_button.connect("mouse_exited", self, "on_mouse_exit")

func on_mouse_entered():
	if push_style:
		target_control.notification(Control.NOTIFICATION_MOUSE_ENTER)

func on_mouse_exit():
	if push_style:
		target_control.notification(Control.NOTIFICATION_MOUSE_EXIT)

func on_button_down():
	if push_style and target_button:
		var input_event: = InputEventMouseButton.new()
		input_event.button_index = BUTTON_LEFT
		input_event.pressed = true
		target_button._gui_input(input_event)

func on_button_up():
	if push_style and target_button:
		var input_event: = InputEventMouseButton.new()
		input_event.button_index = BUTTON_LEFT
		input_event.pressed = false
		target_button._gui_input(input_event)

func on_button_pressed():
	if not push_style and target_button:
		
		target_button.pressed = true
		target_button.emit_signal("pressed")
