extends Node
class_name CallMethodOnPress

export  var function_name: = ""

export (NodePath) var target_path
export (Array) var arguments
onready var target: = get_node(target_path) as Node

onready var parent_button: = get_parent() as BaseButton

func _ready():
	parent_button.connect("pressed", self, "on_button_pressed")

func on_button_pressed():
	if (arguments and arguments.size() > 0):
		target.callv(function_name, arguments)
	else:
		target.call(function_name)

