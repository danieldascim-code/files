extends Node
class_name ReloadPlaceholder

export  var _blink_enabled: = true
export  var _blink_speed: = 0.3

func _ready():
	var parent_line_edit: = get_parent() as LineEdit
	
	parent_line_edit.placeholder_text = parent_line_edit.placeholder_text
	
	parent_line_edit.caret_blink = _blink_enabled
	parent_line_edit.caret_blink_speed = _blink_speed
