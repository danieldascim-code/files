extends Node
class_name CallMethodOnAction

export  var action: = ""
export  var function_name: = ""
export (Array) var arguments
export  var use_unhandled_input: = false
export  var mark_input_as_handled: = false

onready var target: = get_parent() as Node

func handle_event(event: InputEvent):
	if event.is_action_pressed(action):
		if arguments != null and arguments.size() > 0:
			target.callv(function_name, arguments)
		else:
			target.call(function_name)
		if mark_input_as_handled:
			get_tree().set_input_as_handled()

func _input(event):
	if not use_unhandled_input:
		handle_event(event)

func _unhandled_input(event):
	if use_unhandled_input:
		handle_event(event)
