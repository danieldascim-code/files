extends Node

class_name ShowOnOS


enum OSEnum{android, ios, html5, windows, mac, linux}
export (OSEnum, FLAGS) var show_on_os
onready var parent_control: = get_parent() as Control


export  var test_mock_os_name: = ""

func _ready() -> void :
	parent_control.visible = should_show()

func should_show() -> bool:
	var current_os_int: = current_os_bitmask()
	return show_on_os & current_os_int != 0

func current_os_bitmask() -> int:
	
	
	var current_os: = OS.get_name()
	if OS.is_debug_build():
		if not test_mock_os_name.empty():
			current_os = test_mock_os_name
	
	match current_os:
		"Android":
			return 1 << OSEnum.android
		"iOS":
			return 1 << OSEnum.ios
		"HTML5":
			return 1 << OSEnum.html5
		"OSX":
			return 1 << OSEnum.mac
		"Windows", "UWP":
			return 1 << OSEnum.windows
		"X11":
			return 1 << OSEnum.linux
	printerr("[ShowOnOS] unknown OS.get_name() %s" % [current_os])
	return 0
	
