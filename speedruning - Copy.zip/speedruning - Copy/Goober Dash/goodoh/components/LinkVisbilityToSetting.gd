extends Node
class_name LinkVisibilityToSetting
onready var parent_canvas_item: CanvasItem = get_parent()
export  var setting: = ""
export  var flip_bool: = false

func _ready() -> void :
	if not setting.empty():
		SavedSettings.connect("on_value_changed", self, "on_value_changed")
		var b = SavedSettings.get(setting)
		if typeof(b) == TYPE_BOOL:
			_refresh(b)
	
func on_value_changed(k: String, v):
	if k == setting:
		if typeof(v) == TYPE_BOOL:
			_refresh(v)

func _refresh(b: bool):
	if flip_bool:
		b = not b
	parent_canvas_item.visible = b
