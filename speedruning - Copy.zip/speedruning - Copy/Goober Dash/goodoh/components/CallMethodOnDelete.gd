extends Node
class_name CallMethodOnDelete

export (NodePath) var _target
export  var method_name: = ""
export  var arguments: = []
export  var delay: = 0.0
export  var use_call_deferred: = false

onready var target: = get_node(_target) as Node
onready var parent: = get_parent() as Node

func _ready() -> void :
	target.connect("tree_exiting", self, "on_target_deleted")

func on_target_deleted():
	target.disconnect("tree_exiting", self, "on_target_deleted")
	if delay > 0.0:
		yield(get_tree().create_timer(delay), "timeout")
	
	if arguments and arguments.size() > 0:
		parent.callv(method_name, arguments)
	else:
		if use_call_deferred:
			parent.call_deferred(method_name)
		else:
			parent.call(method_name)
