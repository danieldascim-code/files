extends Node
class_name MultiButton




onready var parent_button: = get_parent() as Control

var sibling_buttons: = []
var pressed_sibling_index: = - 1
const verbose: = false
var touch_index: = - 1

func _ready() -> void :
	for sibling in parent_button.get_children():
		var sibling_button: = sibling as BaseButton
		if sibling_button:
			sibling_buttons.append(sibling_button)
			
			sibling_button.mouse_filter = Control.MOUSE_FILTER_IGNORE
			
			sibling_button.toggle_mode = true
	
	parent_button.connect("gui_input", self, "on_parent_gui_input")

func _input(event: InputEvent) -> void :
	var mouse_press_event: = event as InputEventMouseButton
	var touch_press_event: = event as InputEventScreenTouch
	var is_already_pressed: = pressed_sibling_index != - 1
	if mouse_press_event or touch_press_event:
		var touch_index_of_event: = - 1
		if touch_press_event:
			touch_index_of_event = event.index
		
		if not event.is_pressed():
			if is_already_pressed:
				if touch_index == touch_index_of_event:
					var pressed_button: = sibling_buttons[pressed_sibling_index] as BaseButton
					pressed_sibling_index = - 1
					_release_button(pressed_button)
				
func on_parent_gui_input(event: InputEvent):
	var mouse_press_event: = event as InputEventMouseButton
	var touch_press_event: = event as InputEventScreenTouch
	var mouse_motion_event: = event as InputEventMouseMotion
	var touch_motion_event: = event as InputEventScreenDrag
	var is_already_pressed: = pressed_sibling_index != - 1
	var touch_index_of_event: = - 1
	if touch_press_event or touch_motion_event:
		touch_index_of_event = event.index
	
	if mouse_press_event or touch_press_event:
		if event.is_pressed():
			if not is_already_pressed:
				pressed_sibling_index = find_sibling_at_point(event.position)
				if pressed_sibling_index > - 1:
					touch_index = touch_index_of_event
					_press_button(sibling_buttons[pressed_sibling_index])
		else:
			if is_already_pressed:
				if touch_index == touch_index_of_event:
					var pressed_button: = sibling_buttons[pressed_sibling_index] as BaseButton
					pressed_sibling_index = - 1
					_release_button(pressed_button)
	elif mouse_motion_event or touch_motion_event:
		if is_already_pressed:
			if touch_index_of_event == touch_index:
				var pressing_index: = find_sibling_at_point(event.position)
				if pressing_index > - 1:
					if pressing_index != pressed_sibling_index:
						if pressed_sibling_index > - 1:
							_release_button(sibling_buttons[pressed_sibling_index])
						if pressing_index > - 1:
							_press_button(sibling_buttons[pressing_index])
						pressed_sibling_index = pressing_index

func find_sibling_at_point(point: Vector2) -> int:
	for index in sibling_buttons.size():
		var button: = sibling_buttons[index] as BaseButton
		if button.get_rect().has_point(point):
			return index
	return - 1

func _press_button(button: BaseButton):
	if verbose:
		print("[MultiButton] _press_button(%s)" % [button.name])
	button.pressed = true
	button.emit_signal("button_down")
	button.emit_signal("pressed")
	
func _release_button(button: BaseButton):
	if verbose:
		print("[MultiButton] _release_button(%s)" % [button.name])
	button.pressed = false
	button.emit_signal("button_up")
