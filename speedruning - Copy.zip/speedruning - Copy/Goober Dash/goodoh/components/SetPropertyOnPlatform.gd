tool 
extends Node
class_name SetPropertyOnPlatform





export  var export_features: = "pc,mobile,web"



export  var whitelist: = true
export  var use_deferred: = false

var property_path: String setget set_property_path
var property_type: int setget set_property_type
var property_value setget set_property_value


var disabled: = false setget set_disabled
var mock_export_features: = ""


func _ready():
	if Engine.editor_hint:
		return
	
	if disabled:
		return
	
	if use_deferred:
		call_deferred("set_properties")
	else:
		set_properties()

func set_properties():
	var has_feature: = false
	if OS.has_feature("editor") and not mock_export_features.empty():
		for feature in export_features.split(","):
			if feature in mock_export_features.split(","):
				has_feature = true
				break
	else:
		for feature in export_features.split(","):
			if OS.has_feature(feature):
				has_feature = true
				break
			
			if feature == "mobile" and OS.has_feature("winterpixelads"):
				var is_web_mobile = JavaScript.eval(\
\
				"\n\t\t\t\t\twinterpixelIsMobile();\n\t\t\t\t\t")
				if (is_web_mobile):
					has_feature = true
					break
	
	if has_feature == whitelist:
		var value = property_value
		
		if property_value is NodePath:
			if has_node(property_value):
				value = get_parent().get_path_to(get_node(property_value))
		get_parent().set(property_path, value)

func set_disabled(value: bool):
	disabled = value
	if is_inside_tree():
		get_tree().emit_signal("node_configuration_warning_changed", self)

func _get_configuration_warning():
	var warn: = ""
	
	var default_value = get_parent().get(property_path)
	if typeof(default_value) != typeof(property_value):
		warn += "\nProperty value is a different type than the parent\'s value."
	
	if get_parent() and not property_path in get_parent():
		warn += "\nProperty does not exist in parent."
	
	if disabled:
		warn += "\nNode is disabled. This should be for testing/WIP only."
	
	return warn





const variant_type_enum_hint_string: = "Nil,bool,int,float,String,Vector2,Rect2,Vector3,Transform2D,Plane,Quat,AABB,Basis,Transform,Color,NodePath,RID,Object,Dictionary,Array,PoolByteArray,PoolIntArray,PoolRealArray,PoolStringArray,PoolVector2Array,PoolVector3Array,PoolColorArray"

func is_parent_value() -> bool:
	if property_path.empty():
		return true
	elif get_parent():
		var default_value = get_parent().get(property_path)
		return (typeof(default_value) == typeof(property_value)) and (property_value == default_value)
	else:
		return false

func set_property_path(path: String):
	var was_default_val: = is_parent_value()
	
	property_path = path
	
	
	if was_default_val:
		
		var value = null
		if get_parent():
			value = get_parent().get(property_path)
		if value is NodePath:
			value = get_path_to(get_parent().get_node(value))
		property_value = value
		property_type = typeof(value)
	
	_update_list()

func set_property_value(value):
	property_value = value
	property_type = typeof(value)
	_update_list()

func set_property_type(type: int):
	property_type = type
	_update_list()



func property_can_revert(property: String):
	if property == "property_type":
		return true
	if property == "property_value":
		return true
	return false

func property_get_revert(property: String):
	if property == "property_type":
		return typeof(get_parent().get(property_path))
	if property == "property_value":
		
		var value = get_parent().get(property_path)
		if value is NodePath:
			value = get_path_to(get_parent().get_node(value))
		return value
	return null

func _update_list():
	property_list_changed_notify()
	if is_inside_tree():
		get_tree().emit_signal("node_configuration_warning_changed", self)


func _get_property_list():
	var properties: = [
		
		{
			name = "Testing", 
			type = TYPE_NIL, 
			usage = PROPERTY_USAGE_GROUP | PROPERTY_USAGE_SCRIPT_VARIABLE
		}, 
		{
			name = "disabled", 
			type = typeof(disabled), 
			usage = PROPERTY_USAGE_DEFAULT
		}, 
		{
			name = "mock_export_features", 
			type = typeof(mock_export_features), 
			usage = PROPERTY_USAGE_DEFAULT
		}
	]
	if not is_inside_tree():
		
		properties = [
			{
				name = "property_path", 
				type = TYPE_STRING, 
				usage = PROPERTY_USAGE_DEFAULT
			}, 
			{
				name = "property_type", 
				type = TYPE_INT, 
				usage = PROPERTY_USAGE_DEFAULT, 
				hint = PROPERTY_HINT_ENUM, 
				hint_string = variant_type_enum_hint_string
			}, 
			{
				name = "property_value", 
				type = typeof(property_value), 
				usage = PROPERTY_USAGE_DEFAULT
			}
		] + properties
		return properties
	
	
	var default_value = get_parent().get(property_path)
	var type: = typeof(default_value)
	
	
	if not is_parent_value():
		type = typeof(property_value)
	
	if property_type >= 0:
		type = property_type
	
	properties = [
		{
			name = "property_path", 
			type = TYPE_STRING, 
			usage = PROPERTY_USAGE_DEFAULT, 
			hint = PROPERTY_HINT_PROPERTY_OF_INSTANCE, 
			hint_string = str(get_parent().get_instance_id())
		}, 
		{
			name = "property_type", 
			type = TYPE_INT, 
			usage = PROPERTY_USAGE_DEFAULT, 
			hint = PROPERTY_HINT_ENUM, 
			hint_string = variant_type_enum_hint_string
		}, 
		{
			
			name = "property_value", 
			type = type, 
			usage = PROPERTY_USAGE_DEFAULT
		}
	] + properties
	return properties
