extends Node

class_name LoadScenePathOnPress

export (String) var scene_path
onready var parent_button: = get_parent() as Button

var is_loading: = false

func _ready():
	parent_button.connect("pressed", self, "on_button_pressed")

func on_button_pressed():
	if not is_loading:
		is_loading = true
		ScreenTransitions.fade_to_scene_path(scene_path)
