extends Node
class_name PlayAnimationOnReady

export  var animation_name: = ""

onready var parent_animation_player: = get_parent() as AnimationPlayer

func _ready():
	if OS.has_feature("editor"):
		if not parent_animation_player.has_animation(animation_name):
			printerr("[PlayAnimationOnReady] animation %s not found on node %s" % [animation_name, parent_animation_player.get_path()])
	parent_animation_player.play(animation_name)
