extends Node




onready var particles: Particles2D = get_parent()
var was_on_screen: = false
onready var viewport: = get_viewport()
var has_emitted_on_screen: = false

func _process(delta: float) -> void :
	var particles_rect: = particles.visibility_rect
	particles_rect.position += particles.global_position
	var visible_rect: Rect2 = viewport.canvas_transform.affine_inverse().xform(viewport.get_visible_rect())
	var is_on_screen: = visible_rect.intersects(particles_rect)
	if particles.emitting and is_on_screen:
		has_emitted_on_screen = true
	if not is_on_screen and was_on_screen and has_emitted_on_screen:
		
		
		particles.amount = particles.amount
		has_emitted_on_screen = false
	was_on_screen = is_on_screen
