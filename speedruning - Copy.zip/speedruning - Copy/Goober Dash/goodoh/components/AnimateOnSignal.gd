tool 
extends Node
class_name AnimateOnSignal

export  var signal_target: NodePath = ""
export  var signal_name: = ""
export  var delay: = 0.0
export  var duration: = 0.0

var s_target
onready var target: CanvasItem = get_parent()

\
\
"\nNote this TT enum is a duplicate of Tween.TransitionType\n"
enum TT{Linear, Sine, Quint, Quart, Quad, Expo, Elastic, Cubic, Circ, Bounce, Back}
export (TT) var transition = Tween.TRANS_BACK

\
\
"\nNote this ET enum is a duplicate of Tween.EaseType\n"
enum ET{In, Out, InOut, OutIn}
export (ET) var ease_type: = Tween.EASE_OUT

var prop_name: = "scale"
var initial_scale: = Vector2(1.0, 1.0)

func _ready():
	s_target = get_node(signal_target)
	s_target.connect(signal_name, self, "animate")
	var node2d: = target as Node2D
	var control: = target as Control
	if (node2d):
		initial_scale = node2d.scale
	elif (control):
		initial_scale = control.rect_scale
		prop_name = "rect_scale"

func animate():
	if (target):
		target.set(prop_name, Vector2(0.0, 0.0))
		var tween: = create_tween()
		tween.tween_interval(delay)
		tween.tween_property(target, prop_name, initial_scale, duration).set_ease(ease_type).set_trans(transition)
		
