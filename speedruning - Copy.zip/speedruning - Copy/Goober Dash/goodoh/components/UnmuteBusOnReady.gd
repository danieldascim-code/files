extends Node
class_name UnmuteBusOnReady

export  var deferred: = false



export  var bus_name: = "Master"

func _ready():
	if deferred:
		call_deferred("unmute")
	else:
		unmute()

func unmute():
	AudioServer.set_bus_mute(AudioServer.get_bus_index(bus_name), false)
