extends Node

class_name CallMethodWhenButtonToggled

export  var method_when_on: = ""
export  var method_when_off: = ""
export (NodePath) var _button

onready var button: = get_node(_button)
onready var parent: = get_parent()
func _ready() -> void :
	button.connect("toggled", self, "on_button_toggled")

func on_button_toggled(t: bool):
	if t:
		parent.call(method_when_on)
	else:
		parent.call(method_when_off)
