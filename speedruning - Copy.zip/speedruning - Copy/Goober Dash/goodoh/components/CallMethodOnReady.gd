extends Node
class_name CallMethodOnReady

export  var function_name: = ""
export (Array) var arguments
export  var delay: = 0.0

onready var parent: = get_parent() as Node

func _ready():
	if delay > 0.0:
		yield(get_tree().create_timer(delay), "timeout")
	
	if (arguments and arguments.size() > 0):
		parent.callv(function_name, arguments)
	else:
		parent.call_deferred(function_name)
