extends Node

class_name ShowWhenGlobalFocusEnabled

onready var focus_global_autoload: = get_node("/root/FocusGlobal")
onready var parent_control: = get_parent() as Control

export  var show_when_keyboard: = true
export  var show_when_joypad: = true
export  var show_when_focus_disabled: = false

func _ready() -> void :
	focus_global_autoload.connect("focus_changed", self, "on_focus_changed")
	on_focus_changed()

func on_focus_changed():
	var _should_show: = should_show()
	if parent_control.visible != _should_show:
		parent_control.visible = _should_show

func should_show() -> bool:
	var _should_show = false
	var is_focus_enabled = focus_global_autoload.is_focus_enabled()
	if is_focus_enabled:
		if show_when_keyboard:
			if focus_global_autoload.is_using_keyboard:
				_should_show = true
		elif show_when_joypad:
			if not focus_global_autoload.is_using_keyboard:
				_should_show = true
	else:
		if show_when_focus_disabled:
			_should_show = true
	
	return _should_show
