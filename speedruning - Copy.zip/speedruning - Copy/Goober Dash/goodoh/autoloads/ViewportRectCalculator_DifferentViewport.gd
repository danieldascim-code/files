extends Node
class_name ViewportRectCalculator_DifferentViewport

export  var _different_viewport: NodePath
onready var different_viewport: Viewport = get_node(_different_viewport)

func _ready() -> void :
	ViewportRectCalculator.my_viewport = different_viewport

func _exit_tree() -> void :
	ViewportRectCalculator.my_viewport = ViewportRectCalculator.get_viewport()
