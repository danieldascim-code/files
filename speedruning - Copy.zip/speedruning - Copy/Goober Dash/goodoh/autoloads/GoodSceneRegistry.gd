extends Node

const text_entry_dialog_scene: String = "res://goodoh/ui/nodes/UITextEntryDialog.tscn"
const confirmation_dialog_scene: String = "res://goodoh/ui/nodes/UIConfirmationDialog.tscn"
const notification_dialog_scene: String = "res://goodoh/ui/nodes/UINotifyDialog.tscn"
const spinner_dialog_scene: String = "res://goodoh/ui/nodes/UISpinnerDialog.tscn"
const connecting_scene: String = "res://scenes/ConnectingScene.tscn"
