extends Node

var viewport_visible_rect: = Rect2()
onready var viewport: = get_viewport()

func _process(delta: float) -> void :
	_calculate_viewport_visible_rect()

func _calculate_viewport_visible_rect():
	viewport_visible_rect = viewport.canvas_transform.affine_inverse().xform(viewport.get_visible_rect())
