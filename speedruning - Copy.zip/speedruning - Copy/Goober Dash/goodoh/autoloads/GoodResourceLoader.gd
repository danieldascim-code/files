extends Node

signal resource_loaded(path, resource)

const max_milliseconds_per_frame: = 8.0

var load_queue: = []
var resources: = {}
var active_resource_loader: ResourceInteractiveLoader
var active_resource_path: String

export (Array, String) var autoload_paths: Array

func _ready():
	if not OS.has_feature("server"):
		for path in autoload_paths:
			background_load_resource(path)

func load_resource(path: String) -> Resource:
	
	if resources.has(path):
		
		
		
		return resources[path]
	
	if active_resource_path == path:
		
		
		print("[GoodResourceLoader] force finishing requested resource %s" % [path])
		return _finish_active_load()
	
	
	
	
	
	
	
	_finish_active_load()
	load_queue.erase(path)
	var resource: Resource = ResourceLoader.load(path)
	if resource == null:
		printerr("[GoodResourceLoader] get_resource() failed to load resource with path %s" % [path])
		return null
	
	resources[path] = resource
	return resource

func background_load_resource(path: String, type_hint: String = ""):
	if resources.has(path):
		
		return
	if active_resource_path == path:
		
		return
	
	
	
	if active_resource_loader == null:
		print("[GoodResourceLoader] starting load of %s" % [path])
		_start_load(path, type_hint)
	else:
		print("[GoodResourceLoader] enqueing load of %s" % [path])
		load_queue.push_back(path)
	
func is_resource_loaded(path: String) -> bool:
	return resources.has(path)

func _process(_delta):
	
	
	var start_time_ms: = OS.get_ticks_msec()
	if active_resource_loader == null:
		if load_queue.size() > 0:
			var path: String = load_queue.pop_front()
			if resources.has(path):
				print("[GoodResourceLoader] enqueued resource was already loaded %s" % [path])
			else:
				_start_load(path)
	while active_resource_loader != null:
		var result = active_resource_loader.poll()
		match result:
			ERR_FILE_EOF:
				var resource: = active_resource_loader.get_resource()
				resources[active_resource_path] = resource
				print("[GoodResourceLoader] finished load of %s" % [active_resource_path])
				emit_signal("resource_loaded", active_resource_path, resource)
				active_resource_loader = null
				active_resource_path = ""
				
			OK:
				pass
			_:
				printerr("[GoodResourceLoader] process() background load failure %s path %s" % [result, active_resource_path])
				active_resource_loader = null
				active_resource_path = ""
		
		var now: = OS.get_ticks_msec()
		if now - start_time_ms > max_milliseconds_per_frame:
			
			break

func _start_load(path: String, type_hint: String = ""):
	assert (active_resource_loader == null)
	assert (active_resource_path.empty())
	active_resource_loader = ResourceLoader.load_interactive(path, type_hint)
	if active_resource_loader == null:
		printerr("[GoodResourceLoader] failed to background load path %s" % [path])
	else:
		active_resource_path = path

func _finish_active_load():
	if active_resource_loader != null:
		var result = active_resource_loader.wait()
		match result:
			ERR_FILE_EOF:
				var resource: Resource = active_resource_loader.get_resource()
				resources[active_resource_path] = resource
				print("[GoodResourceLoader] force finished active load of %s" % [active_resource_path])
				emit_signal("resource_loaded", active_resource_path, resource)
				active_resource_loader = null
				active_resource_path = ""
				return resource
			_:
				printerr("[GoodResourceLoader] get_resource() err %s while blocking load on resource with path %s" % [result, active_resource_path])
				active_resource_loader = null
				active_resource_path = ""
				return null
