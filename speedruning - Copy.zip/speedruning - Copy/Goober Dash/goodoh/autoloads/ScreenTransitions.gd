extends Node
class_name BaseScreenTransitions

signal transition_completed()

const verbose: = true

onready var tween: Tween = $ColorRect / Tween
onready var color_rect: ColorRect = $ColorRect
var is_showing: = false

func _ready():
	color_rect.visible = false
	color_rect.modulate = Color.transparent

func on_finished():
	
	if verbose:
		print("[ScreenTransitions] on screen transition completed")
	emit_signal("transition_completed")

func fade_in():
	if is_showing:
		yield(get_tree(), "idle_frame")
		return
	is_showing = true
	tween.remove_all()
	tween.interpolate_callback(color_rect, 0.0, "show")
	tween.interpolate_property(color_rect, "modulate", null, Color.white, 0.4, Tween.TRANS_LINEAR, Tween.EASE_IN)
	tween.interpolate_callback(self, 0.4, "on_finished")
	tween.start()
	yield(tween, "tween_all_completed")

func fade_out():
	if not is_showing:
		yield(get_tree(), "idle_frame")
		return
	is_showing = false
	tween.remove_all()
	tween.interpolate_property(color_rect, "modulate", null, Color.transparent, 0.4, Tween.TRANS_LINEAR, Tween.EASE_IN)
	tween.interpolate_callback(color_rect, 0.4, "hide")
	tween.interpolate_callback(self, 0.4, "on_finished")
	tween.start()
	yield(tween, "tween_all_completed")

func fade_to_scene_path(scene_path: String):
	yield(ScreenTransitions.fade_in(), "completed")
	mute_choppy_audio()
	get_tree().change_scene(scene_path)
	unmute_choppy_audio()
	yield(ScreenTransitions.fade_out(), "completed")

func fade_to_scene(scene: PackedScene):
	yield(ScreenTransitions.fade_in(), "completed")
	mute_choppy_audio()
	get_tree().change_scene_to(scene)
	unmute_choppy_audio()
	yield(ScreenTransitions.fade_out(), "completed")

func fade_to_scene_node(scene_node: Node):
	yield(ScreenTransitions.fade_in(), "completed")
	mute_choppy_audio()
	swap_to_scene_node(scene_node)
	unmute_choppy_audio()
	yield(ScreenTransitions.fade_out(), "completed")

func swap_to_scene_node(scene_node: Node):
	var current_scene: Node = get_tree().current_scene
	get_tree().root.remove_child(current_scene)
	current_scene.queue_free()
	get_tree().root.add_child(scene_node)
	get_tree().current_scene = scene_node

func mute_choppy_audio():
	if OS.has_feature("HTML5") and not OS.has_feature("threads"):
		AudioServer.set_bus_mute(AudioServer.get_bus_index("Master"), true)

func unmute_choppy_audio():
	if OS.has_feature("HTML5") and not OS.has_feature("threads"):
		AudioServer.set_bus_mute(AudioServer.get_bus_index("Master"), false)
