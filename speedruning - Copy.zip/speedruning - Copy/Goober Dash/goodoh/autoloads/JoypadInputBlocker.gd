extends Node

var steam_overlay_active: = false

func _ready():
	if OS.has_feature("steam"):
		if Engine.has_singleton("Steam"):
			var Steam_ = Engine.get_singleton("Steam")
			if not Steam_.isSteamRunning():
				printerr("[JoypadInputBlocker] Steam isn\'t running, even though the singleton is available.")
			Steam_.connect("overlay_toggled", self, "_on_steam_overlay_toggled")
		else:
			printerr("[JoypadInputBlocker] \"steam\" feature is present, but Steam singleton is not available.")

func _input(event) -> void :
	if should_block_input():
		if event is InputEventJoypadButton or event is InputEventJoypadMotion:
			get_tree().set_input_as_handled()

func should_block_input() -> bool:
	return not OS.is_window_focused() or steam_overlay_active

func _on_steam_overlay_toggled(active: bool):
	steam_overlay_active = active
