extends Node


export  var setting_name: = "fullscreen"

onready var saved_settings = get_node("/root/SavedSettings")

func _ready():
	if OS.has_feature("server"):
		return
	
	assert (saved_settings != null)
	
	var default_fullscreen: = OS.has_feature("pc")
	saved_settings.set_default_value(setting_name, default_fullscreen)
	
	saved_settings.connect("on_value_changed", self, "on_setting_value_changed")
	on_setting_value_changed(setting_name, saved_settings.get_value(setting_name, false))

func on_setting_value_changed(setting_key: String, setting_value):
	if setting_key == setting_name:
		assert (setting_value is bool)
		set_full_screen(setting_value)

func set_full_screen(f: bool):
	if OS.has_feature("editor") or OS.has_feature("server"):
		
		pass
	else:
		OS.window_fullscreen = f
