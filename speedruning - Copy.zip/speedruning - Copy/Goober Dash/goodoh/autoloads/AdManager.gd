extends Node

signal ad_requested()
signal ad_started()
signal ad_error()
signal ad_ended()
signal _callback_ad_complete(success)
signal window_resized()

const BANNER_REFRESH_DURATION: = 60.0
var banner_refresh_timer: = BANNER_REFRESH_DURATION

const INTERSTITIAL_REFRESH_DURATION: = 60.0 * 2
var interstitial_timer: = 0.0

const REWARDED_VIDEO_REFRESH_DURATION: = 60.0 * 3
var rewarded_video_timer: = REWARDED_VIDEO_REFRESH_DURATION

var _internal_gameplay: = false

var is_web_mobile_cached: = false
var is_web_mobile_result: = false
var is_showing_ad: = false
onready var master_sound = AudioServer.get_bus_index("Master")
export  var mobile_web_render_scale: = 0.5

onready var moonlight: Node = get_node("/root/Moonlight")

func callback_ad_shown(args):
	is_showing_ad = true
	print("godot ad shown")
	emit_signal("ad_started")
	AudioServer.set_bus_mute(master_sound, true)

func callback_ad_ended(args):
	is_showing_ad = false
	print("godot ad ended")
	AudioServer.set_bus_mute(master_sound, false)
	emit_signal("ad_ended")
	emit_signal("_callback_ad_complete", true)

func callback_ad_error(args):
	is_showing_ad = false
	print("godot ad error")
	AudioServer.set_bus_mute(master_sound, false)
	emit_signal("ad_error")
	emit_signal("_callback_ad_complete", false)

func callback_window_resized(args):
	emit_signal("window_resized")

var adShownCB = null
var adEndedCB = null
var adErrorCB = null
var windowResizedCB = null

func _ready():
	if supports_ads():
		adShownCB = JavaScript.create_callback(self, "callback_ad_shown")
		adEndedCB = JavaScript.create_callback(self, "callback_ad_ended")
		adErrorCB = JavaScript.create_callback(self, "callback_ad_error")
		windowResizedCB = JavaScript.create_callback(self, "callback_window_resized")
		
		var jsLib: = JavaScript.get_interface("winterpixelAdHandlers")
		jsLib.registerAdStarted(adShownCB)
		jsLib.registerAdEnded(adEndedCB)
		jsLib.registerAdError(adErrorCB)
		jsLib.registerWindowResized(windowResizedCB)

	if is_web_mobile() and not is_equal_approx(mobile_web_render_scale, 1.0):
		print("[AdManager] applying mobile_web_render_scale: " + str(mobile_web_render_scale))
		WPEngineExtension.javascript_set_canvas_scale(mobile_web_render_scale)

func is_in_discord() -> bool:
	if moonlight:
		return moonlight.discord_api.is_in_discord()
	return false

func supports_ads() -> bool:
	return OS.has_feature("winterpixelads") and not is_in_discord()

func supports_rewarded_ads() -> bool:
	return OS.has_feature("winterpixelads") and not is_in_discord()

func is_user_exempt_from_ads() -> bool:
	var is_exempt: = false
	
	
	
	return is_exempt

func _input(event: InputEvent) -> void :
	if is_showing_ad:
		print("[AdManager] blocking input because showing ad")
		get_tree().set_input_as_handled()

func ads_enabled() -> bool:
	return supports_ads() and not is_user_exempt_from_ads()

func rewarded_ads_enabled() -> bool:
	return supports_rewarded_ads()




func show_interstitial_ad(force: bool = false) -> bool:
	if not ads_enabled():
		print("[AdManager] show_interstitial_ad() ads disabled")
		yield(get_tree(), "idle_frame")
		emit_signal("ad_error")
		return false
	
	if not force and interstitial_timer < INTERSTITIAL_REFRESH_DURATION:
		print("[AdManager] show_interstitial_ad() timer not ready")
		yield(get_tree(), "idle_frame")
		emit_signal("ad_error")
		return false
	
	print("[AdManager] show_interstitial_ad()")
	interstitial_timer = 0.0
	defer_javascript_eval("winterpixelShowInterstitialAd();")
	emit_signal("ad_requested")
	var success: bool = yield(self, "_callback_ad_complete")
	return success




func show_rewarded_ad(force: bool = false, clear_interstitial_timer: bool = true) -> bool:
	if rewarded_video_timer < REWARDED_VIDEO_REFRESH_DURATION and not force:
		print("[AdManager] show_rewarded_ad() timer not ready")
		yield(get_tree(), "idle_frame")
		emit_signal("ad_error")
		return false
	
	
	if not rewarded_ads_enabled():
		yield(get_tree(), "idle_frame")
		emit_signal("ad_error")
		return false
	
	print("[AdManager] show_rewarded_ad()")
	rewarded_video_timer = 0.0
	if clear_interstitial_timer:
		interstitial_timer = 0.0
	defer_javascript_eval("winterpixelShowRewardedAd();")
	emit_signal("ad_requested")
	var success: bool = yield(self, "_callback_ad_complete")
	return success

func is_banner_enabled() -> bool:
	if not supports_ads():
		return false
	if is_web_mobile():
		return false
	return true

func show_banner():
	if not is_banner_enabled():
		return
	print("[AdManager] show_banner()")
	defer_javascript_eval("winterpixelShowBanner();")
	
func hide_banner():
	if not is_banner_enabled():
		return
	print("[AdManager] hide_banner()")
	defer_javascript_eval("winterpixelHideBanner();")

func request_banner():
	if not is_banner_enabled():
		return
	if banner_refresh_timer < BANNER_REFRESH_DURATION:
		return
	banner_refresh_timer = 0.0
	if ads_enabled():
		print("[AdManager] request_banner()")
		defer_javascript_eval("winterpixelRequestBanner();")

func gameplay_started():
	if not _internal_gameplay:
		print("[AdManager] gameplay_started()")
		if ads_enabled():
			JavaScript.eval("winterpixelGameplayStarted();")
		_internal_gameplay = true

func gameplay_stopped():
	if _internal_gameplay:
		print("[AdManager] gameplay_stopped()")
		if ads_enabled():
			JavaScript.eval("winterpixelGameplayStopped();")
		_internal_gameplay = false
		
func happytime():
	if ads_enabled():
		print("[AdManager] happytime()")
		JavaScript.eval("winterpixelHappytime();")

func go_fullscreen_on_web_android():
	print("[AdManager] go_fullscreen_on_web_android()")
	if OS.has_feature("winterpixelads"):
		var is_web_android = JavaScript.eval("winterpixelIsAndroid();")
		if is_web_android:
			JavaScript.eval("winterpixelGoFullscreen();")

func is_web_mobile() -> bool:
	if not is_web_mobile_cached:
		is_web_mobile_cached = true
		is_web_mobile_result = _is_web_mobile()
		
	return is_web_mobile_result

func _is_web_mobile() -> bool:
	if OS.has_feature("HTML5"):
		return bool(JavaScript.eval("winterpixelIsMobile();"))
	return false

func get_ad_driver() -> String:
	if OS.has_feature("HTML5"):
		return JavaScript.eval("getAdDriver();") as String
	return ""
	
func is_sharing_supported(title: String, text: String, url: String) -> bool:
	if OS.has_feature("HTML5"):
		return JavaScript.eval(\
		"\n\t\t\twinterpixelCanShare(" + "\"" + title + "\"," + "\"" + text + "\"," + "\"" + url + "\"" + \
		");\n\t\t") as bool
		
	return false
	
func share(title: String, text: String, url: String):
	if OS.has_feature("HTML5"):
		return JavaScript.eval(\
		"\n\t\t\twinterpixelShare(" + "\"" + title + "\"," + "\"" + text + "\"," + "\"" + url + "\"" + \
		");\n\t\t") as String
	return ""

func _process(delta):
	banner_refresh_timer = banner_refresh_timer + delta
	interstitial_timer = interstitial_timer + delta
	rewarded_video_timer = rewarded_video_timer + delta

func is_rewarded_video_ready() -> bool:
	return rewarded_video_timer >= REWARDED_VIDEO_REFRESH_DURATION

func defer_javascript_eval(s: String):
	
	call_deferred("_deferred_javascript_eval", s)

func _deferred_javascript_eval(s: String):
	JavaScript.eval(s)
