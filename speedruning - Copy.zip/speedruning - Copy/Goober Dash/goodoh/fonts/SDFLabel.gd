tool 
extends WPSDFLabel
class_name SDFLabel

enum Alignment{
	LEFT, CENTER, RIGHT, FILL
}

const default_font_size_index: = 2
enum FontSize{
	_16, _32, _48, _64, _80, _100, _128, _150, _180, _200, _256, _320, _384, _448, _512, Custom
}

const font_sizes: = [16, 32, 48, 64, 80, 100, 128, 150, 180, 200, 256, 320, 384, 448, 512]
const sublabel_name: = "__SDFLabelOutline"
const default_label_theme_type_variation: = "SDFLabel"

export (FontSize) var font_size: = default_font_size_index setget set_font_size
export  var custom_scale: = 1.0 setget set_custom_scale
export  var color: = Color.white setget set_color
export  var outlines: Array = []
export  var editor_add_new_outline: = false setget _set_add_new
export  var force_min_size: = false setget set_force_min_size
export  var max_width: = 0.0 setget set_max_width
export  var fit_inside_parent: = false setget set_fit_inside_parent
export  var fit_inside_parent_margin: = 0.0 setget set_fit_inside_parent_margin
export  var enable_override_line_height: = false setget set_enable_override_line_height
export  var override_line_height: = 0.0 setget set_override_line_height
export  var sdf_material: Material = load("res://goodoh/fonts/msdf-font-shader2.material")
export  var editor_recreate: = false setget _set_run

var sublabels: = []


func _ready():
	theme_type_variation = default_label_theme_type_variation
	_fetch_sublabels()
	_create_labels()
	if Engine.editor_hint:
		mouse_filter = MOUSE_FILTER_IGNORE
		material = sdf_material
		for o in outlines:
			var outline_data: SDFLabelOutlineData = o
			outline_data.connect("changed", self, "on_outline_data_changed")
		
	var parent_control: = self.get_parent_control()
	if parent_control:
		parent_control.connect("resized", self, "on_parent_resized")

func set_color(c: Color):
	color = c
	_apply_color_to_label(self, c)

func set_font_size(i: int):
	font_size = i
	if is_inside_tree():
		_apply_scale_to_sublabels()

func _apply_font_size(f: int):
	set_custom_scale(float(f / default_font_size()))

func on_parent_resized():
	
	if fit_inside_parent:
		_apply_scale_to_sublabels()

func _init():
	outlines = []
	if is_inside_tree() and Engine.editor_hint:
		_fetch_sublabels()

func set_custom_scale(f: float):
	custom_scale = f
	if is_inside_tree():
		_apply_scale_to_sublabels()
		_resize_rect()
		property_list_changed_notify()






























func set_outline_color(i: int, c: Color):
	var label_index: = sublabels.size() - i
	set_label_color(label_index, c)

func set_label_color(i: int, c: Color):
	assert ( not Engine.editor_hint)
	if i < 0 or (i - 1) >= sublabels.size():
		printerr("[SDFLabel] set_outline_color() invalid index %d sublabels.size %d" % [i, sublabels.size()])
	if i == 0:
		self.color = c
	else:
		var label: Label = sublabels[i - 1]
		_apply_color_to_label(label, c)

func _fetch_sublabels():
	
	sublabels.clear()
	for i in get_child_count():
		var c: = get_child(i)
		if c is WPSDFLabel and sublabel_name in c.get_name():
			sublabels.append(c)

func on_outline_data_changed():
	if is_inside_tree():
		_apply_colors_to_sublabels()
		_apply_widths_to_sublabels()

func _create_labels():
	if not is_inside_tree():
		return
	
	
	
	var num_outlines: = outlines.size()
	while sublabels.size() > num_outlines:
		var label: = sublabels.pop_back() as WPSDFLabel
		label.queue_free()
		print("[SDFLabel] delete()")
	while sublabels.size() < num_outlines:
		var new_label: = WPSDFLabel.new()
		new_label.anchor_left = 0.0
		new_label.anchor_top = 0.0
		new_label.anchor_right = 1.0
		new_label.anchor_bottom = 1.0
		new_label.name = sublabel_name
		add_child(new_label)
		sublabels.push_back(new_label)
		print("[SDFLabel] create()")
	
	for i in num_outlines:
		var label: Label = sublabels[sublabels.size() - 1 - i]
		label.show_behind_parent = true
		label.material = sdf_material
		if owner != null:
			label.owner = owner
		else:
			label.owner = self
	
	_apply_theme_type_variation_to_sublabels()
	_apply_autowrap_to_sublabels()
	_apply_colors_to_sublabels()
	_apply_widths_to_sublabels()
	_apply_alignment_to_sublabels()
	_apply_text_to_sublabels()
	_apply_line_height_to_sublabels()
	_apply_scale_to_sublabels()

func sdf_label_minimum_size() -> Vector2:
	
	var _scale: = _get_scale_including_max_width()
	var min_size: = unscaled_minimum_size() * _scale
	
	return Vector2(ceil(min_size.x), ceil(min_size.y))

func _set_run(b: bool):
	if b and is_inside_tree():
		_fetch_sublabels()
		_delete_sublabels()
		_create_labels()

func _set_add_new(b: bool):
	if b and is_inside_tree():
		var outline_data: = SDFLabelOutlineData.new()
		outline_data.connect("changed", self, "on_outline_data_changed")
		outlines.append(outline_data)
		property_list_changed_notify()
		_create_labels()

func _delete_sublabels():
	while sublabels.size() > 0:
		var l: = sublabels.pop_back() as Label
		remove_child(l)
		l.queue_free()
	sublabels.clear()

func _apply_alignment_to_sublabels():
	for i in sublabels.size():
		var l: Label = sublabels[i]
		l.align = align
		l.valign = valign

func _apply_scale_to_sublabels():
	var s: = _get_scale_including_max_width()
	for i in sublabels.size():
		var l: WPSDFLabel = sublabels[i]
		_apply_scale_to_label(l, s)
		l.internal_sdf_scale = s
	_apply_scale_to_label(self, s)
	internal_sdf_scale = s
	_resize_rect()
	property_list_changed_notify()


func _apply_scale_to_label(l: Label, s: float):
	var c: Color = l.get_color("font_color")
	if not is_equal_approx(c.g, s):
		c.g = s
		l.add_color_override("font_color", c)

func _resize_rect():
	rect_min_size = sdf_label_minimum_size()
	if force_min_size:
		rect_size = rect_min_size
	else:
		rect_size = Vector2(max(rect_size.x, rect_min_size.x), max(rect_size.y, rect_min_size.y))
	property_list_changed_notify()

func _apply_text_to_sublabels():
	for i in sublabels.size():
		var l: = sublabels[i] as Label
		l.text = text

func _apply_colors_to_sublabels():
	_apply_color_to_label(self, color)
	assert (sublabels.size() == outlines.size())
	for i in sublabels.size():
		var outline: SDFLabelOutlineData = outlines[i]
		var c = outline.color
		var label = sublabels[sublabels.size() - 1 - i]
		_apply_color_to_label(label, c)

func _apply_widths_to_sublabels():
	var previous_width: = 0.0
	for i in sublabels.size():
		var label: Label = sublabels[sublabels.size() - 1 - i]
		
		var outline: SDFLabelOutlineData = outlines[i]
		var w: = float(outline.width) + previous_width
		_apply_outline_to_label(label, w)
		previous_width = w
		label.rect_position = outline.offset

func _apply_theme_type_variation_to_sublabels():
	for i in sublabels.size():
		var label: Label = sublabels[i]
		label.theme_type_variation = theme_type_variation

func _apply_autowrap_to_sublabels():
	for i in sublabels.size():
		var label: Label = sublabels[i]
		label.autowrap = autowrap

func _apply_color_to_label(label: Label, color: Color):
	
	label.self_modulate = color

func _apply_outline_to_label(label: Label, width: float):
	var w: = 1.0 - (width / default_font_size())
	
	var c: Color = label.get_color("font_color")
	if not is_equal_approx(c.r, w):
		c.r = w
		label.add_color_override("font_color", c)

func set_fit_inside_parent(b: bool):
	fit_inside_parent = b
	if is_inside_tree():
		_apply_scale_to_sublabels()

func set_max_width(f: float):
	max_width = f
	if is_inside_tree():
		_apply_scale_to_sublabels()

func set_fit_inside_parent_margin(f: float):
	fit_inside_parent_margin = f
	if is_inside_tree():
		_apply_scale_to_sublabels()

func get_computed_max_width() -> float:
	
	if max_width > 0.001:
		return max_width
	
	if fit_inside_parent:
		var t: = get_parent_control()
		if t:
			return t.rect_size.x - fit_inside_parent_margin
	return 0.0

func _get_scale_including_max_width() -> float:
	var _scale: = get_scale_including_font_size()
	var computed_max_width: = get_computed_max_width()
	if computed_max_width < 0.001:
		return _scale
	var label_width: = unscaled_minimum_size().x
	if is_zero_approx(label_width):


		return _scale
	
	var label_scale: float = computed_max_width / label_width
	_scale = min(_scale, label_scale)
	
	return _scale

func get_scale_including_font_size() -> float:
	if font_size >= 0 and font_size < font_sizes.size():
		var f: int = font_sizes[font_size]
		return float(f / default_font_size())
	return custom_scale

func set_force_min_size(b: bool):
	force_min_size = b
	if is_inside_tree():
		_apply_scale_to_sublabels()

func set_enable_override_line_height(b: bool):
	enable_override_line_height = b
	if is_inside_tree():
		_apply_line_height_to_sublabels()

func set_override_line_height(f: float):
	override_line_height = f
	if is_inside_tree():
		_apply_line_height_to_sublabels()

func _apply_line_height_to_sublabels():
	if enable_override_line_height:
		add_constant_override("line_spacing", override_line_height)
	else:
		remove_constant_override("line_spacing")
	for s in sublabels:
		if enable_override_line_height:
			s.add_constant_override("line_spacing", override_line_height)
		else:
			s.remove_constant_override("line_spacing")
	_apply_scale_to_sublabels()



func default_font_size() -> float:
	return float(get_constant("sdf_font_size", default_label_theme_type_variation))
