tool 
extends Resource
class_name SDFLabelOutlineData

export  var color: Color setget set_color
export  var width: float setget set_width
export  var offset: Vector2 setget set_offset

func set_width(w: float):
	width = w
	emit_changed()
	
func set_color(c: Color):
	color = c
	emit_changed()

func set_offset(v: Vector2):
	offset = v
	emit_changed()
