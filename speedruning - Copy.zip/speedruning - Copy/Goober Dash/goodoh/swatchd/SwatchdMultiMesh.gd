tool 
extends SwatchdApplier

class_name SwatchdMultiMesh

func apply_color(c: Color) -> void :
	var target = get_target()
	if target:
		
		target.set_color(c)
		
