tool 
extends SwatchdApplier
class_name SwatchdLabelShadow

func apply_color(c: Color):
	var label: = get_target() as Label
	label.add_color_override("font_color_shadow", c)
