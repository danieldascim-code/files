tool 
extends Node
class_name ButtonThemeColorizer




export (Resource) var swatch

const stylebox_names: = ["hover", "pressed", "focus", "disabled", "normal"]

func _ready():
	if swatch == null:
		return
	if not swatch is Swatchd:
		printerr("property \"swatch\" must be of type Swatchd")
		return
	
	var button: = get_parent() as BaseButton
	
	if button.theme == null:
		printerr("Parent button theme is null")
		return
	
	for sb_name in stylebox_names:
		var stylebox: = button.get_stylebox(sb_name, "Button") as StyleBox
		
		var color: = (swatch as Swatchd).get_named_color(sb_name)
		if not (swatch as Swatchd).has_named_color(sb_name):
			color = (swatch as Swatchd).get_named_color("normal").darkened(0.3)
		
		if stylebox is StyleBoxTexture:
			stylebox.modulate_color = color
		elif stylebox is StyleBoxFlat:
			stylebox.bg_color = color
		elif stylebox is StyleBoxLine:
			stylebox.color = color
		
		button.add_stylebox_override(sb_name, stylebox)
