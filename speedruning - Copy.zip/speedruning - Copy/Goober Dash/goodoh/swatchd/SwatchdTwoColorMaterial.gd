tool 
extends ShaderMaterial
class_name SwatchdTwoColorMaterial

export (Resource) var swatch setget set_swatch
export (int) var color_index setget set_color_index
export (String) var color_name setget set_color_name

export (int) var color_index2 setget set_color_index2
export (String) var color_name2 setget set_color_name2

func set_swatch_index(i: int, j: int) -> void :
	
	self.set_shader_param("color_index", i)
	self.set_shader_param("color_index2", j)
	
func apply_texture_index() -> void :
	
	if swatch:
		if color_name != null and not color_name.empty():
			if swatch.named_colors.has(color_name):
				var texture_index = swatch.get_texture_index_for_name(color_name)
				var texture_index2 = swatch.get_texture_index_for_name(color_name2)
				set_swatch_index(texture_index, texture_index2)
			else:
				print("[SwatchdMaterial] color name not found: " + str(color_name))
		elif color_index >= 0 and color_index < swatch.colors.size() and color_index2 >= 0 and color_index2 < swatch.colors.size():
			set_swatch_index(color_index, color_index2)
			
		else:
			pass
			
	
func on_swatch_changed() -> void :
	
	self.set_shader_param("texture_albedo", swatch.cached_texture())
	apply_texture_index()
	
func set_swatch(new_swatch) -> void :
	
	
	if swatch:
		if swatch.is_connected("changed", self, "on_swatch_changed"):
			swatch.disconnect("changed", self, "on_swatch_changed")
	
	
	if (new_swatch is Swatchd):
		swatch = new_swatch
		self.set_shader_param("texture_albedo", swatch.cached_texture())
		if not swatch.is_connected("changed", self, "on_swatch_changed"):
			var e = swatch.connect("changed", self, "on_swatch_changed")
			assert (e == 0)
	elif new_swatch == null:
		swatch = new_swatch
	else:
		print("[SwatchdTwoColorMaterial] set_swatch resource is not a swatch.")
		print(new_swatch)

func set_color_index(color_index_) -> void :
	
	color_index = color_index_
	if color_name.length() > 0 and color_name2.length() > 0:
		apply_texture_index()

func set_color_name(color_name_: String) -> void :
	
	color_name = color_name_
	if color_name.length() > 0 and color_name2.length() > 0:
		apply_texture_index()

func set_color_index2(color_index_) -> void :
	
	color_index2 = color_index_
	if color_name.length() > 0 and color_name2.length() > 0:
		apply_texture_index()

func set_color_name2(color_name_) -> void :
	
	color_name2 = color_name_
	if color_name.length() > 0 and color_name2.length() > 0:
		apply_texture_index()
	
func _ready() -> void :
	
	apply_texture_index()
			
func _exit_tree() -> void :
	
	
	if swatch:
		if swatch.is_connected("changed", self, "on_swatch_changed"):
			swatch.disconnect("changed", self, "on_swatch_changed")
