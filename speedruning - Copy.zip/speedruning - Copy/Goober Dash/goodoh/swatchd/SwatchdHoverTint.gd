tool 
extends SwatchdApplier
class_name SwatchdHoverTint

export  var normal: = "normal"
export  var hover: = "hover"
export  var focus: = "focus"
export  var pressed: = "pressed"
export  var hover_and_pressed: = "hover_pressed"
export  var focus_and_pressed: = "focus_pressed"
export  var hover_and_focused_and_pressed: = "hover_focus_pressed"
export  var tint_children: = false

export  var enable_tint: = false setget set_tint
export  var tint_color: = Color.white setget set_tint_color

var is_hovered: = false
var is_focused: = false

onready var parent_control: = get_parent() as Control
onready var parent_button: = parent_control as BaseButton
onready var enable_hover_and_pressed: bool = swatch.has_named_color(hover_and_pressed)
onready var enable_focus_and_pressed: bool = swatch.has_named_color(focus_and_pressed)
onready var enabled_hover_and_focused_and_pressed: bool = swatch.has_named_color(hover_and_focused_and_pressed)

func _ready():
	if Engine.editor_hint:
		return
	
	parent_control.connect("mouse_entered", self, "on_mouse_entered")
	parent_control.connect("mouse_exited", self, "on_mouse_exited")
	parent_control.connect("focus_entered", self, "on_focus_entered")
	parent_control.connect("focus_exited", self, "on_focus_exited")
	parent_control.connect("visibility_changed", self, "on_visibility_changed")
	if parent_button:
		parent_button.connect("button_down", self, "on_button_down")
		parent_button.connect("button_up", self, "on_button_up")
		parent_button.connect("pressed", self, "on_pressed")
		parent_button.connect("toggled", self, "on_toggled")
	set_color()
	._ready()


func on_mouse_entered():
	is_hovered = true
	set_color()
func on_mouse_exited():
	is_hovered = false
	set_color()


func on_toggled(t: bool):
	set_color()
func on_pressed():
	set_color()
func on_button_down():
	set_color()
func on_button_up():
	
	yield(get_tree(), "idle_frame")
	set_color()


func on_focus_entered():
	is_focused = true
	set_color()
func on_focus_exited():
	is_focused = false
	set_color()


func set_color():
	if swatch == null:
		return
	var is_pressed: = parent_button and parent_button.pressed
	if enabled_hover_and_focused_and_pressed and is_hovered and is_focused and is_pressed:
		set_color_(hover_and_focused_and_pressed)
	elif enable_hover_and_pressed and is_hovered and is_pressed:
		set_color_(hover_and_pressed)
	elif enable_focus_and_pressed and is_focused and is_pressed:
		set_color_(focus_and_pressed)
	elif is_pressed:
		set_color_(pressed)
	elif is_hovered:
		set_color_(hover)
	elif is_focused:
		set_color_(focus)
	else:
		set_color_(normal)


func on_visibility_changed():
	if not parent_control.is_visible_in_tree():
		is_focused = false
		is_hovered = false
		set_color()

func set_color_(color_name: String):
	var color: Color = swatch.get_named_color(color_name)
	if override:
		color.r = override_color.r
		color.g = override_color.g
		color.b = override_color.b
		color.a = override_color.a
	if enable_tint:
		color.r *= tint_color.r
		color.g *= tint_color.g
		color.b *= tint_color.b
		color.a *= tint_color.a
	
	var t: = get_target() as Control
	if tint_children:
		t.modulate = color
	else:
		t.self_modulate = color

func apply_color(_color: Color):
	set_color()

func set_tint(o: bool) -> void :
	enable_tint = o
	if is_inside_tree():
		set_color()

func set_tint_color(c: Color) -> void :
	tint_color = c
	if is_inside_tree():
		set_color()
