tool 
extends SwatchdApplier
class_name SwatchdApplierGeneric

export  var property_name: = ""

func apply_color(color: Color) -> void :
	var t: = get_target() as Node
	t.set_indexed(property_name, color)
