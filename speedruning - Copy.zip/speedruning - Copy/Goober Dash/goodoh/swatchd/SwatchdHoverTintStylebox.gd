tool 
extends SwatchdApplier
class_name SwatchdHoverTintStylebox

export  var stylebox: StyleBoxFlat

const normal: = "normal"
const hover: = "hover"
const focus: = "focus"
const pressed: = "pressed"
const hover_and_pressed: = "hover_pressed"
const focus_and_pressed: = "focus_pressed"
const hover_and_focused_and_pressed: = "hover_focus_pressed"

var is_hovered: = false
var is_focused: = false

onready var parent_control: = get_parent() as Control
onready var parent_button: = parent_control as BaseButton

onready var enable_hover_and_pressed: bool = swatch.has_named_color(hover_and_pressed)
onready var enable_focus_and_pressed: bool = swatch.has_named_color(focus_and_pressed)
onready var enabled_hover_and_focused_and_pressed: bool = swatch.has_named_color(hover_and_focused_and_pressed)

func _ready():
	if Engine.editor_hint:
		return

	parent_control.connect("mouse_entered", self, "on_mouse_entered")
	parent_control.connect("mouse_exited", self, "on_mouse_exited")
	parent_control.connect("focus_entered", self, "on_focus_entered")
	parent_control.connect("focus_exited", self, "on_focus_exited")
	parent_control.connect("visibility_changed", self, "on_visibility_changed")
	if parent_button:
		parent_button.connect("button_down", self, "on_button_down")
		parent_button.connect("button_up", self, "on_button_up")
		parent_button.connect("pressed", self, "on_pressed")
		parent_button.connect("toggled", self, "on_toggled")
	set_color()
	._ready()


func on_mouse_entered():
	is_hovered = true
	set_color()
func on_mouse_exited():
	is_hovered = false
	set_color()


func on_toggled(t: bool):
	set_color()
func on_pressed():
	set_color()
func on_button_down():
	set_color()
func on_button_up():
	
	yield(get_tree(), "idle_frame")
	set_color()


func on_focus_entered():
	is_focused = true
	set_color()
func on_focus_exited():
	is_focused = false
	set_color()


func set_color():
	if swatch == null:
		return
	var is_pressed: = parent_button and parent_button.pressed
	if enabled_hover_and_focused_and_pressed and is_hovered and is_focused and is_pressed:
		set_color_(hover_and_focused_and_pressed)
	elif enable_hover_and_pressed and is_hovered and is_pressed:
		set_color_(hover_and_pressed)
	elif enable_focus_and_pressed and is_focused and is_pressed:
		set_color_(focus_and_pressed)
	elif is_pressed:
		set_color_(pressed)
	elif is_hovered:
		set_color_(hover)
	elif is_focused:
		set_color_(focus)
	else:
		set_color_(normal)


func on_visibility_changed():
	if not parent_control.is_visible_in_tree():
		is_focused = false
		is_hovered = false
		set_color()

func set_color_(color_name: String):
	var color: Color = swatch.get_named_color(color_name)
	var border_color: Color = color.darkened(0.2)
	var border_color_name: = color_name + "_border"
	if swatch.has_named_color(border_color_name):
		border_color = swatch.get_named_color(border_color_name)
	stylebox.bg_color = color
	stylebox.border_color = border_color

func apply_color(_color: Color):
	set_color()
