tool 
extends SwatchdApplier
class_name SwatchdLabel

func apply_color(c: Color):
	var label: = get_target() as Label
	if (label as SDFLabel):
		(label as SDFLabel).color = c
	else:
		label.add_color_override("font_color", c)
