extends Node
class_name LoadSceneListener

export (PackedScene) var scene
var is_loading: = false
signal loading

func do():
	if scene and not is_loading:
		is_loading = true
		emit_signal("loading")
		get_tree().change_scene_to(scene)
