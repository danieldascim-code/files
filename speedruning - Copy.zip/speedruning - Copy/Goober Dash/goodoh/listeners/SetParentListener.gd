extends BaseListener
class_name SetParentListener

export (NodePath) var path: NodePath
export (String) var path_string: = ""

func do():
	
	var target: = get_parent() as Node
	var current_parent: = target.get_parent() as Node
	var new_parent: Node = null
	
	if path:
		new_parent = get_node(path)
	else:
		new_parent = current_parent.get_node(path_string)
	
	if new_parent:
		
		var two_d_target: = target as Node2D
		var two_d_transform: = Transform2D.IDENTITY
		if two_d_target:
			two_d_transform = two_d_target.global_transform
		
		
		current_parent.remove_child(target)
		new_parent.add_child(target)
		
		
		if two_d_target:
			two_d_target.global_transform = two_d_transform
	else:
		WPLog.loge("[SetParentListener] couldn\'t find new parent")
