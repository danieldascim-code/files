extends Node
class_name PlayAnimatedSpriteListener

export  var animation_name: = ""
export (NodePath) var target
export (String) var signal_name
onready var t: = get_node(target)

func _ready():
	t.connect(signal_name, self, "do")

func do():
	var p: AnimatedSprite = get_parent()
	assert (p != null)
	p.play(animation_name)
