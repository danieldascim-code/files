extends Node
class_name CallMethodListener2

export (String) var signal_name: = ""
export (NodePath) var _target
export (String) var function_name: = ""
export (Array) var arguments: = []
export (float) var delay: = 0.0
export (bool) var use_call_deferred: = true

onready var parent: = get_parent() as Node
onready var target: = get_node_or_null(_target)

func _ready():
	if parent:
		parent.connect(signal_name, self, "do")
	
func do():
	if delay > 0.0:
		yield(get_tree().create_timer(delay), "timeout")
	
	if (arguments and arguments.size() > 0):
		target.callv(function_name, arguments)
	else:
		if use_call_deferred:
			target.call_deferred(function_name)
		else:
			target.call(function_name)
