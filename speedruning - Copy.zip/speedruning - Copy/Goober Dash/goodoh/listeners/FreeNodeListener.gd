extends BaseListener
class_name FreeNodeListener

func do():
	get_parent().queue_free()
