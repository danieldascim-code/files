extends Node
class_name LoadScenePathListener

export  var scene_path: = ""
var is_loading: = false

func do():
	if not is_loading:
		is_loading = true
		get_tree().change_scene(scene_path)
