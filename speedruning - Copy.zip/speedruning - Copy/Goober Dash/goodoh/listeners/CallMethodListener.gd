extends Node
class_name CallMethodListener

export (NodePath) var _target
onready var target: = get_node_or_null(_target)
export (String) var signal_name

export  var function_name: = ""
export (Array) var arguments
export  var delay: = 0.0

export  var use_call_deferred: = true

onready var parent: = get_parent() as Node

func _ready():
	if target:
		target.connect(signal_name, self, "do")
	
func do():
	if delay > 0.0:
		yield(get_tree().create_timer(delay), "timeout")
	
	if (arguments and arguments.size() > 0):
		parent.callv(function_name, arguments)
	else:
		if use_call_deferred:
			parent.call_deferred(function_name)
		else:
			parent.call(function_name)
