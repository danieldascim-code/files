extends Node
class_name BaseListener

export (NodePath) var _signal_emitter
onready var signal_emitter: = get_node_or_null(_signal_emitter)
export (String) var signal_name: String
export  var signal_delay: float
export  var signal_one_shot: bool

const listener_method: = "on_signal_called"

func _ready():
	if signal_emitter:
		connect_listener()
	else:
		assert (false)

func on_signal_called():
	if signal_one_shot:
		disconnect_listener()
	
	if signal_delay > 0.0:
		yield(get_tree().create_timer(signal_delay), "timeout")
	
	do()

func do():
	printerr("[BaseListener] do() should be implemented by a child class.")

func disconnect_listener():
	signal_emitter.disconnect(signal_name, self, listener_method)
	
func connect_listener():
	signal_emitter.connect(signal_name, self, listener_method)
