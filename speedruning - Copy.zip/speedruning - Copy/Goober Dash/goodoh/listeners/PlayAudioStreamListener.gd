extends BaseListener
class_name PlayAudioStreamListener

export  var audio_start: = 0.0
export  var free_parent_after_played: = false

func do():
	get_parent().play(audio_start)
	
	if free_parent_after_played:
		
		disconnect_listener()
		yield(get_tree().create_timer(get_parent().stream.get_length()), "timeout")
		get_parent().queue_free()
