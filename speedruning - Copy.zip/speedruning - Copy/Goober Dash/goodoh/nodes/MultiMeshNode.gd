tool 
extends Spatial

class_name MultiMeshNode

signal transform_changed
signal color_changed

export (Color) var color setget set_color
var instance_id: = - 1




func _enter_tree() -> void :
	
	if not is_transform_notification_enabled():
		set_notify_transform(true)
	

func _exit_tree() -> void :
	
	
	pass

func set_color(c: Color) -> void :
	color = c
	emit_signal("color_changed", instance_id, color)

func _notification(what: int) -> void :
	if what == Spatial.NOTIFICATION_TRANSFORM_CHANGED:
		emit_signal("transform_changed", instance_id, self)
