tool 
extends AudioStreamPlayer
class_name RandomAudioStreamPlayer


export (Array, AudioStream) var samples: = []
export (String, DIR) var load_from_folder_tool: = "" setget _load_samples_from_folder

onready var base_volume: = self.volume_db
export (float, 0, 30) var random_volume_range: = 0.0
onready var base_pitch: = self.pitch_scale
export (float, 0, 2) var random_pitch_range: = 0.0

func _init():
	samples = samples.duplicate()

func play(from_position: = 0.0):
	if samples.size() <= 0:
		return
	var i: = randi() %samples.size()
	.stop()
	if random_volume_range != 0.0:
		.set_volume_db(base_volume + (randf() - 0.5) * random_volume_range)
	if random_pitch_range != 0.0:
		.set_pitch_scale(base_pitch + (randf() - 0.5) * random_pitch_range)
	.set_stream(samples[i])
	.play(from_position)


func set_volume_db(new_volume_db):
	.set_volume_db(new_volume_db)
	base_volume = new_volume_db


func set_pitch_scale(new_pitch):
	.set_pitch_scale(max(0.0001, new_pitch))
	base_pitch = new_pitch


func _load_samples_from_folder(path: String):
	if not path.empty() and is_inside_tree():
		print("loading samples from " + path)
		samples.clear()
		var dir: = Directory.new()
		if dir.open(path) == OK:
			dir.list_dir_begin(true)
			var file_name: = dir.get_next()
			while file_name != "":
				if not dir.current_is_dir() and file_name.ends_with(".import"):
					var resource_path: = dir.get_current_dir() + "/" + file_name.replace(".import", "")
					if resource_path.get_extension().to_lower() in ["wav", "ogg"]:
						var resource: = load(resource_path)
						if resource != null:
							samples.append(resource)
				file_name = dir.get_next()
		load_from_folder_tool = ""
		print("loaded %d samples" % [samples.size()])
		property_list_changed_notify()
