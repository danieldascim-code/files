extends Node

export (Array, Material) var materials
export (Array, Material) var particle_materials
export (Array, Material) var two_d_particle_materials

export (NodePath) var _parent_node
onready var parent_node: = get_node(_parent_node) as Node

export  var cache_shaders_on_ready: = true
const size_of_rect: = Vector2(2.0, 2.0)
var has_cached_shaders: = false

func _ready() -> void :
	if cache_shaders_on_ready:
		cache_shaders()

func cache_shaders() -> void :
	if has_cached_shaders:
		return
	has_cached_shaders = true
	print("[ShaderLoader] cache_shaders()")
	print("[ShaderLoader] caching %s shaders" % [materials.size()])
	
	for i in materials.size():
		var m: = materials[i] as Material
		_load_color_rect(m, i)
	
	print("[ShaderLoader] caching %s particles" % [two_d_particle_materials.size()])
	for m in two_d_particle_materials:
		_load_2d_particles(m)
	
	
	var frames_to_wait: = 3
	for i in frames_to_wait:
		yield(get_tree(), "idle_frame")
	print("[ShaderLoader] removing nodes")
	
	for c in parent_node.get_children():
		parent_node.remove_child(c)
		c.queue_free()

func _load_color_rect(m: Material, index: int):
	var color_rect: = ColorRect.new()
	color_rect.set_as_toplevel(true)
	color_rect.rect_position = Vector2(index * size_of_rect.x, 0.0);
	color_rect.rect_min_size = size_of_rect
	color_rect.rect_size = size_of_rect
	color_rect.color = Color.white
	color_rect.material = m
	parent_node.add_child(color_rect)

func _load_2d_particles(m):
	var p: = Particles2D.new()
	p.process_material = m
	p.emitting = true
	parent_node.add_child(p)
