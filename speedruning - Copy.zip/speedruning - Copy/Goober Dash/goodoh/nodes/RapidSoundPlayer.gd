tool 
extends Node
class_name RapidSoundPlayer

export  var audio_stream: AudioStream
export  var time_between_sounds: = 0.1
export  var pitch: = 1.0
export  var volume_db: = 0.0
export  var audio_bus: = "Master"

var audio_stream_players: = []
var audio_stream_player_index: = 0
var timer: = 0.0
var enqueued_sound: = false
var muted: = false

func _ready():
	timer = time_between_sounds
	var num_streams: = 1.0 + int(ceil(audio_stream.get_length() / pitch / time_between_sounds))
	for i in num_streams:
		var audio_stream_player: = AudioStreamPlayer.new()
		audio_stream_player.stream = audio_stream
		audio_stream_player.pitch_scale = pitch
		audio_stream_player.volume_db = volume_db
		audio_stream_player.bus = audio_bus
		audio_stream_players.append(audio_stream_player)
		add_child(audio_stream_player)

func _process(delta: float) -> void :
	if timer < time_between_sounds:
		timer += delta
	
	if enqueued_sound:
		if play_sound():
			enqueued_sound = false

func play_sound(pitch_scale: = 1.0) -> bool:
	if timer >= time_between_sounds:
		timer = 0.0
		var audio_stream_player: = audio_stream_players[audio_stream_player_index] as AudioStreamPlayer
		
		
		enqueued_sound = false
		if not muted:
			audio_stream_player.pitch_scale = pitch_scale
			audio_stream_player.play()
			audio_stream_player_index = (audio_stream_player_index + 1) %audio_stream_players.size()
		return true
	else:
		
		return false

func mute():
	muted = true

func unmute():
	muted = false
