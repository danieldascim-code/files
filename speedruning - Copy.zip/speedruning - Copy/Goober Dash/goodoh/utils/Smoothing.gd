extends Node
class_name Smoothing




static func smooth_damp(current: float, target: float, velocity: float, smooth_time: float, delta_time = 1.0, max_speed: float = INF) -> Vector2:
	\
\
	"\n\tsmoothly damps between current and target without overshoot. returns (output, new_velocity).\n\t"
	delta_time = max(1e-05, delta_time)
	smooth_time = max(0.0001, smooth_time)
	var omega: float = 2.0 / smooth_time
	
	var x = omega * delta_time
	var expo = 1.0 / (1.0 + x + 0.48 * x * x + 0.235 * x * x * x)
	var change = current - target
	var original_to = target
	
	var max_change = max_speed * smooth_time
	change = clamp(change, - max_change, max_change)
	target = current - change
	
	var temp = (velocity + omega * change) * delta_time
	velocity = (velocity - omega * temp) * expo
	var output = target + (change + temp) * expo
	
	if ((original_to - current > 0.0) == (output > original_to)):
		output = original_to
		velocity = (output - original_to) / delta_time
		
	return Vector2(output, velocity)
	
static func smooth_damp_angle(current: float, target: float, velocity: float, smooth_time: float, delta_time = 1.0, max_speed: float = INF) -> Vector2:
	\
\
	"\n\tsmoothly damps between current and target while always using the shortest angle between. returns (output, new_velocity).\n\t"
	target = current + delta_angle(current, target)
	return smooth_damp(current, target, velocity, smooth_time, delta_time, max_speed)

static func delta_angle(current: float, target: float) -> float:
	var delta = fposmod((target - current), PI * 2.0)
	if (delta > PI):
		delta = delta - PI * 2.0
	return delta

static func wrap_angle(angle: float) -> float:
	return wrapf(angle, - PI, PI)

static func slerp(from: float, to: float, t: float) -> float:
	t = clamp(t, 0.0, 1.0)
	t = - 2.0 * t * t * t + 3.0 * t * t;
	return to * t + from * (1.0 - t);

static func smooth_damp_vec3(current: Vector3, target: Vector3, velocity: Vector3, smooth_time: float, delta_time: float, max_speed: float = INF) -> Array:
	\
	"\n\t"
	var output_x: = 0.0
	var output_y: = 0.0
	var output_z: = 0.0
	smooth_time = max(0.0001, smooth_time)
	var omega: = 2.0 / smooth_time
	var x = omega * delta_time
	var expo = 1.0 / (1.0 + x + 0.48 * x * x + 0.235 * x * x * x)
	
	var change_x = current.x - target.x
	var change_y = current.y - target.y
	var change_z = current.z - target.z
	
	var original_to = target
	var max_change = max_speed * smooth_time
	var max_change_sq = max_change * max_change
	var sqrmag = change_x * change_x + change_y * change_y + change_z * change_z
	
	if sqrmag > max_change_sq:
		var mag = sqrt(sqrmag)
		change_x = change_x / mag * max_change
		change_y = change_y / mag * max_change
		change_z = change_z / mag * max_change
	
	target.x = current.x - change_x
	target.y = current.y - change_y
	target.z = current.z - change_z
	
	var temp_x = (velocity.x + omega * change_x) * delta_time
	var temp_y = (velocity.y + omega * change_y) * delta_time
	var temp_z = (velocity.z + omega * change_z) * delta_time
	
	velocity.x = (velocity.x - omega * temp_x) * expo
	velocity.y = (velocity.y - omega * temp_y) * expo
	velocity.z = (velocity.z - omega * temp_z) * expo
	
	output_x = target.x + (change_x + temp_x) * expo
	output_y = target.y + (change_y + temp_y) * expo
	output_z = target.z + (change_z + temp_z) * expo
	
	var orig_minus_current_x = original_to.x - current.x
	var orig_minus_current_y = original_to.y - current.y
	var orig_minus_current_z = original_to.z - current.z
	var out_minus_origin_x = output_x - original_to.x
	var out_minus_origin_y = output_y - original_to.y
	var out_minus_origin_z = output_z - original_to.z
	
	if orig_minus_current_x * out_minus_origin_x + orig_minus_current_y * out_minus_origin_y + orig_minus_current_z * out_minus_origin_z > 0:
		output_x = original_to.x
		output_y = original_to.y
		output_z = original_to.z
		
		velocity.x = (output_x - original_to.x) / delta_time
		velocity.y = (output_y - original_to.y) / delta_time
		velocity.z = (output_z - original_to.z) / delta_time
		
	return [Vector3(output_x, output_y, output_z), velocity]

static func smooth_damp_vec3_angle(current: Vector3, target: Vector3, velocity: Vector3, smooth_time: float, delta_time: float, max_speed: float = INF) -> Array:
	\
	"\n\t"
	target.x = current.x + delta_angle(current.x, target.x)
	target.y = current.y + delta_angle(current.y, target.y)
	target.z = current.z + delta_angle(current.z, target.z)
	
	return smooth_damp_vec3(current, target, velocity, smooth_time, delta_time, max_speed)
























































static func smooth_damp_vec2(current: Vector2, target: Vector2, currentVelocity: Vector2, smoothTime: float, deltaTime: float, maxSpeed: float = INF) -> Array:
		
		smoothTime = max(0.0001, smoothTime);
		var omega: = 2.0 / smoothTime
		
		var x: = omega * deltaTime
		var expo: = 1.0 / (1.0 + x + 0.48 * x * x + 0.235 * x * x * x)
		
		var change_x: = current.x - target.x
		var change_y: = current.y - target.y
		var originalTo: = target
		
		
		var maxChange: = maxSpeed * smoothTime

		var maxChangeSq: = maxChange * maxChange
		var sqDist: = change_x * change_x + change_y * change_y
		if sqDist > maxChangeSq:
			var mag: = sqrt(sqDist)
			change_x = change_x / mag * maxChange;
			change_y = change_y / mag * maxChange;
		
		target.x = current.x - change_x;
		target.y = current.y - change_y;
		
		var temp_x: = (currentVelocity.x + omega * change_x) * deltaTime
		var temp_y: = (currentVelocity.y + omega * change_y) * deltaTime

		currentVelocity.x = (currentVelocity.x - omega * temp_x) * expo
		currentVelocity.y = (currentVelocity.y - omega * temp_y) * expo

		var output_x: = target.x + (change_x + temp_x) * expo
		var output_y: = target.y + (change_y + temp_y) * expo

		
		var origMinusCurrent_x: = originalTo.x - current.x
		var origMinusCurrent_y: = originalTo.y - current.y
		var outMinusOrig_x: = output_x - originalTo.x
		var outMinusOrig_y: = output_y - originalTo.y

		if origMinusCurrent_x * outMinusOrig_x + origMinusCurrent_y * outMinusOrig_y > 0:
			output_x = originalTo.x;
			output_y = originalTo.y;

			currentVelocity.x = (output_x - originalTo.x) / deltaTime;
			currentVelocity.y = (output_y - originalTo.y) / deltaTime;
		
		return [Vector2(output_x, output_y), currentVelocity]




static func apply_projected_max_speed(acceleration: Vector3, velocity: Vector3, max_speed: float, max_speed_direction: Vector3) -> Vector3:
	var accelerated_velocity = velocity + acceleration
	if acceleration.dot(max_speed_direction) > 0.0:
		var accelerated_velocity_in_max_speed_direction = accelerated_velocity.project(max_speed_direction)
		if accelerated_velocity_in_max_speed_direction.length_squared() > max_speed * max_speed:
			var accel_remainder = acceleration - acceleration.project(max_speed_direction)
			acceleration = accel_remainder + max_speed_direction * max(0, max_speed - velocity.project(max_speed_direction).length())
	return acceleration




static func apply_projected_max_speed2d(acceleration: Vector2, velocity: Vector2, max_speed: float, max_speed_direction: Vector2) -> Vector2:
	var accelerated_velocity = velocity + acceleration
	if acceleration.dot(max_speed_direction) > 0.0:
		var accelerated_velocity_in_max_speed_direction = accelerated_velocity.project(max_speed_direction)
		if accelerated_velocity_in_max_speed_direction.length_squared() > max_speed * max_speed:
			var accel_remainder = acceleration - acceleration.project(max_speed_direction)
			acceleration = accel_remainder + max_speed_direction * max(0, max_speed - velocity.project(max_speed_direction).length())
	return acceleration
