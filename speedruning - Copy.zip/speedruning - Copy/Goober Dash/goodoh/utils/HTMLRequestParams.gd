extends Object
class_name HTMLRequestParams




static func get_request_params() -> Dictionary:
	if not OS.has_feature("HTML5"):
		printerr("[HTMLRequstParams] get_request_params() but not html")
		return {}
	
	print("[HTMLRequestParams] get_request_params() about to call winterpixelGetRequestParams()")
	var all_request_params_string = JavaScript.eval("winterpixelGetRequestParams();")
	print("[HTMLRequestParams] get_request_params() winterpixelGetRequestParams() returned " + all_request_params_string)
	
	if not all_request_params_string is String:
		printerr("[HTMLRequestParams] get_request_params() winterpixelGetRequestParams() unable to parse response \'%s\'" % [all_request_params_string])
		return {}
	if all_request_params_string.empty():
		printerr("[HTMLRequestParams] get_request_params() winterpixelGetRequestParams() returned empty string.")
		return {}
	var all_request_params = parse_json(all_request_params_string)
	if not all_request_params is Dictionary:
		printerr("[HTMLRequestParams] get_request_params() winterpixelGetRequestParams() not a dictionary " + all_request_params)
		return {}
	
	print("[HTMLRequestParams] get_request_params() parsed parameters %s" % [all_request_params])
	return all_request_params



static func clear_request_params(params_to_remove: Array) -> void :
	var params_to_remove_string: = to_json(params_to_remove)
	var function_call_string: = "winterpixelClearRequestParams(" + params_to_remove_string + ");"
	print("[HTMLRequestParams] remove_request_params() about to call " + function_call_string)
	JavaScript.eval(function_call_string)



static func set_request_params(params: Dictionary) -> void :
	var params_string: = to_json(params)
	var function_call_string: = "winterpixelSetRequestParams(" + params_string + ");"
	print("[HTMLRequestParams] set_request_params() about to call " + function_call_string)
	JavaScript.eval(function_call_string)
