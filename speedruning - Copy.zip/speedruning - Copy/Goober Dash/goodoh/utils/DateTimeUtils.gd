extends Reference
class_name DateTimeUtils

const seconds_per_day: = 86400
const seconds_per_hour: = 3600
const seconds_per_minute: = 60

static func seconds_to_datetime(seconds: int) -> Dictionary:
	var days: = seconds / seconds_per_day
	seconds = seconds % seconds_per_day
	
	var hours: = seconds / seconds_per_hour
	seconds = seconds % seconds_per_hour
	
	var minutes: = seconds / seconds_per_minute
	seconds = seconds % seconds_per_minute
	
	return {
		"days": days, 
		"hours": hours, 
		"minutes": minutes, 
		"seconds": seconds
	}

static func format_time(time: int) -> String:
	var time_dict: = seconds_to_datetime(time)
	
	var days: int = time_dict["days"]
	var hours: int = time_dict["hours"]
	var minutes: int = time_dict["minutes"]
	var seconds: int = time_dict["seconds"]
	
	if days > 0:
		return "%dd %dh %dm %ds" % [days, hours, minutes, seconds]
	elif hours > 0:
		return "%dh %dm %ds" % [hours, minutes, seconds]
	elif minutes > 0:
		return "%dm %ds" % [minutes, seconds]
	else:
		return "%ds" % [seconds]

static func format_time_shorter(time: int) -> String:
	var time_dict: = seconds_to_datetime(time)
	var days: int = time_dict["days"]
	var hours: int = time_dict["hours"]
	var minutes: int = time_dict["minutes"]
	var seconds: int = time_dict["seconds"]
	
	if days > 0:
		return "%dd %dh" % [days, hours]
	elif hours > 0:
		return "%dh %dm" % [hours, minutes]
	elif minutes > 0:
		return "%dm %ds" % [minutes, seconds]
	else:
		return "%ds" % [seconds]

static func format_time_past(time: int) -> String:
	var time_dict: = seconds_to_datetime(time)
	var days: int = time_dict["days"]
	var hours: int = time_dict["hours"]
	var minutes: int = time_dict["minutes"]
	var seconds: int = time_dict["seconds"]
	
	if days > 365:
		var years: = int(round(days / 365.0))
		if years == 1:
			return "1 year ago"
		return "%d years ago" % [years]
	elif days > 30:
		var months: = int(round(days / 30.0))
		if months == 1:
			return "1 month ago"
		return "%d months ago" % [months]
	elif days > 0:
		if days == 1:
			return "1 day ago"
		else:
			return "%d days ago" % [days]
	elif hours > 0:
		if hours == 1:
			return "1 hour ago"
		return "%d hours ago" % [hours]
	elif minutes > 0:
		if minutes == 1:
			return "1 minute ago"
		return "%d minutes ago" % [minutes]
	else:
		if seconds == 1:
			return "1 second ago"
		else:
			return "%d seconds ago" % [seconds]
		
static func format_time_clock(time: int) -> String:
	var time_dict: = seconds_to_datetime(time)
	
	var days: int = time_dict["days"]
	var hours: int = time_dict["hours"]
	var minutes: int = time_dict["minutes"]
	var seconds: int = time_dict["seconds"] + 1
	
	if days > 0:
		return "%dd %d:%02d:%02d" % [days, hours, minutes, seconds]
	elif hours > 0:
		return "%d:%02d:%02d" % [hours, minutes, seconds]
	elif minutes > 0:
		return "%d:%02d" % [minutes, seconds]
	else:
		return "%d" % [seconds]


static func number_to_ordinal_string(number: int) -> String:
	var i: int = number
	var j: int = i % 10
	var k: int = i % 100;
	if (j == 1 and k != 11):
		return str(i) + "st"
	
	if (j == 2 and k != 12):
		return str(i) + "nd"
	
	if (j == 3 and k != 13):
		return str(i) + "rd"
	
	return str(i) + "th"

