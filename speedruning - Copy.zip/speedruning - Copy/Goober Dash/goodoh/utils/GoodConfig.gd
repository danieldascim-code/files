extends Node

var config_file: ConfigFile = null
var env: = ""

const section_name: = "main"
const config_dir: = "res://config/"
const file_extension: = ".ini"

func _init() -> void :
	_load_config()

func get_config_value(s: String, default = null):
	if not config_file:
		printerr("[GoodConfig] no config file loaded")
		assert (false)
		return null
	return config_file.get_value(section_name, s, default)

func _load_config():
	
	var ini_file: = OS.get_environment("INI_FILE")
	if OS.has_feature("web"):
		var js_config_name = JavaScript.eval(\
\
		"\n\t\t\tgetconfigFile();\n\t\t") as String
		ini_file = js_config_name
		print("[GoodConfig] web config: " + ini_file)
	if ini_file.empty():
		print("No .ini file in environment")
		
		var f: = File.new()
		if f.file_exists(full_path_for_env("local")):
			ini_file = "local"
		elif f.file_exists(full_path_for_env("dev")):
			ini_file = "dev"
		elif OS.has_feature("editor") and f.file_exists(full_path_for_env("staging")):
			
			ini_file = "staging"
		elif f.file_exists(full_path_for_env("prod")):
			ini_file = "prod"
		elif f.file_exists(full_path_for_env("staging")):
			ini_file = "staging"
		else:
			
			ini_file = get_config_file_path_from_directory(config_dir)
	_parse_config(ini_file)

func _parse_config(ini_file: String):
	env = ini_file
	print("[GoodConfig] _parse_config() %s" % [ini_file])
	var full_path: = full_path_for_env(ini_file)
	
	if File.new().file_exists(full_path):
		config_file = ConfigFile.new()
		config_file.load(full_path)
		if not config_file.has_section(section_name):
			printerr("[GoodConfig] config file %s has no section named %s" % [config_file, section_name])
			assert (false)
	else:
		printerr("[GoodConfig] no config file found")
		assert (false)

func full_path_for_env(e: String) -> String:
	return config_dir + e + file_extension
	
func get_env() -> String:
	return env

func get_config_file_path_from_directory(path: String) -> String:
	var dir: = Directory.new()
	if dir.open(path) == OK:
		dir.list_dir_begin(true)
		var file_name: = dir.get_next()
		while file_name != "":
			if not dir.current_is_dir() and file_name.ends_with(file_extension):
				return file_name.get_basename()
			file_name = dir.get_next()
		
		printerr("[GoodConfig] did not find any config files in path %s" % [path])
		assert (false)
		return ""
	else:
		printerr("[GoodConfig] could not access directory path %s" % [path])
		assert (false)
		return ""
