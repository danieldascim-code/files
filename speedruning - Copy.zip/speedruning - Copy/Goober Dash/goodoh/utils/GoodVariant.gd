extends Reference
class_name GoodVariant

enum Variant_Type{
	_Nil, 
	_bool, 
	_int, 
	_float, 
	_String, 
	_Vector2, 
	_Rect2, 
	_Vector3, 
	_Transform2D, 
	_Plane, 
	_Quat, 
	_AABB, 
	_Basis, 
	_Transform, 
	_Color, 
	_NodePath, 
	_RID, 
	_Object, 
	_Dictionary, 
	_Array, 
	_PoolByteArray, 
	_PoolIntArray, 
	_PoolRealArray, 
	_PoolStringArray, 
	_PoolVector2Array, 
	_PoolVector3Array, 
	_PoolColorArray
}
