extends Node
class_name GoodMath

static func sphere_intersects_box(sphere_center: Vector3, sphere_radius: float, box_center: Vector3, box_extents: Vector3) -> bool:
	var squared_distance: = squared_distance_from_point_to_box(sphere_center, box_center, box_extents)
	return squared_distance <= sphere_radius * sphere_radius
	
static func squared_distance_from_point_to_box(point: Vector3, box_center: Vector3, box_extents: Vector3) -> float:
	var sq: = 0.0
	var min_aabb = box_center - box_extents
	var max_aabb = box_center + box_extents
	sq += squared_distance_point_line(point.x, min_aabb.x, max_aabb.x)
	sq += squared_distance_point_line(point.y, min_aabb.y, max_aabb.y)
	sq += squared_distance_point_line(point.z, min_aabb.z, max_aabb.z)
	
	return sq
	
static func squared_distance_point_line(pn: float, bmin: float, bmax: float) -> float:
	var out: = 0.0
	var v: = pn
	if v < bmin:
		var val = bmin - v
		out += val * val
	if v > bmax:
		var val = v - bmax
		out += val * val
	return out

static func logarithm(base: float, value: float) -> float:
	var b: = log(base)
	if b <= 0:
		return NAN
	return log(value) / b

static func angle_to_angle(from: float, to: float) -> float:
	return fposmod(to - from + PI, PI * 2) - PI

static func perp_dot(a: Vector2, b: Vector2) -> float:
	return a.x * b.y - a.y * b.x

static func randi_range(from: int, to_exclusive: int) -> int:
	return randi() %(to_exclusive - from) + from

static func trs_transform2d(t: Vector2, r: float, s: Vector2) -> Transform2D:
	return Transform2D(
		Vector2(cos(r) * s.x, sin(r) * s.x), 
		Vector2(sin(r) * - s.y, cos(r) * s.y), 
		t
	)

static func trs_transform2d_with_pivot(t: Vector2, r: float, s: Vector2, pivot: Vector2) -> Transform2D:
		var transform: = Transform2D.IDENTITY
		
		
		transform.x *= s.x
		transform.y *= s.y
		
		
		transform.origin += pivot
		transform = transform.rotated(r)
		transform.origin -= pivot
		
		
		transform.origin += t
		return transform

static func trs_transform2d_with_pivot_and_non_pivot_rotation(t: Vector2, r: float, s: Vector2, pivot: Vector2, r2: float) -> Transform2D:
		var transform: = Transform2D.IDENTITY
		
		transform = transform.rotated(r)
	
		
		transform.x *= s.x
		transform.y *= s.y
		
		
		transform.origin -= pivot
		transform = transform.rotated(r2)
		transform.origin += pivot
		
		
		transform.origin += t
		return transform

static func calculate_max_force_to_reach_max_speed(force: Vector2, velocity: Vector2, mass: float, max_speed: float, delta_time: float) -> Vector2:
	var velocity_along_force: = velocity.project(force)
	if velocity_along_force.dot(force) > 0.0:
		
		var max_delta_v: = max_speed - velocity_along_force.length()
		if max_delta_v < 0.0:
			return Vector2.ZERO
		var max_force: = max_delta_v * mass / delta_time
		force = force.limit_length(max_force)
	return force

static func apply_projected_max_speed2d(acceleration: Vector2, velocity: Vector2, max_speed: float, max_speed_direction: Vector2) -> Vector2:
	var accelerated_velocity = velocity + acceleration
	if acceleration.dot(max_speed_direction) > 0.0:
		var accelerated_velocity_in_max_speed_direction = accelerated_velocity.project(max_speed_direction)
		if accelerated_velocity_in_max_speed_direction.length_squared() > max_speed * max_speed:
			var accel_remainder = acceleration - acceleration.project(max_speed_direction)
			acceleration = accel_remainder + max_speed_direction * max(0, max_speed - velocity.project(max_speed_direction).length())
	return acceleration

static func delta_angle(current: float, target: float) -> float:
	var delta = fposmod((target - current), PI * 2.0)
	if (delta > PI):
		delta = delta - PI * 2.0
	return delta

static func wrap_angle(angle: float) -> float:
	return wrapf(angle, - PI, PI)












static func signed_project(a: Vector2, b: Vector2) -> Vector2:
	return b * abs(a.dot(b) / b.length_squared())
