extends Reference
class_name FileUtils

static func load_file(path: String) -> String:
	var f: = File.new()
	var e: = f.open(path, File.READ)
	if e != OK:
		printerr("[FileUtils] load_file() Failed to open file at path %s with error %s" % [path, e])
		return ""
	var s: = f.get_as_text()
	f.close()
	return s
