extends Node
class_name WinterpixelReviewRequester


func request_review():
	if OS.has_feature("Android"):
		AndroidWinterpixelUtils.request_review()
	elif OS.has_feature("iOS"):
		Moonlight.shop.request_review()
