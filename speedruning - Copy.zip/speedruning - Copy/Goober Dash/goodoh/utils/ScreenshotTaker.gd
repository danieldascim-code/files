extends Node

var timer: = 0.0
onready var user_dir: = OS.get_user_data_dir()

var is_enabled: = false

func _ready():
	SavedSettings.connect("on_value_changed", self, "on_saved_setting_changed")
	is_enabled = SavedSettings.get_value("auto_screenshot", false)

func on_saved_setting_changed(k: String, v):
	if k == "auto_screenshot":
		is_enabled = bool(v)

func take_screenshot():
	var time: = OS.get_unix_time()
	var file_path: = "user://%s-screenshot.png" % [time]
	var absolute_path: = ProjectSettings.globalize_path(file_path)
	print("taking screenshot to %s" % [absolute_path])
	
	var image: = get_viewport().get_texture().get_data()
	image.flip_y()
	
	image.save_png(file_path)

func _process(delta):
	if Input.is_action_just_pressed("editor_screenshot"):
		take_screenshot()
	if is_enabled:
		timer += delta
		if timer > 10.0:
			timer = 0.0
			take_screenshot()
