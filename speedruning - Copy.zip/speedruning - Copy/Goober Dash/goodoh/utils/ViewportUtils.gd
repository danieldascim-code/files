extends Reference
class_name ViewportUtils




















static func _window_to_viewport(viewport: Viewport, window_position: Vector2) -> Vector2:
	return viewport.get_final_transform().affine_inverse().xform(window_position)

static func _viewport_to_window(viewport: Viewport, viewport_position: Vector2) -> Vector2:
	return viewport.get_final_transform().xform(viewport_position)

static func _viewport_to_world(viewport: Viewport, viewport_position: Vector2) -> Vector2:
	return viewport.canvas_transform.affine_inverse().xform(viewport_position)

static func _world_to_viewport(viewport: Viewport, world_position: Vector2) -> Vector2:
	return viewport.canvas_transform.xform(world_position)


static func _viewport_visible_rect(viewport: Viewport) -> Rect2:
	return viewport.canvas_transform.affine_inverse().xform(viewport.get_visible_rect())
