extends Reference
class_name DictionaryUtils













static func nested_dictionary_lookup(nested_key: String, dictionary: Dictionary):
	return nested_typed_dictionary_lookup(nested_key, dictionary, - 1)

static func nested_typed_dictionary_lookup(nested_key: String, dictionary: Dictionary, type: int):
	var split_key_array: = nested_key.split(".", false)
	var dictionary_level: = dictionary
	for i in split_key_array.size():
		var split_key: = split_key_array[i] as String
		if not dictionary_level.has(split_key):
			break
		
		var is_last_key: bool = i == split_key_array.size() - 1
		if is_last_key:
			var value = dictionary_level[split_key]
			if type == - 1:
				return value
			var value_type: = typeof(value)
			match type:
				TYPE_INT:
					if value_type == TYPE_INT or value_type == TYPE_REAL:
						return int(value)
				_:
					return value
			
			return null
		
		var split_value = dictionary_level[split_key]
		if not split_value is Dictionary:
			break
		
		dictionary_level = split_value
	
	
	return null
