tool 
extends Control

export  var _run: = false setget set_run
export  var _label_default_size: = 48
onready var label_parent: = $VBoxContainer as Control

const font_sizes: = [16, 32, 48, 64, 80, 100, 128, 150, 180, 200, 256, 320, 384, 448, 512]


func generate_fonts_theme():
	_delete_rows()
	print("generating fonts")
	var template_size: = 256
	var template_type: = "Label_256"
	var template_font: = theme.get_font("font", template_type)
	if theme.is_type_variation(template_type, "Label"):
		template_type = "Label_%d" % template_size
		template_font = theme.get_font("font", template_type) as DynamicFont
	
	var base_shadow_offset_x: = theme.get_constant("shadow_offset_x", template_type)
	var base_shadow_offset_y: = theme.get_constant("shadow_offset_y", template_type)
	var shadow_color: = theme.get_color("font_color_shadow", template_type)
	var outline_modulate: = theme.get_color("font_outline_modulate", template_type)
	var font_color: = theme.get_color("font_color", template_type)
	
	var template_spacing_top: = float(template_font.extra_spacing_top) / float(template_font.size)
	var template_spacing_bottom: = float(template_font.extra_spacing_bottom) / float(template_font.size)
	var template_spacing_char: = float(template_font.extra_spacing_char) / float(template_font.size)
	var template_spacing_space: = float(template_font.extra_spacing_space) / float(template_font.size)
	var template_outline_size: = float(template_font.outline_size) / float(template_font.size)
	var template_font_name: = _get_font_name(template_font)
	var template_shadow_offset_x: = float(base_shadow_offset_x) / float(template_font.size)
	var template_shadow_offset_y: = float(base_shadow_offset_y) / float(template_font.size)
	var template_font_color_shadow: = Color.transparent
	var template_font_color_outline: = Color.transparent
	
	if not font_sizes.has(_label_default_size):
		font_sizes.append(_label_default_size)
	
	for i in font_sizes.size():
		var font_size: = int(font_sizes[i])
		var font_resource: = DynamicFont.new()
		font_resource.size = font_size
		font_resource.font_data = template_font.font_data
		font_resource.extra_spacing_top = round_away_from_zero(template_spacing_top * font_size)
		font_resource.extra_spacing_bottom = round_away_from_zero(template_spacing_bottom * font_size)
		font_resource.extra_spacing_char = round_away_from_zero(template_spacing_char * font_size)
		font_resource.extra_spacing_space = round_away_from_zero(template_spacing_space * font_size)
		font_resource.outline_size = round_away_from_zero(template_outline_size * font_size)
		font_resource.use_mipmaps = template_font.use_mipmaps
		font_resource.use_filter = template_font.use_filter
		font_resource.outline_color = template_font.outline_color
		
		var theme_type: = "Label_%d" % [font_size]
		var is_default_size: = _label_default_size == font_size
		var is_largest_size: = bool(i == font_sizes.size() - 1)
		var shadow_offset_x: = round_away_from_zero(template_shadow_offset_x * font_size)
		var shadow_offset_y: = round_away_from_zero(template_shadow_offset_y * font_size)
		
		
		if is_default_size:
			
			
			_create_theme_type("Label", font_resource, shadow_offset_x, shadow_offset_y, shadow_color, outline_modulate, font_color)
		
		
		_create_theme_type(theme_type, font_resource, shadow_offset_x, shadow_offset_y, shadow_color, outline_modulate, font_color)
		theme.set_type_variation(theme_type, "Label")
		
		
		_create_row(theme_type, theme_type)

func _create_theme_type(theme_type: String, font: DynamicFont, shadow_offset_x: int, shadow_offset_y: int, font_color_shadow: Color, outline_modulate: Color, font_color: Color):
	theme.set_font("font", theme_type, font)
	theme.set_constant("shadow_offset_x", theme_type, shadow_offset_x)
	theme.set_constant("shadow_offset_y", theme_type, shadow_offset_y)
	theme.set_color("font_color_shadow", theme_type, font_color_shadow)
	theme.set_color("font_outline_modulate", theme_type, outline_modulate)
	theme.set_color("font_color", theme_type, font_color)

func _create_row(theme_type: String, label: String) -> Label:
	var l: = Label.new()
	l.name = label
	label_parent.add_child(l)
	l.owner = self
	l.text = label
	l.size_flags_horizontal = 0
	if theme_type != "Label":
		l.theme_type_variation = theme_type
	
	var c: = ColorRect.new()
	l.add_child(c)
	c.color = Color.mediumseagreen
	c.owner = self
	c.show_behind_parent = true
	c.anchor_right = 1.0
	c.anchor_bottom = 1.0
	return l

func _delete_rows():
	var to_delete: = []
	for i in label_parent.get_child_count():
		var c: = label_parent.get_child(i)
		if c is Label:
			if not "Template" in c.name:
				to_delete.append(c)
	for c in to_delete:
		label_parent.remove_child(c)
		c.queue_free()

func _get_font_name(d: DynamicFont) -> String:
	var font_name: = d.font_data.font_path.get_basename().get_file()
	return font_name

func _init():
	if is_inside_tree():
		label_parent = $VBoxContainer as Control

func set_run(b: bool):
	if b:
		generate_fonts_theme()

static func round_away_from_zero(value: float) -> int:
	if value < 0.0:
		return int(floor(value))
	return int(ceil(value))
