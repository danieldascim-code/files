extends Box2DPhysicsBody
class_name PlayerDeathParticleBody








func _ready():
	pass





